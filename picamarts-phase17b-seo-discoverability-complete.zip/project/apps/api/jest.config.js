'use strict';

module.exports = {
  testEnvironment: 'node',
  rootDir: 'src',
  testMatch: ['**/tests/**/*.test.js'],
  verbose: true,
  clearMocks: true,
  testTimeout: 15000,
};
