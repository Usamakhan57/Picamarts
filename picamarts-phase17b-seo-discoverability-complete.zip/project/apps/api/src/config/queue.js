'use strict';

const config = require('./index');
const { getRedisClient } = require('./redis');
const logger = require('../utils/logger');

/**
 * Phase 12, Part 3 — Queue System (BullMQ). One shared factory for
 * every named queue (email/notification/image-processing/background),
 * plus a shared "move exhausted job to the dead-letter queue" helper
 * every worker attaches identically.
 *
 * `createQueue(name)` returns `null` when queues are disabled (no
 * REDIS_URL, or QUEUE_ENABLED=false, or NODE_ENV=test) — every
 * producer (queues/*.queue.js) checks for that and returns `null`
 * itself, letting its caller fall back to a synchronous equivalent
 * (see emails/mailer.js#sendMail) instead of throwing.
 */

const DEFAULT_JOB_OPTIONS = {
  attempts: config.queue.jobAttempts,
  backoff: { type: 'exponential', delay: config.queue.jobBackoffMs },
  // Keep a bounded history instead of every job forever.
  removeOnComplete: { age: 3600, count: 1000 },
  removeOnFail: { age: 7 * 24 * 3600, count: 5000 },
};

const queues = new Map();

/** @returns {import('bullmq').Queue|null} */
const createQueue = (name) => {
  if (!config.queue.enabled) return null;
  if (queues.has(name)) return queues.get(name);

  // Lazy require — keeps `bullmq` out of the require graph entirely
  // for anyone running with queues disabled.
  const { Queue } = require('bullmq');

  const queue = new Queue(name, {
    connection: getRedisClient(),
    defaultJobOptions: DEFAULT_JOB_OPTIONS,
  });
  queues.set(name, queue);
  return queue;
};

/** Dead-letter queue: every worker moves a job here once it has exhausted every retry, instead of losing the payload. */
const DEAD_LETTER_QUEUE_NAME = 'dead-letter';
const getDeadLetterQueue = () => createQueue(DEAD_LETTER_QUEUE_NAME);

/**
 * Attaches the standard `failed` handler to a BullMQ Worker: logs the
 * failure (Part 6 — structured logging) and, once every attempt is
 * exhausted, forwards the job's name/data/error to the dead-letter
 * queue for manual inspection instead of silently dropping it.
 *
 * @param {import('bullmq').Worker} worker
 * @param {string} queueName - the worker's own queue name, recorded on the dead-letter entry
 */
const attachFailureHandling = (worker, queueName) => {
  worker.on('failed', async (job, error) => {
    const attemptsMade = job?.attemptsMade ?? 0;
    const attemptsMax = job?.opts?.attempts ?? 1;
    const exhausted = attemptsMade >= attemptsMax;

    logger.error(
      `[queue:${queueName}] job "${job?.name}" (${job?.id}) failed on attempt ${attemptsMade}/${attemptsMax}: ${error.message}`
    );

    if (!exhausted) return;

    const deadLetter = getDeadLetterQueue();
    if (!deadLetter) return;

    try {
      await deadLetter.add('dead-letter', {
        originalQueue: queueName,
        jobName: job?.name,
        jobData: job?.data,
        error: error.message,
        failedAt: new Date().toISOString(),
      });
      logger.warn(`[queue:${queueName}] job "${job?.name}" (${job?.id}) moved to the dead-letter queue.`);
    } catch (dlqError) {
      logger.error(
        `[queue:${queueName}] failed to move job "${job?.name}" (${job?.id}) to the dead-letter queue: ${dlqError.message}`
      );
    }
  });

  worker.on('error', (error) => {
    logger.error(`[queue:${queueName}] worker error: ${error.message}`);
  });
};

module.exports = { createQueue, getDeadLetterQueue, attachFailureHandling, DEFAULT_JOB_OPTIONS, DEAD_LETTER_QUEUE_NAME };
