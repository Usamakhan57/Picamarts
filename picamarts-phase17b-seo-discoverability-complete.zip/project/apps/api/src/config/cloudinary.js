'use strict';

const cloudinary = require('cloudinary').v2;
const config = require('./index');
const logger = require('../utils/logger');

if (config.cloudinary.cloudName && config.cloudinary.apiKey && config.cloudinary.apiSecret) {
  cloudinary.config({
    cloud_name: config.cloudinary.cloudName,
    api_key: config.cloudinary.apiKey,
    api_secret: config.cloudinary.apiSecret,
    secure: true,
  });
} else {
  logger.warn(
    'Cloudinary credentials are not fully configured — file uploads will fail until CLOUDINARY_* env vars are set.'
  );
}

module.exports = cloudinary;
