'use strict';

const path = require('node:path');
const dotenv = require('dotenv');
const { z } = require('zod');

// Load the .env file from the backend root before anything else reads
// process.env. Safe to call multiple times; dotenv no-ops if already loaded.
dotenv.config({ path: path.resolve(__dirname, '../../.env') });

/**
 * Schema for every environment variable the app relies on.
 * Fails fast (and loudly) on boot if something required is missing or
 * malformed, instead of surfacing a confusing error later at runtime.
 */
const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  PORT: z.coerce.number().int().positive().default(5000),
  API_PREFIX: z.string().default('/api'),
  APP_NAME: z.string().default('PicaMarts'),

  CORS_ORIGINS: z.string().default('http://localhost:3000'),

  MONGODB_URI: z.string().min(1, 'MONGODB_URI is required'),
  MONGODB_URI_TEST: z.string().optional(),

  JWT_ACCESS_SECRET: z.string().min(1, 'JWT_ACCESS_SECRET is required'),
  JWT_ACCESS_EXPIRES_IN: z.string().default('15m'),
  JWT_REFRESH_SECRET: z.string().min(1, 'JWT_REFRESH_SECRET is required'),
  JWT_REFRESH_EXPIRES_IN: z.string().default('30d'),
  REFRESH_TOKEN_COOKIE_NAME: z.string().default('picamarts_rt'),
  BCRYPT_SALT_ROUNDS: z.coerce.number().int().min(4).max(15).default(12),

  EMAIL_VERIFICATION_EXPIRES_IN_HOURS: z.coerce.number().int().positive().default(24),
  PASSWORD_RESET_EXPIRES_IN_MINUTES: z.coerce.number().int().positive().default(30),
  FRONTEND_URL: z.string().default('http://localhost:3000'),

  CLOUDINARY_CLOUD_NAME: z.string().optional().default(''),
  CLOUDINARY_API_KEY: z.string().optional().default(''),
  CLOUDINARY_API_SECRET: z.string().optional().default(''),
  CLOUDINARY_UPLOAD_FOLDER: z.string().default('picamarts'),

  SMTP_HOST: z.string().optional().default(''),
  SMTP_PORT: z.coerce.number().int().optional().default(587),
  SMTP_SECURE: z
    .string()
    .optional()
    .default('false')
    .transform((v) => v === 'true'),
  SMTP_USER: z.string().optional().default(''),
  SMTP_PASS: z.string().optional().default(''),
  // Full "From" header, e.g. "Picamarts Support <support@picamarts.com>"
  EMAIL_FROM: z.string().default('Picamarts Support <support@picamarts.com>'),
  SUPPORT_EMAIL: z.string().email().default('support@picamarts.com'),
  ADMIN_EMAIL: z.string().email().default('admin@picamarts.com'),

  RATE_LIMIT_WINDOW_MS: z.coerce.number().int().positive().default(900000),
  RATE_LIMIT_MAX: z.coerce.number().int().positive().default(300),
  AUTH_RATE_LIMIT_WINDOW_MS: z.coerce.number().int().positive().default(900000),
  AUTH_RATE_LIMIT_MAX: z.coerce.number().int().positive().default(20),

  LOG_LEVEL: z.enum(['error', 'warn', 'info', 'http', 'debug']).default('info'),

  // ---------------------------------------------------------
  // Cart (Phase 7) — tax and shipping are placeholders until a
  // real tax-jurisdiction / shipping-rate system exists.
  // ---------------------------------------------------------
  CART_TAX_RATE_PERCENT: z.coerce.number().nonnegative().default(0),
  CART_SHIPPING_FLAT_FEE: z.coerce.number().nonnegative().default(0),

  // ---------------------------------------------------------
  // Payments (Phase 9) — Stripe only. STRIPE_WEBHOOK_SECRET is not
  // read yet (webhooks land in Step 2 of this phase) but is included
  // now so ops can provision it ahead of time.
  // ---------------------------------------------------------
  STRIPE_SECRET_KEY: z.string().optional().default(''),
  STRIPE_WEBHOOK_SECRET: z.string().optional().default(''),
  STRIPE_CURRENCY: z.string().trim().toLowerCase().default('usd'),

  SWAGGER_ENABLED: z
    .string()
    .optional()
    .default('true')
    .transform((v) => v === 'true'),
  API_URL: z.string().default('http://localhost:5000'),

  // ---------------------------------------------------------
  // Phase 12 — Redis (caching, rate-limit store, BullMQ queues).
  // Optional: every consumer (cache middleware, rate limiter,
  // queues) falls back to an in-process/no-op equivalent when this
  // is empty, so the app boots and passes its test suite with no
  // Redis available at all — same "fail gracefully, never block
  // boot" philosophy as MONGODB_URI_TEST.
  // ---------------------------------------------------------
  REDIS_URL: z.string().optional().default(''),
  CACHE_TTL_SECONDS: z.coerce.number().int().positive().default(60),
  CACHE_KEY_PREFIX: z.string().default('picamarts:cache:'),

  // ---------------------------------------------------------
  // Phase 12 — BullMQ queues (email/notification/image-processing/
  // background jobs). QUEUE_ENABLED lets ops force queues off even
  // when REDIS_URL is set (e.g. to run a single-process debug
  // instance) without unsetting Redis entirely.
  // ---------------------------------------------------------
  QUEUE_ENABLED: z
    .string()
    .optional()
    .default('true')
    .transform((v) => v === 'true'),
  QUEUE_JOB_ATTEMPTS: z.coerce.number().int().positive().default(3),
  QUEUE_JOB_BACKOFF_MS: z.coerce.number().int().positive().default(2000),

  // ---------------------------------------------------------
  // Phase 12 — Brute-force login protection (Redis-backed; a no-op
  // when Redis is unavailable — see middlewares/bruteForce.middleware.js).
  // ---------------------------------------------------------
  LOGIN_BRUTE_FORCE_MAX_ATTEMPTS: z.coerce.number().int().positive().default(10),
  LOGIN_BRUTE_FORCE_WINDOW_MINUTES: z.coerce.number().int().positive().default(15),

  // ---------------------------------------------------------
  // Phase 12 — Production process management (PM2 ecosystem.config.js
  // reads these directly via process.env, not through config/index.js).
  // ---------------------------------------------------------
  PM2_INSTANCES: z.string().default('max'),
  MAX_MEMORY_RESTART: z.string().default('512M'),
});

const parsed = envSchema.safeParse(process.env);

if (!parsed.success) {
  // Intentionally use console here — the logger depends on config, so it
  // isn't safe to assume it exists yet at this point in the boot sequence.
  // Fails fast and loudly (Phase 12, Part 8): a clear, actionable message
  // and a clean exit(1) — never an unhandled exception / stack trace dump,
  // and never a partially-booted server left listening with bad config.
  // eslint-disable-next-line no-console
  console.error('❌ Invalid environment configuration — the application will not start.');
  // eslint-disable-next-line no-console
  console.error('   The following environment variables are missing or invalid:');
  Object.entries(parsed.error.flatten().fieldErrors).forEach(([key, messages]) => {
    // eslint-disable-next-line no-console
    console.error(`   • ${key}: ${(messages || []).join('; ')}`);
  });
  // eslint-disable-next-line no-console
  console.error('   See apps/api/.env.example and docs/ENVIRONMENT.md for every supported variable.');
  process.exit(1);
}

module.exports = parsed.data;
