'use strict';

const Stripe = require('stripe');
const config = require('./index');

/**
 * Single Stripe client instance for the whole app. Kept in its own
 * file (rather than constructed inline in payment.service.js) purely
 * so tests can `jest.mock('../../config/stripe')` and stub out the
 * few methods they need, the same way other provider SDKs
 * (cloudinary, nodemailer) are wrapped here.
 *
 * In test/development without a real key configured, `config.stripe.secretKey`
 * defaults to an empty string — the client still constructs fine;
 * it simply isn't called in that environment because payment.service.js
 * is always exercised against a mocked client in tests.
 */
const stripeClient = new Stripe(config.stripe.secretKey || 'sk_test_placeholder', {
  apiVersion: '2024-06-20',
});

module.exports = stripeClient;
