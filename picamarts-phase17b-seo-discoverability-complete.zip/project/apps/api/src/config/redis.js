'use strict';

const config = require('./index');
const logger = require('../utils/logger');

/**
 * Phase 12, Part 2 — Redis. A single shared ioredis connection reused
 * by the cache middleware, the Redis-backed rate-limit store, the
 * brute-force guard, and every BullMQ queue/worker (BullMQ requires
 * `maxRetriesPerRequest: null` on the connection it's handed — see
 * https://docs.bullmq.io/guide/going-to-production).
 *
 * Mirrors this project's established "degrade, never crash" pattern
 * for optional infrastructure (compare notification.service.js's
 * `mongoose.connection.readyState !== 1` guard): every consumer reads
 * `isRedisReady()` first and falls back to its own no-Redis behavior
 * instead of assuming a connection exists. `config.redis.enabled` is
 * already `false` for the whole test run (see config/index.js) and
 * whenever `REDIS_URL` is unset, so this module never opens a real
 * socket in the test suite.
 */

let client = null;
let ready = false;

const getRedisClient = () => {
  if (!config.redis.enabled) return null;
  if (client) return client;

  // Lazy require — keeps `ioredis` out of the require graph entirely
  // for anyone running without Redis configured.
  const Redis = require('ioredis');

  client = new Redis(config.redis.url, {
    // BullMQ's own requirement; also sensible for cache/rate-limit use —
    // a command should fail fast and let the caller fall back rather
    // than queue up indefinitely against a dead connection.
    maxRetriesPerRequest: null,
    enableReadyCheck: true,
    lazyConnect: true,
    retryStrategy: (times) => Math.min(times * 200, 5000),
  });

  client.on('ready', () => {
    ready = true;
    logger.info('Redis connected.');
  });
  client.on('error', (error) => {
    ready = false;
    logger.warn(`Redis error: ${error.message}`);
  });
  client.on('close', () => {
    ready = false;
  });

  client.connect().catch((error) => {
    logger.warn(`Redis connection failed: ${error.message}`);
  });

  return client;
};

const isRedisReady = () => ready;

/** Closes the shared connection — used by server.js's graceful shutdown and by test teardown. */
const disconnectRedis = async () => {
  if (!client) return;
  await client.quit().catch(() => client.disconnect());
  client = null;
  ready = false;
};

module.exports = { getRedisClient, isRedisReady, disconnectRedis };
