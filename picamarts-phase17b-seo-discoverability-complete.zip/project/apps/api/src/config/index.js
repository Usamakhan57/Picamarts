'use strict';

const env = require('./env');

/**
 * Single source of truth for configuration, grouped by concern.
 * Import this instead of reading `process.env` directly anywhere else
 * in the codebase — that keeps every config value validated and typed.
 */
const config = {
  env: env.NODE_ENV,
  isProduction: env.NODE_ENV === 'production',
  isDevelopment: env.NODE_ENV === 'development',
  isTest: env.NODE_ENV === 'test',

  appName: env.APP_NAME,
  port: env.PORT,
  apiPrefix: env.API_PREFIX,
  apiUrl: env.API_URL,

  corsOrigins: env.CORS_ORIGINS.split(',').map((origin) => origin.trim()).filter(Boolean),

  db: {
    uri: env.NODE_ENV === 'test' && env.MONGODB_URI_TEST ? env.MONGODB_URI_TEST : env.MONGODB_URI,
  },

  jwt: {
    accessSecret: env.JWT_ACCESS_SECRET,
    accessExpiresIn: env.JWT_ACCESS_EXPIRES_IN,
    refreshSecret: env.JWT_REFRESH_SECRET,
    refreshExpiresIn: env.JWT_REFRESH_EXPIRES_IN,
    refreshCookieName: env.REFRESH_TOKEN_COOKIE_NAME,
  },

  auth: {
    emailVerificationExpiresInHours: env.EMAIL_VERIFICATION_EXPIRES_IN_HOURS,
    passwordResetExpiresInMinutes: env.PASSWORD_RESET_EXPIRES_IN_MINUTES,
  },

  frontendUrl: env.FRONTEND_URL,

  bcrypt: {
    saltRounds: env.BCRYPT_SALT_ROUNDS,
  },

  cloudinary: {
    cloudName: env.CLOUDINARY_CLOUD_NAME,
    apiKey: env.CLOUDINARY_API_KEY,
    apiSecret: env.CLOUDINARY_API_SECRET,
    uploadFolder: env.CLOUDINARY_UPLOAD_FOLDER,
  },

  mail: {
    host: env.SMTP_HOST,
    port: env.SMTP_PORT,
    secure: env.SMTP_SECURE,
    user: env.SMTP_USER,
    pass: env.SMTP_PASS,
    // Full RFC-5322 "From" header: "Picamarts Support <support@picamarts.com>"
    from: env.EMAIL_FROM,
    supportEmail: env.SUPPORT_EMAIL,
    adminEmail: env.ADMIN_EMAIL,
  },

  rateLimit: {
    windowMs: env.RATE_LIMIT_WINDOW_MS,
    max: env.RATE_LIMIT_MAX,
    authWindowMs: env.AUTH_RATE_LIMIT_WINDOW_MS,
    authMax: env.AUTH_RATE_LIMIT_MAX,
  },

  log: {
    level: env.LOG_LEVEL,
  },

  /** Phase 7 — Cart. Both placeholders until a real tax-jurisdiction / shipping-rate system exists. */
  cart: {
    taxRatePercent: env.CART_TAX_RATE_PERCENT,
    shippingFlatFee: env.CART_SHIPPING_FLAT_FEE,
  },

  /** Phase 9 — Payments (Stripe only). webhookSecret is provisioned now but unused until Step 2 (webhooks). */
  stripe: {
    secretKey: env.STRIPE_SECRET_KEY,
    webhookSecret: env.STRIPE_WEBHOOK_SECRET,
    currency: env.STRIPE_CURRENCY,
  },

  swagger: {
    enabled: env.SWAGGER_ENABLED,
  },

  /** Phase 12 — Redis (caching + rate-limit store + BullMQ connection). Empty url = disabled everywhere that reads this. */
  redis: {
    url: env.REDIS_URL,
    enabled: Boolean(env.REDIS_URL) && env.NODE_ENV !== 'test',
    cacheTtlSeconds: env.CACHE_TTL_SECONDS,
    cacheKeyPrefix: env.CACHE_KEY_PREFIX,
  },

  /** Phase 12 — BullMQ queues (email/notification/image-processing/background jobs). */
  queue: {
    enabled: env.QUEUE_ENABLED && Boolean(env.REDIS_URL) && env.NODE_ENV !== 'test',
    jobAttempts: env.QUEUE_JOB_ATTEMPTS,
    jobBackoffMs: env.QUEUE_JOB_BACKOFF_MS,
  },

  /** Phase 12 — Redis-backed login brute-force protection (middlewares/bruteForce.middleware.js). */
  bruteForce: {
    maxAttempts: env.LOGIN_BRUTE_FORCE_MAX_ATTEMPTS,
    windowMinutes: env.LOGIN_BRUTE_FORCE_WINDOW_MINUTES,
  },
};

module.exports = config;
