'use strict';

const config = require('./index');
const logger = require('../utils/logger');

/**
 * Reflects the incoming Origin only if it's in the configured allow-list.
 * Allows non-browser / same-origin requests (no Origin header, e.g. curl,
 * server-to-server, health checks) through unconditionally.
 */
const corsOptions = {
  origin(origin, callback) {
    if (!origin || config.corsOrigins.includes(origin)) {
      callback(null, true);
      return;
    }

    logger.security(`CORS blocked request from disallowed origin: ${origin}`);
    callback(new Error('Not allowed by CORS'));
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  exposedHeaders: ['Content-Disposition'],
  maxAge: 86400,
};

module.exports = corsOptions;
