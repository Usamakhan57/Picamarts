'use strict';

const License = require('../models/License');

const create = (data) => License.create(data);

const findById = (id) => License.findById(id).exec();

const existsByName = (name) => License.exists({ name: name.trim() });

const findByIds = (ids = []) => License.find({ _id: { $in: ids } }).exec();

const list = (filter = {}, options = {}) => License.paginate(filter, options);

const updateById = (id, update) => License.findByIdAndUpdate(id, update, { new: true, runValidators: true }).exec();

const deleteById = (id) => License.findByIdAndDelete(id).exec();

module.exports = { create, findById, existsByName, findByIds, list, updateById, deleteById };
