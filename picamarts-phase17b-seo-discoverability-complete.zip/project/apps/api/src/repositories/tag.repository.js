'use strict';

const Tag = require('../models/Tag');

const create = (data) => Tag.create(data);

const findById = (id) => Tag.findById(id).exec();

const findBySlug = (slug) => Tag.findOne({ slug: slug.toLowerCase().trim() }).exec();

const existsByName = (name) => Tag.exists({ name: name.trim() });

const findByIds = (ids = []) => Tag.find({ _id: { $in: ids } }).exec();

const list = (filter = {}, options = {}) => Tag.paginate(filter, options);

const updateById = (id, update) => Tag.findByIdAndUpdate(id, update, { new: true, runValidators: true }).exec();

const deleteById = (id) => Tag.findByIdAndDelete(id).exec();

module.exports = { create, findById, findBySlug, existsByName, findByIds, list, updateById, deleteById };
