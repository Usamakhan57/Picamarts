'use strict';

const mongoose = require('mongoose');
const Order = require('../models/Order');
const Payment = require('../models/Payment');
const Product = require('../models/Product');
const Review = require('../models/Review');
const Seller = require('../models/Seller');
const User = require('../models/User');
const Wishlist = require('../models/Wishlist');
const SearchHistory = require('../models/SearchHistory');
const { ORDER_STATUSES, PAYMENT_STATUSES: ORDER_PAYMENT_STATUSES } = require('../constants/orderEnums');
const { PAYMENT_STATUSES } = require('../constants/paymentEnums');
const { PRODUCT_STATUSES } = require('../constants/productEnums');
const { SELLER_STATUSES } = require('../constants/sellerStatus');
const { ROLES } = require('../constants/roles');
const { ACTIVE_REVIEW_STATUSES } = require('../constants/reviewEnums');
const { startOfToday, startOfWeek, startOfMonth, startOfYear, bucketExpr, bucketLabel } = require('../utils/dateBuckets');

/**
 * Data-access only — Phase 11 (Analytics & Admin Reports). Every
 * function here is read-only and queries Order/Payment/Product/
 * Review/Seller/User directly, the same cross-module convention every
 * later phase has used since Phase 8 (see order.repository.js querying
 * Product, payment.repository.js querying Order): analytics is
 * entirely additive and never edits those modules' own repository/
 * service/controller/validator files.
 *
 * Authorization scoping (admin vs seller-own-store) is applied by the
 * caller (analytics.service.js) via the `match` object every function
 * accepts — this file has no notion of "who is asking".
 */

const toObjectId = (id) => (id ? new mongoose.Types.ObjectId(id) : id);

// --------------------------------------------------------------------
// Part 1 — Admin Dashboard
// --------------------------------------------------------------------

/** Revenue is recognized on orders whose payment has actually settled. */
const PAID_ORDER_MATCH = { paymentStatus: ORDER_PAYMENT_STATUSES.PAID };

/**
 * Sums `grandTotal` for paid orders matching `baseMatch`, further split
 * into total/today/week/month/year in a single aggregation via
 * `$facet` — one round trip instead of five.
 */
const getRevenueSummary = async (baseMatch = {}) => {
  const match = { ...baseMatch, ...PAID_ORDER_MATCH };
  const sumStage = (extra) => [{ $match: { ...match, ...extra } }, { $group: { _id: null, total: { $sum: '$grandTotal' } } }];

  const [result] = await Order.aggregate([
    {
      $facet: {
        total: sumStage({}),
        today: sumStage({ createdAt: { $gte: startOfToday() } }),
        week: sumStage({ createdAt: { $gte: startOfWeek() } }),
        month: sumStage({ createdAt: { $gte: startOfMonth() } }),
        year: sumStage({ createdAt: { $gte: startOfYear() } }),
      },
    },
  ]).exec();

  const pick = (arr) => arr?.[0]?.total ?? 0;
  return {
    total: pick(result.total),
    today: pick(result.today),
    week: pick(result.week),
    month: pick(result.month),
    year: pick(result.year),
  };
};

/** Order counts by every ORDER_STATUSES value, plus a grand total — all in one aggregation. */
const getOrderCounts = async (baseMatch = {}) => {
  const rows = await Order.aggregate([
    { $match: baseMatch },
    { $group: { _id: '$status', count: { $sum: 1 } } },
  ]).exec();

  const byStatus = Object.fromEntries(Object.values(ORDER_STATUSES).map((s) => [s, 0]));
  let total = 0;
  rows.forEach((r) => {
    if (r._id in byStatus) byStatus[r._id] = r.count;
    total += r.count;
  });

  return { total, ...byStatus };
};

/** Platform-wide buyer counts (admin only — never seller-scoped). */
const getCustomerCounts = async () => {
  const [result] = await User.aggregate([
    { $match: { role: ROLES.BUYER } },
    {
      $facet: {
        total: [{ $count: 'n' }],
        active: [{ $match: { isActive: true } }, { $count: 'n' }],
        newThisMonth: [{ $match: { createdAt: { $gte: startOfMonth() } } }, { $count: 'n' }],
      },
    },
  ]).exec();

  const pick = (arr) => arr?.[0]?.n ?? 0;
  return { total: pick(result.total), active: pick(result.active), new: pick(result.newThisMonth) };
};

/** Platform-wide seller counts by verification status (admin only). */
const getSellerCounts = async () => {
  const [result] = await Seller.aggregate([
    {
      $facet: {
        total: [{ $count: 'n' }],
        active: [{ $match: { status: SELLER_STATUSES.APPROVED } }, { $count: 'n' }],
        pending: [{ $match: { status: SELLER_STATUSES.PENDING } }, { $count: 'n' }],
      },
    },
  ]).exec();

  const pick = (arr) => arr?.[0]?.n ?? 0;
  return { total: pick(result.total), active: pick(result.active), pending: pick(result.pending) };
};

/** Product counts by status, plus an out-of-stock count — `productMatch` scopes to one seller for seller-facing dashboards. */
const getProductCounts = async (productMatch = {}) => {
  const [result] = await Product.aggregate([
    { $match: productMatch },
    {
      $facet: {
        total: [{ $count: 'n' }],
        active: [{ $match: { status: PRODUCT_STATUSES.PUBLISHED } }, { $count: 'n' }],
        draft: [{ $match: { status: PRODUCT_STATUSES.DRAFT } }, { $count: 'n' }],
        outOfStock: [
          { $match: { status: { $ne: PRODUCT_STATUSES.DELETED }, stock: { $lte: 0 }, allowBackorder: false } },
          { $count: 'n' },
        ],
      },
    },
  ]).exec();

  const pick = (arr) => arr?.[0]?.n ?? 0;
  return {
    total: pick(result.total),
    active: pick(result.active),
    draft: pick(result.draft),
    outOfStock: pick(result.outOfStock),
  };
};

// --------------------------------------------------------------------
// Part 2 — Sales Analytics (chart-ready time series)
// --------------------------------------------------------------------

/** Bucketed sales (paid-order revenue + order count) per `period`, chart-ready (sorted ascending by bucket). */
const getSalesSeries = async (baseMatch, period) => {
  const rows = await Order.aggregate([
    { $match: { ...baseMatch, ...PAID_ORDER_MATCH } },
    {
      $group: {
        _id: bucketExpr(period, '$createdAt'),
        revenue: { $sum: '$grandTotal' },
        orders: { $sum: 1 },
      },
    },
    { $sort: { _id: 1 } },
  ]).exec();

  return rows.map((r) => ({ label: bucketLabel(r._id), revenue: r.revenue, orders: r.orders }));
};

// --------------------------------------------------------------------
// Part 3 — Order Analytics
// --------------------------------------------------------------------

const getOrdersByStatus = (baseMatch) => getOrderCounts(baseMatch);

const getOrdersByDate = (baseMatch, period) =>
  Order.aggregate([
    { $match: baseMatch },
    { $group: { _id: bucketExpr(period, '$createdAt'), count: { $sum: 1 } } },
    { $sort: { _id: 1 } },
  ])
    .exec()
    .then((rows) => rows.map((r) => ({ label: bucketLabel(r._id), count: r.count })));

/** Average grandTotal across paid orders, plus cancellation/refund rates against every order in scope. */
const getOrderStats = async (baseMatch = {}) => {
  const [result] = await Order.aggregate([
    { $match: baseMatch },
    {
      $facet: {
        totals: [{ $count: 'n' }],
        avgPaidValue: [{ $match: PAID_ORDER_MATCH }, { $group: { _id: null, avg: { $avg: '$grandTotal' } } }],
        cancelled: [{ $match: { status: ORDER_STATUSES.CANCELLED } }, { $count: 'n' }],
        refunded: [{ $match: { status: ORDER_STATUSES.REFUNDED } }, { $count: 'n' }],
      },
    },
  ]).exec();

  const totalOrders = result.totals?.[0]?.n ?? 0;
  const cancelledOrders = result.cancelled?.[0]?.n ?? 0;
  const refundedOrders = result.refunded?.[0]?.n ?? 0;

  return {
    averageOrderValue: Math.round((result.avgPaidValue?.[0]?.avg ?? 0) * 100) / 100,
    cancelledOrders,
    refundedOrders,
    refundRate: totalOrders > 0 ? Math.round((refundedOrders / totalOrders) * 1000) / 10 : 0,
  };
};

// --------------------------------------------------------------------
// Part 4 — Revenue Analytics
// --------------------------------------------------------------------

const getRevenueTrend = (baseMatch, period) => getSalesSeries(baseMatch, period);

/** Revenue attributed via each paid order's line items, grouped by the product's category. */
const getRevenueByCategory = (baseMatch) =>
  Order.aggregate([
    { $match: { ...baseMatch, ...PAID_ORDER_MATCH } },
    { $unwind: '$items' },
    ...(baseMatch['items.seller'] ? [{ $match: { 'items.seller': baseMatch['items.seller'] } }] : []),
    { $lookup: { from: 'products', localField: 'items.product', foreignField: '_id', as: 'productDoc' } },
    { $unwind: { path: '$productDoc', preserveNullAndEmptyArrays: true } },
    {
      $group: {
        _id: '$productDoc.category',
        revenue: { $sum: '$items.lineTotal' },
        unitsSold: { $sum: '$items.quantity' },
      },
    },
    { $lookup: { from: 'categories', localField: '_id', foreignField: '_id', as: 'categoryDoc' } },
    { $unwind: { path: '$categoryDoc', preserveNullAndEmptyArrays: true } },
    { $project: { _id: 0, categoryId: '$_id', category: { $ifNull: ['$categoryDoc.name', 'Uncategorized'] }, revenue: 1, unitsSold: 1 } },
    { $sort: { revenue: -1 } },
  ]).exec();

const getRevenueBySeller = (baseMatch) =>
  Order.aggregate([
    { $match: { ...baseMatch, ...PAID_ORDER_MATCH } },
    { $unwind: '$items' },
    ...(baseMatch['items.seller'] ? [{ $match: { 'items.seller': baseMatch['items.seller'] } }] : []),
    { $group: { _id: '$items.seller', revenue: { $sum: '$items.lineTotal' }, unitsSold: { $sum: '$items.quantity' } } },
    { $lookup: { from: 'users', localField: '_id', foreignField: '_id', as: 'sellerDoc' } },
    { $unwind: { path: '$sellerDoc', preserveNullAndEmptyArrays: true } },
    { $project: { _id: 0, sellerId: '$_id', sellerName: '$sellerDoc.name', revenue: 1, unitsSold: 1 } },
    { $sort: { revenue: -1 } },
  ]).exec();

const getRevenueByProduct = (baseMatch) =>
  Order.aggregate([
    { $match: { ...baseMatch, ...PAID_ORDER_MATCH } },
    { $unwind: '$items' },
    ...(baseMatch['items.seller'] ? [{ $match: { 'items.seller': baseMatch['items.seller'] } }] : []),
    {
      $group: {
        _id: '$items.product',
        title: { $first: '$items.titleSnapshot' },
        revenue: { $sum: '$items.lineTotal' },
        unitsSold: { $sum: '$items.quantity' },
      },
    },
    { $project: { _id: 0, productId: '$_id', title: 1, revenue: 1, unitsSold: 1 } },
    { $sort: { revenue: -1 } },
  ]).exec();

/** Revenue by payment method, from the Payment collection (only settled payments count). */
const getRevenueByPaymentMethod = (paymentMatch) =>
  Payment.aggregate([
    { $match: { ...paymentMatch, status: PAYMENT_STATUSES.SUCCEEDED } },
    { $group: { _id: '$paymentMethod', revenue: { $sum: '$amount' }, count: { $sum: 1 } } },
    { $project: { _id: 0, paymentMethod: '$_id', revenue: 1, count: 1 } },
    { $sort: { revenue: -1 } },
  ]).exec();

// --------------------------------------------------------------------
// Part 5 — Product Analytics
// --------------------------------------------------------------------

const withLimit = (pipeline, limit) => (limit ? [...pipeline, { $limit: limit }] : pipeline);

const getBestSellingProducts = (productMatch, limit = 20) =>
  Product.aggregate(
    withLimit(
      [
        { $match: { ...productMatch, status: { $ne: PRODUCT_STATUSES.DELETED } } },
        { $sort: { salesCount: -1 } },
        { $project: { _id: 0, productId: '$_id', title: 1, salesCount: 1, stock: 1 } },
      ],
      limit
    )
  ).exec();

const getMostViewedProducts = (productMatch, limit = 20) =>
  Product.aggregate(
    withLimit(
      [
        { $match: { ...productMatch, status: { $ne: PRODUCT_STATUSES.DELETED } } },
        { $sort: { views: -1 } },
        { $project: { _id: 0, productId: '$_id', title: 1, views: 1 } },
      ],
      limit
    )
  ).exec();

const getHighestRatedProducts = (productMatch, limit = 20) =>
  Product.aggregate(
    withLimit(
      [
        { $match: { ...productMatch, status: { $ne: PRODUCT_STATUSES.DELETED }, ratingCount: { $gt: 0 } } },
        { $sort: { ratingAverage: -1, ratingCount: -1 } },
        { $project: { _id: 0, productId: '$_id', title: 1, ratingAverage: 1, ratingCount: 1 } },
      ],
      limit
    )
  ).exec();

const getLowStockProducts = (productMatch, limit = 50) =>
  Product.aggregate(
    withLimit(
      [
        {
          $match: {
            ...productMatch,
            status: PRODUCT_STATUSES.PUBLISHED,
            allowBackorder: false,
            $expr: { $and: [{ $gt: ['$stock', 0] }, { $lte: ['$stock', '$lowStockThreshold'] }] },
          },
        },
        { $sort: { stock: 1 } },
        { $project: { _id: 0, productId: '$_id', title: 1, stock: 1, lowStockThreshold: 1 } },
      ],
      limit
    )
  ).exec();

const getOutOfStockProducts = (productMatch, limit = 50) =>
  Product.aggregate(
    withLimit(
      [
        { $match: { ...productMatch, status: { $ne: PRODUCT_STATUSES.DELETED }, stock: { $lte: 0 }, allowBackorder: false } },
        { $sort: { updatedAt: -1 } },
        { $project: { _id: 0, productId: '$_id', title: 1, stock: 1 } },
      ],
      limit
    )
  ).exec();

// --------------------------------------------------------------------
// Part 6 — Seller Analytics (admin only)
// --------------------------------------------------------------------

/**
 * Per-seller revenue/orders/units, joined with product count and
 * average rating. `sellerId` narrows to a single seller (seller's own
 * scoped dashboard reuses this); omitted, it ranks every seller.
 */
const getSellerPerformance = async (sellerId, limit = 20) => {
  const orderMatch = sellerId ? { 'items.seller': toObjectId(sellerId) } : {};

  const revenueRows = await Order.aggregate([
    { $match: PAID_ORDER_MATCH },
    { $unwind: '$items' },
    ...(sellerId ? [{ $match: orderMatch }] : []),
    {
      $group: {
        _id: '$items.seller',
        revenue: { $sum: '$items.lineTotal' },
        unitsSold: { $sum: '$items.quantity' },
        orderIds: { $addToSet: '$_id' },
      },
    },
    { $project: { _id: 1, revenue: 1, unitsSold: 1, orderCount: { $size: '$orderIds' } } },
  ]).exec();

  const revenueBySeller = new Map(revenueRows.map((r) => [r._id.toString(), r]));

  const sellerFilter = sellerId ? { user: toObjectId(sellerId) } : {};
  const sellers = await Seller.find(sellerFilter).select('user storeName status').lean().exec();

  const productCounts = await Product.aggregate([
    { $match: { status: { $ne: PRODUCT_STATUSES.DELETED }, ...(sellerId ? { seller: toObjectId(sellerId) } : {}) } },
    { $group: { _id: '$seller', count: { $sum: 1 }, avgRating: { $avg: '$ratingAverage' } } },
  ]).exec();
  const productsBySeller = new Map(productCounts.map((r) => [r._id.toString(), r]));

  const rows = sellers.map((s) => {
    const key = s.user.toString();
    const rev = revenueBySeller.get(key);
    const prod = productsBySeller.get(key);
    return {
      sellerId: key,
      storeName: s.storeName,
      status: s.status,
      revenue: rev?.revenue ?? 0,
      orderCount: rev?.orderCount ?? 0,
      unitsSold: rev?.unitsSold ?? 0,
      productCount: prod?.count ?? 0,
      averageRating: prod ? Math.round((prod.avgRating || 0) * 10) / 10 : 0,
    };
  });

  rows.sort((a, b) => b.revenue - a.revenue);
  return limit ? rows.slice(0, limit) : rows;
};

/** New-seller-approvals-per-month, for a seller growth chart. */
const getSellerGrowth = (period = 'monthly') =>
  Seller.aggregate([
    { $match: { status: SELLER_STATUSES.APPROVED, reviewedAt: { $ne: null } } },
    { $group: { _id: bucketExpr(period, '$reviewedAt'), count: { $sum: 1 } } },
    { $sort: { _id: 1 } },
  ])
    .exec()
    .then((rows) => rows.map((r) => ({ label: bucketLabel(r._id), count: r.count })));

// --------------------------------------------------------------------
// Part 7 — Customer Analytics (admin only)
// --------------------------------------------------------------------

const getNewCustomersSeries = (period = 'monthly') =>
  User.aggregate([
    { $match: { role: ROLES.BUYER } },
    { $group: { _id: bucketExpr(period, '$createdAt'), count: { $sum: 1 } } },
    { $sort: { _id: 1 } },
  ])
    .exec()
    .then((rows) => rows.map((r) => ({ label: bucketLabel(r._id), count: r.count })));

/** Buyers with 2+ paid orders vs exactly 1, for a returning-vs-one-time split. */
const getReturningCustomerStats = async () => {
  const rows = await Order.aggregate([
    { $match: PAID_ORDER_MATCH },
    { $group: { _id: '$buyer', orderCount: { $sum: 1 } } },
    { $group: { _id: null, returning: { $sum: { $cond: [{ $gte: ['$orderCount', 2] }, 1, 0] } }, oneTime: { $sum: { $cond: [{ $eq: ['$orderCount', 1] }, 1, 0] } } } },
  ]).exec();

  return { returning: rows[0]?.returning ?? 0, oneTime: rows[0]?.oneTime ?? 0 };
};

/** Lifetime value + order/purchase-frequency per buyer, sorted by spend, for a top-buyers report. */
const getTopBuyers = (limit = 20) =>
  Order.aggregate([
    { $match: PAID_ORDER_MATCH },
    {
      $group: {
        _id: '$buyer',
        lifetimeValue: { $sum: '$grandTotal' },
        orderCount: { $sum: 1 },
        firstOrderAt: { $min: '$createdAt' },
        lastOrderAt: { $max: '$createdAt' },
      },
    },
    { $sort: { lifetimeValue: -1 } },
    { $limit: limit },
    { $lookup: { from: 'users', localField: '_id', foreignField: '_id', as: 'buyerDoc' } },
    { $unwind: { path: '$buyerDoc', preserveNullAndEmptyArrays: true } },
    {
      $project: {
        _id: 0,
        buyerId: '$_id',
        name: '$buyerDoc.name',
        email: '$buyerDoc.email',
        lifetimeValue: 1,
        orderCount: 1,
        firstOrderAt: 1,
        lastOrderAt: 1,
      },
    },
  ]).exec();

// --------------------------------------------------------------------
// Part 8 — Payment Analytics (admin only)
// --------------------------------------------------------------------

const getPaymentStats = async (paymentMatch = {}) => {
  const [result] = await Payment.aggregate([
    { $match: paymentMatch },
    {
      $facet: {
        successful: [{ $match: { status: PAYMENT_STATUSES.SUCCEEDED } }, { $count: 'n' }],
        failed: [{ $match: { status: PAYMENT_STATUSES.FAILED } }, { $count: 'n' }],
        pending: [{ $match: { status: { $in: [PAYMENT_STATUSES.PENDING, PAYMENT_STATUSES.PROCESSING] } } }, { $count: 'n' }],
        refunds: [
          { $match: { refundAmount: { $gt: 0 } } },
          { $group: { _id: null, count: { $sum: 1 }, amount: { $sum: '$refundAmount' } } },
        ],
        stripeRevenue: [
          { $match: { provider: 'stripe', status: PAYMENT_STATUSES.SUCCEEDED } },
          { $group: { _id: null, amount: { $sum: '$amount' } } },
        ],
      },
    },
  ]).exec();

  const pickCount = (arr) => arr?.[0]?.n ?? 0;
  return {
    successfulPayments: pickCount(result.successful),
    failedPayments: pickCount(result.failed),
    pendingPayments: pickCount(result.pending),
    refundCount: result.refunds?.[0]?.count ?? 0,
    refundAmount: result.refunds?.[0]?.amount ?? 0,
    stripeRevenue: result.stripeRevenue?.[0]?.amount ?? 0,
  };
};

// --------------------------------------------------------------------
// Part 9 — Review Analytics
// --------------------------------------------------------------------

/**
 * @param {object} reviewMatch - date-range/etc. filters on the Review collection itself
 * @param {string|null} sellerId - when set, scopes every facet to reviews on that seller's own products (via a product lookup) — the seller-facing view (Part 13)
 */
const getReviewStats = async (reviewMatch = {}, sellerId = null) => {
  const basePipeline = [
    { $match: { ...reviewMatch, status: { $in: ACTIVE_REVIEW_STATUSES } } },
    { $lookup: { from: 'products', localField: 'product', foreignField: '_id', as: 'productDoc' } },
    { $unwind: { path: '$productDoc', preserveNullAndEmptyArrays: true } },
    ...(sellerId ? [{ $match: { 'productDoc.seller': toObjectId(sellerId) } }] : []),
  ];

  const [summary] = await Review.aggregate([
    ...basePipeline,
    {
      $group: {
        _id: null,
        count: { $sum: 1 },
        average: { $avg: '$rating' },
        dist1: { $sum: { $cond: [{ $eq: ['$rating', 1] }, 1, 0] } },
        dist2: { $sum: { $cond: [{ $eq: ['$rating', 2] }, 1, 0] } },
        dist3: { $sum: { $cond: [{ $eq: ['$rating', 3] }, 1, 0] } },
        dist4: { $sum: { $cond: [{ $eq: ['$rating', 4] }, 1, 0] } },
        dist5: { $sum: { $cond: [{ $eq: ['$rating', 5] }, 1, 0] } },
      },
    },
  ]).exec();

  const perProduct = await Review.aggregate([
    ...basePipeline,
    { $group: { _id: '$product', title: { $first: '$productDoc.title' }, count: { $sum: 1 }, average: { $avg: '$rating' } } },
    { $sort: { count: -1 } },
    { $limit: 20 },
    { $project: { _id: 0, productId: '$_id', title: 1, reviewCount: '$count', averageRating: { $round: ['$average', 1] } } },
  ]).exec();

  // Per-seller breakdown is a platform-wide (admin) view — a seller
  // already scoped to their own products doesn't need themselves
  // broken out as a single row.
  const perSeller = sellerId
    ? []
    : await Review.aggregate([
        ...basePipeline,
        { $group: { _id: '$productDoc.seller', count: { $sum: 1 }, average: { $avg: '$rating' } } },
        { $sort: { count: -1 } },
      ]).exec();

  return {
    averageRating: summary ? Math.round(summary.average * 10) / 10 : 0,
    totalReviews: summary?.count ?? 0,
    distribution: {
      1: summary?.dist1 ?? 0,
      2: summary?.dist2 ?? 0,
      3: summary?.dist3 ?? 0,
      4: summary?.dist4 ?? 0,
      5: summary?.dist5 ?? 0,
    },
    mostReviewedProducts: perProduct,
    reviewsPerSeller: perSeller.map((r) => ({
      sellerId: r._id,
      reviewCount: r.count,
      averageRating: Math.round((r.average || 0) * 10) / 10,
    })),
  };
};

// --------------------------------------------------------------------
// Phase 17A.2 — Marketplace Growth: trending categories/brands, most
// wishlisted products, search analytics. Additive — nothing above this
// section changed.
// --------------------------------------------------------------------

/**
 * Trending categories: published products created within the trailing
 * `windowDays`, grouped by category and ranked by combined views then
 * sales — same recency+popularity heuristic product.service.js already
 * uses for `/products/trending` (Phase 5), just grouped by category
 * instead of returned as individual products. `productMatch` carries
 * the same seller-scoping `buildProductMatch` already applies to every
 * other product-analytics call.
 */
const getTrendingCategories = (productMatch, windowDays = 30, limit = 10) => {
  const since = new Date(Date.now() - windowDays * 24 * 60 * 60 * 1000);
  return Product.aggregate([
    { $match: { ...productMatch, status: PRODUCT_STATUSES.PUBLISHED, createdAt: { $gte: since } } },
    { $group: { _id: '$category', views: { $sum: '$views' }, salesCount: { $sum: '$salesCount' }, productCount: { $sum: 1 } } },
    { $lookup: { from: 'categories', localField: '_id', foreignField: '_id', as: 'categoryDoc' } },
    { $unwind: { path: '$categoryDoc', preserveNullAndEmptyArrays: true } },
    {
      $project: {
        _id: 0,
        categoryId: '$_id',
        category: { $ifNull: ['$categoryDoc.name', 'Uncategorized'] },
        views: 1,
        salesCount: 1,
        productCount: 1,
      },
    },
    { $sort: { views: -1, salesCount: -1 } },
    { $limit: limit },
  ]).exec();
};

/** Same heuristic as getTrendingCategories, grouped by brand instead. Products with no brand are excluded (nothing to rank them under). */
const getTrendingBrands = (productMatch, windowDays = 30, limit = 10) => {
  const since = new Date(Date.now() - windowDays * 24 * 60 * 60 * 1000);
  return Product.aggregate([
    { $match: { ...productMatch, status: PRODUCT_STATUSES.PUBLISHED, createdAt: { $gte: since }, brand: { $ne: null } } },
    { $group: { _id: '$brand', views: { $sum: '$views' }, salesCount: { $sum: '$salesCount' }, productCount: { $sum: 1 } } },
    { $lookup: { from: 'brands', localField: '_id', foreignField: '_id', as: 'brandDoc' } },
    { $unwind: { path: '$brandDoc', preserveNullAndEmptyArrays: true } },
    {
      $project: {
        _id: 0,
        brandId: '$_id',
        brand: { $ifNull: ['$brandDoc.name', 'Unknown'] },
        views: 1,
        salesCount: 1,
        productCount: 1,
      },
    },
    { $sort: { views: -1, salesCount: -1 } },
    { $limit: limit },
  ]).exec();
};

/**
 * Most-wishlisted products, counted across EVERY buyer's EVERY
 * wishlist (Phase 17A.2's multi-wishlist model — see Wishlist.js —
 * still keeps every wishlist, default or named, in the same
 * collection, so this needs no awareness of which wishlist an item
 * sits in). `productMatch` optionally scopes to one seller's products
 * (same convention as every other product-analytics function).
 */
const getMostWishlistedProducts = (productMatch = {}, limit = 20) =>
  Wishlist.aggregate([
    { $unwind: '$items' },
    { $group: { _id: '$items.product', wishlistCount: { $sum: 1 } } },
    { $lookup: { from: 'products', localField: '_id', foreignField: '_id', as: 'productDoc' } },
    { $unwind: '$productDoc' },
    { $match: Object.keys(productMatch).length ? Object.fromEntries(Object.entries(productMatch).map(([k, v]) => [`productDoc.${k}`, v])) : {} },
    {
      $project: {
        _id: 0,
        productId: '$_id',
        title: '$productDoc.title',
        wishlistCount: 1,
      },
    },
    { $sort: { wishlistCount: -1 } },
    { $limit: limit },
  ]).exec();

/**
 * Search analytics: the most-searched terms across every buyer's
 * search history (see SearchHistory.js, Phase 17A.1), grouped
 * case-insensitively so "Laptop" and "laptop" count as the same term.
 * Platform-wide only — there's no per-seller notion of "what buyers
 * searched for" (a search term isn't scoped to a seller), so this
 * takes no productMatch/seller-scoping unlike the functions above.
 */
const getSearchAnalytics = (limit = 20) =>
  SearchHistory.aggregate([
    { $unwind: '$items' },
    { $group: { _id: { $toLower: '$items.query' }, searchCount: { $sum: 1 }, lastSearchedAt: { $max: '$items.searchedAt' } } },
    { $project: { _id: 0, term: '$_id', searchCount: 1, lastSearchedAt: 1 } },
    { $sort: { searchCount: -1, lastSearchedAt: -1 } },
    { $limit: limit },
  ]).exec();

module.exports = {
  getRevenueSummary,
  getOrderCounts,
  getCustomerCounts,
  getSellerCounts,
  getProductCounts,
  getSalesSeries,
  getOrdersByStatus,
  getOrdersByDate,
  getOrderStats,
  getRevenueTrend,
  getRevenueByCategory,
  getRevenueBySeller,
  getRevenueByProduct,
  getRevenueByPaymentMethod,
  getBestSellingProducts,
  getMostViewedProducts,
  getHighestRatedProducts,
  getLowStockProducts,
  getOutOfStockProducts,
  getSellerPerformance,
  getSellerGrowth,
  getNewCustomersSeries,
  getReturningCustomerStats,
  getTopBuyers,
  getPaymentStats,
  getReviewStats,
  getTrendingCategories,
  getTrendingBrands,
  getMostWishlistedProducts,
  getSearchAnalytics,
};
