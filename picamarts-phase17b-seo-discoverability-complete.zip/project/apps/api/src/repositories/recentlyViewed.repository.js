'use strict';

const RecentlyViewed = require('../models/RecentlyViewed');

/**
 * Data-access only — trimming/reordering rules live in
 * recentlyViewed.service.js. Same raw-vs-populated split as
 * wishlist.repository.js.
 */
const RECENTLY_VIEWED_PRODUCT_FIELDS =
  'title slug thumbnail basePrice salePrice currency status stock reservedStock allowBackorder seller category';

const findByBuyer = (buyerId) =>
  RecentlyViewed.findOne({ buyer: buyerId }).populate('items.product', RECENTLY_VIEWED_PRODUCT_FIELDS).exec();

const findRawByBuyer = (buyerId) => RecentlyViewed.findOne({ buyer: buyerId }).exec();

const createForBuyer = (buyerId) => RecentlyViewed.create({ buyer: buyerId, items: [] });

module.exports = { findByBuyer, findRawByBuyer, createForBuyer, RECENTLY_VIEWED_PRODUCT_FIELDS };
