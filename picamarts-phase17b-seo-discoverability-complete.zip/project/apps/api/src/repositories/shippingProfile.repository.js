'use strict';

const ShippingProfile = require('../models/ShippingProfile');

/** Data-access only — ownership rules live in shippingProfile.service.js. */

const create = (data) => ShippingProfile.create(data);

const findById = (id) => ShippingProfile.findById(id).exec();

const listBySeller = (sellerId, options = {}) =>
  ShippingProfile.paginate({ seller: sellerId }, { sort: { createdAt: -1 }, limit: 100, ...options });

const listAll = (filter = {}, options = {}) =>
  ShippingProfile.paginate(filter, { sort: { createdAt: -1 }, ...options });

/** Fetch-mutate-save so pre-save hooks (none currently, but future-proof) and full-document validation always run. */
const updateById = async (id, update) => {
  const doc = await ShippingProfile.findById(id).exec();
  if (!doc) return null;
  Object.assign(doc, update);
  return doc.save();
};

const deleteById = (id) => ShippingProfile.findByIdAndDelete(id).exec();

module.exports = { create, findById, listBySeller, listAll, updateById, deleteById };
