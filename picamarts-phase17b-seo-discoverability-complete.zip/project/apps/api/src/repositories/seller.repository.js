'use strict';

const Seller = require('../models/Seller');

const create = (data) => Seller.create(data);

const findById = (id) => Seller.findById(id).exec();

const findByUserId = (userId) => Seller.findOne({ user: userId }).exec();

const findBySlug = (slug) => Seller.findOne({ storeSlug: slug.toLowerCase().trim() }).exec();

const existsBySlug = (slug) => Seller.exists({ storeSlug: slug.toLowerCase().trim() });

const existsByUserId = (userId) => Seller.exists({ user: userId });

const list = (filter = {}, options = {}) => Seller.paginate(filter, options);

/**
 * Phase 15C, Part 4 — Admin Seller Management. `findById` above is
 * reused internally by the approve/reject/suspend/reinstate workflow
 * (via getSellerById), which then does `userRepository.findById(seller.user)`
 * — populating that path would silently break those calls (`seller.user`
 * would become an object, not the plain id they expect). So the admin
 * detail view and the admin list use these two NEW, separate,
 * populate-only functions instead of touching `findById`/`list` above.
 */
const ADMIN_USER_POPULATE = { path: 'user', select: 'name email isActive' };

const findByIdWithUser = (id) => Seller.findById(id).populate(ADMIN_USER_POPULATE).exec();

const listWithUser = (filter = {}, options = {}) => Seller.paginate(filter, { ...options, populate: ADMIN_USER_POPULATE });

const updateById = (id, update) => Seller.findByIdAndUpdate(id, update, { new: true, runValidators: true }).exec();

const deleteById = (id) => Seller.findByIdAndDelete(id).exec();

module.exports = {
  create,
  findById,
  findByUserId,
  findBySlug,
  existsBySlug,
  existsByUserId,
  list,
  updateById,
  deleteById,
  findByIdWithUser,
  listWithUser,
};
