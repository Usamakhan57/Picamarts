'use strict';

const Page = require('../models/Page');

/**
 * Phase 10.3 — Page Repository. Data-access only — business rules
 * (authorization, publish stamping, duplicate pageType/slug guards)
 * live in page.service.js.
 */

const create = (data) => Page.create(data);

const findById = (id) => Page.findById(id).exec();

const findBySlug = (slug) => Page.findOne({ slug: slug.toLowerCase().trim() }).exec();

const findByType = (pageType) => Page.findOne({ pageType }).exec();

const existsBySlug = (slug) => Page.exists({ slug: slug.toLowerCase().trim() });

const existsByType = (pageType) => Page.exists({ pageType });

/** Public listing only ever needs published pages; the admin listing passes no status filter. */
const list = (filter = {}, options = {}) => Page.paginate(filter, options);

const updateById = (id, update) => Page.findByIdAndUpdate(id, update, { new: true, runValidators: true }).exec();

const deleteById = (id) => Page.findByIdAndDelete(id).exec();

module.exports = {
  create,
  findById,
  findBySlug,
  findByType,
  existsBySlug,
  existsByType,
  list,
  updateById,
  deleteById,
};
