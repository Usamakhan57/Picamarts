'use strict';

const backgroundQueue = require('../queues/background.queue');
const logger = require('../utils/logger');

/**
 * Phase 12, Part 3 — Background Jobs. Schedules the two repeatable
 * maintenance jobs workers/background.worker.js knows how to process:
 *
 *   purge-expired-tokens — daily at 03:00. Directly queries the User
 *     model (a narrow, additive, read/write-scoped query in this new
 *     file — the same cross-module convention order.repository.js
 *     established for Product, notification.repository.js for User,
 *     etc.) to drop expired refresh tokens and stale password-reset/
 *     email-verification token hashes. Never touches User.js itself.
 *
 *   low-stock-scan — daily at 04:00. Reuses the low-stock definition
 *     Phase 11's analytics already established (published, non-
 *     backorderable, 0 < stock <= lowStockThreshold) and fans out one
 *     Notifications-queue job per affected seller.
 *
 * Both are no-ops to schedule when queues are disabled — BullMQ
 * `repeat` scheduling requires a live queue, same as any other job.
 */
const registerMaintenanceJobs = async () => {
  const purge = await backgroundQueue.addBackgroundJob(
    'purge-expired-tokens',
    {},
    { repeat: { pattern: '0 3 * * *' }, jobId: 'purge-expired-tokens' }
  );
  const lowStock = await backgroundQueue.addBackgroundJob(
    'low-stock-scan',
    {},
    { repeat: { pattern: '0 4 * * *' }, jobId: 'low-stock-scan' }
  );

  if (purge || lowStock) {
    logger.info('Scheduled repeatable background jobs: purge-expired-tokens (03:00), low-stock-scan (04:00).');
  } else {
    logger.info('Queues are disabled — repeatable background jobs were not scheduled.');
  }
};

module.exports = { registerMaintenanceJobs };
