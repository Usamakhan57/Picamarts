'use strict';

const { registerMaintenanceJobs } = require('./maintenance.job');

/**
 * Registers scheduled/background jobs. Phase 12, Part 3 fills in what
 * this file's own header comment asked for since Phase 1: repeatable
 * BullMQ jobs, scheduled once at API server boot (see server.js) —
 * purging expired auth tokens and scanning for low-stock products (see
 * jobs/maintenance.job.js). A no-op, logged as such, when queues are
 * disabled (no Redis configured).
 */
const registerJobs = async () => {
  await registerMaintenanceJobs();
};

module.exports = { registerJobs };
