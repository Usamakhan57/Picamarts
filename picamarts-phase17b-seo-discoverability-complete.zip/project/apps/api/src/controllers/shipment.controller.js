'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const shipmentService = require('../services/shipment.service');

/**
 * Phase 14.2 — Shipment Records, Customer Tracking, Seller/Admin
 * Shipping Dashboards. Ownership (buyer: own shipments only; seller:
 * their own only; admin: everything) is enforced in
 * shipment.service.js — pure request/response plumbing here.
 */

const createShipment = asyncHandler(async (req, res) => {
  const shipment = await shipmentService.createShipment(req.params.orderId, req.body, req.user);
  new ApiResponse(httpStatus.CREATED, { shipment }, 'Shipment created successfully.').send(res);
});

const listForOrder = asyncHandler(async (req, res) => {
  const shipments = await shipmentService.listShipmentsForOrder(req.params.orderId, req.user);
  new ApiResponse(httpStatus.OK, { shipments }, 'Shipments retrieved successfully.').send(res);
});

const getById = asyncHandler(async (req, res) => {
  const shipment = await shipmentService.getShipmentById(req.params.shipmentId, req.user);
  new ApiResponse(httpStatus.OK, { shipment }, 'Shipment retrieved successfully.').send(res);
});

const updateStatus = asyncHandler(async (req, res) => {
  const shipment = await shipmentService.updateShipmentStatus(req.params.shipmentId, req.body.status, req.body, req.user);
  new ApiResponse(httpStatus.OK, { shipment }, 'Shipment status updated successfully.').send(res);
});

const addTracking = asyncHandler(async (req, res) => {
  const shipment = await shipmentService.addTracking(req.params.shipmentId, req.body, req.user);
  new ApiResponse(httpStatus.OK, { shipment }, 'Tracking added successfully.').send(res);
});

const listMine = asyncHandler(async (req, res) => {
  const shipments = await shipmentService.listMyShipments(req.user.id);
  new ApiResponse(httpStatus.OK, { shipments }, 'Shipments retrieved successfully.').send(res);
});

const listOrdersToShip = asyncHandler(async (req, res) => {
  const orders = await shipmentService.listOrdersToShip(req.user.id);
  new ApiResponse(httpStatus.OK, { orders }, 'Orders to ship retrieved successfully.').send(res);
});

const listShipments = asyncHandler(async (req, res) => {
  const { items, meta } = await shipmentService.listShipments(req.query, req.user);
  new ApiResponse(httpStatus.OK, { shipments: items }, 'Shipments retrieved successfully.', meta).send(res);
});

const getAdminOverview = asyncHandler(async (req, res) => {
  const overview = await shipmentService.getAdminOverview();
  new ApiResponse(httpStatus.OK, overview, 'Shipping overview retrieved successfully.').send(res);
});

module.exports = {
  createShipment,
  listForOrder,
  getById,
  updateStatus,
  addTracking,
  listMine,
  listOrdersToShip,
  listShipments,
  getAdminOverview,
};
