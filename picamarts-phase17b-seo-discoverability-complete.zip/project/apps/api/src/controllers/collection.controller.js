'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const { getPagination } = require('../utils/pagination');
const { buildSortQuery } = require('../utils/sortHelper');
const { buildSearchQuery } = require('../utils/searchHelper');
const collectionService = require('../services/collection.service');

/** Phase 4 — Admin marketplace management. Public reads, admin-only writes. */

const SEARCH_FIELDS = ['name', 'description'];
const SORT_FIELDS = ['name', 'createdAt', 'updatedAt'];

/**
 * @swagger
 * /collections:
 *   get:
 *     summary: List collections (paginated, searchable, filterable, sortable)
 *     tags: [Collections]
 *     parameters:
 *       - in: query
 *         name: page
 *         schema: { type: integer }
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *       - in: query
 *         name: q
 *         schema: { type: string }
 *       - in: query
 *         name: sort
 *         schema: { type: string }
 *       - in: query
 *         name: featured
 *         schema: { type: boolean }
 *       - in: query
 *         name: active
 *         schema: { type: boolean }
 *     responses:
 *       200: { description: Paginated list of collections }
 */
const list = asyncHandler(async (req, res) => {
  const { page, limit } = getPagination(req.query);
  const sort = buildSortQuery(req.query.sort, SORT_FIELDS);
  const filter = { ...buildSearchQuery(req.query.q, SEARCH_FIELDS) };

  if (req.query.featured !== undefined) filter.featured = req.query.featured;
  if (req.query.active !== undefined) filter.active = req.query.active;

  const { items, meta } = await collectionService.listCollections(filter, { page, limit, sort });

  new ApiResponse(httpStatus.OK, { collections: items }, 'Collections retrieved successfully.', meta).send(res);
});

/**
 * @swagger
 * /collections/{id}:
 *   get:
 *     summary: Get a collection by id
 *     tags: [Collections]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Collection found }
 *       404: { description: Collection not found }
 */
const getById = asyncHandler(async (req, res) => {
  const collection = await collectionService.getCollectionById(req.params.id);
  new ApiResponse(httpStatus.OK, { collection }, 'Collection retrieved successfully.').send(res);
});

/**
 * @swagger
 * /collections/slug/{slug}:
 *   get:
 *     summary: Get a collection by slug
 *     tags: [Collections]
 *     parameters:
 *       - in: path
 *         name: slug
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Collection found }
 *       404: { description: Collection not found }
 */
const getBySlug = asyncHandler(async (req, res) => {
  const collection = await collectionService.getCollectionBySlug(req.params.slug);
  new ApiResponse(httpStatus.OK, { collection }, 'Collection retrieved successfully.').send(res);
});

/**
 * @swagger
 * /collections:
 *   post:
 *     summary: Create a collection (admin only)
 *     tags: [Collections]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       201: { description: Collection created }
 *       422: { description: Validation failed }
 */
const create = asyncHandler(async (req, res) => {
  const collection = await collectionService.createCollection(req.body);
  new ApiResponse(httpStatus.CREATED, { collection }, 'Collection created successfully.').send(res);
});

/**
 * @swagger
 * /collections/{id}:
 *   patch:
 *     summary: Update a collection (admin only)
 *     tags: [Collections]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Collection updated }
 *       404: { description: Collection not found }
 */
const update = asyncHandler(async (req, res) => {
  const collection = await collectionService.updateCollection(req.params.id, req.body);
  new ApiResponse(httpStatus.OK, { collection }, 'Collection updated successfully.').send(res);
});

/**
 * @swagger
 * /collections/{id}:
 *   delete:
 *     summary: Delete a collection (admin only)
 *     tags: [Collections]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Collection deleted }
 *       404: { description: Collection not found }
 */
const remove = asyncHandler(async (req, res) => {
  await collectionService.deleteCollection(req.params.id);
  new ApiResponse(httpStatus.OK, null, 'Collection deleted successfully.').send(res);
});

/**
 * @swagger
 * /collections/{id}/toggle-active:
 *   patch:
 *     summary: Toggle a collection's active/inactive status (admin only)
 *     tags: [Collections]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Status toggled }
 *       404: { description: Collection not found }
 */
const toggleActive = asyncHandler(async (req, res) => {
  const current = await collectionService.getCollectionById(req.params.id);
  const collection = await collectionService.updateCollection(req.params.id, { active: !current.active });

  new ApiResponse(
    httpStatus.OK,
    { collection },
    `Collection ${collection.active ? 'activated' : 'deactivated'} successfully.`
  ).send(res);
});

module.exports = { list, getById, getBySlug, create, update, remove, toggleActive };
