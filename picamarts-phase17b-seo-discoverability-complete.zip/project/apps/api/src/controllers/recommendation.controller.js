'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const recommendationService = require('../services/recommendation.service');

/**
 * Phase 17A.2, Part 1 — Recommendation Engine. Every route here is
 * public except /personalized (buyer-only — see recommendation.routes.js).
 */

/**
 * @swagger
 * /recommendations/related/{productId}:
 *   get:
 *     summary: Products in the same category or with overlapping tags
 *     tags: [Recommendations]
 *     parameters:
 *       - in: path
 *         name: productId
 *         required: true
 *         schema: { type: string }
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Related products }
 *       404: { description: Product not found }
 */
const related = asyncHandler(async (req, res) => {
  const products = await recommendationService.getRelatedProducts(req.params.productId, req.query.limit);
  new ApiResponse(httpStatus.OK, { products }, 'Related products retrieved successfully.').send(res);
});

/**
 * @swagger
 * /recommendations/frequently-bought-together/{productId}:
 *   get:
 *     summary: Products most often purchased in the same order as this one
 *     tags: [Recommendations]
 *     parameters:
 *       - in: path
 *         name: productId
 *         required: true
 *         schema: { type: string }
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Frequently bought together products }
 */
const frequentlyBoughtTogether = asyncHandler(async (req, res) => {
  const products = await recommendationService.getFrequentlyBoughtTogether(req.params.productId, req.query.limit);
  new ApiResponse(httpStatus.OK, { products }, 'Frequently bought together products retrieved successfully.').send(res);
});

/**
 * @swagger
 * /recommendations/also-viewed/{productId}:
 *   get:
 *     summary: Products viewed by buyers who also viewed this one
 *     tags: [Recommendations]
 *     parameters:
 *       - in: path
 *         name: productId
 *         required: true
 *         schema: { type: string }
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Also-viewed products }
 */
const alsoViewed = asyncHandler(async (req, res) => {
  const products = await recommendationService.getAlsoViewed(req.params.productId, req.query.limit);
  new ApiResponse(httpStatus.OK, { products }, 'Also-viewed products retrieved successfully.').send(res);
});

/**
 * @swagger
 * /recommendations/trending:
 *   get:
 *     summary: Trending products (thin pass-through to the existing /products/trending feed)
 *     tags: [Recommendations]
 *     parameters:
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Trending products }
 */
const trending = asyncHandler(async (req, res) => {
  const products = await recommendationService.getTrending(req.query.limit);
  new ApiResponse(httpStatus.OK, { products }, 'Trending products retrieved successfully.').send(res);
});

/**
 * @swagger
 * /recommendations/personalized:
 *   get:
 *     summary: Recommendations for the authenticated buyer, based on purchase history, wishlist contents, and recently viewed products
 *     tags: [Recommendations]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Personalized product recommendations }
 *       401: { description: Authentication required }
 */
const personalized = asyncHandler(async (req, res) => {
  const products = await recommendationService.getPersonalized(req.user.id, req.query.limit);
  new ApiResponse(httpStatus.OK, { products }, 'Personalized recommendations retrieved successfully.').send(res);
});

module.exports = { related, frequentlyBoughtTogether, alsoViewed, trending, personalized };
