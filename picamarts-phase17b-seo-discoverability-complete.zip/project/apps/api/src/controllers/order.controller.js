'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const orderService = require('../services/order.service');

/**
 * Phase 8, Part 2 — Orders. Visibility/authorization nuances (buyer:
 * own orders only; seller: orders containing their products,
 * fulfillment statuses only; admin: everything) are enforced in
 * order.service.js — this file is pure request/response plumbing.
 */

/**
 * @swagger
 * /orders:
 *   post:
 *     summary: Create an order from the authenticated buyer's current cart
 *     description: >
 *       Re-validates and prices the cart exactly as POST /checkout
 *       does (empty cart, unpublished/out-of-stock/over-quantity items
 *       all rejected with 400), atomically reserves stock per item
 *       (rolled back entirely if anything fails partway), and clears
 *       the cart once the order is safely created.
 *     tags: [Orders]
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [shippingAddress]
 *             properties:
 *               shippingAddress:
 *                 type: object
 *                 required: [fullName, line1, city, postalCode, country]
 *                 properties:
 *                   fullName: { type: string }
 *                   line1: { type: string }
 *                   line2: { type: string }
 *                   city: { type: string }
 *                   state: { type: string }
 *                   postalCode: { type: string }
 *                   country: { type: string }
 *                   phone: { type: string }
 *               billingAddress:
 *                 type: object
 *                 description: Falls back to shippingAddress when omitted
 *               notes: { type: string }
 *     responses:
 *       201:
 *         description: Order created
 *         content:
 *           application/json:
 *             example:
 *               success: true
 *               message: Order created successfully.
 *               data:
 *                 order:
 *                   id: 64f1a2b3c4d5e6f7a8b9c0d1
 *                   orderNumber: ORD-2026-000001
 *                   status: pending
 *                   paymentStatus: pending
 *                   items:
 *                     - id: 64f1a2b3c4d5e6f7a8b9c0d2
 *                       product: 64f1a2b3c4d5e6f7a8b9c0d3
 *                       title: Sample Product
 *                       quantity: 2
 *                       lockedPrice: 29.99
 *                       lineTotal: 59.98
 *                   grandTotal: 59.98
 *       400:
 *         description: Cart isn't checkout-ready, or a product no longer has enough stock
 *         content:
 *           application/json:
 *             example:
 *               success: false
 *               message: Cart is not ready for checkout.
 *               details: ['Your cart is empty.']
 *       401: { description: Authentication required }
 *       403: { description: Only buyers can place orders }
 *       422: { description: Validation failed (missing/invalid shippingAddress) }
 */
const createOrder = asyncHandler(async (req, res) => {
  const order = await orderService.createOrder(req.user.id, req.body, req.user);
  new ApiResponse(httpStatus.CREATED, { order }, 'Order created successfully.').send(res);
});

/**
 * @swagger
 * /orders:
 *   get:
 *     summary: List orders visible to the authenticated user
 *     description: Buyers see only their own orders; sellers see orders containing at least one of their products; admins see every order.
 *     tags: [Orders]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: status
 *         schema: { type: string, enum: [pending, confirmed, processing, packed, shipped, delivered, cancelled, refunded] }
 *       - in: query
 *         name: page
 *         schema: { type: integer, minimum: 1 }
 *       - in: query
 *         name: limit
 *         schema: { type: integer, minimum: 1, maximum: 100 }
 *     responses:
 *       200: { description: Paginated order list }
 *       401: { description: Authentication required }
 */
const listOrders = asyncHandler(async (req, res) => {
  const { items, meta } = await orderService.listOrders(req.user, req.query);
  new ApiResponse(httpStatus.OK, { orders: items }, 'Orders retrieved successfully.', meta).send(res);
});

/**
 * @swagger
 * /orders/{orderId}:
 *   get:
 *     summary: Get a single order by id
 *     description: Returns 404 (not 403) for an order the caller isn't allowed to see, so its existence isn't leaked.
 *     tags: [Orders]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: orderId
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Order retrieved }
 *       401: { description: Authentication required }
 *       404: { description: Order not found (or not visible to the caller) }
 */
const getOrderById = asyncHandler(async (req, res) => {
  const order = await orderService.getOrderById(req.params.orderId, req.user);
  new ApiResponse(httpStatus.OK, { order }, 'Order retrieved successfully.').send(res);
});

/**
 * @swagger
 * /orders/{orderId}/status:
 *   patch:
 *     summary: Update an order's fulfillment status (seller or admin)
 *     description: A seller may only set fulfillment-related statuses (confirmed/processing/packed/shipped/delivered) on an order containing their own product(s). An admin may set any status. A terminal order (cancelled/refunded) can no longer be moved.
 *     tags: [Orders]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: orderId
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [status]
 *             properties:
 *               status: { type: string, enum: [pending, confirmed, processing, packed, shipped, delivered, cancelled, refunded] }
 *     responses:
 *       200: { description: Status updated; the full updated order is returned }
 *       400: { description: Order is already in a terminal status }
 *       401: { description: Authentication required }
 *       403: { description: Not permitted to set this status (e.g. a seller attempting cancelled/refunded) }
 *       404: { description: Order not found (or not visible to the caller) }
 *       422: { description: Validation failed (invalid status value) }
 */
const updateOrderStatus = asyncHandler(async (req, res) => {
  const order = await orderService.updateOrderStatus(req.params.orderId, req.body.status, req.user);
  new ApiResponse(httpStatus.OK, { order }, 'Order status updated successfully.').send(res);
});

/**
 * @swagger
 * /orders/{orderId}/cancel:
 *   patch:
 *     summary: Cancel an order (buyer's own pending order, or admin — any non-terminal order)
 *     description: Restores every unit this order had reserved back to stock.
 *     tags: [Orders]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: orderId
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Order cancelled; the full updated order is returned }
 *       400: { description: Order isn't pending (buyer) or is already cancelled/refunded }
 *       401: { description: Authentication required }
 *       403: { description: Not permitted to cancel this order }
 *       404: { description: Order not found (or not visible to the caller) }
 */
const cancelOrder = asyncHandler(async (req, res) => {
  const order = await orderService.cancelOrder(req.params.orderId, req.user);
  new ApiResponse(httpStatus.OK, { order }, 'Order cancelled successfully.').send(res);
});

module.exports = { createOrder, listOrders, getOrderById, updateOrderStatus, cancelOrder };
