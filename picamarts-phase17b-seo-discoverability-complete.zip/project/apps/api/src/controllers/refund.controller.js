'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const refundService = require('../services/refund.service');
const { uploadAttachments } = require('../services/attachmentUpload.service');

/**
 * @swagger
 * tags:
 *   name: Refunds
 *   description: Buyer refund requests, the admin refund queue, and Stripe refund processing (Phase 16D)
 */

const createRefundRequest = asyncHandler(async (req, res) => {
  const request = await refundService.createRefundRequest(req.params.orderId, req.user, req.body);
  new ApiResponse(httpStatus.CREATED, { request }, 'Refund request submitted.').send(res);
});

const uploadRefundAttachments = asyncHandler(async (req, res) => {
  const urls = await uploadAttachments(req.files);
  new ApiResponse(httpStatus.OK, { attachments: urls }, 'Attachments uploaded.').send(res);
});

const listMyRefundRequests = asyncHandler(async (req, res) => {
  const { page, limit } = req.query;
  const { items, meta } = await refundService.listMyRefundRequests(req.user.id, { page, limit });
  new ApiResponse(httpStatus.OK, { requests: items }, 'Refund requests retrieved.', meta).send(res);
});

const getRefundRequest = asyncHandler(async (req, res) => {
  const request = await refundService.getRefundRequest(req.params.requestId, req.user);
  new ApiResponse(httpStatus.OK, { request }, 'Refund request retrieved.').send(res);
});

const cancelRefundRequest = asyncHandler(async (req, res) => {
  const request = await refundService.cancelRefundRequest(req.params.requestId, req.user);
  new ApiResponse(httpStatus.OK, { request }, 'Refund request cancelled.').send(res);
});

const listAdminQueue = asyncHandler(async (req, res) => {
  const { page, limit, status, q } = req.query;
  const { items, meta } = await refundService.getAdminQueue({ page, limit, status, q });
  new ApiResponse(httpStatus.OK, { requests: items }, 'Refund queue retrieved.', meta).send(res);
});

const getAdminOverview = asyncHandler(async (req, res) => {
  const overview = await refundService.getAdminOverview();
  new ApiResponse(httpStatus.OK, overview, 'Refund overview retrieved.').send(res);
});

const approveRefundRequest = asyncHandler(async (req, res) => {
  const request = await refundService.approveRefundRequest(req.params.requestId, req.user, req.body.note);
  new ApiResponse(httpStatus.OK, { request }, 'Refund request processed.').send(res);
});

const rejectRefundRequest = asyncHandler(async (req, res) => {
  const request = await refundService.rejectRefundRequest(req.params.requestId, req.user, req.body.note);
  new ApiResponse(httpStatus.OK, { request }, 'Refund request rejected.').send(res);
});

const retryRefundRequest = asyncHandler(async (req, res) => {
  const request = await refundService.retryRefundRequest(req.params.requestId, req.user);
  new ApiResponse(httpStatus.OK, { request }, 'Refund retry attempted.').send(res);
});

const bulkAction = asyncHandler(async (req, res) => {
  const result = await refundService.bulkAction(req.body.ids, req.body.action, req.user, req.body.reason);
  new ApiResponse(httpStatus.OK, result, 'Bulk action completed.').send(res);
});

module.exports = {
  createRefundRequest,
  uploadRefundAttachments,
  listMyRefundRequests,
  getRefundRequest,
  cancelRefundRequest,
  listAdminQueue,
  getAdminOverview,
  approveRefundRequest,
  rejectRefundRequest,
  retryRefundRequest,
  bulkAction,
};
