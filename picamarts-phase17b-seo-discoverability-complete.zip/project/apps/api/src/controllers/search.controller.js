'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const searchService = require('../services/search.service');
const searchHistoryService = require('../services/searchHistory.service');
const { ROLES } = require('../constants/roles');

/**
 * Phase 17A, Part 1 — Advanced Global Search. `/search` is public
 * (attachUserIfPresent — see search.routes.js) so anonymous buyers can
 * search too; search history is only ever recorded for an
 * authenticated buyer, fire-and-forget so a logging failure never
 * breaks the search response itself (same convention as
 * recentlyViewed.service.js#recordView).
 */

/**
 * @swagger
 * /search:
 *   get:
 *     summary: Cross-entity search — products, categories, brands, collections, tags, and sellers
 *     tags: [Search]
 *     parameters:
 *       - in: query
 *         name: q
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Grouped search results, each group capped to a small preview size }
 */
const search = asyncHandler(async (req, res) => {
  const results = await searchService.globalSearch(req.query.q);

  if (req.user?.role === ROLES.BUYER) {
    searchHistoryService.recordSearch(req.user.id, req.query.q).catch(() => {});
  }

  new ApiResponse(httpStatus.OK, results, 'Search results retrieved successfully.').send(res);
});

/**
 * @swagger
 * /search/suggestions:
 *   get:
 *     summary: Lightweight autocomplete suggestions as the buyer types
 *     tags: [Search]
 *     parameters:
 *       - in: query
 *         name: q
 *         required: true
 *         schema: { type: string }
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *     responses:
 *       200: { description: A short list of product/category/brand suggestions }
 */
const suggestions = asyncHandler(async (req, res) => {
  const results = await searchService.getSuggestions(req.query.q, req.query.limit);
  new ApiResponse(httpStatus.OK, { suggestions: results }, 'Suggestions retrieved successfully.').send(res);
});

/**
 * @swagger
 * /search/history:
 *   get:
 *     summary: Get the authenticated buyer's recent searches
 *     tags: [Search]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: The buyer's recent searches, newest first }
 */
const getHistory = asyncHandler(async (req, res) => {
  const history = await searchHistoryService.getHistory(req.user.id);
  new ApiResponse(httpStatus.OK, { history }, 'Search history retrieved successfully.').send(res);
});

/**
 * @swagger
 * /search/history/{id}:
 *   delete:
 *     summary: Remove a single entry from the authenticated buyer's search history
 *     tags: [Search]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Entry removed; the full updated history is returned }
 *       404: { description: Search history entry not found }
 */
const removeHistoryEntry = asyncHandler(async (req, res) => {
  const history = await searchHistoryService.removeEntry(req.user.id, req.params.id);
  new ApiResponse(httpStatus.OK, { history }, 'Search history entry removed successfully.').send(res);
});

/**
 * @swagger
 * /search/history:
 *   delete:
 *     summary: Clear the authenticated buyer's entire search history
 *     tags: [Search]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Search history cleared }
 */
const clearHistory = asyncHandler(async (req, res) => {
  const history = await searchHistoryService.clear(req.user.id);
  new ApiResponse(httpStatus.OK, { history }, 'Search history cleared successfully.').send(res);
});

module.exports = { search, suggestions, getHistory, removeHistoryEntry, clearHistory };
