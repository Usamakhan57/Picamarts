'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const { getPagination } = require('../utils/pagination');
const { buildSortQuery } = require('../utils/sortHelper');
const { buildSearchQuery } = require('../utils/searchHelper');
const categoryService = require('../services/category.service');

/**
 * Phase 4 — Admin marketplace management.
 * Public reads (list/get) stay open so the storefront can render the
 * category tree/menu; writes are admin-only (see category.routes.js).
 */

const SEARCH_FIELDS = ['name', 'description'];
const SORT_FIELDS = ['name', 'sortOrder', 'level', 'createdAt', 'updatedAt'];

/**
 * @swagger
 * /categories:
 *   get:
 *     summary: List categories (paginated, searchable, filterable, sortable)
 *     tags: [Categories]
 *     parameters:
 *       - in: query
 *         name: page
 *         schema: { type: integer }
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *       - in: query
 *         name: q
 *         schema: { type: string }
 *         description: Free-text search across name and description
 *       - in: query
 *         name: sort
 *         schema: { type: string }
 *         description: Comma separated fields, prefix with "-" for descending, e.g. "-createdAt,name"
 *       - in: query
 *         name: parentCategory
 *         schema: { type: string }
 *       - in: query
 *         name: isActive
 *         schema: { type: boolean }
 *       - in: query
 *         name: isFeatured
 *         schema: { type: boolean }
 *     responses:
 *       200:
 *         description: Paginated list of categories
 */
const list = asyncHandler(async (req, res) => {
  const { page, limit } = getPagination(req.query);
  const sort = buildSortQuery(req.query.sort, SORT_FIELDS);
  const filter = { ...buildSearchQuery(req.query.q, SEARCH_FIELDS) };

  if (req.query.parentCategory !== undefined) filter.parentCategory = req.query.parentCategory;
  if (req.query.isActive !== undefined) filter.isActive = req.query.isActive;
  if (req.query.isFeatured !== undefined) filter.isFeatured = req.query.isFeatured;

  const { items, meta } = await categoryService.listCategories(filter, { page, limit, sort });

  new ApiResponse(httpStatus.OK, { categories: items }, 'Categories retrieved successfully.', meta).send(res);
});

/**
 * @swagger
 * /categories/{id}:
 *   get:
 *     summary: Get a category by id
 *     tags: [Categories]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Category found }
 *       404: { description: Category not found }
 */
const getById = asyncHandler(async (req, res) => {
  const category = await categoryService.getCategoryById(req.params.id);
  new ApiResponse(httpStatus.OK, { category }, 'Category retrieved successfully.').send(res);
});

/**
 * @swagger
 * /categories/slug/{slug}:
 *   get:
 *     summary: Get a category by slug
 *     tags: [Categories]
 *     parameters:
 *       - in: path
 *         name: slug
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Category found }
 *       404: { description: Category not found }
 */
const getBySlug = asyncHandler(async (req, res) => {
  const category = await categoryService.getCategoryBySlug(req.params.slug);
  new ApiResponse(httpStatus.OK, { category }, 'Category retrieved successfully.').send(res);
});

/**
 * @swagger
 * /categories:
 *   post:
 *     summary: Create a category (admin only)
 *     tags: [Categories]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       201: { description: Category created }
 *       400: { description: Invalid parent category }
 *       422: { description: Validation failed }
 */
const create = asyncHandler(async (req, res) => {
  const category = await categoryService.createCategory({ ...req.body, createdBy: req.user.id });
  new ApiResponse(httpStatus.CREATED, { category }, 'Category created successfully.').send(res);
});

/**
 * @swagger
 * /categories/{id}:
 *   patch:
 *     summary: Update a category (admin only)
 *     tags: [Categories]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Category updated }
 *       400: { description: Invalid parent category / would create a cycle }
 *       404: { description: Category not found }
 */
const update = asyncHandler(async (req, res) => {
  const category = await categoryService.updateCategory(req.params.id, req.body);
  new ApiResponse(httpStatus.OK, { category }, 'Category updated successfully.').send(res);
});

/**
 * @swagger
 * /categories/{id}:
 *   delete:
 *     summary: Delete a category (admin only). Refused while it still has subcategories.
 *     tags: [Categories]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Category deleted }
 *       404: { description: Category not found }
 *       409: { description: Category still has subcategories }
 */
const remove = asyncHandler(async (req, res) => {
  await categoryService.deleteCategory(req.params.id);
  new ApiResponse(httpStatus.OK, null, 'Category deleted successfully.').send(res);
});

/**
 * @swagger
 * /categories/{id}/toggle-active:
 *   patch:
 *     summary: Toggle a category's active/inactive status (admin only)
 *     tags: [Categories]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Status toggled }
 *       404: { description: Category not found }
 */
const toggleActive = asyncHandler(async (req, res) => {
  const current = await categoryService.getCategoryById(req.params.id);
  const category = await categoryService.updateCategory(req.params.id, { isActive: !current.isActive });

  new ApiResponse(
    httpStatus.OK,
    { category },
    `Category ${category.isActive ? 'activated' : 'deactivated'} successfully.`
  ).send(res);
});

module.exports = { list, getById, getBySlug, create, update, remove, toggleActive };
