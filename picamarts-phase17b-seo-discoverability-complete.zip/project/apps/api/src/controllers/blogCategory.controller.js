'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const { getPagination } = require('../utils/pagination');
const { buildSortQuery } = require('../utils/sortHelper');
const { buildSearchQuery } = require('../utils/searchHelper');
const blogCategoryService = require('../services/blogCategory.service');

/**
 * @swagger
 * tags:
 *   name: Blog Categories
 *   description: Blog category management (Phase 10.3, Part 2)
 */

const SEARCH_FIELDS = ['name', 'description'];
const SORT_FIELDS = ['name', 'createdAt', 'updatedAt'];

/**
 * @swagger
 * /blog/categories:
 *   get:
 *     summary: List blog categories
 *     tags: [Blog Categories]
 *     parameters:
 *       - in: query
 *         name: page
 *         schema: { type: integer }
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *       - in: query
 *         name: q
 *         schema: { type: string }
 *       - in: query
 *         name: active
 *         schema: { type: boolean }
 *     responses:
 *       200: { description: Paginated list of blog categories }
 */
const list = asyncHandler(async (req, res) => {
  const { page, limit } = getPagination(req.query);
  const sort = buildSortQuery(req.query.sort, SORT_FIELDS);
  const filter = { ...buildSearchQuery(req.query.q, SEARCH_FIELDS) };
  if (req.query.active !== undefined) filter.active = req.query.active;

  const { items, meta } = await blogCategoryService.listCategories(filter, { page, limit, sort });

  new ApiResponse(httpStatus.OK, { categories: items }, 'Blog categories retrieved successfully.', meta).send(res);
});

/**
 * @swagger
 * /blog/categories/{id}:
 *   get:
 *     summary: Get a blog category by id
 *     tags: [Blog Categories]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Category found }
 *       404: { description: Category not found }
 */
const getById = asyncHandler(async (req, res) => {
  const category = await blogCategoryService.getCategoryById(req.params.id);
  new ApiResponse(httpStatus.OK, { category }, 'Blog category retrieved successfully.').send(res);
});

/**
 * @swagger
 * /blog/categories/slug/{slug}:
 *   get:
 *     summary: Get a blog category by slug
 *     tags: [Blog Categories]
 *     parameters:
 *       - in: path
 *         name: slug
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Category found }
 *       404: { description: Category not found }
 */
const getBySlug = asyncHandler(async (req, res) => {
  const category = await blogCategoryService.getCategoryBySlug(req.params.slug);
  new ApiResponse(httpStatus.OK, { category }, 'Blog category retrieved successfully.').send(res);
});

/**
 * @swagger
 * /blog/categories:
 *   post:
 *     summary: Create a blog category (admin only)
 *     tags: [Blog Categories]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       201: { description: Category created }
 *       409: { description: Slug already in use }
 *       422: { description: Validation failed }
 */
const create = asyncHandler(async (req, res) => {
  const category = await blogCategoryService.createCategory(req.body);
  new ApiResponse(httpStatus.CREATED, { category }, 'Blog category created successfully.').send(res);
});

/**
 * @swagger
 * /blog/categories/{id}:
 *   patch:
 *     summary: Update a blog category (admin only)
 *     tags: [Blog Categories]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Category updated }
 *       404: { description: Category not found }
 *       409: { description: Slug already in use }
 */
const update = asyncHandler(async (req, res) => {
  const category = await blogCategoryService.updateCategory(req.params.id, req.body);
  new ApiResponse(httpStatus.OK, { category }, 'Blog category updated successfully.').send(res);
});

/**
 * @swagger
 * /blog/categories/{id}:
 *   delete:
 *     summary: Delete a blog category (admin only)
 *     tags: [Blog Categories]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Category deleted }
 *       404: { description: Category not found }
 */
const remove = asyncHandler(async (req, res) => {
  await blogCategoryService.deleteCategory(req.params.id);
  new ApiResponse(httpStatus.OK, null, 'Blog category deleted successfully.').send(res);
});

module.exports = { list, getById, getBySlug, create, update, remove };
