'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const recentlyViewedService = require('../services/recentlyViewed.service');

/**
 * Phase 17A, Part 5 — Recently Viewed. Every endpoint operates on the
 * AUTHENTICATED BUYER'S OWN list (see routes/v1/recentlyViewed.routes.js,
 * gated to the buyer role only — same reasoning as Wishlist/Cart).
 * Views themselves are recorded from product.controller.js, not here —
 * this controller only reads/manages the resulting list.
 */

/**
 * @swagger
 * /recently-viewed:
 *   get:
 *     summary: Get the authenticated buyer's recently viewed products
 *     tags: [Recently Viewed]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: The buyer's recently viewed products, newest first }
 */
const list = asyncHandler(async (req, res) => {
  const recentlyViewed = await recentlyViewedService.getRecentlyViewed(req.user.id);
  new ApiResponse(httpStatus.OK, { recentlyViewed }, 'Recently viewed products retrieved successfully.').send(res);
});

/**
 * @swagger
 * /recently-viewed/{productId}:
 *   delete:
 *     summary: Remove a single product from the authenticated buyer's recently viewed list
 *     tags: [Recently Viewed]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: productId
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Product removed; the full updated list is returned }
 *       404: { description: Recently viewed item not found }
 */
const removeItem = asyncHandler(async (req, res) => {
  const recentlyViewed = await recentlyViewedService.removeItem(req.user.id, req.params.productId);
  new ApiResponse(httpStatus.OK, { recentlyViewed }, 'Product removed from recently viewed successfully.').send(res);
});

/**
 * @swagger
 * /recently-viewed:
 *   delete:
 *     summary: Clear the authenticated buyer's entire recently viewed list
 *     tags: [Recently Viewed]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Recently viewed list cleared }
 */
const clear = asyncHandler(async (req, res) => {
  const recentlyViewed = await recentlyViewedService.clear(req.user.id);
  new ApiResponse(httpStatus.OK, { recentlyViewed }, 'Recently viewed list cleared successfully.').send(res);
});

module.exports = { list, removeItem, clear };
