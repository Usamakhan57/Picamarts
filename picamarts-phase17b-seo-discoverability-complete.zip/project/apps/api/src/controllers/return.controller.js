'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const returnService = require('../services/return.service');
const { uploadAttachments } = require('../services/attachmentUpload.service');

/**
 * @swagger
 * tags:
 *   name: Returns
 *   description: Buyer return requests and the seller/admin return workflow (Phase 16D)
 */

const createReturnRequest = asyncHandler(async (req, res) => {
  const request = await returnService.createReturnRequest(req.params.orderId, req.user, req.body);
  new ApiResponse(httpStatus.CREATED, { request }, 'Return request submitted.').send(res);
});

const uploadReturnAttachments = asyncHandler(async (req, res) => {
  const urls = await uploadAttachments(req.files);
  new ApiResponse(httpStatus.OK, { attachments: urls }, 'Attachments uploaded.').send(res);
});

const listMyReturnRequests = asyncHandler(async (req, res) => {
  const { page, limit } = req.query;
  const { items, meta } = await returnService.listMyReturnRequests(req.user.id, { page, limit });
  new ApiResponse(httpStatus.OK, { requests: items }, 'Return requests retrieved.', meta).send(res);
});

const getReturnRequest = asyncHandler(async (req, res) => {
  const request = await returnService.getReturnRequest(req.params.requestId, req.user);
  new ApiResponse(httpStatus.OK, { request }, 'Return request retrieved.').send(res);
});

const cancelReturnRequest = asyncHandler(async (req, res) => {
  const request = await returnService.cancelReturnRequest(req.params.requestId, req.user);
  new ApiResponse(httpStatus.OK, { request }, 'Return request cancelled.').send(res);
});

const addReturnShipping = asyncHandler(async (req, res) => {
  const request = await returnService.addReturnShipping(req.params.requestId, req.user, req.body);
  new ApiResponse(httpStatus.OK, { request }, 'Return shipping tracking added.').send(res);
});

const listForSeller = asyncHandler(async (req, res) => {
  const { page, limit } = req.query;
  const { items, meta } = await returnService.listForSeller(req.user.id, { page, limit });
  new ApiResponse(httpStatus.OK, { requests: items }, 'Return requests retrieved.', meta).send(res);
});

const approveReturnRequest = asyncHandler(async (req, res) => {
  const request = await returnService.approveReturnRequest(req.params.requestId, req.user, req.body.note);
  new ApiResponse(httpStatus.OK, { request }, 'Return request approved.').send(res);
});

const rejectReturnRequest = asyncHandler(async (req, res) => {
  const request = await returnService.rejectReturnRequest(req.params.requestId, req.user, req.body.note);
  new ApiResponse(httpStatus.OK, { request }, 'Return request rejected.').send(res);
});

const markReceived = asyncHandler(async (req, res) => {
  const request = await returnService.markReceived(req.params.requestId, req.user);
  new ApiResponse(httpStatus.OK, { request }, 'Return marked as received.').send(res);
});

const completeReturn = asyncHandler(async (req, res) => {
  const request = await returnService.completeReturn(req.params.requestId, req.user);
  new ApiResponse(httpStatus.OK, { request }, 'Return completed.').send(res);
});

const listAdminQueue = asyncHandler(async (req, res) => {
  const { page, limit, status } = req.query;
  const { items, meta } = await returnService.getAdminQueue({ page, limit, status });
  new ApiResponse(httpStatus.OK, { requests: items }, 'Return queue retrieved.', meta).send(res);
});

const getAdminOverview = asyncHandler(async (req, res) => {
  const overview = await returnService.getAdminOverview();
  new ApiResponse(httpStatus.OK, overview, 'Return overview retrieved.').send(res);
});

module.exports = {
  createReturnRequest,
  uploadReturnAttachments,
  listMyReturnRequests,
  getReturnRequest,
  cancelReturnRequest,
  addReturnShipping,
  listForSeller,
  approveReturnRequest,
  rejectReturnRequest,
  markReceived,
  completeReturn,
  listAdminQueue,
  getAdminOverview,
};
