# controllers/

Controllers are the HTTP boundary only: parse `req`, call a **service**,
shape an `ApiResponse`. No business logic and no direct Mongoose model
access here — that belongs in `services/` and `repositories/`.

```
routes  →  controllers  →  services  →  repositories  →  models
```

- **controllers/** — req/res handling, calls one or more services
- **services/** — business logic, orchestration, transactions
- **repositories/** — data access only (Mongoose queries), no business rules

`health.controller.js` (infrastructure) and `auth.controller.js` (Phase 2)
exist so far. Phase 3 adds `category.controller.js`,
`collection.controller.js`, `brand.controller.js`, `tag.controller.js`,
`license.controller.js`, and `product.controller.js` — **scaffolds
only**: every handler responds `501 Not Implemented`. They exist so the
route shape (and its validators/middleware slots) is in place ahead of
time, without exposing working admin/seller CRUD before that business
logic is built in a later phase.

Phase 5 adds `seller.controller.js` — working seller self-service
(apply, profile, verification document, dashboard) and admin approval
workflow (list/approve/reject/suspend/reinstate). Product ownership by
a seller stays out of scope here; only a read-only product count
breakdown is surfaced on the seller dashboard.
