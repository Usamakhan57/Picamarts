'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const { getPagination } = require('../utils/pagination');
const newsletterService = require('../services/newsletter.service');

/**
 * @swagger
 * tags:
 *   name: Newsletter
 *   description: Newsletter subscribe/unsubscribe + admin subscriber management (Phase 10.3, Part 5)
 */

/** Minimal, dependency-free CSV field escaping — wraps in quotes and doubles any embedded quote whenever the value contains a comma, quote, or newline. */
const csvField = (value) => {
  const str = String(value ?? '');
  return /[",\n]/.test(str) ? `"${str.replace(/"/g, '""')}"` : str;
};

/**
 * @swagger
 * /newsletter/subscribe:
 *   post:
 *     summary: Subscribe an email to the newsletter (public, no authentication required)
 *     tags: [Newsletter]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [email]
 *             properties:
 *               email: { type: string, format: email }
 *     responses:
 *       201: { description: Subscribed successfully }
 *       409: { description: This email is already subscribed }
 *       422: { description: Validation failed }
 */
const subscribe = asyncHandler(async (req, res) => {
  const { subscriber } = await newsletterService.subscribe(req.body.email);
  new ApiResponse(httpStatus.CREATED, { subscriber }, 'Subscribed to the newsletter successfully.').send(res);
});

/**
 * @swagger
 * /newsletter/unsubscribe:
 *   post:
 *     summary: Unsubscribe an email from the newsletter (public, no authentication required)
 *     tags: [Newsletter]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [email]
 *             properties:
 *               email: { type: string, format: email }
 *     responses:
 *       200: { description: Unsubscribed successfully }
 *       404: { description: No subscription found for this email }
 *       422: { description: Validation failed }
 */
const unsubscribe = asyncHandler(async (req, res) => {
  const subscriber = await newsletterService.unsubscribeByEmail(req.body.email);
  new ApiResponse(httpStatus.OK, { subscriber }, 'Unsubscribed from the newsletter successfully.').send(res);
});

/**
 * @swagger
 * /newsletter/unsubscribe/{token}:
 *   get:
 *     summary: One-click unsubscribe via the token emailed at subscribe time (public)
 *     tags: [Newsletter]
 *     parameters:
 *       - in: path
 *         name: token
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Unsubscribed successfully }
 *       400: { description: Invalid or already-used unsubscribe link }
 */
const unsubscribeByToken = asyncHandler(async (req, res) => {
  const subscriber = await newsletterService.unsubscribeByToken(req.params.token);
  new ApiResponse(httpStatus.OK, { subscriber }, 'Unsubscribed from the newsletter successfully.').send(res);
});

/**
 * @swagger
 * /newsletter/subscribers:
 *   get:
 *     summary: List newsletter subscribers (admin only)
 *     tags: [Newsletter]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: page
 *         schema: { type: integer }
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *       - in: query
 *         name: status
 *         schema: { type: string, enum: [subscribed, unsubscribed] }
 *     responses:
 *       200: { description: Paginated list of subscribers }
 *       401: { description: Authentication required }
 *       403: { description: Admin only }
 */
const listSubscribers = asyncHandler(async (req, res) => {
  const { page, limit } = getPagination(req.query);
  const filter = {};
  if (req.query.status) filter.status = req.query.status;

  const { items, meta } = await newsletterService.listSubscribers(filter, { page, limit });

  new ApiResponse(httpStatus.OK, { subscribers: items }, 'Subscribers retrieved successfully.', meta).send(res);
});

/**
 * @swagger
 * /newsletter/export:
 *   get:
 *     summary: Export newsletter subscribers as a CSV download (admin only)
 *     tags: [Newsletter]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: status
 *         schema: { type: string, enum: [subscribed, unsubscribed] }
 *     responses:
 *       200:
 *         description: CSV file
 *         content:
 *           text/csv:
 *             schema: { type: string }
 *       401: { description: Authentication required }
 *       403: { description: Admin only }
 */
const exportSubscribers = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.query.status) filter.status = req.query.status;

  const subscribers = await newsletterService.exportSubscribers(filter);

  const header = 'email,status,subscribedAt,unsubscribedAt';
  const rows = subscribers.map((s) =>
    [csvField(s.email), csvField(s.status), csvField(s.subscribedAt?.toISOString() ?? ''), csvField(s.unsubscribedAt?.toISOString() ?? '')].join(',')
  );
  const csv = [header, ...rows].join('\n');

  res.status(httpStatus.OK);
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="newsletter-subscribers-${Date.now()}.csv"`);
  res.send(csv);
});

module.exports = { subscribe, unsubscribe, unsubscribeByToken, listSubscribers, exportSubscribers };
