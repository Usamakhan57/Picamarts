'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const { getPagination } = require('../utils/pagination');
const { buildSortQuery } = require('../utils/sortHelper');
const { buildSearchQuery } = require('../utils/searchHelper');
const blogPostService = require('../services/blogPost.service');

/**
 * @swagger
 * tags:
 *   name: Blog
 *   description: Blog post management (Phase 10.3, Part 2)
 */

const SEARCH_FIELDS = ['title', 'excerpt', 'content'];
const SORT_FIELDS = ['title', 'publishedAt', 'createdAt', 'updatedAt'];

/**
 * @swagger
 * /blog:
 *   get:
 *     summary: List blog posts (public sees published only; admin sees everything)
 *     description: Supports free-text search (`q`), category/tag filtering, and pagination.
 *     tags: [Blog]
 *     parameters:
 *       - in: query
 *         name: page
 *         schema: { type: integer }
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *       - in: query
 *         name: q
 *         schema: { type: string }
 *       - in: query
 *         name: sort
 *         schema: { type: string }
 *       - in: query
 *         name: category
 *         schema: { type: string }
 *         description: Blog category id
 *       - in: query
 *         name: tag
 *         schema: { type: string }
 *       - in: query
 *         name: status
 *         schema: { type: string, enum: [draft, published] }
 *         description: Admin only in effect — non-admin callers always get published-only regardless of this value.
 *     responses:
 *       200: { description: Paginated list of blog posts }
 */
const list = asyncHandler(async (req, res) => {
  const { page, limit } = getPagination(req.query);
  const sort = buildSortQuery(req.query.sort, SORT_FIELDS, { publishedAt: -1 });
  const filter = { ...buildSearchQuery(req.query.q, SEARCH_FIELDS) };
  if (req.query.category) filter.category = req.query.category;
  if (req.query.tag) filter.tags = req.query.tag.toLowerCase();
  if (req.query.status) filter.status = req.query.status;

  const { items, meta } = await blogPostService.listPosts(filter, { page, limit, sort }, req.user);

  new ApiResponse(httpStatus.OK, { posts: items }, 'Blog posts retrieved successfully.', meta).send(res);
});

/**
 * @swagger
 * /blog/tags:
 *   get:
 *     summary: List distinct tags used across published posts, with post counts
 *     tags: [Blog]
 *     responses:
 *       200:
 *         description: Distinct tags
 *         content:
 *           application/json:
 *             example:
 *               success: true
 *               message: Tags retrieved successfully.
 *               data: { tags: [{ tag: "nodejs", count: 5 }, { tag: "mongodb", count: 3 }] }
 */
const listTags = asyncHandler(async (req, res) => {
  const tags = await blogPostService.listTags();
  new ApiResponse(httpStatus.OK, { tags }, 'Tags retrieved successfully.').send(res);
});

/**
 * @swagger
 * /blog/slug/{slug}:
 *   get:
 *     summary: Get a blog post by slug
 *     tags: [Blog]
 *     parameters:
 *       - in: path
 *         name: slug
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Blog post found }
 *       404: { description: Blog post not found (or not published, for non-admin callers) }
 */
const getBySlug = asyncHandler(async (req, res) => {
  const post = await blogPostService.getPostBySlug(req.params.slug, req.user ?? null);
  new ApiResponse(httpStatus.OK, { post }, 'Blog post retrieved successfully.').send(res);
});

/**
 * @swagger
 * /blog/slug/{slug}/related:
 *   get:
 *     summary: Get related posts (same category or overlapping tags) for a published post
 *     tags: [Blog]
 *     parameters:
 *       - in: path
 *         name: slug
 *         required: true
 *         schema: { type: string }
 *       - in: query
 *         name: limit
 *         schema: { type: integer, minimum: 1, maximum: 12 }
 *     responses:
 *       200: { description: Related posts }
 *       404: { description: Blog post not found or not published }
 */
const getRelated = asyncHandler(async (req, res) => {
  const posts = await blogPostService.getRelatedPosts(req.params.slug, req.query.limit);
  new ApiResponse(httpStatus.OK, { posts }, 'Related posts retrieved successfully.').send(res);
});

/**
 * @swagger
 * /blog/{id}:
 *   get:
 *     summary: Get a blog post by id
 *     tags: [Blog]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Blog post found }
 *       404: { description: Blog post not found (or not published, for non-admin callers) }
 */
const getById = asyncHandler(async (req, res) => {
  const post = await blogPostService.getPostById(req.params.id, req.user ?? null);
  new ApiResponse(httpStatus.OK, { post }, 'Blog post retrieved successfully.').send(res);
});

/**
 * @swagger
 * /blog:
 *   post:
 *     summary: Create a blog post (admin only)
 *     tags: [Blog]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       201: { description: Blog post created }
 *       409: { description: Slug already in use }
 *       422: { description: Validation failed }
 */
const create = asyncHandler(async (req, res) => {
  const post = await blogPostService.createPost(req.body, req.user);
  new ApiResponse(httpStatus.CREATED, { post }, 'Blog post created successfully.').send(res);
});

/**
 * @swagger
 * /blog/{id}:
 *   patch:
 *     summary: Update a blog post (admin only)
 *     tags: [Blog]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Blog post updated }
 *       404: { description: Blog post not found }
 *       409: { description: Slug already in use }
 */
const update = asyncHandler(async (req, res) => {
  const post = await blogPostService.updatePost(req.params.id, req.body, req.user);
  new ApiResponse(httpStatus.OK, { post }, 'Blog post updated successfully.').send(res);
});

/**
 * @swagger
 * /blog/{id}:
 *   delete:
 *     summary: Delete a blog post (admin only)
 *     tags: [Blog]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Blog post deleted }
 *       404: { description: Blog post not found }
 */
const remove = asyncHandler(async (req, res) => {
  await blogPostService.deletePost(req.params.id);
  new ApiResponse(httpStatus.OK, null, 'Blog post deleted successfully.').send(res);
});

module.exports = { list, listTags, getBySlug, getRelated, getById, create, update, remove };
