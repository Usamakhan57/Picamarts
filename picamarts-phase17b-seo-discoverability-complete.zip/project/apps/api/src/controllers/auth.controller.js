'use strict';

const config = require('../config');
const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const { getRefreshCookieOptions } = require('../utils/cookieOptions');
const authService = require('../services/auth.service');

const getRequestMeta = (req) => ({ userAgent: req.headers['user-agent'] || '', ip: req.ip });

/** Sets the httpOnly refresh-token cookie on the response. */
const setRefreshCookie = (res, refreshToken, maxAgeMs) => {
  res.cookie(config.jwt.refreshCookieName, refreshToken, getRefreshCookieOptions(maxAgeMs));
};

/** Clears the httpOnly refresh-token cookie. */
const clearRefreshCookie = (res) => {
  res.clearCookie(config.jwt.refreshCookieName, getRefreshCookieOptions(0));
};

/**
 * @swagger
 * /auth/register:
 *   post:
 *     summary: Register a new buyer or seller account
 *     tags: [Auth]
 */
const register = asyncHandler(async (req, res) => {
  const user = await authService.register(req.body);

  new ApiResponse(
    httpStatus.CREATED,
    { user },
    'Registration successful. Please check your email to verify your account.'
  ).send(res);
});

/**
 * @swagger
 * /auth/verify-email:
 *   post:
 *     summary: Verify an email address using the token from the verification email
 *     tags: [Auth]
 */
const verifyEmail = asyncHandler(async (req, res) => {
  const user = await authService.verifyEmail(req.body.token);

  new ApiResponse(httpStatus.OK, { user }, 'Email verified successfully.').send(res);
});

/**
 * @swagger
 * /auth/login:
 *   post:
 *     summary: Log in and receive an access token (refresh token set as an httpOnly cookie)
 *     tags: [Auth]
 */
const login = asyncHandler(async (req, res) => {
  const { user, accessToken, refreshToken, refreshMaxAgeMs } = await authService.login(req.body, getRequestMeta(req));

  setRefreshCookie(res, refreshToken, refreshMaxAgeMs);

  new ApiResponse(httpStatus.OK, { user, accessToken }, 'Login successful.').send(res);
});

/**
 * @swagger
 * /auth/logout:
 *   post:
 *     summary: Log out of the current session
 *     tags: [Auth]
 */
const logout = asyncHandler(async (req, res) => {
  const refreshToken = req.cookies?.[config.jwt.refreshCookieName];
  await authService.logout(refreshToken);
  clearRefreshCookie(res);

  new ApiResponse(httpStatus.OK, null, 'Logged out successfully.').send(res);
});

/**
 * @swagger
 * /auth/refresh:
 *   post:
 *     summary: Exchange a refresh token (cookie) for a new access + refresh token pair
 *     tags: [Auth]
 */
const refresh = asyncHandler(async (req, res) => {
  const incomingRefreshToken = req.cookies?.[config.jwt.refreshCookieName];

  const { user, accessToken, refreshToken, refreshMaxAgeMs } = await authService.refreshTokens(
    incomingRefreshToken,
    getRequestMeta(req)
  );

  setRefreshCookie(res, refreshToken, refreshMaxAgeMs);

  new ApiResponse(httpStatus.OK, { user, accessToken }, 'Token refreshed.').send(res);
});

/**
 * @swagger
 * /auth/forgot-password:
 *   post:
 *     summary: Request a password reset email
 *     tags: [Auth]
 */
const forgotPassword = asyncHandler(async (req, res) => {
  await authService.forgotPassword(req.body.email);

  new ApiResponse(httpStatus.OK, null, 'If an account with that email exists, a reset link has been sent.').send(res);
});

/**
 * @swagger
 * /auth/reset-password:
 *   post:
 *     summary: Reset a password using the token from the forgot-password email
 *     tags: [Auth]
 */
const resetPassword = asyncHandler(async (req, res) => {
  await authService.resetPassword(req.body.token, req.body.newPassword);

  new ApiResponse(httpStatus.OK, null, 'Password reset successfully. Please log in again.').send(res);
});

/**
 * @swagger
 * /auth/change-password:
 *   post:
 *     summary: Change the current user's password
 *     tags: [Auth]
 *     security: [{ bearerAuth: [] }]
 */
const changePassword = asyncHandler(async (req, res) => {
  await authService.changePassword(req.user.id, req.body.currentPassword, req.body.newPassword);
  clearRefreshCookie(res);

  new ApiResponse(httpStatus.OK, null, 'Password changed successfully. Please log in again.').send(res);
});

/**
 * @swagger
 * /auth/me:
 *   get:
 *     summary: Get the currently authenticated user
 *     tags: [Auth]
 *     security: [{ bearerAuth: [] }]
 */
const getMe = asyncHandler(async (req, res) => {
  const user = await authService.getCurrentUser(req.user.id);

  new ApiResponse(httpStatus.OK, { user }, 'Current user fetched.').send(res);
});

/**
 * @swagger
 * /auth/profile:
 *   patch:
 *     summary: Update the current user's profile (name, avatar)
 *     tags: [Auth]
 *     security: [{ bearerAuth: [] }]
 */
const updateProfile = asyncHandler(async (req, res) => {
  const user = await authService.updateProfile(req.user.id, req.body);

  new ApiResponse(httpStatus.OK, { user }, 'Profile updated successfully.').send(res);
});

module.exports = {
  register,
  verifyEmail,
  login,
  logout,
  refresh,
  forgotPassword,
  resetPassword,
  changePassword,
  getMe,
  updateProfile,
};
