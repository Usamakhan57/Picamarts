'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const cartService = require('../services/cart.service');

/**
 * Phase 7, Part 1 — Shopping Cart. Every endpoint here operates on the
 * AUTHENTICATED BUYER'S OWN cart — there's no buyer-id path param, the
 * cart is always "mine" (see routes/v1/cart.routes.js, gated to the
 * buyer role only).
 */

/**
 * @swagger
 * /cart:
 *   get:
 *     summary: Get the authenticated buyer's cart
 *     tags: [Cart]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200:
 *         description: The buyer's cart (empty shape if they don't have one yet)
 *         content:
 *           application/json:
 *             example:
 *               success: true
 *               message: Cart retrieved successfully.
 *               data:
 *                 cart:
 *                   id: 64f1a2b3c4d5e6f7a8b9c0d1
 *                   items:
 *                     - id: 64f1a2b3c4d5e6f7a8b9c0d2
 *                       product:
 *                         id: 64f1a2b3c4d5e6f7a8b9c0d3
 *                         title: Sample Product
 *                         basePrice: 29.99
 *                         salePrice: null
 *                         availableStock: 12
 *                       quantity: 2
 *                       unitPrice: 29.99
 *                       lineSubtotal: 59.98
 *                       lineDiscount: 0
 *                       lineTotal: 59.98
 *                       isAvailable: true
 *                   summary:
 *                     itemCount: 2
 *                     subtotal: 59.98
 *                     discount: 0
 *                     tax: 0
 *                     shipping: 0
 *                     grandTotal: 59.98
 *       401: { description: Authentication required }
 *       403: { description: Only buyers have a cart }
 */
const getCart = asyncHandler(async (req, res) => {
  const cart = await cartService.getCart(req.user.id);
  new ApiResponse(httpStatus.OK, { cart }, 'Cart retrieved successfully.').send(res);
});

/**
 * @swagger
 * /cart/items:
 *   post:
 *     summary: Add a product to the authenticated buyer's cart
 *     description: >
 *       If the product is already in the cart, the requested quantity
 *       is added to the existing line rather than creating a
 *       duplicate. Rejects deleted/draft/archived/out-of-stock
 *       products, and rejects a combined quantity greater than the
 *       product's currently available stock.
 *     tags: [Cart]
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [productId]
 *             properties:
 *               productId: { type: string }
 *               quantity: { type: integer, minimum: 1, default: 1 }
 *     responses:
 *       200: { description: Item added; the full updated cart is returned }
 *       400: { description: Product not published, out of stock, or requested quantity exceeds available stock }
 *       401: { description: Authentication required }
 *       403: { description: Only buyers can add to a cart }
 *       404: { description: Product not found }
 *       422: { description: Validation failed (missing/invalid productId or quantity) }
 */
const addItem = asyncHandler(async (req, res) => {
  const cart = await cartService.addItemToCart(req.user.id, req.body, req.user);
  new ApiResponse(httpStatus.OK, { cart }, 'Item added to cart successfully.').send(res);
});

/**
 * @swagger
 * /cart/items/{itemId}:
 *   patch:
 *     summary: Set a cart line's quantity (covers both increase and decrease)
 *     tags: [Cart]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: itemId
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [quantity]
 *             properties:
 *               quantity: { type: integer, minimum: 1 }
 *     responses:
 *       200: { description: Quantity updated; the full updated cart is returned }
 *       400: { description: Requested quantity exceeds available stock, or product no longer purchasable }
 *       401: { description: Authentication required }
 *       404: { description: Cart item not found }
 *       422: { description: Validation failed }
 */
const updateItemQuantity = asyncHandler(async (req, res) => {
  const cart = await cartService.updateItemQuantity(req.user.id, req.params.itemId, req.body.quantity, req.user);
  new ApiResponse(httpStatus.OK, { cart }, 'Cart item quantity updated successfully.').send(res);
});

/**
 * @swagger
 * /cart/items/{itemId}:
 *   delete:
 *     summary: Remove a single line from the authenticated buyer's cart
 *     tags: [Cart]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: itemId
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Item removed; the full updated cart is returned }
 *       401: { description: Authentication required }
 *       404: { description: Cart item not found }
 */
const removeItem = asyncHandler(async (req, res) => {
  const cart = await cartService.removeItem(req.user.id, req.params.itemId);
  new ApiResponse(httpStatus.OK, { cart }, 'Item removed from cart successfully.').send(res);
});

/**
 * @swagger
 * /cart:
 *   delete:
 *     summary: Clear the authenticated buyer's cart
 *     description: A buyer with no cart yet is treated as already-empty (returns an empty cart, not a 404).
 *     tags: [Cart]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Cart cleared }
 *       401: { description: Authentication required }
 */
const clearCart = asyncHandler(async (req, res) => {
  const cart = await cartService.clearCart(req.user.id);
  new ApiResponse(httpStatus.OK, { cart }, 'Cart cleared successfully.').send(res);
});

module.exports = { getCart, addItem, updateItemQuantity, removeItem, clearCart };
