'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const analyticsService = require('../services/analytics.service');
const { EXPORT_CONTENT_TYPES } = require('../utils/reportExport');

/**
 * Phase 11 — Analytics & Admin Reports.
 *
 * Pure request/response plumbing — authorization scoping (admin vs
 * seller-own-store) and every aggregation live in analytics.service.js
 * / analytics.repository.js. `req.user` is always present (every route
 * below sits behind `protect` + `authorize(ROLES.ADMIN, ROLES.SELLER)`
 * or `authorize(ROLES.ADMIN)` — see analytics.routes.js).
 */

/**
 * @swagger
 * tags:
 *   name: Analytics
 *   description: Admin/seller analytics dashboards and exportable reports (Phase 11)
 */

/**
 * @swagger
 * components:
 *   parameters:
 *     AnalyticsFrom:
 *       in: query
 *       name: from
 *       schema: { type: string }
 *       description: ISO date/datetime lower bound (inclusive)
 *     AnalyticsTo:
 *       in: query
 *       name: to
 *       schema: { type: string }
 *       description: ISO date/datetime upper bound (inclusive)
 *     AnalyticsSellerId:
 *       in: query
 *       name: sellerId
 *       schema: { type: string }
 *       description: Admin-only drill-down to one seller's store. Ignored for a seller caller — they are always scoped to their own store.
 */

/**
 * @swagger
 * /analytics/dashboard:
 *   get:
 *     summary: Admin dashboard totals — revenue, orders, customers, sellers, products (Part 1)
 *     description: Sellers receive the same shape scoped to their own store; `customers`/`sellers` are omitted for a seller caller (platform-wide concepts).
 *     tags: [Analytics]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - $ref: '#/components/parameters/AnalyticsFrom'
 *       - $ref: '#/components/parameters/AnalyticsTo'
 *       - $ref: '#/components/parameters/AnalyticsSellerId'
 *     responses:
 *       200: { description: Dashboard totals }
 *       401: { description: Authentication required }
 *       403: { description: Buyers may not access analytics }
 */
const getDashboard = asyncHandler(async (req, res) => {
  const data = await analyticsService.getDashboard(req.user, req.query);
  new ApiResponse(httpStatus.OK, data, 'Dashboard analytics retrieved successfully.').send(res);
});

/**
 * @swagger
 * /analytics/sales:
 *   get:
 *     summary: Chart-ready sales series — daily/weekly/monthly/yearly, or a custom date range (Part 2)
 *     tags: [Analytics]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: period
 *         schema: { type: string, enum: [daily, weekly, monthly, yearly, custom] }
 *       - $ref: '#/components/parameters/AnalyticsFrom'
 *       - $ref: '#/components/parameters/AnalyticsTo'
 *       - $ref: '#/components/parameters/AnalyticsSellerId'
 *     responses:
 *       200: { description: Sales series }
 *       401: { description: Authentication required }
 *       403: { description: Buyers may not access analytics }
 */
const getSales = asyncHandler(async (req, res) => {
  const data = await analyticsService.getSalesAnalytics(req.user, req.query);
  new ApiResponse(httpStatus.OK, data, 'Sales analytics retrieved successfully.').send(res);
});

/**
 * @swagger
 * /analytics/orders:
 *   get:
 *     summary: Orders by status/date, average order value, and refund rate (Part 3)
 *     tags: [Analytics]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: period
 *         schema: { type: string, enum: [daily, weekly, monthly, yearly, custom] }
 *       - $ref: '#/components/parameters/AnalyticsFrom'
 *       - $ref: '#/components/parameters/AnalyticsTo'
 *       - $ref: '#/components/parameters/AnalyticsSellerId'
 *     responses:
 *       200: { description: Order analytics }
 *       401: { description: Authentication required }
 *       403: { description: Buyers may not access analytics }
 */
const getOrders = asyncHandler(async (req, res) => {
  const data = await analyticsService.getOrderAnalytics(req.user, req.query);
  new ApiResponse(httpStatus.OK, data, 'Order analytics retrieved successfully.').send(res);
});

/**
 * @swagger
 * /analytics/revenue:
 *   get:
 *     summary: Revenue trend or breakdown by category/seller/product/payment method (Part 4)
 *     description: groupBy=seller and groupBy=payment_method are admin-only (403 for a seller caller).
 *     tags: [Analytics]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: groupBy
 *         schema: { type: string, enum: [trend, category, seller, product, payment_method] }
 *       - in: query
 *         name: period
 *         schema: { type: string, enum: [daily, weekly, monthly, yearly, custom] }
 *       - $ref: '#/components/parameters/AnalyticsFrom'
 *       - $ref: '#/components/parameters/AnalyticsTo'
 *       - $ref: '#/components/parameters/AnalyticsSellerId'
 *     responses:
 *       200: { description: Revenue analytics }
 *       401: { description: Authentication required }
 *       403: { description: Forbidden for this role/grouping }
 */
const getRevenue = asyncHandler(async (req, res) => {
  const data = await analyticsService.getRevenueAnalytics(req.user, req.query);
  new ApiResponse(httpStatus.OK, data, 'Revenue analytics retrieved successfully.').send(res);
});

/**
 * @swagger
 * /analytics/products:
 *   get:
 *     summary: Best-selling, most-viewed, highest-rated, low-stock, or out-of-stock products (Part 5)
 *     tags: [Analytics]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: type
 *         schema: { type: string, enum: [best_selling, most_viewed, highest_rated, low_stock, out_of_stock] }
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *       - $ref: '#/components/parameters/AnalyticsSellerId'
 *     responses:
 *       200: { description: Product analytics }
 *       401: { description: Authentication required }
 *       403: { description: Buyers may not access analytics }
 */
const getProducts = asyncHandler(async (req, res) => {
  const data = await analyticsService.getProductAnalytics(req.user, req.query);
  new ApiResponse(httpStatus.OK, data, 'Product analytics retrieved successfully.').send(res);
});

/**
 * @swagger
 * /analytics/sellers:
 *   get:
 *     summary: Seller performance leaderboard and growth trend (Part 6, admin only)
 *     tags: [Analytics]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - $ref: '#/components/parameters/AnalyticsSellerId'
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *       - in: query
 *         name: period
 *         schema: { type: string, enum: [daily, weekly, monthly, yearly, custom] }
 *     responses:
 *       200: { description: Seller analytics }
 *       401: { description: Authentication required }
 *       403: { description: Admins only }
 */
const getSellers = asyncHandler(async (req, res) => {
  const data = await analyticsService.getSellerAnalytics(req.user, req.query);
  new ApiResponse(httpStatus.OK, data, 'Seller analytics retrieved successfully.').send(res);
});

/**
 * @swagger
 * /analytics/customers:
 *   get:
 *     summary: New/returning customers, lifetime value, top buyers, purchase frequency (Part 7, admin only)
 *     tags: [Analytics]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: period
 *         schema: { type: string, enum: [daily, weekly, monthly, yearly, custom] }
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Customer analytics }
 *       401: { description: Authentication required }
 *       403: { description: Admins only }
 */
const getCustomers = asyncHandler(async (req, res) => {
  const data = await analyticsService.getCustomerAnalytics(req.user, req.query);
  new ApiResponse(httpStatus.OK, data, 'Customer analytics retrieved successfully.').send(res);
});

/**
 * @swagger
 * /analytics/payments:
 *   get:
 *     summary: Successful/failed/pending payments, refunds, Stripe revenue (Part 8, admin only)
 *     tags: [Analytics]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - $ref: '#/components/parameters/AnalyticsFrom'
 *       - $ref: '#/components/parameters/AnalyticsTo'
 *       - in: query
 *         name: paymentStatus
 *         schema: { type: string, enum: [pending, processing, succeeded, failed, cancelled] }
 *     responses:
 *       200: { description: Payment analytics }
 *       401: { description: Authentication required }
 *       403: { description: Admins only }
 */
const getPayments = asyncHandler(async (req, res) => {
  const data = await analyticsService.getPaymentAnalytics(req.user, req.query);
  new ApiResponse(httpStatus.OK, data, 'Payment analytics retrieved successfully.').send(res);
});

/**
 * @swagger
 * /analytics/reviews:
 *   get:
 *     summary: Average rating, distribution, most-reviewed products, reviews per seller (Part 9)
 *     tags: [Analytics]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - $ref: '#/components/parameters/AnalyticsFrom'
 *       - $ref: '#/components/parameters/AnalyticsTo'
 *       - $ref: '#/components/parameters/AnalyticsSellerId'
 *     responses:
 *       200: { description: Review analytics }
 *       401: { description: Authentication required }
 *       403: { description: Buyers may not access analytics }
 */
const getReviews = asyncHandler(async (req, res) => {
  const data = await analyticsService.getReviewAnalytics(req.user, req.query);
  new ApiResponse(httpStatus.OK, data, 'Review analytics retrieved successfully.').send(res);
});

/**
 * @swagger
 * /analytics/export:
 *   get:
 *     summary: Export a report as CSV, XLSX, or PDF (Part 10)
 *     description: >
 *       `report=sellers|customers|payments` are admin-only. Every other
 *       report is available to admins (unscoped) and sellers
 *       (auto-scoped to their own store). Accepts the same filters as
 *       the matching JSON endpoint (groupBy for revenue, type for
 *       products, period for time-series reports).
 *     tags: [Analytics]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: report
 *         required: true
 *         schema: { type: string, enum: [sales, orders, revenue, products, sellers, customers, payments, reviews] }
 *       - in: query
 *         name: format
 *         schema: { type: string, enum: [csv, xlsx, pdf], default: csv }
 *       - $ref: '#/components/parameters/AnalyticsFrom'
 *       - $ref: '#/components/parameters/AnalyticsTo'
 *       - $ref: '#/components/parameters/AnalyticsSellerId'
 *     responses:
 *       200:
 *         description: File download
 *         content:
 *           text/csv: { schema: { type: string } }
 *           application/vnd.openxmlformats-officedocument.spreadsheetml.sheet: { schema: { type: string, format: binary } }
 *           application/pdf: { schema: { type: string, format: binary } }
 *       401: { description: Authentication required }
 *       403: { description: Forbidden for this role/report }
 *       422: { description: Validation failed }
 */
const exportReport = asyncHandler(async (req, res) => {
  const { format } = req.query;
  const { filename, buffer } = await analyticsService.exportReport(req.user, req.query);

  res.status(httpStatus.OK);
  res.setHeader('Content-Type', EXPORT_CONTENT_TYPES[format]);
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  res.send(buffer);
});

/**
 * @swagger
 * /analytics/categories:
 *   get:
 *     summary: Trending categories — recently published products ranked by combined views/sales, grouped by category (Phase 17A.2)
 *     tags: [Analytics]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: windowDays
 *         schema: { type: integer }
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Trending categories }
 */
const getCategories = asyncHandler(async (req, res) => {
  const data = await analyticsService.getCategoryAnalytics(req.user, req.query);
  new ApiResponse(httpStatus.OK, data, 'Category analytics retrieved successfully.').send(res);
});

/**
 * @swagger
 * /analytics/brands:
 *   get:
 *     summary: Trending brands — same heuristic as /analytics/categories, grouped by brand (Phase 17A.2)
 *     tags: [Analytics]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: windowDays
 *         schema: { type: integer }
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Trending brands }
 */
const getBrands = asyncHandler(async (req, res) => {
  const data = await analyticsService.getBrandAnalytics(req.user, req.query);
  new ApiResponse(httpStatus.OK, data, 'Brand analytics retrieved successfully.').send(res);
});

/**
 * @swagger
 * /analytics/search:
 *   get:
 *     summary: Most-searched terms across every buyer's search history (Phase 17A.2, admin only)
 *     tags: [Analytics]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Search analytics }
 *       403: { description: Admins only }
 */
const getSearch = asyncHandler(async (req, res) => {
  const data = await analyticsService.getSearchAnalytics(req.user, req.query);
  new ApiResponse(httpStatus.OK, data, 'Search analytics retrieved successfully.').send(res);
});

module.exports = {
  getDashboard,
  getSales,
  getOrders,
  getRevenue,
  getProducts,
  getSellers,
  getCustomers,
  getPayments,
  getReviews,
  getCategories,
  getBrands,
  getSearch,
  exportReport,
};
