'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const digitalDeliveryService = require('../services/digitalDelivery.service');

/**
 * Phase 14.1 — Digital Product Delivery. Ownership/authorization
 * nuances (buyer: own downloads only; seller: their own products'
 * deliveries/logs only; admin: everything) are enforced in
 * digitalDelivery.service.js — this file is pure request/response
 * plumbing, same convention every other controller in this codebase
 * follows.
 */

/**
 * @swagger
 * /downloads:
 *   get:
 *     summary: List the authenticated buyer's own digital deliveries ("My Downloads")
 *     tags: [Digital Delivery]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: The buyer's downloads, each with its files, license key (if any), usage, and expiry }
 *       401: { description: Authentication required }
 */
const listMyDownloads = asyncHandler(async (req, res) => {
  const downloads = await digitalDeliveryService.listMyDownloads(req.user.id);
  new ApiResponse(httpStatus.OK, { downloads }, 'Downloads retrieved successfully.').send(res);
});

/**
 * @swagger
 * /downloads/{downloadId}/files/{fileId}:
 *   get:
 *     summary: Redeem a signed, short-lived download URL for one purchased file
 *     description: >
 *       Part 4/5/15 — Purchase Validation + Secure Downloads. Rejects
 *       (403) if the caller doesn't own the download, (403) if revoked,
 *       (400) if expired or the download limit has been reached. On
 *       success, the returned URL is a Cloudinary-signed link valid for
 *       a short window — never the raw, permanently-public file URL.
 *     tags: [Digital Delivery]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: downloadId
 *         required: true
 *         schema: { type: string }
 *       - in: path
 *         name: fileId
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: A short-lived signed download URL }
 *       400: { description: Download link expired, or download limit reached }
 *       401: { description: Authentication required }
 *       403: { description: Not the download's owner, or access has been revoked }
 *       404: { description: Download or file not found }
 */
const redeemDownload = asyncHandler(async (req, res) => {
  const result = await digitalDeliveryService.redeemDownload(req.params.downloadId, req.params.fileId, req.user, {
    ipAddress: req.ip,
    userAgent: req.headers['user-agent'] || '',
  });
  new ApiResponse(httpStatus.OK, result, 'Download link generated.').send(res);
});

/**
 * @swagger
 * /downloads/{downloadId}/revoke:
 *   patch:
 *     summary: Revoke a buyer's access to a digital delivery (admin any; seller their own product's only)
 *     tags: [Digital Delivery]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: downloadId
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       required: false
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               reason: { type: string }
 *     responses:
 *       200: { description: Download revoked }
 *       403: { description: Not permitted to manage this download }
 *       404: { description: Download not found }
 */
const revokeDownload = asyncHandler(async (req, res) => {
  const download = await digitalDeliveryService.revokeDownload(req.params.downloadId, req.body.reason, req.user);
  new ApiResponse(httpStatus.OK, { download }, 'Download revoked.').send(res);
});

/**
 * @swagger
 * /downloads/{downloadId}/reinstate:
 *   patch:
 *     summary: Reverse a revocation (admin only)
 *     tags: [Digital Delivery]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: downloadId
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Download reinstated }
 *       403: { description: Admin only }
 *       404: { description: Download not found }
 */
const reinstateDownload = asyncHandler(async (req, res) => {
  const download = await digitalDeliveryService.reinstateDownload(req.params.downloadId, req.user);
  new ApiResponse(httpStatus.OK, { download }, 'Download reinstated.').send(res);
});

/**
 * @swagger
 * /downloads/stats:
 *   get:
 *     summary: Download/delivery statistics per product (seller sees their own; admin sees everything)
 *     tags: [Digital Delivery]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Per-product totalPurchases/totalDownloads/revoked counts }
 *       403: { description: Buyers cannot access this endpoint }
 */
const getDeliveryStats = asyncHandler(async (req, res) => {
  const stats = await digitalDeliveryService.getDeliveryStats(req.user);
  new ApiResponse(httpStatus.OK, { stats }, 'Delivery statistics retrieved successfully.').send(res);
});

/**
 * @swagger
 * /downloads/deliveries:
 *   get:
 *     summary: List digital deliveries (seller sees their own products'; admin sees everything)
 *     tags: [Digital Delivery]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Paginated Download records }
 *       403: { description: Buyers cannot access this endpoint }
 */
const listDeliveries = asyncHandler(async (req, res) => {
  const { items, meta } = await digitalDeliveryService.listDeliveries(req.query, req.user);
  new ApiResponse(httpStatus.OK, { deliveries: items }, 'Deliveries retrieved successfully.', meta).send(res);
});

/**
 * @swagger
 * /downloads/logs:
 *   get:
 *     summary: Download redemption history (Part 12) — seller needs a downloadId scoped to their own product; admin sees everything, optionally filtered
 *     tags: [Digital Delivery]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Paginated download log entries (user, product, file, ip, user agent, timestamp) }
 *       403: { description: Not permitted, or a seller omitted the required downloadId filter }
 */
const listDownloadLogs = asyncHandler(async (req, res) => {
  const { items, meta } = await digitalDeliveryService.listDownloadLogs(req.query, req.user);
  new ApiResponse(httpStatus.OK, { logs: items }, 'Download logs retrieved successfully.', meta).send(res);
});

module.exports = {
  listMyDownloads,
  redeemDownload,
  revokeDownload,
  reinstateDownload,
  getDeliveryStats,
  listDeliveries,
  listDownloadLogs,
};
