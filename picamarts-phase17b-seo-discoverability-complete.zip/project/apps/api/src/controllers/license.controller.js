'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const { getPagination } = require('../utils/pagination');
const { buildSortQuery } = require('../utils/sortHelper');
const { buildSearchQuery } = require('../utils/searchHelper');
const licenseService = require('../services/license.service');

/** Phase 4 — Admin marketplace management. Public reads, admin-only writes. */

const SEARCH_FIELDS = ['name', 'description'];
const SORT_FIELDS = ['name', 'priceMultiplier', 'createdAt', 'updatedAt'];

/**
 * @swagger
 * /licenses:
 *   get:
 *     summary: List licenses (paginated, searchable, filterable, sortable)
 *     tags: [Licenses]
 *     parameters:
 *       - in: query
 *         name: page
 *         schema: { type: integer }
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *       - in: query
 *         name: q
 *         schema: { type: string }
 *       - in: query
 *         name: sort
 *         schema: { type: string }
 *       - in: query
 *         name: active
 *         schema: { type: boolean }
 *     responses:
 *       200: { description: Paginated list of licenses }
 */
const list = asyncHandler(async (req, res) => {
  const { page, limit } = getPagination(req.query);
  const sort = buildSortQuery(req.query.sort, SORT_FIELDS);
  const filter = { ...buildSearchQuery(req.query.q, SEARCH_FIELDS) };

  if (req.query.active !== undefined) filter.active = req.query.active;

  const { items, meta } = await licenseService.listLicenses(filter, { page, limit, sort });

  new ApiResponse(httpStatus.OK, { licenses: items }, 'Licenses retrieved successfully.', meta).send(res);
});

/**
 * @swagger
 * /licenses/{id}:
 *   get:
 *     summary: Get a license by id
 *     tags: [Licenses]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: License found }
 *       404: { description: License not found }
 */
const getById = asyncHandler(async (req, res) => {
  const license = await licenseService.getLicenseById(req.params.id);
  new ApiResponse(httpStatus.OK, { license }, 'License retrieved successfully.').send(res);
});

/**
 * @swagger
 * /licenses:
 *   post:
 *     summary: Create a license (admin only) — e.g. Personal, Commercial, Extended Commercial
 *     tags: [Licenses]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       201: { description: License created }
 *       409: { description: A license with this name already exists }
 *       422: { description: Validation failed }
 */
const create = asyncHandler(async (req, res) => {
  const license = await licenseService.createLicense(req.body);
  new ApiResponse(httpStatus.CREATED, { license }, 'License created successfully.').send(res);
});

/**
 * @swagger
 * /licenses/{id}:
 *   patch:
 *     summary: Update a license (admin only)
 *     tags: [Licenses]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: License updated }
 *       404: { description: License not found }
 */
const update = asyncHandler(async (req, res) => {
  const license = await licenseService.updateLicense(req.params.id, req.body);
  new ApiResponse(httpStatus.OK, { license }, 'License updated successfully.').send(res);
});

/**
 * @swagger
 * /licenses/{id}:
 *   delete:
 *     summary: Delete a license (admin only)
 *     tags: [Licenses]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: License deleted }
 *       404: { description: License not found }
 */
const remove = asyncHandler(async (req, res) => {
  await licenseService.deleteLicense(req.params.id);
  new ApiResponse(httpStatus.OK, null, 'License deleted successfully.').send(res);
});

/**
 * @swagger
 * /licenses/{id}/toggle-active:
 *   patch:
 *     summary: Toggle a license's active/inactive status (admin only)
 *     tags: [Licenses]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Status toggled }
 *       404: { description: License not found }
 */
const toggleActive = asyncHandler(async (req, res) => {
  const current = await licenseService.getLicenseById(req.params.id);
  const license = await licenseService.updateLicense(req.params.id, { active: !current.active });

  new ApiResponse(
    httpStatus.OK,
    { license },
    `License ${license.active ? 'activated' : 'deactivated'} successfully.`
  ).send(res);
});

module.exports = { list, getById, create, update, remove, toggleActive };
