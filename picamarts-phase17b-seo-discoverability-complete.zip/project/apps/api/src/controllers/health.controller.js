'use strict';

const mongoose = require('mongoose');
const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const config = require('../config');
const { isRedisReady } = require('../config/redis');

const MONGOOSE_STATES = ['disconnected', 'connected', 'connecting', 'disconnecting'];

/** Bytes → MB, rounded to 1 decimal, for a human-readable memory report. */
const toMB = (bytes) => Math.round((bytes / 1024 / 1024) * 10) / 10;

const getMemoryUsage = () => {
  const mem = process.memoryUsage();
  return {
    rssMB: toMB(mem.rss),
    heapUsedMB: toMB(mem.heapUsed),
    heapTotalMB: toMB(mem.heapTotal),
    externalMB: toMB(mem.external),
  };
};

/** Redis status block reused by every health endpoint below. */
const getRedisStatus = () => {
  if (!config.redis.enabled) return { enabled: false, status: 'disabled' };
  return { enabled: true, status: isRedisReady() ? 'connected' : 'disconnected' };
};

/** Queue status block. Queues share the Redis connection, so "ready" tracks Redis readiness directly. */
const getQueueStatus = () => {
  if (!config.queue.enabled) return { enabled: false, status: 'disabled' };
  return { enabled: true, status: isRedisReady() ? 'connected' : 'disconnected' };
};

const getDatabaseStatus = () => MONGOOSE_STATES[mongoose.connection.readyState] || 'unknown';

/**
 * @swagger
 * /health:
 *   get:
 *     summary: Health check
 *     description: Reports process uptime, memory usage, and the connection state of every backing service (database, Redis, queues). Used by uptime monitors and load balancers.
 *     tags: [System]
 *     responses:
 *       200:
 *         description: Service is up.
 */
const getHealth = asyncHandler(async (req, res) => {
  const payload = {
    status: 'ok',
    uptimeSeconds: Math.round(process.uptime()),
    timestamp: new Date().toISOString(),
    database: getDatabaseStatus(),
    redis: getRedisStatus(),
    queue: getQueueStatus(),
    memory: getMemoryUsage(),
  };

  new ApiResponse(httpStatus.OK, payload, 'Service is healthy').send(res);
});

/**
 * @swagger
 * /health/live:
 *   get:
 *     summary: Liveness probe
 *     description: >
 *       Answers only "is this process alive and able to handle a request" —
 *       deliberately does NOT check the database or Redis, so a slow/down
 *       dependency never causes an orchestrator (Docker/Kubernetes) to
 *       restart an otherwise-healthy process. Pair with /health/ready for
 *       "should traffic be routed here".
 *     tags: [System]
 *     responses:
 *       200: { description: Process is alive. }
 */
const getLiveness = asyncHandler(async (req, res) => {
  new ApiResponse(httpStatus.OK, { status: 'alive', uptimeSeconds: Math.round(process.uptime()) }, 'Process is alive').send(
    res
  );
});

/**
 * @swagger
 * /health/ready:
 *   get:
 *     summary: Readiness probe
 *     description: >
 *       Answers "should traffic be routed to this instance right now" —
 *       checks the database connection (required) and Redis (only if
 *       configured; a Redis-less deployment is still considered ready,
 *       since every Redis-backed feature in this app degrades gracefully
 *       without it). Returns 503 while not ready so a load balancer stops
 *       sending traffic here without killing the process.
 *     tags: [System]
 *     responses:
 *       200: { description: Ready to receive traffic. }
 *       503: { description: Not ready — a required dependency is unavailable. }
 */
const getReadiness = asyncHandler(async (req, res) => {
  const databaseReady = mongoose.connection.readyState === 1;
  const redisStatus = getRedisStatus();
  // Redis is optional infrastructure — only fails readiness if it's
  // configured (enabled) but not actually connected.
  const redisReady = !redisStatus.enabled || redisStatus.status === 'connected';

  const ready = databaseReady && redisReady;
  const payload = {
    status: ready ? 'ready' : 'not_ready',
    database: getDatabaseStatus(),
    redis: redisStatus,
    queue: getQueueStatus(),
  };

  new ApiResponse(ready ? httpStatus.OK : httpStatus.SERVICE_UNAVAILABLE, payload, ready ? 'Ready' : 'Not ready').send(res);
});

module.exports = { getHealth, getLiveness, getReadiness };
