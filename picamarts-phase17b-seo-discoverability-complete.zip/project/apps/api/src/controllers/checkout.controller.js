'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const checkoutService = require('../services/checkout.service');

/**
 * Phase 8, Part 1 — Checkout. Both endpoints operate on the
 * AUTHENTICATED BUYER'S OWN cart (see routes/v1/checkout.routes.js,
 * gated to the buyer role only — same reasoning as Cart/Wishlist).
 */

/**
 * @swagger
 * /checkout/summary:
 *   get:
 *     summary: Preview the authenticated buyer's checkout readiness
 *     description: >
 *       Always succeeds — even for an empty or problem-laden cart —
 *       so the UI can show the cart alongside WHY checkout isn't
 *       available yet (`canCheckout: false` with `blockingIssues`),
 *       the same way GET /cart shows stale lines without blocking.
 *     tags: [Checkout]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200:
 *         description: Checkout preview
 *         content:
 *           application/json:
 *             examples:
 *               ready:
 *                 summary: Cart is ready to check out
 *                 value:
 *                   success: true
 *                   message: Checkout summary retrieved successfully.
 *                   data:
 *                     checkout:
 *                       items:
 *                         - id: 64f1a2b3c4d5e6f7a8b9c0d2
 *                           product: { id: 64f1a2b3c4d5e6f7a8b9c0d3, title: Sample Product, availableStock: 8 }
 *                           quantity: 2
 *                           unitPrice: 29.99
 *                           lineSubtotal: 59.98
 *                           lineDiscount: 0
 *                           lineTotal: 59.98
 *                           isAvailable: true
 *                       summary: { itemCount: 2, subtotal: 59.98, discount: 0, tax: 0, shipping: 0, grandTotal: 59.98 }
 *                       canCheckout: true
 *                       blockingIssues: []
 *               blocked:
 *                 summary: Cart has an issue blocking checkout
 *                 value:
 *                   success: true
 *                   message: Checkout summary retrieved successfully.
 *                   data:
 *                     checkout:
 *                       items: []
 *                       summary: { itemCount: 0, subtotal: 0, discount: 0, tax: 0, shipping: 0, grandTotal: 0 }
 *                       canCheckout: false
 *                       blockingIssues: ['Your cart is empty.']
 *       401: { description: Authentication required }
 *       403: { description: Only buyers can check out }
 */
const getSummary = asyncHandler(async (req, res) => {
  const checkout = await checkoutService.getCheckoutSummary(req.user.id);
  new ApiResponse(httpStatus.OK, { checkout }, 'Checkout summary retrieved successfully.').send(res);
});

/**
 * @swagger
 * /checkout:
 *   post:
 *     summary: Validate and price the authenticated buyer's cart for checkout, locking current prices
 *     description: >
 *       Rejects (400) with every blocking issue if the cart is empty,
 *       or contains a draft/archived/deleted/out-of-stock product, or
 *       a quantity exceeding available stock. On success, returns the
 *       priced, locked summary the client proceeds to POST /orders
 *       with (Phase 8, Part 2).
 *     tags: [Checkout]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200:
 *         description: Cart is checkout-ready; the locked summary is returned
 *         content:
 *           application/json:
 *             example:
 *               success: true
 *               message: Checkout summary locked successfully.
 *               data:
 *                 checkout:
 *                   items:
 *                     - id: 64f1a2b3c4d5e6f7a8b9c0d2
 *                       product: { id: 64f1a2b3c4d5e6f7a8b9c0d3, title: Sample Product }
 *                       quantity: 2
 *                       lockedPrice: 29.99
 *                       lineSubtotal: 59.98
 *                       lineDiscount: 0
 *                       lineTotal: 59.98
 *                   summary: { itemCount: 2, subtotal: 59.98, discount: 0, tax: 0, shipping: 0, grandTotal: 59.98 }
 *                   lockedAt: '2026-07-23T10:00:00.000Z'
 *       400:
 *         description: Cart isn't checkout-ready
 *         content:
 *           application/json:
 *             example:
 *               success: false
 *               message: Cart is not ready for checkout.
 *               details: ['Your cart is empty.']
 *       401: { description: Authentication required }
 *       403: { description: Only buyers can check out }
 */
const checkout = asyncHandler(async (req, res) => {
  const checkoutSummary = await checkoutService.checkout(req.user.id);
  new ApiResponse(httpStatus.OK, { checkout: checkoutSummary }, 'Checkout summary locked successfully.').send(res);
});

/**
 * @swagger
 * /checkout/shipping:
 *   post:
 *     summary: Estimate available shipping methods/costs for the buyer's current cart against a destination
 *     description: >
 *       Phase 14.2, Part 5. A preview only — digital-only carts return
 *       shippingRequired:false immediately; physical items without an
 *       assigned ShippingProfile are listed under unconfiguredItems
 *       rather than silently priced at zero.
 *     tags: [Checkout]
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               country: { type: string }
 *               state: { type: string }
 *     responses:
 *       200: { description: Available shipping methods, cost, and estimated delivery windows }
 *       401: { description: Authentication required }
 */
const estimateShipping = asyncHandler(async (req, res) => {
  const estimate = await checkoutService.estimateShipping(req.user.id, req.body);
  new ApiResponse(httpStatus.OK, estimate, 'Shipping estimate calculated successfully.').send(res);
});

module.exports = { getSummary, checkout, estimateShipping };
