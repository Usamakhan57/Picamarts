'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const disputeService = require('../services/dispute.service');
const { uploadAttachments } = require('../services/attachmentUpload.service');

/**
 * @swagger
 * tags:
 *   name: Disputes
 *   description: Stripe chargeback synchronization and the marketplace Dispute Center (Phase 16D)
 */

const openDispute = asyncHandler(async (req, res) => {
  const dispute = await disputeService.openBuyerDispute(req.params.orderId, req.user, req.body);
  new ApiResponse(httpStatus.CREATED, { dispute }, 'Dispute opened.').send(res);
});

const uploadEvidenceAttachments = asyncHandler(async (req, res) => {
  const urls = await uploadAttachments(req.files);
  new ApiResponse(httpStatus.OK, { attachments: urls }, 'Attachments uploaded.').send(res);
});

const addEvidence = asyncHandler(async (req, res) => {
  const dispute = await disputeService.addEvidence(req.params.disputeId, req.user, req.body);
  new ApiResponse(httpStatus.OK, { dispute }, 'Evidence submitted.').send(res);
});

const getDispute = asyncHandler(async (req, res) => {
  const dispute = await disputeService.getDispute(req.params.disputeId, req.user);
  new ApiResponse(httpStatus.OK, { dispute }, 'Dispute retrieved.').send(res);
});

const listMine = asyncHandler(async (req, res) => {
  const { page, limit } = req.query;
  const { items, meta } = await disputeService.listMine(req.user, { page, limit });
  new ApiResponse(httpStatus.OK, { disputes: items }, 'Disputes retrieved.', meta).send(res);
});

const listAdminQueue = asyncHandler(async (req, res) => {
  const { page, limit, status } = req.query;
  const { items, meta } = await disputeService.getAdminQueue({ page, limit, status });
  new ApiResponse(httpStatus.OK, { disputes: items }, 'Dispute queue retrieved.', meta).send(res);
});

const getAdminOverview = asyncHandler(async (req, res) => {
  const overview = await disputeService.getAdminOverview();
  new ApiResponse(httpStatus.OK, overview, 'Dispute overview retrieved.').send(res);
});

const markUnderReview = asyncHandler(async (req, res) => {
  const dispute = await disputeService.markUnderReview(req.params.disputeId, req.user, req.body.note);
  new ApiResponse(httpStatus.OK, { dispute }, 'Dispute marked under review.').send(res);
});

const resolveDispute = asyncHandler(async (req, res) => {
  const dispute = await disputeService.resolveDispute(req.params.disputeId, req.user, req.body.outcome, req.body.note);
  new ApiResponse(httpStatus.OK, { dispute }, 'Dispute resolved.').send(res);
});

const closeDispute = asyncHandler(async (req, res) => {
  const dispute = await disputeService.closeDispute(req.params.disputeId, req.user, req.body.note);
  new ApiResponse(httpStatus.OK, { dispute }, 'Dispute closed.').send(res);
});

module.exports = {
  openDispute,
  uploadEvidenceAttachments,
  addEvidence,
  getDispute,
  listMine,
  listAdminQueue,
  getAdminOverview,
  markUnderReview,
  resolveDispute,
  closeDispute,
};
