'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const wishlistService = require('../services/wishlist.service');

/**
 * Phase 17A.2, Part 2 — Wishlist Enhancements. Mounted at `/wishlists`
 * (plural — see routes/v1/wishlists.routes.js), distinct from the
 * pre-existing singular `/wishlist` (wishlist.controller.js, Phase 7)
 * which continues to operate on the buyer's default wishlist only and
 * is completely unchanged. Both controllers share the same
 * wishlist.service.js — this file just exposes the multi-wishlist
 * functions that file already has.
 *
 * Every route except GET /wishlists/shared/:token requires
 * authentication and is buyer-only (see routes/v1/wishlists.routes.js)
 * — ownership itself is enforced inside the service (404, never 403,
 * on a wishlist that isn't the caller's).
 */

const list = asyncHandler(async (req, res) => {
  const wishlists = await wishlistService.listWishlists(req.user.id);
  new ApiResponse(httpStatus.OK, { wishlists }, 'Wishlists retrieved successfully.').send(res);
});

const create = asyncHandler(async (req, res) => {
  const wishlist = await wishlistService.createWishlist(req.user.id, req.body);
  new ApiResponse(httpStatus.CREATED, { wishlist }, 'Wishlist created successfully.').send(res);
});

const getById = asyncHandler(async (req, res) => {
  const wishlist = await wishlistService.getWishlistById(req.user.id, req.params.id);
  new ApiResponse(httpStatus.OK, { wishlist }, 'Wishlist retrieved successfully.').send(res);
});

const rename = asyncHandler(async (req, res) => {
  const wishlist = await wishlistService.renameWishlist(req.user.id, req.params.id, req.body);
  new ApiResponse(httpStatus.OK, { wishlist }, 'Wishlist updated successfully.').send(res);
});

const setVisibility = asyncHandler(async (req, res) => {
  const wishlist = await wishlistService.setVisibility(req.user.id, req.params.id, req.body.isPublic);
  new ApiResponse(httpStatus.OK, { wishlist }, 'Wishlist visibility updated successfully.').send(res);
});

const remove = asyncHandler(async (req, res) => {
  await wishlistService.deleteWishlist(req.user.id, req.params.id);
  new ApiResponse(httpStatus.OK, null, 'Wishlist deleted successfully.').send(res);
});

/** Public — no auth. A wrong/expired/unpublished token 404s (see wishlist.service.js#getSharedWishlist). */
const getShared = asyncHandler(async (req, res) => {
  const wishlist = await wishlistService.getSharedWishlist(req.params.token);
  new ApiResponse(httpStatus.OK, { wishlist }, 'Shared wishlist retrieved successfully.').send(res);
});

const addItem = asyncHandler(async (req, res) => {
  const wishlist = await wishlistService.addItemToWishlist(req.user.id, req.params.id, req.body.productId, req.user);
  new ApiResponse(httpStatus.OK, { wishlist }, 'Product added to wishlist successfully.').send(res);
});

const removeItem = asyncHandler(async (req, res) => {
  const wishlist = await wishlistService.removeItemFromWishlist(req.user.id, req.params.id, req.params.productId);
  new ApiResponse(httpStatus.OK, { wishlist }, 'Product removed from wishlist successfully.').send(res);
});

const moveItem = asyncHandler(async (req, res) => {
  const result = await wishlistService.moveItem(req.user.id, req.params.id, req.body.productId, req.body.toWishlistId);
  new ApiResponse(httpStatus.OK, result, 'Product moved successfully.').send(res);
});

const getAnalytics = asyncHandler(async (req, res) => {
  const analytics = await wishlistService.getWishlistAnalytics(req.user.id, req.params.id);
  new ApiResponse(httpStatus.OK, analytics, 'Wishlist analytics retrieved successfully.').send(res);
});

module.exports = { list, create, getById, rename, setVisibility, remove, getShared, addItem, removeItem, moveItem, getAnalytics };
