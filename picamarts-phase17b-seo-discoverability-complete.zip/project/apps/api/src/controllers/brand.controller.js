'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const { getPagination } = require('../utils/pagination');
const { buildSortQuery } = require('../utils/sortHelper');
const { buildSearchQuery } = require('../utils/searchHelper');
const brandService = require('../services/brand.service');

/** Phase 4 — Admin marketplace management. Public reads, admin-only writes. */

const SEARCH_FIELDS = ['name', 'description'];
const SORT_FIELDS = ['name', 'createdAt', 'updatedAt'];

/**
 * @swagger
 * /brands:
 *   get:
 *     summary: List brands (paginated, searchable, filterable, sortable)
 *     tags: [Brands]
 *     parameters:
 *       - in: query
 *         name: page
 *         schema: { type: integer }
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *       - in: query
 *         name: q
 *         schema: { type: string }
 *       - in: query
 *         name: sort
 *         schema: { type: string }
 *       - in: query
 *         name: featured
 *         schema: { type: boolean }
 *       - in: query
 *         name: active
 *         schema: { type: boolean }
 *     responses:
 *       200: { description: Paginated list of brands }
 */
const list = asyncHandler(async (req, res) => {
  const { page, limit } = getPagination(req.query);
  const sort = buildSortQuery(req.query.sort, SORT_FIELDS);
  const filter = { ...buildSearchQuery(req.query.q, SEARCH_FIELDS) };

  if (req.query.featured !== undefined) filter.featured = req.query.featured;
  if (req.query.active !== undefined) filter.active = req.query.active;

  const { items, meta } = await brandService.listBrands(filter, { page, limit, sort });

  new ApiResponse(httpStatus.OK, { brands: items }, 'Brands retrieved successfully.', meta).send(res);
});

/**
 * @swagger
 * /brands/{id}:
 *   get:
 *     summary: Get a brand by id
 *     tags: [Brands]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Brand found }
 *       404: { description: Brand not found }
 */
const getById = asyncHandler(async (req, res) => {
  const brand = await brandService.getBrandById(req.params.id);
  new ApiResponse(httpStatus.OK, { brand }, 'Brand retrieved successfully.').send(res);
});

/**
 * @swagger
 * /brands/slug/{slug}:
 *   get:
 *     summary: Get a brand by slug
 *     tags: [Brands]
 *     parameters:
 *       - in: path
 *         name: slug
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Brand found }
 *       404: { description: Brand not found }
 */
const getBySlug = asyncHandler(async (req, res) => {
  const brand = await brandService.getBrandBySlug(req.params.slug);
  new ApiResponse(httpStatus.OK, { brand }, 'Brand retrieved successfully.').send(res);
});

/**
 * @swagger
 * /brands:
 *   post:
 *     summary: Create a brand (admin only). Logo is uploaded separately via the existing Cloudinary helper and passed as { url, publicId }.
 *     tags: [Brands]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       201: { description: Brand created }
 *       422: { description: Validation failed (e.g. invalid website URL) }
 */
const create = asyncHandler(async (req, res) => {
  const brand = await brandService.createBrand(req.body);
  new ApiResponse(httpStatus.CREATED, { brand }, 'Brand created successfully.').send(res);
});

/**
 * @swagger
 * /brands/{id}:
 *   patch:
 *     summary: Update a brand (admin only)
 *     tags: [Brands]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Brand updated }
 *       404: { description: Brand not found }
 */
const update = asyncHandler(async (req, res) => {
  const brand = await brandService.updateBrand(req.params.id, req.body);
  new ApiResponse(httpStatus.OK, { brand }, 'Brand updated successfully.').send(res);
});

/**
 * @swagger
 * /brands/{id}:
 *   delete:
 *     summary: Delete a brand (admin only)
 *     tags: [Brands]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Brand deleted }
 *       404: { description: Brand not found }
 */
const remove = asyncHandler(async (req, res) => {
  await brandService.deleteBrand(req.params.id);
  new ApiResponse(httpStatus.OK, null, 'Brand deleted successfully.').send(res);
});

/**
 * @swagger
 * /brands/{id}/toggle-active:
 *   patch:
 *     summary: Toggle a brand's active/inactive status (admin only)
 *     tags: [Brands]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Status toggled }
 *       404: { description: Brand not found }
 */
const toggleActive = asyncHandler(async (req, res) => {
  const current = await brandService.getBrandById(req.params.id);
  const brand = await brandService.updateBrand(req.params.id, { active: !current.active });

  new ApiResponse(httpStatus.OK, { brand }, `Brand ${brand.active ? 'activated' : 'deactivated'} successfully.`).send(res);
});

module.exports = { list, getById, getBySlug, create, update, remove, toggleActive };
