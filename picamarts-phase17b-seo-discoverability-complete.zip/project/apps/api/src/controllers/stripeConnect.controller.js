'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const stripeConnectService = require('../services/stripeConnect.service');

/**
 * @swagger
 * tags:
 *   name: Stripe Connect
 *   description: Seller Stripe Connect onboarding foundation (Phase 16A)
 */

/**
 * @swagger
 * /connect/account:
 *   post:
 *     summary: Create (or reuse) the authenticated seller's Stripe Connect Express account
 *     tags: [Stripe Connect]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       201: { description: Connect account created or already existed }
 *       401: { description: Authentication required }
 *       403: { description: Sellers only }
 *       404: { description: No seller profile found for this account }
 */
const createAccount = asyncHandler(async (req, res) => {
  const account = await stripeConnectService.createAccount(req.user.id);
  new ApiResponse(httpStatus.CREATED, { account }, 'Stripe Connect account ready.').send(res);
});

/**
 * @swagger
 * /connect/account:
 *   get:
 *     summary: Get the authenticated seller's current Stripe Connect account status
 *     description: Always re-checks Stripe directly and refreshes the cached status before responding.
 *     tags: [Stripe Connect]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Current account status }
 *       401: { description: Authentication required }
 *       403: { description: Sellers only }
 *       404: { description: No seller profile found for this account }
 */
const getAccountStatus = asyncHandler(async (req, res) => {
  const account = await stripeConnectService.getAccountStatus(req.user.id);
  new ApiResponse(httpStatus.OK, { account }, 'Stripe Connect account status retrieved.').send(res);
});

/**
 * @swagger
 * /connect/account/onboarding-link:
 *   post:
 *     summary: Create a fresh Stripe-hosted onboarding link (covers both first-time onboarding and refresh/retry)
 *     description: Account Links are single-use and expire after a few minutes — call this again any time a new link is needed.
 *     tags: [Stripe Connect]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       201: { description: Onboarding link created }
 *       400: { description: No Connect account exists yet for this seller }
 *       401: { description: Authentication required }
 *       403: { description: Sellers only }
 *       404: { description: No seller profile found for this account }
 */
const createOnboardingLink = asyncHandler(async (req, res) => {
  const link = await stripeConnectService.createOnboardingLink(req.user.id);
  new ApiResponse(httpStatus.CREATED, link, 'Onboarding link created.').send(res);
});

module.exports = { createAccount, getAccountStatus, createOnboardingLink };
