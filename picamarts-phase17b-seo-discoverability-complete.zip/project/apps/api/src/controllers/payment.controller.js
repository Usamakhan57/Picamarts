'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const paymentService = require('../services/payment.service');

/**
 * Phase 9, Step 1 — Payments (Stripe only: PaymentIntent creation,
 * confirmation, retrieval, cancellation). Ownership/business-rule
 * checks live in payment.service.js — this file is pure request/
 * response plumbing.
 */

/**
 * @swagger
 * /payments:
 *   post:
 *     summary: Create (or reuse) a Stripe PaymentIntent for an order
 *     description: >
 *       Amount and currency are always derived from the order's own
 *       locked grandTotal — never taken from the request body. If the
 *       order already has a pending/processing/succeeded payment
 *       attempt, that same attempt is returned instead of creating a
 *       duplicate PaymentIntent.
 *     tags: [Payments]
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [orderId]
 *             properties:
 *               orderId: { type: string }
 *     responses:
 *       201:
 *         description: PaymentIntent created (or an existing attempt reused)
 *         content:
 *           application/json:
 *             example:
 *               success: true
 *               message: Payment intent created.
 *               data:
 *                 payment:
 *                   id: 64f1a2b3c4d5e6f7a8b9c0d1
 *                   order: 64f1a2b3c4d5e6f7a8b9c0d2
 *                   status: pending
 *                   amount: 59.98
 *                   currency: usd
 *                 clientSecret: pi_1P.._secret_..
 *       400: { description: The order can't be paid (cancelled/already paid/refunded), or Stripe rejected the request }
 *       401: { description: Authentication required }
 *       404: { description: Order not found }
 *       422: { description: Validation failed (missing/invalid orderId) }
 */
const createPaymentIntent = asyncHandler(async (req, res) => {
  const result = await paymentService.createPaymentIntent(req.body.orderId, req.user);
  new ApiResponse(httpStatus.CREATED, result, 'Payment intent created.').send(res);
});

/**
 * @swagger
 * /payments/{paymentId}/confirm:
 *   post:
 *     summary: Confirm a payment's PaymentIntent with Stripe
 *     description: >
 *       On success the order is synced (paymentStatus: paid, status:
 *       confirmed). On failure the payment is marked failed and the
 *       order's paymentStatus follows it to failed — the order itself
 *       remains pending so the buyer can retry.
 *     tags: [Payments]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: paymentId
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       required: false
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               paymentMethodId: { type: string }
 *     responses:
 *       200: { description: Payment confirmed (or moved to processing/failed) }
 *       400: { description: Payment already finished, or the provider declined/errored }
 *       401: { description: Authentication required }
 *       404: { description: Payment not found (or not owned by the caller) }
 */
const confirmPayment = asyncHandler(async (req, res) => {
  const payment = await paymentService.confirmPayment(req.params.paymentId, req.user, req.body);
  new ApiResponse(httpStatus.OK, { payment }, 'Payment confirmed.').send(res);
});

/**
 * @swagger
 * /payments/{paymentId}:
 *   get:
 *     summary: Retrieve a payment by id
 *     description: Refreshes against Stripe's current PaymentIntent status (best-effort) before returning. Buyers see only their own payments; admins see any.
 *     tags: [Payments]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: paymentId
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Payment retrieved }
 *       401: { description: Authentication required }
 *       404: { description: Payment not found (or not visible to the caller) }
 */
const retrievePayment = asyncHandler(async (req, res) => {
  const payment = await paymentService.retrievePayment(req.params.paymentId, req.user);
  new ApiResponse(httpStatus.OK, { payment }, 'Payment retrieved.').send(res);
});

/**
 * @swagger
 * /payments/{paymentId}/cancel:
 *   post:
 *     summary: Cancel a payment's PaymentIntent before it succeeds
 *     description: Not applicable to an already-succeeded payment — use a refund instead (Step 2).
 *     tags: [Payments]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: paymentId
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Payment cancelled }
 *       400: { description: Payment already succeeded or already cancelled }
 *       401: { description: Authentication required }
 *       404: { description: Payment not found (or not owned by the caller) }
 */
const cancelPaymentIntent = asyncHandler(async (req, res) => {
  const payment = await paymentService.cancelPaymentIntent(req.params.paymentId, req.user);
  new ApiResponse(httpStatus.OK, { payment }, 'Payment cancelled.').send(res);
});

/**
 * @swagger
 * /payments/{paymentId}/refund:
 *   post:
 *     summary: Refund a succeeded payment, fully or partially (admin only)
 *     description: >
 *       Omit `amount` for a full refund of whatever remains
 *       refundable; pass one for a partial refund. A full refund
 *       (refundAmount reaching the full payment amount) also flips
 *       the order itself to paymentStatus/status "refunded" — a
 *       partial refund only updates the payment's own refund fields.
 *     tags: [Payments]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: paymentId
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       required: false
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               amount: { type: number, description: Omit for a full refund of the remaining refundable amount }
 *     responses:
 *       200:
 *         description: Refund issued; the updated payment (with refund history) is returned
 *         content:
 *           application/json:
 *             example:
 *               success: true
 *               message: Refund processed.
 *               data:
 *                 payment:
 *                   id: 64f1a2b3c4d5e6f7a8b9c0d1
 *                   status: succeeded
 *                   refundStatus: full
 *                   refundAmount: 59.98
 *                   refunds:
 *                     - stripeRefundId: re_1P..
 *                       amount: 59.98
 *                       status: succeeded
 *       400: { description: Payment isn't succeeded yet, already fully refunded, amount out of range, or Stripe rejected the refund }
 *       401: { description: Authentication required }
 *       403: { description: Admin only }
 *       404: { description: Payment not found }
 */
const refundPayment = asyncHandler(async (req, res) => {
  const payment = await paymentService.processRefund(req.params.paymentId, req.body.amount, req.user);
  new ApiResponse(httpStatus.OK, { payment }, 'Refund processed.').send(res);
});

/**
 * @swagger
 * /payments:
 *   get:
 *     summary: List payments visible to the authenticated user
 *     description: Buyers see only their own payment history; admins see every payment.
 *     tags: [Payments]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: status
 *         schema: { type: string, enum: [pending, processing, succeeded, failed, cancelled] }
 *       - in: query
 *         name: page
 *         schema: { type: integer, minimum: 1 }
 *       - in: query
 *         name: limit
 *         schema: { type: integer, minimum: 1, maximum: 100 }
 *     responses:
 *       200: { description: Paginated payment list }
 *       401: { description: Authentication required }
 */
const listPayments = asyncHandler(async (req, res) => {
  const { items, meta } = await paymentService.listPayments(req.user, req.query);
  new ApiResponse(httpStatus.OK, { payments: items }, 'Payments retrieved successfully.', meta).send(res);
});

/**
 * @swagger
 * /payments/webhooks/stripe:
 *   post:
 *     summary: Stripe webhook endpoint
 *     description: >
 *       NOT authenticated via JWT — Stripe itself is the caller,
 *       verified instead by the `Stripe-Signature` header against
 *       STRIPE_WEBHOOK_SECRET. Mounted directly in app.js ahead of the
 *       global JSON body parser (see app.js) so the exact raw request
 *       bytes are available for signature verification; it is not
 *       reachable through this v1 router. Duplicate/redelivered events
 *       (matched by Stripe's event id) are silently no-op'd.
 *     tags: [Payments]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema: { type: object }
 *     responses:
 *       200: { description: Event processed (or already-processed duplicate acknowledged) }
 *       400: { description: Signature verification failed }
 */
const handleStripeWebhook = asyncHandler(async (req, res) => {
  const signature = req.headers['stripe-signature'];
  const result = await paymentService.handleStripeWebhook(req.body, signature);
  new ApiResponse(httpStatus.OK, result, 'Webhook processed.').send(res);
});

module.exports = {
  createPaymentIntent,
  confirmPayment,
  retrievePayment,
  cancelPaymentIntent,
  refundPayment,
  listPayments,
  handleStripeWebhook,
};
