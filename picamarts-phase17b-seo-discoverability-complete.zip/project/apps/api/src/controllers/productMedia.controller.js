'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const ApiError = require('../utils/ApiError');
const httpStatus = require('../constants/httpStatus');
const productMediaService = require('../services/productMedia.service');

/**
 * Phase 6, Feature 1 — Image Upload, Feature 4 — Image Ordering,
 * Feature 5 — Set Featured Image, Feature 6.1 — Remove Gallery Image,
 * and Feature 6.2 — Replace Gallery Image In-Place.
 */

/**
 * @swagger
 * /products/{id}/thumbnail:
 *   post:
 *     summary: Upload (or replace) a product's thumbnail image (owner seller or admin)
 *     tags: [Product Media]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               image: { type: string, format: binary }
 *     responses:
 *       200: { description: Thumbnail uploaded }
 *       400: { description: Missing file or unsupported/oversized image }
 *       403: { description: Not the product owner }
 *       404: { description: Product not found }
 */
const uploadThumbnail = asyncHandler(async (req, res) => {
  if (!req.file) {
    throw ApiError.badRequest('An image file is required.');
  }

  const thumbnail = await productMediaService.uploadThumbnail(req.params.id, req.file, req.user);
  new ApiResponse(httpStatus.OK, { thumbnail }, 'Thumbnail uploaded successfully.').send(res);
});

/**
 * @swagger
 * /products/{id}/images:
 *   post:
 *     summary: Upload one or more gallery images (owner seller or admin)
 *     tags: [Product Media]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               images:
 *                 type: array
 *                 items: { type: string, format: binary }
 *     responses:
 *       200: { description: Gallery images uploaded }
 *       400: { description: No files, unsupported/oversized image, or gallery limit exceeded }
 *       403: { description: Not the product owner }
 *       404: { description: Product not found }
 */
const uploadGalleryImages = asyncHandler(async (req, res) => {
  const gallery = await productMediaService.uploadGalleryImages(req.params.id, req.files, req.user);
  new ApiResponse(httpStatus.OK, { gallery }, 'Gallery images uploaded successfully.').send(res);
});

/**
 * @swagger
 * /products/{id}/images/order:
 *   patch:
 *     summary: Reorder a product's gallery images (owner seller or admin)
 *     tags: [Product Media]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               order:
 *                 type: array
 *                 items: { type: string }
 *                 description: Every existing gallery image id, in the desired order
 *     responses:
 *       200: { description: Gallery reordered }
 *       400: { description: order isn't an exact permutation of the current gallery ids }
 *       403: { description: Not the product owner }
 *       404: { description: Product not found }
 */
const reorderGalleryImages = asyncHandler(async (req, res) => {
  const gallery = await productMediaService.reorderGalleryImages(req.params.id, req.body.order, req.user);
  new ApiResponse(httpStatus.OK, { gallery }, 'Gallery reordered successfully.').send(res);
});

/**
 * @swagger
 * /products/{id}/images/{imageId}/featured:
 *   patch:
 *     summary: Promote a gallery image to be the product's thumbnail (owner seller or admin). The previous thumbnail, if any, is demoted into the gallery rather than deleted.
 *     tags: [Product Media]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *       - in: path
 *         name: imageId
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Thumbnail and gallery updated }
 *       403: { description: Not the product owner }
 *       404: { description: Product or gallery image not found }
 */
const setFeaturedImage = asyncHandler(async (req, res) => {
  const { thumbnail, gallery } = await productMediaService.setFeaturedImage(
    req.params.id,
    req.params.imageId,
    req.user
  );
  new ApiResponse(httpStatus.OK, { thumbnail, gallery }, 'Featured image updated successfully.').send(res);
});

/**
 * @swagger
 * /products/{id}/images/{imageId}:
 *   delete:
 *     summary: Remove a single gallery image (owner seller or admin)
 *     tags: [Product Media]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *       - in: path
 *         name: imageId
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Gallery image removed and remaining images recompacted }
 *       403: { description: Not the product owner }
 *       404: { description: Product or gallery image not found }
 */
const removeGalleryImage = asyncHandler(async (req, res) => {
  const gallery = await productMediaService.removeGalleryImage(req.params.id, req.params.imageId, req.user);
  new ApiResponse(httpStatus.OK, { gallery }, 'Gallery image removed successfully.').send(res);
});

/**
 * @swagger
 * /products/{id}/images/{imageId}:
 *   patch:
 *     summary: Replace an existing gallery image's file in place (owner seller or admin)
 *     description: >
 *       Uploads a new file to Cloudinary and swaps it into the same
 *       gallery slot — the image's id and position are preserved, only
 *       the file and its derived metadata change. The old Cloudinary
 *       asset is deleted only after the new one is uploaded and saved
 *       successfully; if the save fails, the newly uploaded asset is
 *       rolled back and the existing image is left unchanged.
 *     tags: [Product Media]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *         description: Product id
 *       - in: path
 *         name: imageId
 *         required: true
 *         schema: { type: string }
 *         description: Existing gallery image id to replace
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required: [image]
 *             properties:
 *               image:
 *                 type: string
 *                 format: binary
 *                 description: Replacement image file (jpg, jpeg, png, webp, or avif)
 *           encoding:
 *             image:
 *               contentType: image/jpeg, image/png, image/webp, image/avif
 *     responses:
 *       200:
 *         description: Gallery image replaced; the full updated product is returned
 *         content:
 *           application/json:
 *             example:
 *               success: true
 *               message: Gallery image replaced successfully.
 *               data:
 *                 product:
 *                   id: 64f1a2b3c4d5e6f7a8b9c0d1
 *                   title: Sample Product
 *                   gallery:
 *                     - id: 64f1a2b3c4d5e6f7a8b9c0d2
 *                       url: https://res.cloudinary.com/demo/image/upload/v1/products/gallery/new.jpg
 *                       publicId: products/gallery/new
 *                       width: 1200
 *                       height: 1200
 *                       format: webp
 *                       bytes: 84213
 *                       resourceType: image
 *                       position: 0
 *       400:
 *         description: Missing file, or unsupported/oversized/corrupted image
 *         content:
 *           application/json:
 *             example:
 *               success: false
 *               message: An image file is required.
 *       403:
 *         description: Not the product owner
 *         content:
 *           application/json:
 *             example:
 *               success: false
 *               message: You do not have permission to manage this product.
 *       404:
 *         description: Product or gallery image not found
 *         content:
 *           application/json:
 *             example:
 *               success: false
 *               message: Gallery image not found.
 */
const replaceGalleryImage = asyncHandler(async (req, res) => {
  if (!req.file) {
    throw ApiError.badRequest('An image file is required.');
  }

  const product = await productMediaService.replaceGalleryImage(
    req.params.id,
    req.params.imageId,
    req.file,
    req.user
  );
  new ApiResponse(httpStatus.OK, { product }, 'Gallery image replaced successfully.').send(res);
});

/**
 * @swagger
 * /products/{id}/downloads:
 *   post:
 *     summary: Upload one or more downloadable files to a digital/hybrid product (owner seller or admin)
 *     description: >
 *       Phase 14.1, Part 2 — Digital Asset Upload. Files are stored as
 *       Cloudinary "authenticated" assets (never publicly reachable by
 *       URL alone — see Part 3); buyers only ever get a signed,
 *       expiring link at download time (see /downloads/:downloadId/files/:fileId).
 *     tags: [Product Media]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               files:
 *                 type: array
 *                 items: { type: string, format: binary }
 *     responses:
 *       200: { description: Files uploaded }
 *       400: { description: No files, unsupported/oversized file, physical-only product, or file-count limit exceeded }
 *       403: { description: Not the product owner }
 *       404: { description: Product not found }
 */
const uploadDownloadFiles = asyncHandler(async (req, res) => {
  const downloadFiles = await productMediaService.uploadDownloadFiles(req.params.id, req.files, req.user);
  new ApiResponse(httpStatus.OK, { downloadFiles }, 'Files uploaded successfully.').send(res);
});

/**
 * @swagger
 * /products/{id}/downloads/{fileId}:
 *   delete:
 *     summary: Remove a single downloadable file (owner seller or admin)
 *     description: Buyers who already purchased keep their delivered copy — see Download's own file snapshot.
 *     tags: [Product Media]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *       - in: path
 *         name: fileId
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: File removed }
 *       403: { description: Not the product owner }
 *       404: { description: Product or file not found }
 */
const removeDownloadFile = asyncHandler(async (req, res) => {
  const downloadFiles = await productMediaService.removeDownloadFile(req.params.id, req.params.fileId, req.user);
  new ApiResponse(httpStatus.OK, { downloadFiles }, 'File removed successfully.').send(res);
});

module.exports = {
  uploadThumbnail,
  uploadGalleryImages,
  reorderGalleryImages,
  setFeaturedImage,
  removeGalleryImage,
  replaceGalleryImage,
  uploadDownloadFiles,
  removeDownloadFile,
};
