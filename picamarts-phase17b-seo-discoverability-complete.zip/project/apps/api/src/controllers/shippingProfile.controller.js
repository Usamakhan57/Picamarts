'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const shippingProfileService = require('../services/shippingProfile.service');

/**
 * Phase 14.2, Part 1/2/3 — Shipping Profiles, Zones, Rates. Ownership
 * (seller manages only their own; admin manages any) is enforced in
 * shippingProfile.service.js — pure request/response plumbing here,
 * same convention every other controller follows.
 */

const create = asyncHandler(async (req, res) => {
  const profile = await shippingProfileService.createProfile(req.body, req.user);
  new ApiResponse(httpStatus.CREATED, { profile }, 'Shipping profile created successfully.').send(res);
});

const listMine = asyncHandler(async (req, res) => {
  const { items, meta } = await shippingProfileService.listMyProfiles(req.user, req.query);
  new ApiResponse(httpStatus.OK, { profiles: items }, 'Shipping profiles retrieved successfully.', meta).send(res);
});

const listAll = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.query.seller) filter.seller = req.query.seller;
  const { items, meta } = await shippingProfileService.listAllProfiles(filter, req.query);
  new ApiResponse(httpStatus.OK, { profiles: items }, 'Shipping profiles retrieved successfully.', meta).send(res);
});

const getById = asyncHandler(async (req, res) => {
  const profile = await shippingProfileService.getProfileById(req.params.id, req.user);
  new ApiResponse(httpStatus.OK, { profile }, 'Shipping profile retrieved successfully.').send(res);
});

const update = asyncHandler(async (req, res) => {
  const profile = await shippingProfileService.updateProfile(req.params.id, req.body, req.user);
  new ApiResponse(httpStatus.OK, { profile }, 'Shipping profile updated successfully.').send(res);
});

const remove = asyncHandler(async (req, res) => {
  await shippingProfileService.deleteProfile(req.params.id, req.user);
  new ApiResponse(httpStatus.OK, {}, 'Shipping profile deleted successfully.').send(res);
});

module.exports = { create, listMine, listAll, getById, update, remove };
