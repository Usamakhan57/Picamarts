'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const homepageService = require('../services/homepage.service');

/**
 * @swagger
 * tags:
 *   name: Homepage CMS
 *   description: Homepage sections management (Phase 10.3, Part 3)
 */

/**
 * @swagger
 * /homepage:
 *   get:
 *     summary: Get the live homepage configuration (public)
 *     description: Returns an empty-but-valid default shape if the admin hasn't saved a configuration yet.
 *     tags: [Homepage CMS]
 *     responses:
 *       200: { description: Homepage configuration }
 */
const get = asyncHandler(async (req, res) => {
  const homepage = await homepageService.getHomepageConfig();
  new ApiResponse(httpStatus.OK, { homepage }, 'Homepage configuration retrieved successfully.').send(res);
});

/**
 * @swagger
 * /homepage:
 *   patch:
 *     summary: Update the homepage configuration (admin only)
 *     description: >
 *       Partial update — only the sections included in the request body
 *       are replaced (e.g. sending only `heroBanner` leaves testimonials,
 *       footerContent, etc. untouched). Changes take effect immediately;
 *       there is no draft/published step for the homepage configuration.
 *     tags: [Homepage CMS]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Homepage configuration updated }
 *       422: { description: Validation failed }
 */
const update = asyncHandler(async (req, res) => {
  const homepage = await homepageService.updateHomepageConfig(req.body, req.user);
  new ApiResponse(httpStatus.OK, { homepage }, 'Homepage configuration updated successfully.').send(res);
});

module.exports = { get, update };
