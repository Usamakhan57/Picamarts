'use strict';

const asyncHandler = require('../utils/asyncHandler');
const sitemapService = require('../services/sitemap.service');
const config = require('../config');

const SITEMAP_CACHE_CONTROL = 'public, max-age=3600'; // 1 hour — crawlers re-fetch on their own schedule anyway

const sendXml = (res, xml) => {
  res.set('Content-Type', 'application/xml; charset=UTF-8');
  res.set('Cache-Control', SITEMAP_CACHE_CONTROL);
  res.send(xml);
};

const getSitemapIndex = asyncHandler(async (req, res) => {
  sendXml(res, await sitemapService.getSitemapIndex());
});

const getProductsSitemap = asyncHandler(async (req, res) => {
  sendXml(res, await sitemapService.getProductsSitemap(req.params.page));
});

const getCategoriesSitemap = asyncHandler(async (req, res) => {
  sendXml(res, await sitemapService.getCategoriesSitemap());
});

const getBrandsSitemap = asyncHandler(async (req, res) => {
  sendXml(res, await sitemapService.getBrandsSitemap());
});

const getCollectionsSitemap = asyncHandler(async (req, res) => {
  sendXml(res, await sitemapService.getCollectionsSitemap());
});

const getPagesSitemap = asyncHandler(async (req, res) => {
  sendXml(res, await sitemapService.getPagesSitemap());
});

/**
 * Dynamic robots.txt — points crawlers at the sitemap index and blocks
 * the storefront's non-public/duplicate-content surfaces (account,
 * checkout, cart, seller dashboards, admin, the API surface itself).
 * Non-production environments disallow everything so a staging/preview
 * deploy never gets indexed by accident.
 */
const getRobotsTxt = asyncHandler(async (req, res) => {
  const apiUrl = (config.apiUrl || '').replace(/\/+$/, '');
  const lines = config.isProduction
    ? [
        'User-agent: *',
        'Allow: /',
        'Disallow: /account',
        'Disallow: /dashboard',
        'Disallow: /checkout',
        'Disallow: /cart',
        'Disallow: /wishlist',
        'Disallow: /wishlists',
        'Disallow: /orders',
        'Disallow: /downloads',
        'Disallow: /shipments',
        'Disallow: /settings',
        'Disallow: /security',
        'Disallow: /payment-methods',
        'Disallow: /payments',
        'Disallow: /invoices',
        'Disallow: /notifications',
        'Disallow: /addresses',
        'Disallow: /support',
        'Disallow: /coupons',
        'Disallow: /following',
        'Disallow: /browsing-history',
        'Disallow: /profile',
        'Disallow: /seller/dashboard',
        'Disallow: /seller/overview',
        'Disallow: /seller/products',
        'Disallow: /seller/orders',
        'Disallow: /seller/shipping',
        'Disallow: /seller/downloads',
        'Disallow: /seller/earnings',
        'Disallow: /seller/analytics',
        'Disallow: /seller/reviews',
        'Disallow: /seller/notifications',
        'Disallow: /seller/store',
        'Disallow: /seller/profile',
        'Disallow: /order-failed',
        'Disallow: /reset-password',
        'Disallow: /403',
        '',
        `Sitemap: ${apiUrl}/sitemap.xml`,
      ]
    : ['User-agent: *', 'Disallow: /'];

  res.set('Content-Type', 'text/plain; charset=UTF-8');
  res.set('Cache-Control', SITEMAP_CACHE_CONTROL);
  res.send(lines.join('\n'));
});

module.exports = {
  getSitemapIndex,
  getProductsSitemap,
  getCategoriesSitemap,
  getBrandsSitemap,
  getCollectionsSitemap,
  getPagesSitemap,
  getRobotsTxt,
};
