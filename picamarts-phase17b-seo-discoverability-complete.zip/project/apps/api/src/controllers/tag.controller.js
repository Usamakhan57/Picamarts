'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const { getPagination } = require('../utils/pagination');
const { buildSortQuery } = require('../utils/sortHelper');
const { buildSearchQuery } = require('../utils/searchHelper');
const tagService = require('../services/tag.service');

/**
 * Phase 4 — Admin marketplace management.
 * Note: tags have no `active` flag (see Tag model) so there is no
 * toggle-active endpoint for this resource, unlike the other four.
 * Creation stays open to sellers per the existing route (tag.routes.js);
 * edits/deletes remain admin-only.
 */

const SEARCH_FIELDS = ['name'];
const SORT_FIELDS = ['name', 'createdAt', 'updatedAt'];

/**
 * @swagger
 * /tags:
 *   get:
 *     summary: List tags (paginated, searchable, sortable)
 *     tags: [Tags]
 *     parameters:
 *       - in: query
 *         name: page
 *         schema: { type: integer }
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *       - in: query
 *         name: q
 *         schema: { type: string }
 *       - in: query
 *         name: sort
 *         schema: { type: string }
 *     responses:
 *       200: { description: Paginated list of tags }
 */
const list = asyncHandler(async (req, res) => {
  const { page, limit } = getPagination(req.query);
  const sort = buildSortQuery(req.query.sort, SORT_FIELDS);
  const filter = { ...buildSearchQuery(req.query.q, SEARCH_FIELDS) };

  const { items, meta } = await tagService.listTags(filter, { page, limit, sort });

  new ApiResponse(httpStatus.OK, { tags: items }, 'Tags retrieved successfully.', meta).send(res);
});

/**
 * @swagger
 * /tags/{id}:
 *   get:
 *     summary: Get a tag by id
 *     tags: [Tags]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Tag found }
 *       404: { description: Tag not found }
 */
const getById = asyncHandler(async (req, res) => {
  const tag = await tagService.getTagById(req.params.id);
  new ApiResponse(httpStatus.OK, { tag }, 'Tag retrieved successfully.').send(res);
});

/**
 * @swagger
 * /tags:
 *   post:
 *     summary: Create a tag (seller or admin)
 *     tags: [Tags]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       201: { description: Tag created }
 *       409: { description: A tag with this name already exists }
 *       422: { description: Validation failed }
 */
const create = asyncHandler(async (req, res) => {
  const tag = await tagService.createTag(req.body);
  new ApiResponse(httpStatus.CREATED, { tag }, 'Tag created successfully.').send(res);
});

/**
 * @swagger
 * /tags/{id}:
 *   patch:
 *     summary: Update a tag (admin only)
 *     tags: [Tags]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Tag updated }
 *       404: { description: Tag not found }
 */
const update = asyncHandler(async (req, res) => {
  const tag = await tagService.updateTag(req.params.id, req.body);
  new ApiResponse(httpStatus.OK, { tag }, 'Tag updated successfully.').send(res);
});

/**
 * @swagger
 * /tags/{id}:
 *   delete:
 *     summary: Delete a tag (admin only)
 *     tags: [Tags]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Tag deleted }
 *       404: { description: Tag not found }
 */
const remove = asyncHandler(async (req, res) => {
  await tagService.deleteTag(req.params.id);
  new ApiResponse(httpStatus.OK, null, 'Tag deleted successfully.').send(res);
});

module.exports = { list, getById, create, update, remove };
