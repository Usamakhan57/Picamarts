'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const notificationService = require('../services/notification.service');

/**
 * @swagger
 * tags:
 *   name: Notifications
 *   description: In-app + email notification endpoints (Phase 10.2)
 */

// --------------------------------------------------------------------
// GET /notifications
// --------------------------------------------------------------------

/**
 * @swagger
 * /notifications:
 *   get:
 *     summary: List the authenticated user's own notifications
 *     description: >
 *       Paginated, most-recent-first by default. Filter with
 *       `isRead=true`/`isRead=false` to see only read or unread
 *       notifications; omit it to see everything.
 *     tags: [Notifications]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: page
 *         schema: { type: integer, minimum: 1 }
 *       - in: query
 *         name: limit
 *         schema: { type: integer, minimum: 1, maximum: 100 }
 *       - in: query
 *         name: sort
 *         schema: { type: string, enum: [newest, oldest] }
 *       - in: query
 *         name: isRead
 *         schema: { type: boolean }
 *     responses:
 *       200:
 *         description: Notification list
 *         content:
 *           application/json:
 *             example:
 *               success: true
 *               message: Notifications retrieved successfully.
 *               data:
 *                 notifications:
 *                   - id: 64f1a2b3c4d5e6f7a8b9c0d1
 *                     type: order_shipped
 *                     title: Order shipped
 *                     message: Your order ORD-2026-000001 is now shipped.
 *                     isRead: false
 *                     priority: normal
 *                     createdAt: '2026-07-23T10:00:00.000Z'
 *               meta:
 *                 totalItems: 1
 *                 totalPages: 1
 *                 currentPage: 1
 *                 pageSize: 20
 *       401: { description: Authentication required }
 *       422: { description: Validation failed }
 */
const listNotifications = asyncHandler(async (req, res) => {
  const { items, meta } = await notificationService.listNotifications(req.user, req.query);
  new ApiResponse(httpStatus.OK, { notifications: items }, 'Notifications retrieved successfully.', meta).send(res);
});

// --------------------------------------------------------------------
// GET /notifications/unread-count
// --------------------------------------------------------------------

/**
 * @swagger
 * /notifications/unread-count:
 *   get:
 *     summary: Get the authenticated user's unread notification count
 *     tags: [Notifications]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200:
 *         description: Unread count
 *         content:
 *           application/json:
 *             example:
 *               success: true
 *               message: Unread count retrieved successfully.
 *               data: { unreadCount: 3 }
 *       401: { description: Authentication required }
 */
const getUnreadCount = asyncHandler(async (req, res) => {
  const result = await notificationService.getUnreadCount(req.user);
  new ApiResponse(httpStatus.OK, result, 'Unread count retrieved successfully.').send(res);
});

// --------------------------------------------------------------------
// GET /notifications/preferences
// --------------------------------------------------------------------

/**
 * @swagger
 * /notifications/preferences:
 *   get:
 *     summary: Get the authenticated user's notification preferences
 *     description: Defaults to both channels enabled until the user changes them.
 *     tags: [Notifications]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200:
 *         description: Current preferences
 *         content:
 *           application/json:
 *             example:
 *               success: true
 *               message: Preferences retrieved successfully.
 *               data: { emailEnabled: true, inAppEnabled: true }
 *       401: { description: Authentication required }
 */
const getPreferences = asyncHandler(async (req, res) => {
  const preferences = await notificationService.getPreferences(req.user);
  new ApiResponse(httpStatus.OK, preferences, 'Preferences retrieved successfully.').send(res);
});

// --------------------------------------------------------------------
// PATCH /notifications/preferences
// --------------------------------------------------------------------

/**
 * @swagger
 * /notifications/preferences:
 *   patch:
 *     summary: Update the authenticated user's notification preferences
 *     tags: [Notifications]
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               emailEnabled: { type: boolean }
 *               inAppEnabled: { type: boolean }
 *     responses:
 *       200: { description: Preferences updated }
 *       401: { description: Authentication required }
 *       422: { description: Validation failed }
 */
const updatePreferences = asyncHandler(async (req, res) => {
  const preferences = await notificationService.updatePreferences(req.user, req.body);
  new ApiResponse(httpStatus.OK, preferences, 'Preferences updated successfully.').send(res);
});

// --------------------------------------------------------------------
// POST /notifications/broadcast
// --------------------------------------------------------------------

/**
 * @swagger
 * /notifications/broadcast:
 *   post:
 *     summary: Send a broadcast/system/maintenance notification (admin only)
 *     description: >
 *       `target` may be "all" (every buyer + seller), "buyers",
 *       "sellers", or an explicit array of user ids. Respects each
 *       recipient's own notification preferences — this does not
 *       override an opt-out.
 *     tags: [Notifications]
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [type, title, message]
 *             properties:
 *               type:
 *                 type: string
 *                 enum: [broadcast_notification, system_announcement, maintenance_notice]
 *               title: { type: string, maxLength: 150 }
 *               message: { type: string, maxLength: 1000 }
 *               target:
 *                 oneOf:
 *                   - type: string
 *                     enum: [all, buyers, sellers]
 *                   - type: array
 *                     items: { type: string }
 *               sendEmail: { type: boolean, default: false }
 *     responses:
 *       201:
 *         description: Broadcast dispatched
 *         content:
 *           application/json:
 *             example:
 *               success: true
 *               message: Broadcast sent successfully.
 *               data: { targeted: 42, sent: 42 }
 *       401: { description: Authentication required }
 *       403: { description: Admin only }
 *       422: { description: Validation failed }
 */
const broadcastNotification = asyncHandler(async (req, res) => {
  const result = await notificationService.broadcastNotification(req.body, req.user);
  new ApiResponse(httpStatus.CREATED, result, 'Broadcast sent successfully.').send(res);
});

// --------------------------------------------------------------------
// GET /notifications/:id
// --------------------------------------------------------------------

/**
 * @swagger
 * /notifications/{id}:
 *   get:
 *     summary: Get a single notification by id
 *     description: Buyers/sellers may only fetch their own; admins may fetch any.
 *     tags: [Notifications]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Notification found }
 *       401: { description: Authentication required }
 *       404: { description: Notification not found (or not owned by the caller) }
 */
const getNotificationById = asyncHandler(async (req, res) => {
  const notification = await notificationService.getNotificationById(req.params.id, req.user);
  new ApiResponse(httpStatus.OK, { notification }, 'Notification retrieved successfully.').send(res);
});

// --------------------------------------------------------------------
// PATCH /notifications/:id/read
// --------------------------------------------------------------------

/**
 * @swagger
 * /notifications/{id}/read:
 *   patch:
 *     summary: Mark a single notification as read
 *     tags: [Notifications]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Notification marked as read }
 *       401: { description: Authentication required }
 *       404: { description: Notification not found (or not owned by the caller) }
 */
const markAsRead = asyncHandler(async (req, res) => {
  const notification = await notificationService.markAsRead(req.params.id, req.user);
  new ApiResponse(httpStatus.OK, { notification }, 'Notification marked as read.').send(res);
});

// --------------------------------------------------------------------
// PATCH /notifications/read-all
// --------------------------------------------------------------------

/**
 * @swagger
 * /notifications/read-all:
 *   patch:
 *     summary: Mark every one of the caller's unread notifications as read
 *     tags: [Notifications]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200:
 *         description: All notifications marked as read
 *         content:
 *           application/json:
 *             example:
 *               success: true
 *               message: All notifications marked as read.
 *               data: { matched: 5, modified: 5 }
 *       401: { description: Authentication required }
 */
const markAllAsRead = asyncHandler(async (req, res) => {
  const result = await notificationService.markAllAsRead(req.user);
  new ApiResponse(httpStatus.OK, result, 'All notifications marked as read.').send(res);
});

// --------------------------------------------------------------------
// DELETE /notifications/:id
// --------------------------------------------------------------------

/**
 * @swagger
 * /notifications/{id}:
 *   delete:
 *     summary: Delete a single notification
 *     tags: [Notifications]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Notification deleted }
 *       401: { description: Authentication required }
 *       404: { description: Notification not found (or not owned by the caller) }
 */
const deleteNotification = asyncHandler(async (req, res) => {
  await notificationService.deleteNotification(req.params.id, req.user);
  new ApiResponse(httpStatus.OK, null, 'Notification deleted successfully.').send(res);
});

// --------------------------------------------------------------------
// DELETE /notifications
// --------------------------------------------------------------------

/**
 * @swagger
 * /notifications:
 *   delete:
 *     summary: Delete every one of the caller's own notifications
 *     tags: [Notifications]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200:
 *         description: All notifications deleted
 *         content:
 *           application/json:
 *             example:
 *               success: true
 *               message: All notifications deleted.
 *               data: { deleted: 12 }
 *       401: { description: Authentication required }
 */
const deleteAllNotifications = asyncHandler(async (req, res) => {
  const result = await notificationService.deleteAllNotifications(req.user);
  new ApiResponse(httpStatus.OK, result, 'All notifications deleted.').send(res);
});

module.exports = {
  listNotifications,
  getUnreadCount,
  getPreferences,
  updatePreferences,
  broadcastNotification,
  getNotificationById,
  markAsRead,
  markAllAsRead,
  deleteNotification,
  deleteAllNotifications,
};
