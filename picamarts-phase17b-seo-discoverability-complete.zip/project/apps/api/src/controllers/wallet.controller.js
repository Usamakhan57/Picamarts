'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const walletService = require('../services/wallet.service');
const sellerRepository = require('../repositories/seller.repository');
const ApiError = require('../utils/ApiError');

/**
 * @swagger
 * tags:
 *   name: Wallet
 *   description: Seller wallet balances/ledger + admin finance overview (Phase 16B)
 */

/**
 * @swagger
 * /wallet/me:
 *   get:
 *     summary: The authenticated seller's wallet balance summary
 *     tags: [Wallet]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Wallet summary }
 *       401: { description: Authentication required }
 *       403: { description: Sellers only }
 */
const getMySummary = asyncHandler(async (req, res) => {
  const summary = await walletService.getWalletSummary(req.user.id);
  new ApiResponse(httpStatus.OK, { wallet: summary }, 'Wallet summary retrieved.').send(res);
});

/**
 * @swagger
 * /wallet/me/transactions:
 *   get:
 *     summary: The authenticated seller's own paginated ledger history
 *     tags: [Wallet]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Paginated ledger entries }
 *       401: { description: Authentication required }
 *       403: { description: Sellers only }
 */
const getMyTransactions = asyncHandler(async (req, res) => {
  const { page, limit } = req.query;
  const { items, meta } = await walletService.getLedgerHistory(req.user.id, { page, limit });
  new ApiResponse(httpStatus.OK, { transactions: items }, 'Transactions retrieved.', meta).send(res);
});

/**
 * @swagger
 * /wallet/admin/overview:
 *   get:
 *     summary: Marketplace-wide finance overview (admin only)
 *     tags: [Wallet]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Platform-wide revenue/commission/wallet totals }
 *       401: { description: Authentication required }
 *       403: { description: Admins only }
 */
const getAdminOverview = asyncHandler(async (req, res) => {
  const overview = await walletService.getAdminOverview();
  new ApiResponse(httpStatus.OK, overview, 'Finance overview retrieved.').send(res);
});

/**
 * @swagger
 * /wallet/admin/{sellerId}:
 *   get:
 *     summary: One seller's wallet + commission totals (admin only)
 *     description: sellerId is the Seller PROFILE id (same convention as GET /sellers/{id}), not the User id.
 *     tags: [Wallet]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Seller wallet detail }
 *       401: { description: Authentication required }
 *       403: { description: Admins only }
 *       404: { description: Seller not found }
 */
const getAdminSellerWallet = asyncHandler(async (req, res) => {
  const detail = await walletService.getAdminSellerWallet(req.params.sellerId);
  new ApiResponse(httpStatus.OK, detail, 'Seller wallet retrieved.').send(res);
});

/**
 * @swagger
 * /wallet/admin/{sellerId}/adjust:
 *   post:
 *     summary: Manually credit or debit a seller's wallet (admin only)
 *     description: sellerId is the Seller PROFILE id — resolved to the owning User internally.
 *     tags: [Wallet]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       201: { description: Adjustment recorded }
 *       400: { description: Amount must be greater than 0 }
 *       401: { description: Authentication required }
 *       403: { description: Admins only }
 *       404: { description: Seller not found }
 *       422: { description: Validation failed }
 */
const adjustSellerWallet = asyncHandler(async (req, res) => {
  const seller = await sellerRepository.findById(req.params.sellerId);
  if (!seller) throw ApiError.notFound('Seller not found.');

  const result = await walletService.recordManualAdjustment(seller.user, req.body, req.user.id);
  new ApiResponse(httpStatus.CREATED, result, 'Manual adjustment recorded.').send(res);
});

/**
 * @swagger
 * /wallet/admin/{sellerId}/close:
 *   post:
 *     summary: Record a closing-balance ledger snapshot for a seller (admin only)
 *     description: sellerId is the Seller PROFILE id. On-demand only — not a scheduled job.
 *     tags: [Wallet]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       201: { description: Closing balance snapshot recorded }
 *       401: { description: Authentication required }
 *       403: { description: Admins only }
 *       404: { description: Seller not found }
 */
const closeSellerBalance = asyncHandler(async (req, res) => {
  const seller = await sellerRepository.findById(req.params.sellerId);
  if (!seller) throw ApiError.notFound('Seller not found.');

  const entry = await walletService.recordClosingBalanceSnapshot(seller.user, req.user.id);
  new ApiResponse(httpStatus.CREATED, { entry }, 'Closing balance snapshot recorded.').send(res);
});

module.exports = {
  getMySummary,
  getMyTransactions,
  getAdminOverview,
  getAdminSellerWallet,
  adjustSellerWallet,
  closeSellerBalance,
};
