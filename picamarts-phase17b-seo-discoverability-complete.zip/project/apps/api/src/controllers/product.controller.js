'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const { getPagination } = require('../utils/pagination');
const productService = require('../services/product.service');
const recentlyViewedService = require('../services/recentlyViewed.service');
const { STOCK_STATUSES } = require('../constants/productEnums');
const { ROLES } = require('../constants/roles');

/**
 * Phase 5 — Product CRUD (Feature 1), Listing (Feature 2), Search
 * (Feature 3), Filters (Feature 4), Status (Feature 7), Inventory
 * (Feature 8), and Featured Products (Feature 9).
 */

/**
 * Named sort presets for product listing. Keys are the accepted
 * `?sort=` values; unknown/missing values fall back to `newest`.
 */
const SORT_OPTIONS = {
  newest: { createdAt: -1 },
  oldest: { createdAt: 1 },
  price_asc: { basePrice: 1 },
  priceAsc: { basePrice: 1 },
  // Phase 17A, Part 2 — Smart Filtering's "Sort by" list names these
  // "Lowest Price" / "Highest Price" explicitly; kept as aliases of
  // the existing price_asc/price_desc rather than replacing them, so
  // no existing `?sort=price_asc` caller breaks.
  lowest_price: { basePrice: 1 },
  price_desc: { basePrice: -1 },
  priceDesc: { basePrice: -1 },
  highest_price: { basePrice: -1 },
  popular: { views: -1 },
  featured: { featured: -1, createdAt: -1 },
  best_selling: { salesCount: -1 },
  bestSelling: { salesCount: -1 },
  // Phase 17A, Part 2 — new: "Highest Rated" sort preset.
  highest_rated: { ratingAverage: -1, ratingCount: -1 },
  highestRated: { ratingAverage: -1, ratingCount: -1 },
  rating_desc: { ratingAverage: -1, ratingCount: -1 },
};
const DEFAULT_SORT = SORT_OPTIONS.newest;

/** Resolves a `?sort=` query value to a Mongo sort object, defaulting to newest. */
const resolveSort = (sortParam) => (sortParam && SORT_OPTIONS[sortParam]) || DEFAULT_SORT;

/** Reshapes repository pagination meta into the { page, limit, ... } envelope this feature's spec requires. */
const toPaginationEnvelope = (meta) => ({
  page: meta.currentPage,
  limit: meta.pageSize,
  totalItems: meta.totalItems,
  totalPages: meta.totalPages,
  hasNextPage: meta.hasNextPage,
  hasPrevPage: meta.hasPrevPage,
});

/** Builds the exact-match filter fragment shared by every list endpoint. Multi-select relationship fields (category/brand/collection/seller) are handled separately below, since they now also accept a comma-separated list. */
const buildExactFilter = (query) => {
  const filter = {};
  ['status', 'featured', 'type', 'condition'].forEach((field) => {
    if (query[field] !== undefined) filter[field] = query[field];
  });
  return filter;
};

const OBJECT_ID_RE = /^[0-9a-fA-F]{24}$/;

/** `?tags=<id1>,<id2>` → `{ tags: { $in: [...] } }`. Malformed ids are silently dropped rather than erroring. */
const buildTagsFilter = (query) => {
  if (!query.tags) return {};
  const ids = query.tags
    .split(',')
    .map((t) => t.trim())
    .filter((t) => OBJECT_ID_RE.test(t));
  return ids.length ? { tags: { $in: ids } } : {};
};

/**
 * Phase 17A, Part 2 — Smart Filtering (multi-select). Same
 * comma-separated shape as buildTagsFilter above, applied to
 * category/brand/collection. A single id keeps the exact pre-17A
 * filter shape (`{ [field]: id }`) rather than always wrapping in
 * `$in` — no behavior change for any existing single-value caller.
 */
const buildMultiSelectFilter = (query, field) => {
  const raw = query[field];
  if (raw === undefined) return {};
  const ids = raw
    .split(',')
    .map((v) => v.trim())
    .filter((v) => OBJECT_ID_RE.test(v));
  if (!ids.length) return {};
  return ids.length === 1 ? { [field]: ids[0] } : { [field]: { $in: ids } };
};

/**
 * Phase 17A, Part 2 — Smart Filtering (seller + seller rating).
 * `seller` (multi-select ids) and `minSellerRating` (computed via
 * product.repository.js#findSellerIdsByMinRating) both ultimately
 * constrain the same `seller` field, so they're resolved together
 * here into a single fragment — building them as two separate
 * fragments would let mergeFilters' `Object.assign` silently let one
 * `seller` key clobber the other instead of intersecting them.
 * Async (the rating branch needs an aggregation query), so this is
 * awaited directly in buildListFilter rather than folded into the
 * generic buildMultiSelectFilter above.
 */
const buildSellerFilter = async (query) => {
  const hasSellerParam = query.seller !== undefined;
  const hasMinSellerRating = query.minSellerRating !== undefined;
  if (!hasSellerParam && !hasMinSellerRating) return {};

  let ids = null; // null = "no constraint from this source yet"
  if (hasSellerParam) {
    ids = query.seller
      .split(',')
      .map((v) => v.trim())
      .filter((v) => OBJECT_ID_RE.test(v));
  }

  if (hasMinSellerRating) {
    const qualifying = (await productService.findSellerIdsByMinRating(query.minSellerRating)).map((id) => id.toString());
    ids = ids === null ? qualifying : ids.filter((id) => qualifying.includes(id));
  }

  // An explicit filter that matches nothing must still return "no results", not "no filter".
  if (!ids || !ids.length) return { seller: { $in: [] } };
  return ids.length === 1 ? { seller: ids[0] } : { seller: { $in: ids } };
};

/** `?minPrice=&maxPrice=` → a `basePrice` range constraint. */
const buildPriceRangeFilter = (query) => {
  if (query.minPrice === undefined && query.maxPrice === undefined) return {};
  const range = {};
  if (query.minPrice !== undefined) range.$gte = query.minPrice;
  if (query.maxPrice !== undefined) range.$lte = query.maxPrice;
  return { basePrice: range };
};

/** `?minRating=` → products rated at or above the given average. */
const buildRatingFilter = (query) => {
  if (query.minRating === undefined) return {};
  return { ratingAverage: { $gte: query.minRating } };
};

/**
 * `?stockStatus=in_stock|out_of_stock|low_stock` → a stock constraint.
 * Stock status isn't stored — it's derived from stock/lowStockThreshold/
 * allowBackorder, same as the "Inventory" business rule describes.
 */
const STOCK_STATUS_CLAUSES = {
  [STOCK_STATUSES.IN_STOCK]: () => ({ $or: [{ stock: { $gt: 0 } }, { allowBackorder: true }] }),
  [STOCK_STATUSES.OUT_OF_STOCK]: () => ({ stock: { $lte: 0 }, allowBackorder: false }),
  [STOCK_STATUSES.LOW_STOCK]: () => ({
    $expr: { $and: [{ $gt: ['$stock', 0] }, { $lte: ['$stock', '$lowStockThreshold'] }] },
  }),
};
const buildStockStatusFilter = (query) => {
  const build = query.stockStatus && STOCK_STATUS_CLAUSES[query.stockStatus];
  return build ? build() : {};
};

/**
 * Merges several filter fragments into one Mongo query. Plain
 * field-constraint fragments (tags/basePrice/ratingAverage/etc.) are
 * assigned directly; fragments carrying a `$or` or `$expr` (search,
 * in_stock, low_stock) can't just be spread together — a second `$or`
 * key would silently overwrite the first — so more than one of those
 * gets combined under `$and` instead.
 */
const mergeFilters = (...fragments) => {
  const merged = {};
  const andClauses = [];

  fragments.forEach((fragment) => {
    if (!fragment || Object.keys(fragment).length === 0) return;
    if (fragment.$or || fragment.$expr) {
      andClauses.push(fragment);
    } else {
      Object.assign(merged, fragment);
    }
  });

  if (andClauses.length === 1) Object.assign(merged, andClauses[0]);
  else if (andClauses.length > 1) merged.$and = andClauses;

  return merged;
};

/** Builds the full filter (equality + multi-select relationships + tags + price + rating + stock + search) shared by every list endpoint. */
const buildListFilter = async (query) =>
  mergeFilters(
    buildExactFilter(query),
    buildMultiSelectFilter(query, 'category'),
    buildMultiSelectFilter(query, 'brand'),
    buildMultiSelectFilter(query, 'collection'),
    await buildSellerFilter(query),
    buildTagsFilter(query),
    buildPriceRangeFilter(query),
    buildRatingFilter(query),
    buildStockStatusFilter(query),
    await productService.buildSearchFilter(query.q)
  );

/**
 * @swagger
 * /products:
 *   get:
 *     summary: List published products (public catalog)
 *     tags: [Products]
 *     parameters:
 *       - in: query
 *         name: page
 *         schema: { type: integer }
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *       - in: query
 *         name: sort
 *         schema: { type: string, enum: [newest, oldest, price_asc, price_desc, lowest_price, highest_price, popular, featured, best_selling, highest_rated] }
 *         description: Named sort preset. Defaults to newest.
 *       - in: query
 *         name: q
 *         schema: { type: string }
 *         description: Free-text search across title, slug, description, SKU, brand name, category name, and tag names
 *       - in: query
 *         name: category
 *         schema: { type: string }
 *         description: Single id, or comma-separated ids for multi-select
 *       - in: query
 *         name: brand
 *         schema: { type: string }
 *         description: Single id, or comma-separated ids for multi-select
 *       - in: query
 *         name: collection
 *         schema: { type: string }
 *         description: Single id, or comma-separated ids for multi-select
 *       - in: query
 *         name: tags
 *         schema: { type: string }
 *         description: Comma-separated tag ids
 *       - in: query
 *         name: condition
 *         schema: { type: string, enum: [new, used, refurbished] }
 *       - in: query
 *         name: minPrice
 *         schema: { type: number }
 *       - in: query
 *         name: maxPrice
 *         schema: { type: number }
 *       - in: query
 *         name: minRating
 *         schema: { type: number, minimum: 0, maximum: 5 }
 *         description: Minimum PRODUCT rating average
 *       - in: query
 *         name: minSellerRating
 *         schema: { type: number, minimum: 0, maximum: 5 }
 *         description: Minimum SELLER rating average (review-weighted across the seller's published products)
 *       - in: query
 *         name: stockStatus
 *         schema: { type: string, enum: [in_stock, out_of_stock, low_stock] }
 *       - in: query
 *         name: featured
 *         schema: { type: boolean }
 *       - in: query
 *         name: type
 *         schema: { type: string }
 *     responses:
 *       200: { description: Paginated list of published products }
 */
const list = asyncHandler(async (req, res) => {
  const { page, limit } = getPagination(req.query);
  const sort = resolveSort(req.query.sort);
  const filter = await buildListFilter(req.query);
  delete filter.status; // public catalog is always status: published — see listPublicProducts

  const { items, meta } = await productService.listPublicProducts(filter, { page, limit, sort });

  res.status(httpStatus.OK).json({ success: true, data: items, pagination: toPaginationEnvelope(meta) });
});

/**
 * Feature 9 — curated public feeds. Each is a fixed filter/sort on the
 * published catalog (see product.service.js for the exact definition
 * of each); only page/limit are accepted, no sort/filter override.
 */
const CURATED_FEEDS = {
  featured: (options) => productService.listFeaturedProducts(options),
  trending: (options) => productService.listTrendingProducts(options),
  popular: (options) => productService.listPopularProducts(options),
  latest: (options) => productService.listLatestProducts(options),
};

/** Builds a curated-feed handler (featured/trending/popular/latest) — same response shape as list(). */
const curatedFeedHandler = (feedName) =>
  asyncHandler(async (req, res) => {
    const { page, limit } = getPagination(req.query);
    const { items, meta } = await CURATED_FEEDS[feedName]({ page, limit });
    res.status(httpStatus.OK).json({ success: true, data: items, pagination: toPaginationEnvelope(meta) });
  });

/**
 * @swagger
 * /products/featured:
 *   get:
 *     summary: Products flagged as featured (published only), newest first
 *     tags: [Products]
 *     parameters:
 *       - in: query
 *         name: page
 *         schema: { type: integer }
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Paginated list of featured products }
 */
const featured = curatedFeedHandler('featured');

/**
 * @swagger
 * /products/trending:
 *   get:
 *     summary: Published products from the last 30 days, ranked by views then sales. A heuristic — there's no event-tracking system to measure true recent velocity.
 *     tags: [Products]
 *     parameters:
 *       - in: query
 *         name: page
 *         schema: { type: integer }
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Paginated list of trending products }
 */
const trending = curatedFeedHandler('trending');

/**
 * @swagger
 * /products/popular:
 *   get:
 *     summary: All-time most-viewed published products
 *     tags: [Products]
 *     parameters:
 *       - in: query
 *         name: page
 *         schema: { type: integer }
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Paginated list of popular products }
 */
const popular = curatedFeedHandler('popular');

/**
 * @swagger
 * /products/latest:
 *   get:
 *     summary: Most recently published products
 *     tags: [Products]
 *     parameters:
 *       - in: query
 *         name: page
 *         schema: { type: integer }
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Paginated list of the latest products }
 */
const latest = curatedFeedHandler('latest');

/**
 * @swagger
 * /products/mine:
 *   get:
 *     summary: List the authenticated seller's own products (any status except deleted)
 *     tags: [Products]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Paginated list of the caller's products }
 */
const mine = asyncHandler(async (req, res) => {
  const { page, limit } = getPagination(req.query);
  const sort = resolveSort(req.query.sort);
  const filter = await buildListFilter(req.query);
  delete filter.seller; // scoped to the caller, not a client-supplied seller id

  const { items, meta } = await productService.listSellerProducts(req.user.id, filter, { page, limit, sort }, req.user);

  res.status(httpStatus.OK).json({ success: true, data: items, pagination: toPaginationEnvelope(meta) });
});

/**
 * @swagger
 * /products/admin:
 *   get:
 *     summary: List every product, including drafts (admin only). Pass status=deleted to view the trash.
 *     tags: [Products]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Paginated list of all products }
 */
const adminList = asyncHandler(async (req, res) => {
  const { page, limit } = getPagination(req.query);
  const sort = resolveSort(req.query.sort);
  const filter = await buildListFilter(req.query);

  const { items, meta } = await productService.listAdminProducts(filter, { page, limit, sort });

  res.status(httpStatus.OK).json({ success: true, data: items, pagination: toPaginationEnvelope(meta) });
});

/**
 * @swagger
 * /products/{id}:
 *   get:
 *     summary: Get a product by id
 *     tags: [Products]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Product found }
 *       404: { description: Product not found }
 */
const getById = asyncHandler(async (req, res) => {
  const product = await productService.getProductById(req.params.id, req.user);
  // Phase 17A, Part 5 — Recently Viewed. Fire-and-forget, buyer-only
  // (sellers/admins viewing their own or others' listings isn't a
  // "recently viewed" signal in the same sense) — never blocks or
  // fails the product response itself.
  if (req.user?.role === ROLES.BUYER) {
    recentlyViewedService.recordView(req.user.id, product.id).catch(() => {});
  }
  new ApiResponse(httpStatus.OK, { product }, 'Product retrieved successfully.').send(res);
});

/**
 * @swagger
 * /products/slug/{slug}:
 *   get:
 *     summary: Get a product by slug
 *     tags: [Products]
 *     parameters:
 *       - in: path
 *         name: slug
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Product found }
 *       404: { description: Product not found }
 */
const getBySlug = asyncHandler(async (req, res) => {
  const product = await productService.getProductBySlug(req.params.slug, req.user);
  if (req.user?.role === ROLES.BUYER) {
    recentlyViewedService.recordView(req.user.id, product.id).catch(() => {});
  }
  new ApiResponse(httpStatus.OK, { product }, 'Product retrieved successfully.').send(res);
});

/**
 * @swagger
 * /products:
 *   post:
 *     summary: Create a product (seller creates their own; admin may create for any seller)
 *     tags: [Products]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       201: { description: Product created }
 *       409: { description: Duplicate slug or SKU }
 *       422: { description: Validation failed }
 */
const create = asyncHandler(async (req, res) => {
  const product = await productService.createProduct(req.body, req.user);
  new ApiResponse(httpStatus.CREATED, { product }, 'Product created successfully.').send(res);
});

/**
 * @swagger
 * /products/{id}:
 *   patch:
 *     summary: Update a product (owner seller or admin)
 *     tags: [Products]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Product updated }
 *       403: { description: Not the product owner }
 *       404: { description: Product not found }
 *       409: { description: Duplicate slug or SKU }
 */
const update = asyncHandler(async (req, res) => {
  const product = await productService.updateProduct(req.params.id, req.body, req.user);
  new ApiResponse(httpStatus.OK, { product }, 'Product updated successfully.').send(res);
});

/**
 * @swagger
 * /products/{id}/status:
 *   patch:
 *     summary: Change a product's status (owner seller or admin). Only draft/published/archived — deleted is soft-delete only.
 *     tags: [Products]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               status: { type: string, enum: [draft, published, archived] }
 *     responses:
 *       200: { description: Status changed }
 *       403: { description: Not the product owner }
 *       404: { description: Product not found }
 */
const changeStatus = asyncHandler(async (req, res) => {
  const product = await productService.changeProductStatus(req.params.id, req.body.status, req.user);
  new ApiResponse(httpStatus.OK, { product }, 'Product status updated successfully.').send(res);
});

/**
 * @swagger
 * /products/{id}:
 *   delete:
 *     summary: Soft-delete a product (owner seller or admin). Never a physical delete.
 *     tags: [Products]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Product deleted }
 *       403: { description: Not the product owner }
 *       404: { description: Product not found }
 */
const remove = asyncHandler(async (req, res) => {
  await productService.softDeleteProduct(req.params.id, req.user);
  new ApiResponse(httpStatus.OK, null, 'Product deleted successfully.').send(res);
});

module.exports = {
  list,
  featured,
  trending,
  popular,
  latest,
  mine,
  adminList,
  getById,
  getBySlug,
  create,
  update,
  changeStatus,
  remove,
};
