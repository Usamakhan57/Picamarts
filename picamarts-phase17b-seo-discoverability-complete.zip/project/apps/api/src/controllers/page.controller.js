'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const { getPagination } = require('../utils/pagination');
const { buildSortQuery } = require('../utils/sortHelper');
const { buildSearchQuery } = require('../utils/searchHelper');
const pageService = require('../services/page.service');

/**
 * @swagger
 * tags:
 *   name: CMS Pages
 *   description: Static content page management (Phase 10.3, Part 1)
 */

const SEARCH_FIELDS = ['title', 'content'];
const SORT_FIELDS = ['title', 'publishedAt', 'createdAt', 'updatedAt'];

/**
 * @swagger
 * /pages:
 *   get:
 *     summary: List CMS pages (public sees published only; admin sees everything)
 *     tags: [CMS Pages]
 *     parameters:
 *       - in: query
 *         name: page
 *         schema: { type: integer }
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *       - in: query
 *         name: q
 *         schema: { type: string }
 *       - in: query
 *         name: sort
 *         schema: { type: string }
 *       - in: query
 *         name: status
 *         schema: { type: string, enum: [draft, published] }
 *         description: Admin only in effect — non-admin callers always get published-only regardless of this value.
 *     responses:
 *       200: { description: Paginated list of pages }
 */
const list = asyncHandler(async (req, res) => {
  const { page, limit } = getPagination(req.query);
  const sort = buildSortQuery(req.query.sort, SORT_FIELDS);
  const filter = { ...buildSearchQuery(req.query.q, SEARCH_FIELDS) };
  if (req.query.status) filter.status = req.query.status;

  const { items, meta } = await pageService.listPages(filter, { page, limit, sort }, req.user);

  new ApiResponse(httpStatus.OK, { pages: items }, 'Pages retrieved successfully.', meta).send(res);
});

/**
 * @swagger
 * /pages/type/{pageType}:
 *   get:
 *     summary: Get a page by its fixed type (admin only)
 *     description: Used by the admin UI to load (or discover the absence of) e.g. the "About Us" page for editing.
 *     tags: [CMS Pages]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: pageType
 *         required: true
 *         schema: { type: string, enum: [homepage, about-us, contact-us, privacy-policy, terms-conditions, faq, refund-policy, shipping-policy, cookie-policy] }
 *     responses:
 *       200: { description: Page found }
 *       404: { description: No page has been created yet for this type }
 */
const getByType = asyncHandler(async (req, res) => {
  const page = await pageService.getPageByType(req.params.pageType);
  new ApiResponse(httpStatus.OK, { page }, 'Page retrieved successfully.').send(res);
});

/**
 * @swagger
 * /pages/slug/{slug}:
 *   get:
 *     summary: Get a page by slug
 *     tags: [CMS Pages]
 *     parameters:
 *       - in: path
 *         name: slug
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Page found }
 *       404: { description: Page not found (or not published, for non-admin callers) }
 */
const getBySlug = asyncHandler(async (req, res) => {
  const page = await pageService.getPageBySlug(req.params.slug, req.user ?? null);
  new ApiResponse(httpStatus.OK, { page }, 'Page retrieved successfully.').send(res);
});

/**
 * @swagger
 * /pages/{id}:
 *   get:
 *     summary: Get a page by id
 *     tags: [CMS Pages]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Page found }
 *       404: { description: Page not found (or not published, for non-admin callers) }
 */
const getById = asyncHandler(async (req, res) => {
  const page = await pageService.getPageById(req.params.id, req.user ?? null);
  new ApiResponse(httpStatus.OK, { page }, 'Page retrieved successfully.').send(res);
});

/**
 * @swagger
 * /pages:
 *   post:
 *     summary: Create a CMS page (admin only)
 *     description: One page per `pageType` — a second create for the same type returns 409; use PATCH to edit it instead.
 *     tags: [CMS Pages]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       201: { description: Page created }
 *       409: { description: A page for this pageType (or this slug) already exists }
 *       422: { description: Validation failed }
 */
const create = asyncHandler(async (req, res) => {
  const page = await pageService.createPage(req.body, req.user);
  new ApiResponse(httpStatus.CREATED, { page }, 'Page created successfully.').send(res);
});

/**
 * @swagger
 * /pages/{id}:
 *   patch:
 *     summary: Update a CMS page (admin only)
 *     tags: [CMS Pages]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Page updated }
 *       404: { description: Page not found }
 *       409: { description: Slug already in use }
 */
const update = asyncHandler(async (req, res) => {
  const page = await pageService.updatePage(req.params.id, req.body, req.user);
  new ApiResponse(httpStatus.OK, { page }, 'Page updated successfully.').send(res);
});

/**
 * @swagger
 * /pages/{id}:
 *   delete:
 *     summary: Delete a CMS page (admin only)
 *     tags: [CMS Pages]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Page deleted }
 *       404: { description: Page not found }
 */
const remove = asyncHandler(async (req, res) => {
  await pageService.deletePage(req.params.id);
  new ApiResponse(httpStatus.OK, null, 'Page deleted successfully.').send(res);
});

module.exports = { list, getByType, getBySlug, getById, create, update, remove };
