'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const wishlistService = require('../services/wishlist.service');

/**
 * Phase 7, Part 2 — Wishlist. Every endpoint operates on the
 * AUTHENTICATED BUYER'S OWN wishlist (see routes/v1/wishlist.routes.js,
 * gated to the buyer role only — same reasoning as Cart).
 *
 * Includes one endpoint beyond the 4 explicitly listed in the brief:
 * POST /wishlist/:productId/move-to-cart. "Move Wishlist Item to Cart"
 * was explicitly named as a feature the Wishlist must support, so it
 * gets a route here rather than being left unreachable — flagged as
 * an assumption, same as the admin-cart-debugging endpoint was flagged
 * and deliberately NOT added in Part 1.
 */

/**
 * @swagger
 * /wishlist:
 *   get:
 *     summary: Get the authenticated buyer's wishlist
 *     tags: [Wishlist]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200:
 *         description: The buyer's wishlist (empty shape if they don't have one yet)
 *         content:
 *           application/json:
 *             example:
 *               success: true
 *               message: Wishlist retrieved successfully.
 *               data:
 *                 wishlist:
 *                   id: 64f1a2b3c4d5e6f7a8b9c0d1
 *                   itemCount: 1
 *                   items:
 *                     - id: 64f1a2b3c4d5e6f7a8b9c0d2
 *                       product:
 *                         id: 64f1a2b3c4d5e6f7a8b9c0d3
 *                         title: Sample Product
 *                         basePrice: 29.99
 *                         salePrice: null
 *                         status: published
 *                       addedAt: '2026-07-20T10:00:00.000Z'
 *       401: { description: Authentication required }
 *       403: { description: Only buyers have a wishlist }
 */
const getWishlist = asyncHandler(async (req, res) => {
  const wishlist = await wishlistService.getWishlist(req.user.id);
  new ApiResponse(httpStatus.OK, { wishlist }, 'Wishlist retrieved successfully.').send(res);
});

/**
 * @swagger
 * /wishlist:
 *   post:
 *     summary: Add a product to the authenticated buyer's wishlist
 *     description: Idempotent on duplicates — a product already saved just returns the wishlist unchanged.
 *     tags: [Wishlist]
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [productId]
 *             properties:
 *               productId: { type: string }
 *     responses:
 *       200: { description: Product added (or already present); the full updated wishlist is returned }
 *       401: { description: Authentication required }
 *       403: { description: Only buyers have a wishlist }
 *       404: { description: Product not found }
 *       422: { description: Validation failed (missing/invalid productId) }
 */
const addItem = asyncHandler(async (req, res) => {
  const wishlist = await wishlistService.addItem(req.user.id, req.body.productId, req.user);
  new ApiResponse(httpStatus.OK, { wishlist }, 'Product added to wishlist successfully.').send(res);
});

/**
 * @swagger
 * /wishlist/{productId}:
 *   delete:
 *     summary: Remove a product from the authenticated buyer's wishlist
 *     tags: [Wishlist]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: productId
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Product removed; the full updated wishlist is returned }
 *       401: { description: Authentication required }
 *       404: { description: Wishlist item not found }
 */
const removeItem = asyncHandler(async (req, res) => {
  const wishlist = await wishlistService.removeItem(req.user.id, req.params.productId);
  new ApiResponse(httpStatus.OK, { wishlist }, 'Product removed from wishlist successfully.').send(res);
});

/**
 * @swagger
 * /wishlist:
 *   delete:
 *     summary: Clear the authenticated buyer's wishlist
 *     description: A buyer with no wishlist yet is treated as already-empty (returns an empty wishlist, not a 404).
 *     tags: [Wishlist]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Wishlist cleared }
 *       401: { description: Authentication required }
 */
const clearWishlist = asyncHandler(async (req, res) => {
  const wishlist = await wishlistService.clearWishlist(req.user.id);
  new ApiResponse(httpStatus.OK, { wishlist }, 'Wishlist cleared successfully.').send(res);
});

/**
 * @swagger
 * /wishlist/{productId}/move-to-cart:
 *   post:
 *     summary: Move a wishlist item into the authenticated buyer's cart
 *     description: >
 *       Adds the product to the cart (quantity 1) first — this is
 *       where published/stock rules are enforced — and only removes
 *       it from the wishlist once that succeeds, so a rejected move
 *       leaves the wishlist untouched.
 *     tags: [Wishlist]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: productId
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Item moved; both the updated wishlist and cart are returned }
 *       400: { description: Product not published, out of stock, or no available stock }
 *       401: { description: Authentication required }
 *       404: { description: Wishlist item (or product) not found }
 */
const moveItemToCart = asyncHandler(async (req, res) => {
  const { wishlist, cart } = await wishlistService.moveItemToCart(req.user.id, req.params.productId, req.user);
  new ApiResponse(httpStatus.OK, { wishlist, cart }, 'Item moved to cart successfully.').send(res);
});

module.exports = { getWishlist, addItem, removeItem, clearWishlist, moveItemToCart };
