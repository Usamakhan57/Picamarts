'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const { getPagination } = require('../utils/pagination');
const { buildSortQuery } = require('../utils/sortHelper');
const reviewService = require('../services/review.service');

/**
 * Phase 10.1 — Product Reviews & Ratings.
 *
 * This file is pure request/response plumbing — authorization, purchase
 * verification, duplicate detection, and rating aggregation all live in
 * review.service.js.
 */

/**
 * @swagger
 * tags:
 *   name: Reviews
 *   description: Product review and rating endpoints (Phase 10.1)
 */

// --------------------------------------------------------------------
// GET /reviews — admin-only moderation queue (Phase 15C, Part 9)
// --------------------------------------------------------------------

const ADMIN_SORT_FIELDS = ['createdAt', 'rating', 'helpfulCount'];

/**
 * @swagger
 * /reviews:
 *   get:
 *     summary: List reviews across every product (admin only, paginated, filterable)
 *     tags: [Reviews]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: status
 *         schema: { type: string, enum: [published, hidden, deleted] }
 *       - in: query
 *         name: rating
 *         schema: { type: integer, minimum: 1, maximum: 5 }
 *     responses:
 *       200: { description: Paginated list of reviews across every product }
 */
const listAll = asyncHandler(async (req, res) => {
  const { page, limit } = getPagination(req.query);
  const sort = buildSortQuery(req.query.sort, ADMIN_SORT_FIELDS);
  const filter = {};
  if (req.query.status) filter.status = req.query.status;
  if (req.query.rating) filter.rating = Number(req.query.rating);

  const { items, meta } = await reviewService.listAllReviewsForAdmin(filter, { page, limit, sort });
  new ApiResponse(httpStatus.OK, { reviews: items }, 'Reviews retrieved successfully.', meta).send(res);
});

// --------------------------------------------------------------------
// POST /products/:id/reviews
// --------------------------------------------------------------------

/**
 * @swagger
 * /products/{id}/reviews:
 *   post:
 *     summary: Submit a review for a product (verified buyers only)
 *     description: >
 *       Only a buyer who has at least one paid order containing this
 *       product may submit a review. One active review per buyer per
 *       product — a second POST returns 409. Rating must be 1–5 (integer).
 *       Review body is required (10–5 000 chars). Images are optional
 *       (max 5 URLs). A verified-purchase badge is automatically attached.
 *     tags: [Reviews]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *         description: Product id
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [rating, body]
 *             properties:
 *               rating:
 *                 type: integer
 *                 minimum: 1
 *                 maximum: 5
 *               title:
 *                 type: string
 *                 maxLength: 150
 *               body:
 *                 type: string
 *                 minLength: 10
 *                 maxLength: 5000
 *               images:
 *                 type: array
 *                 maxItems: 5
 *                 items:
 *                   type: object
 *                   properties:
 *                     url: { type: string, format: uri }
 *                     alt: { type: string }
 *     responses:
 *       201:
 *         description: Review created
 *         content:
 *           application/json:
 *             example:
 *               success: true
 *               message: Review submitted successfully.
 *               data:
 *                 review:
 *                   id: 64f1a2b3c4d5e6f7a8b9c0d1
 *                   product: 64f1a2b3c4d5e6f7a8b9c0d2
 *                   reviewer: { id: 64f1a2b3c4d5e6f7a8b9c0d3, name: Jane Doe }
 *                   rating: 5
 *                   title: Great product!
 *                   body: Really happy with this purchase. Would buy again.
 *                   images: []
 *                   verifiedPurchase: true
 *                   helpfulCount: 0
 *                   reportCount: 0
 *                   status: published
 *                   createdAt: '2026-07-23T10:00:00.000Z'
 *       400: { description: Product not published }
 *       401: { description: Authentication required }
 *       403: { description: Only buyers can review / buyer has not purchased this product }
 *       404: { description: Product not found }
 *       409: { description: Buyer has already reviewed this product }
 *       422: { description: Validation failed }
 */
const createReview = asyncHandler(async (req, res) => {
  const review = await reviewService.createReview(req.params.id, req.body, req.user);
  new ApiResponse(httpStatus.CREATED, { review }, 'Review submitted successfully.').send(res);
});

// --------------------------------------------------------------------
// GET /products/:id/reviews
// --------------------------------------------------------------------

/**
 * @swagger
 * /products/{id}/reviews:
 *   get:
 *     summary: List reviews for a product
 *     description: >
 *       Returns paginated reviews for the product along with an
 *       aggregated rating summary (average, total count, distribution).
 *       Anonymous and authenticated non-admin users see only published
 *       reviews. Admins also see hidden (moderated) reviews.
 *       Optional filters: `rating` (1–5 star filter), `sort`
 *       (newest|oldest|helpful|highest|lowest).
 *     tags: [Reviews]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *         description: Product id
 *       - in: query
 *         name: page
 *         schema: { type: integer, minimum: 1 }
 *       - in: query
 *         name: limit
 *         schema: { type: integer, minimum: 1, maximum: 100 }
 *       - in: query
 *         name: sort
 *         schema:
 *           type: string
 *           enum: [newest, oldest, helpful, highest, lowest]
 *       - in: query
 *         name: rating
 *         schema: { type: integer, minimum: 1, maximum: 5 }
 *         description: Filter by exact star value
 *     responses:
 *       200:
 *         description: Review list with rating summary
 *         content:
 *           application/json:
 *             example:
 *               success: true
 *               message: Reviews retrieved successfully.
 *               data:
 *                 summary:
 *                   ratingAverage: 4.3
 *                   ratingCount: 12
 *                   distribution: { '1': 0, '2': 1, '3': 1, '4': 4, '5': 6 }
 *                 reviews:
 *                   - id: 64f1a2b3c4d5e6f7a8b9c0d1
 *                     rating: 5
 *                     title: Great product!
 *                     body: Really happy with this purchase.
 *                     verifiedPurchase: true
 *                     helpfulCount: 3
 *               meta:
 *                 totalItems: 12
 *                 totalPages: 1
 *                 currentPage: 1
 *                 itemsPerPage: 20
 *       404: { description: Product not found }
 *       422: { description: Validation failed }
 */
const listReviews = asyncHandler(async (req, res) => {
  const { items, summary, meta } = await reviewService.listReviews(req.params.id, req.query, req.user ?? null);
  new ApiResponse(httpStatus.OK, { summary, reviews: items }, 'Reviews retrieved successfully.', meta).send(res);
});

// --------------------------------------------------------------------
// PATCH /reviews/:reviewId
// --------------------------------------------------------------------

/**
 * @swagger
 * /reviews/{reviewId}:
 *   patch:
 *     summary: Update a review (buyer edits own / admin moderates)
 *     description: >
 *       A buyer may update rating, title, body, and images of their own
 *       published review. An admin may additionally change the review's
 *       status (published → hidden to moderate, hidden → published to
 *       restore) and add a moderationNote. Admins cannot set status to
 *       "deleted" via PATCH — use DELETE for that.
 *     tags: [Reviews]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: reviewId
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               rating: { type: integer, minimum: 1, maximum: 5 }
 *               title: { type: string, maxLength: 150 }
 *               body: { type: string, minLength: 10, maxLength: 5000 }
 *               images: { type: array, maxItems: 5 }
 *               status:
 *                 type: string
 *                 enum: [published, hidden]
 *                 description: Admin only — moderate/restore a review
 *               moderationNote:
 *                 type: string
 *                 maxLength: 500
 *                 description: Admin only
 *     responses:
 *       200: { description: Review updated }
 *       401: { description: Authentication required }
 *       403: { description: Not the reviewer or not an admin }
 *       404: { description: Review not found }
 *       422: { description: Validation failed }
 */
const updateReview = asyncHandler(async (req, res) => {
  const review = await reviewService.updateReview(req.params.reviewId, req.body, req.user);
  new ApiResponse(httpStatus.OK, { review }, 'Review updated successfully.').send(res);
});

// --------------------------------------------------------------------
// DELETE /reviews/:reviewId
// --------------------------------------------------------------------

/**
 * @swagger
 * /reviews/{reviewId}:
 *   delete:
 *     summary: Delete a review (buyer deletes own / admin deletes any)
 *     description: >
 *       Soft-delete — the document is retained in the database with
 *       status "deleted" for audit purposes. Product rating is
 *       recomputed immediately, excluding deleted reviews.
 *     tags: [Reviews]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: reviewId
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Review deleted }
 *       401: { description: Authentication required }
 *       403: { description: Not the reviewer or not an admin }
 *       404: { description: Review not found }
 */
const deleteReview = asyncHandler(async (req, res) => {
  await reviewService.deleteReview(req.params.reviewId, req.user);
  new ApiResponse(httpStatus.OK, null, 'Review deleted successfully.').send(res);
});

// --------------------------------------------------------------------
// POST /reviews/:reviewId/helpful
// --------------------------------------------------------------------

/**
 * @swagger
 * /reviews/{reviewId}/helpful:
 *   post:
 *     summary: Mark a review as helpful
 *     description: Increments the helpful counter. Any authenticated user can vote.
 *     tags: [Reviews]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: reviewId
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Helpful vote recorded }
 *       401: { description: Authentication required }
 *       404: { description: Review not found or not published }
 */
const markHelpful = asyncHandler(async (req, res) => {
  const review = await reviewService.markHelpful(req.params.reviewId);
  new ApiResponse(httpStatus.OK, { review }, 'Helpful vote recorded.').send(res);
});

// --------------------------------------------------------------------
// POST /reviews/:reviewId/report
// --------------------------------------------------------------------

/**
 * @swagger
 * /reviews/{reviewId}/report:
 *   post:
 *     summary: Report a review as inappropriate
 *     description: >
 *       Authenticated users can flag a published review. Idempotent —
 *       a second report from the same user is silently ignored.
 *       Admins can view report counts via the admin review listing.
 *     tags: [Reviews]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: reviewId
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               reason:
 *                 type: string
 *                 maxLength: 500
 *     responses:
 *       200: { description: Review reported }
 *       401: { description: Authentication required }
 *       404: { description: Review not found or not published }
 */
const reportReview = asyncHandler(async (req, res) => {
  const result = await reviewService.reportReview(req.params.reviewId, req.body, req.user);
  new ApiResponse(httpStatus.OK, result, 'Review reported successfully.').send(res);
});

module.exports = {
  createReview,
  listReviews,
  listAll,
  updateReview,
  deleteReview,
  markHelpful,
  reportReview,
};
