'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const { getPagination } = require('../utils/pagination');
const { buildSortQuery } = require('../utils/sortHelper');
const { buildSearchQuery } = require('../utils/searchHelper');
const userService = require('../services/user.service');

/**
 * Phase 15C, Part 3 — Admin User Management. Every route here is
 * admin-only (see user.routes.js). Read + moderate only — no
 * create/update-profile endpoints; see user.service.js for why.
 */

const SEARCH_FIELDS = ['name', 'email'];
const SORT_FIELDS = ['name', 'email', 'createdAt', 'lastLoginAt'];

/**
 * @swagger
 * /users:
 *   get:
 *     summary: List users (admin only, paginated, searchable, filterable by role/status)
 *     tags: [Users]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Paginated list of users }
 */
const list = asyncHandler(async (req, res) => {
  const { page, limit } = getPagination(req.query);
  const sort = buildSortQuery(req.query.sort, SORT_FIELDS);
  const filter = { ...buildSearchQuery(req.query.q, SEARCH_FIELDS) };

  if (req.query.role) filter.role = req.query.role;
  if (req.query.status === 'active') filter.isActive = true;
  if (req.query.status === 'suspended') filter.isActive = false;

  const { items, meta } = await userService.listUsers(filter, { page, limit, sort });

  new ApiResponse(httpStatus.OK, { users: items }, 'Users retrieved successfully.', meta).send(res);
});

/**
 * @swagger
 * /users/{id}:
 *   get:
 *     summary: Get a user by id (admin only)
 *     tags: [Users]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: User found }
 *       404: { description: User not found }
 */
const getById = asyncHandler(async (req, res) => {
  const user = await userService.getUserById(req.params.id);
  new ApiResponse(httpStatus.OK, { user }, 'User retrieved successfully.').send(res);
});

/**
 * @swagger
 * /users/{id}/suspend:
 *   patch:
 *     summary: Suspend a user account (admin only)
 *     tags: [Users]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: User suspended }
 *       400: { description: Already suspended, or attempting to suspend your own account }
 */
const suspend = asyncHandler(async (req, res) => {
  const user = await userService.suspendUser(req.params.id, req.user.id);
  new ApiResponse(httpStatus.OK, { user }, 'User suspended successfully.').send(res);
});

/**
 * @swagger
 * /users/{id}/activate:
 *   patch:
 *     summary: Reactivate a suspended user account (admin only)
 *     tags: [Users]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: User activated }
 *       400: { description: Already active }
 */
const activate = asyncHandler(async (req, res) => {
  const user = await userService.activateUser(req.params.id);
  new ApiResponse(httpStatus.OK, { user }, 'User activated successfully.').send(res);
});

/**
 * @swagger
 * /users/{id}:
 *   delete:
 *     summary: Delete a user account (admin only; not available for admin accounts or your own)
 *     tags: [Users]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: User deleted }
 *       403: { description: Cannot delete an admin account }
 */
const remove = asyncHandler(async (req, res) => {
  await userService.deleteUser(req.params.id, req.user.id);
  new ApiResponse(httpStatus.OK, null, 'User deleted successfully.').send(res);
});

module.exports = { list, getById, suspend, activate, remove };
