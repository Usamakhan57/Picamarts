'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const { getPagination } = require('../utils/pagination');
const { buildSortQuery } = require('../utils/sortHelper');
const { buildSearchQuery } = require('../utils/searchHelper');
const sellerService = require('../services/seller.service');

/** Phase 5 — Seller Module: self-service store/profile + admin approval workflow. */

const SEARCH_FIELDS = ['storeName', 'storeDescription'];
const SORT_FIELDS = ['storeName', 'createdAt', 'updatedAt'];

// ---------------------------------------------------------------------
// Seller self-service
// ---------------------------------------------------------------------

/**
 * @swagger
 * /sellers/apply:
 *   post:
 *     summary: Apply to become a seller (creates a pending seller profile)
 *     tags: [Sellers]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       201: { description: Application submitted }
 *       409: { description: A seller application already exists for this account }
 */
const apply = asyncHandler(async (req, res) => {
  const seller = await sellerService.applyAsSeller(req.user.id, req.body);
  new ApiResponse(httpStatus.CREATED, { seller }, 'Seller application submitted successfully.').send(res);
});

/**
 * @swagger
 * /sellers/me:
 *   get:
 *     summary: Get the authenticated seller's own profile
 *     tags: [Sellers]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Seller profile }
 *       404: { description: No seller profile found for this account }
 */
const getMyProfile = asyncHandler(async (req, res) => {
  const seller = await sellerService.getSellerByUserId(req.user.id);
  new ApiResponse(httpStatus.OK, { seller }, 'Seller profile retrieved successfully.').send(res);
});

/**
 * @swagger
 * /sellers/me:
 *   patch:
 *     summary: Update the authenticated seller's own store profile
 *     tags: [Sellers]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Seller profile updated }
 *       404: { description: No seller profile found for this account }
 */
const updateMyProfile = asyncHandler(async (req, res) => {
  const seller = await sellerService.updateOwnProfile(req.user.id, req.body);
  new ApiResponse(httpStatus.OK, { seller }, 'Seller profile updated successfully.').send(res);
});

/**
 * @swagger
 * /sellers/me/verification-document:
 *   post:
 *     summary: Submit or resubmit a verification document. Resubmitting after a rejection moves the application back to pending.
 *     tags: [Sellers]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Verification document submitted }
 *       404: { description: No seller profile found for this account }
 */
const submitVerificationDocument = asyncHandler(async (req, res) => {
  const seller = await sellerService.submitVerificationDocument(req.user.id, req.body.verificationDocument);
  new ApiResponse(httpStatus.OK, { seller }, 'Verification document submitted successfully.').send(res);
});

/**
 * @swagger
 * /sellers/me/dashboard:
 *   get:
 *     summary: Get the authenticated seller's dashboard summary (profile + product counts)
 *     tags: [Sellers]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Dashboard summary }
 *       404: { description: No seller profile found for this account }
 */
const getMyDashboard = asyncHandler(async (req, res) => {
  const dashboard = await sellerService.getDashboard(req.user.id);
  new ApiResponse(httpStatus.OK, dashboard, 'Dashboard retrieved successfully.').send(res);
});

// ---------------------------------------------------------------------
// Public storefront
// ---------------------------------------------------------------------

/**
 * @swagger
 * /sellers/store/{slug}:
 *   get:
 *     summary: Get an approved seller's public storefront profile by slug
 *     tags: [Sellers]
 *     parameters:
 *       - in: path
 *         name: slug
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Store found }
 *       404: { description: Store not found }
 */
const getStoreBySlug = asyncHandler(async (req, res) => {
  const seller = await sellerService.getPublicStoreBySlug(req.params.slug);
  new ApiResponse(httpStatus.OK, { seller }, 'Store retrieved successfully.').send(res);
});

// ---------------------------------------------------------------------
// Admin management
// ---------------------------------------------------------------------

/**
 * @swagger
 * /sellers:
 *   get:
 *     summary: List sellers (admin only, paginated, searchable, filterable, sortable)
 *     tags: [Sellers]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: page
 *         schema: { type: integer }
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *       - in: query
 *         name: q
 *         schema: { type: string }
 *       - in: query
 *         name: sort
 *         schema: { type: string }
 *       - in: query
 *         name: status
 *         schema: { type: string }
 *     responses:
 *       200: { description: Paginated list of sellers }
 */
const list = asyncHandler(async (req, res) => {
  const { page, limit } = getPagination(req.query);
  const sort = buildSortQuery(req.query.sort, SORT_FIELDS);
  const filter = { ...buildSearchQuery(req.query.q, SEARCH_FIELDS) };

  if (req.query.status !== undefined) filter.status = req.query.status;

  const { items, meta } = await sellerService.listSellers(filter, { page, limit, sort });

  new ApiResponse(httpStatus.OK, { sellers: items }, 'Sellers retrieved successfully.', meta).send(res);
});

/**
 * @swagger
 * /sellers/{id}:
 *   get:
 *     summary: Get a seller by id (admin only)
 *     tags: [Sellers]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Seller found }
 *       404: { description: Seller not found }
 */
const getById = asyncHandler(async (req, res) => {
  const seller = await sellerService.getSellerByIdForAdmin(req.params.id);
  new ApiResponse(httpStatus.OK, { seller }, 'Seller retrieved successfully.').send(res);
});

/**
 * @swagger
 * /sellers/{id}:
 *   patch:
 *     summary: Update admin-editable seller fields, e.g. commissionRate (admin only)
 *     tags: [Sellers]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Seller updated }
 *       404: { description: Seller not found }
 */
const update = asyncHandler(async (req, res) => {
  const seller = await sellerService.updateSellerByAdmin(req.params.id, req.body);
  new ApiResponse(httpStatus.OK, { seller }, 'Seller updated successfully.').send(res);
});

/**
 * @swagger
 * /sellers/{id}/approve:
 *   patch:
 *     summary: Approve a pending (or rejected) seller application (admin only)
 *     tags: [Sellers]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Seller approved }
 *       404: { description: Seller not found }
 */
const approve = asyncHandler(async (req, res) => {
  const seller = await sellerService.approveSeller(req.params.id, req.user.id);
  new ApiResponse(httpStatus.OK, { seller }, 'Seller approved successfully.').send(res);
});

/**
 * @swagger
 * /sellers/{id}/reject:
 *   patch:
 *     summary: Reject a seller application, optionally with a reason (admin only)
 *     tags: [Sellers]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Seller rejected }
 *       404: { description: Seller not found }
 */
const reject = asyncHandler(async (req, res) => {
  const seller = await sellerService.rejectSeller(req.params.id, req.user.id, req.body.reason);
  new ApiResponse(httpStatus.OK, { seller }, 'Seller rejected successfully.').send(res);
});

/**
 * @swagger
 * /sellers/{id}/suspend:
 *   patch:
 *     summary: Suspend an approved seller, optionally with a reason (admin only)
 *     tags: [Sellers]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Seller suspended }
 *       400: { description: Only an approved seller can be suspended }
 *       404: { description: Seller not found }
 */
const suspend = asyncHandler(async (req, res) => {
  const seller = await sellerService.suspendSeller(req.params.id, req.user.id, req.body.reason);
  new ApiResponse(httpStatus.OK, { seller }, 'Seller suspended successfully.').send(res);
});

/**
 * @swagger
 * /sellers/{id}/reinstate:
 *   patch:
 *     summary: Reinstate a suspended seller back to approved (admin only)
 *     tags: [Sellers]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Seller reinstated }
 *       400: { description: Only a suspended seller can be reinstated }
 *       404: { description: Seller not found }
 */
const reinstate = asyncHandler(async (req, res) => {
  const seller = await sellerService.reinstateSeller(req.params.id, req.user.id);
  new ApiResponse(httpStatus.OK, { seller }, 'Seller reinstated successfully.').send(res);
});

/**
 * @swagger
 * /sellers/{id}:
 *   delete:
 *     summary: Delete a seller profile (admin only)
 *     tags: [Sellers]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Seller deleted }
 *       404: { description: Seller not found }
 */
const remove = asyncHandler(async (req, res) => {
  await sellerService.deleteSeller(req.params.id);
  new ApiResponse(httpStatus.OK, null, 'Seller deleted successfully.').send(res);
});

module.exports = {
  apply,
  getMyProfile,
  updateMyProfile,
  submitVerificationDocument,
  getMyDashboard,
  getStoreBySlug,
  list,
  getById,
  update,
  approve,
  reject,
  suspend,
  reinstate,
  remove,
};
