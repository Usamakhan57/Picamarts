'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const commissionService = require('../services/commission.service');

/**
 * @swagger
 * tags:
 *   name: Commission
 *   description: Admin commission settings — global/category/seller (Phase 16B, Part 5)
 */

/**
 * @swagger
 * /commission/settings:
 *   get:
 *     summary: Get the global default commission rate (admin only)
 *     tags: [Commission]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Global commission settings }
 *       401: { description: Authentication required }
 *       403: { description: Admins only }
 */
const getGlobalSettings = asyncHandler(async (req, res) => {
  const settings = await commissionService.getGlobalSettings();
  new ApiResponse(httpStatus.OK, { settings }, 'Global commission settings retrieved.').send(res);
});

/**
 * @swagger
 * /commission/settings:
 *   patch:
 *     summary: Update the global default commission rate (admin only)
 *     tags: [Commission]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Global commission settings updated }
 *       401: { description: Authentication required }
 *       403: { description: Admins only }
 *       422: { description: Validation failed }
 */
const updateGlobalSettings = asyncHandler(async (req, res) => {
  const settings = await commissionService.updateGlobalSettings(req.body.defaultCommissionRate, req.user.id);
  new ApiResponse(httpStatus.OK, { settings }, 'Global commission settings updated.').send(res);
});

/**
 * @swagger
 * /commission/categories/{categoryId}:
 *   patch:
 *     summary: Set (or clear, with null) a category's commission override (admin only)
 *     tags: [Commission]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Category commission updated }
 *       401: { description: Authentication required }
 *       403: { description: Admins only }
 *       404: { description: Category not found }
 *       422: { description: Validation failed }
 */
const updateCategoryCommission = asyncHandler(async (req, res) => {
  const result = await commissionService.setCategoryCommission(req.params.categoryId, req.body.commissionRate);
  new ApiResponse(httpStatus.OK, result, 'Category commission updated.').send(res);
});

/**
 * @swagger
 * /commission/sellers/{sellerId}:
 *   patch:
 *     summary: Set (or clear, with null) a seller's commission override (admin only)
 *     description: sellerId is the Seller PROFILE id (same convention as PATCH /sellers/{id}) — this reuses the existing Seller.commissionRate field rather than a new one.
 *     tags: [Commission]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Seller commission override updated }
 *       401: { description: Authentication required }
 *       403: { description: Admins only }
 *       404: { description: Seller not found }
 *       422: { description: Validation failed }
 */
const updateSellerCommission = asyncHandler(async (req, res) => {
  const result = await commissionService.setSellerCommissionOverride(req.params.sellerId, req.body.commissionRate);
  new ApiResponse(httpStatus.OK, result, 'Seller commission override updated.').send(res);
});

module.exports = { getGlobalSettings, updateGlobalSettings, updateCategoryCommission, updateSellerCommission };
