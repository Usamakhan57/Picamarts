'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const payoutService = require('../services/payout.service');

/**
 * @swagger
 * tags:
 *   name: Payouts
 *   description: Seller withdrawal requests, Stripe transfers, and the admin payout queue (Phase 16C)
 */

/**
 * @swagger
 * /payouts/me:
 *   post:
 *     summary: Request a withdrawal of the authenticated seller's available balance
 *     tags: [Payouts]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       201: { description: Withdrawal request created, balance locked }
 *       400: { description: Invalid amount, exceeds balance, or Stripe payouts not enabled }
 *       401: { description: Authentication required }
 *       403: { description: Sellers only }
 *       409: { description: An active request already exists }
 */
const createWithdrawal = asyncHandler(async (req, res) => {
  const request = await payoutService.createWithdrawalRequest(req.user.id, req.body);
  new ApiResponse(httpStatus.CREATED, { request }, 'Withdrawal request created.').send(res);
});

/**
 * @swagger
 * /payouts/me:
 *   get:
 *     summary: The authenticated seller's own paginated withdrawal history
 *     tags: [Payouts]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Paginated withdrawal requests }
 *       401: { description: Authentication required }
 *       403: { description: Sellers only }
 */
const listMyWithdrawals = asyncHandler(async (req, res) => {
  const { page, limit } = req.query;
  const { items, meta } = await payoutService.getSellerRequests(req.user.id, { page, limit });
  new ApiResponse(httpStatus.OK, { requests: items }, 'Withdrawal requests retrieved.', meta).send(res);
});

/**
 * @swagger
 * /payouts/me/{requestId}/cancel:
 *   post:
 *     summary: Cancel a still-pending withdrawal request (releases the balance lock)
 *     tags: [Payouts]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Request cancelled }
 *       401: { description: Authentication required }
 *       403: { description: Sellers only }
 *       404: { description: Request not found }
 *       409: { description: Request is no longer pending }
 */
const cancelWithdrawal = asyncHandler(async (req, res) => {
  const request = await payoutService.cancelWithdrawalRequest(req.user.id, req.params.requestId);
  new ApiResponse(httpStatus.OK, { request }, 'Withdrawal request cancelled.').send(res);
});

/**
 * @swagger
 * /payouts/admin:
 *   get:
 *     summary: Admin payout queue, optionally filtered by status (admin only)
 *     tags: [Payouts]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Paginated withdrawal requests }
 *       401: { description: Authentication required }
 *       403: { description: Admins only }
 */
const listAdminQueue = asyncHandler(async (req, res) => {
  const { page, limit, status } = req.query;
  const { items, meta } = await payoutService.getAdminQueue({ page, limit, status });
  new ApiResponse(httpStatus.OK, { requests: items }, 'Payout queue retrieved.', meta).send(res);
});

/**
 * @swagger
 * /payouts/admin/overview:
 *   get:
 *     summary: Marketplace-wide payout totals by status (admin only)
 *     tags: [Payouts]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Payout totals by status, plus totalPaid/totalPending }
 *       401: { description: Authentication required }
 *       403: { description: Admins only }
 */
const getAdminOverview = asyncHandler(async (req, res) => {
  const overview = await payoutService.getAdminPayoutOverview();
  new ApiResponse(httpStatus.OK, overview, 'Payout overview retrieved.').send(res);
});

/**
 * @swagger
 * /payouts/admin/{requestId}/approve:
 *   post:
 *     summary: Approve a pending withdrawal request and immediately attempt the Stripe transfer (admin only)
 *     tags: [Payouts]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Request approved and processed (completed or failed) }
 *       401: { description: Authentication required }
 *       403: { description: Admins only }
 *       404: { description: Request not found }
 *       409: { description: Request is not pending }
 */
const approveWithdrawal = asyncHandler(async (req, res) => {
  const request = await payoutService.approveWithdrawalRequest(req.params.requestId, req.user.id);
  new ApiResponse(httpStatus.OK, { request }, 'Withdrawal request processed.').send(res);
});

/**
 * @swagger
 * /payouts/admin/{requestId}/reject:
 *   post:
 *     summary: Reject a pending withdrawal request and release its balance lock (admin only)
 *     tags: [Payouts]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Request rejected }
 *       401: { description: Authentication required }
 *       403: { description: Admins only }
 *       404: { description: Request not found }
 *       409: { description: Request is not pending }
 */
const rejectWithdrawal = asyncHandler(async (req, res) => {
  const request = await payoutService.rejectWithdrawalRequest(req.params.requestId, req.user.id, req.body.reason);
  new ApiResponse(httpStatus.OK, { request }, 'Withdrawal request rejected.').send(res);
});

/**
 * @swagger
 * /payouts/admin/{requestId}/retry:
 *   post:
 *     summary: Retry the Stripe transfer for a failed withdrawal request (admin only)
 *     tags: [Payouts]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Retry attempted (completed or failed again) }
 *       401: { description: Authentication required }
 *       403: { description: Admins only }
 *       404: { description: Request not found }
 *       409: { description: Request is not failed }
 */
const retryWithdrawal = asyncHandler(async (req, res) => {
  const request = await payoutService.retryWithdrawalRequest(req.params.requestId);
  new ApiResponse(httpStatus.OK, { request }, 'Withdrawal retry attempted.').send(res);
});

module.exports = {
  createWithdrawal,
  listMyWithdrawals,
  cancelWithdrawal,
  listAdminQueue,
  getAdminOverview,
  approveWithdrawal,
  rejectWithdrawal,
  retryWithdrawal,
};
