'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const httpStatus = require('../constants/httpStatus');
const { getPagination } = require('../utils/pagination');
const { buildSortQuery } = require('../utils/sortHelper');
const { buildSearchQuery } = require('../utils/searchHelper');
const contactMessageService = require('../services/contactMessage.service');

/**
 * @swagger
 * tags:
 *   name: Contact
 *   description: Contact form submission + admin inbox (Phase 10.3, Part 4)
 */

const SEARCH_FIELDS = ['name', 'email', 'subject', 'message'];
const SORT_FIELDS = ['createdAt', 'updatedAt', 'status'];

/**
 * @swagger
 * /contact:
 *   post:
 *     summary: Submit the contact form (public, no authentication required)
 *     tags: [Contact]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [name, email, message]
 *             properties:
 *               name: { type: string, maxLength: 120 }
 *               email: { type: string, format: email }
 *               phone: { type: string }
 *               subject: { type: string, maxLength: 200 }
 *               message: { type: string, maxLength: 5000 }
 *     responses:
 *       201: { description: Message submitted }
 *       422: { description: Validation failed }
 */
const submit = asyncHandler(async (req, res) => {
  const message = await contactMessageService.submitMessage(req.body);
  new ApiResponse(httpStatus.CREATED, { message }, 'Your message has been submitted successfully.').send(res);
});

/**
 * @swagger
 * /contact:
 *   get:
 *     summary: List contact messages (admin only — the inbox)
 *     tags: [Contact]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: page
 *         schema: { type: integer }
 *       - in: query
 *         name: limit
 *         schema: { type: integer }
 *       - in: query
 *         name: q
 *         schema: { type: string }
 *       - in: query
 *         name: status
 *         schema: { type: string, enum: [new, in_progress, resolved] }
 *     responses:
 *       200: { description: Paginated list of contact messages }
 *       401: { description: Authentication required }
 *       403: { description: Admin only }
 */
const list = asyncHandler(async (req, res) => {
  const { page, limit } = getPagination(req.query);
  const sort = buildSortQuery(req.query.sort, SORT_FIELDS);
  const filter = { ...buildSearchQuery(req.query.q, SEARCH_FIELDS) };
  if (req.query.status) filter.status = req.query.status;

  const { items, meta } = await contactMessageService.listMessages(filter, { page, limit, sort });

  new ApiResponse(httpStatus.OK, { messages: items }, 'Contact messages retrieved successfully.', meta).send(res);
});

/**
 * @swagger
 * /contact/{id}:
 *   get:
 *     summary: Get a single contact message (admin only)
 *     tags: [Contact]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Message found }
 *       401: { description: Authentication required }
 *       403: { description: Admin only }
 *       404: { description: Message not found }
 */
const getById = asyncHandler(async (req, res) => {
  const message = await contactMessageService.getMessageById(req.params.id);
  new ApiResponse(httpStatus.OK, { message }, 'Contact message retrieved successfully.').send(res);
});

/**
 * @swagger
 * /contact/{id}/status:
 *   patch:
 *     summary: Update a contact message's status and/or admin notes (admin only)
 *     description: Moving status to "resolved" stamps resolvedAt/resolvedBy the first time only.
 *     tags: [Contact]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               status: { type: string, enum: [new, in_progress, resolved] }
 *               adminNotes: { type: string }
 *     responses:
 *       200: { description: Message updated }
 *       401: { description: Authentication required }
 *       403: { description: Admin only }
 *       404: { description: Message not found }
 */
const updateStatus = asyncHandler(async (req, res) => {
  const message = await contactMessageService.updateMessageStatus(req.params.id, req.body, req.user);
  new ApiResponse(httpStatus.OK, { message }, 'Contact message updated successfully.').send(res);
});

/**
 * @swagger
 * /contact/{id}:
 *   delete:
 *     summary: Delete a contact message (admin only)
 *     tags: [Contact]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Message deleted }
 *       401: { description: Authentication required }
 *       403: { description: Admin only }
 *       404: { description: Message not found }
 */
const remove = asyncHandler(async (req, res) => {
  await contactMessageService.deleteMessage(req.params.id);
  new ApiResponse(httpStatus.OK, null, 'Contact message deleted successfully.').send(res);
});

module.exports = { submit, list, getById, updateStatus, remove };
