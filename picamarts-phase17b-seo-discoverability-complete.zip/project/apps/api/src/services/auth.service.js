'use strict';

const ms = require('ms');
const { v4: uuidv4 } = require('uuid');
const config = require('../config');
const ApiError = require('../utils/ApiError');
const userRepository = require('../repositories/user.repository');
const { comparePassword } = require('../utils/password');
const { generateToken, hashToken } = require('../utils/cryptoToken');
const { signAccessToken, signRefreshToken, verifyRefreshToken } = require('../utils/token');
const { sendMail } = require('../emails/mailer');
const verificationEmailTemplate = require('../emails/templates/verificationEmail');
const resetPasswordEmailTemplate = require('../emails/templates/resetPasswordEmail');
const welcomeEmailTemplate = require('../emails/templates/welcomeEmail');
// Phase 10.2 — Notification System. Additive, fire-and-forget calls
// only (`.catch(() => {})`) — see order.service.js's identical comment.
const notificationService = require('./notification.service');
const logger = require('../utils/logger');

const REFRESH_COOKIE_MAX_AGE_MS = ms(config.jwt.refreshExpiresIn);

/** Builds the JWT payload embedded in access/refresh tokens. */
const buildTokenPayload = (user) => ({ sub: user._id.toString(), role: user.role });

/**
 * Signs a fresh access + refresh token pair for a user and persists the
 * refresh token's hash as a new session on the user document.
 *
 * @returns {Promise<{ accessToken: string, refreshToken: string }>}
 */
const issueTokenPair = async (user, meta = {}) => {
  const payload = buildTokenPayload(user);
  const accessToken = signAccessToken(payload);
  const refreshToken = signRefreshToken({ ...payload, jti: uuidv4() });

  await userRepository.addRefreshToken(user._id, {
    tokenHash: hashToken(refreshToken),
    userAgent: meta.userAgent || '',
    ip: meta.ip || '',
    expiresAt: new Date(Date.now() + REFRESH_COOKIE_MAX_AGE_MS),
  });

  return { accessToken, refreshToken };
};

/**
 * Registers a new buyer/seller account and emails a verification link.
 * Does not log the user in — email verification is required first.
 */
const register = async ({ name, email, password, role }) => {
  const alreadyExists = await userRepository.existsByEmail(email);
  if (alreadyExists) {
    throw ApiError.conflict('An account with this email already exists.');
  }

  const { rawToken, hashedToken } = generateToken();
  const expiresAt = new Date(Date.now() + config.auth.emailVerificationExpiresInHours * 60 * 60 * 1000);

  const user = await userRepository.create({
    name,
    email,
    password,
    role,
    emailVerificationTokenHash: hashedToken,
    emailVerificationExpires: expiresAt,
  });

  const verifyUrl = `${config.frontendUrl}/verify-email/${rawToken}`;
  const { subject, html, text } = verificationEmailTemplate({
    name: user.name,
    verifyUrl,
    expiresInHours: config.auth.emailVerificationExpiresInHours,
  });
  await sendMail({ to: user.email, subject, html, text });

  return user;
};

/** Verifies a user's email using the raw token emailed to them, then sends a welcome email. */
const verifyEmail = async (rawToken) => {
  const user = await userRepository.findByEmailVerificationTokenHash(hashToken(rawToken));

  if (!user) {
    throw ApiError.badRequest('This verification link is invalid or has expired.');
  }

  user.isEmailVerified = true;
  user.emailVerificationTokenHash = null;
  user.emailVerificationExpires = null;
  await userRepository.save(user);

  const { subject, html, text } = welcomeEmailTemplate({ name: user.name, appUrl: config.frontendUrl });
  await sendMail({ to: user.email, subject, html, text });

  notificationService.notifyEmailVerified(user._id.toString()).catch(() => {});

  return user;
};

/** Authenticates a user and issues a new token pair. */
const login = async ({ email, password }, meta = {}) => {
  const user = await userRepository.findByEmail(email, { withPassword: true });

  if (!user || !(await comparePassword(password, user.password))) {
    throw ApiError.unauthorized('Incorrect email or password.');
  }

  if (!user.isActive) {
    throw ApiError.forbidden('This account has been disabled. Please contact support.');
  }

  if (!user.isEmailVerified) {
    throw ApiError.forbidden('Please verify your email address before logging in.');
  }

  const { accessToken, refreshToken } = await issueTokenPair(user, meta);

  user.lastLoginAt = new Date();
  await userRepository.save(user);

  return { user, accessToken, refreshToken, refreshMaxAgeMs: REFRESH_COOKIE_MAX_AGE_MS };
};

/**
 * Rotates a refresh token: verifies it, confirms the matching session is
 * still on record, removes that session, and issues a brand new pair.
 *
 * If the token's signature/expiry is valid but no matching session is
 * found, that's a signal the token was already rotated once before (or
 * is forged) — every session for that user is revoked as a precaution
 * against refresh-token replay.
 */
const refreshTokens = async (rawRefreshToken, meta = {}) => {
  if (!rawRefreshToken) {
    throw ApiError.unauthorized('Refresh token missing.');
  }

  let payload;
  try {
    payload = verifyRefreshToken(rawRefreshToken);
  } catch {
    throw ApiError.unauthorized('Invalid or expired refresh token. Please log in again.');
  }

  const user = await userRepository.findById(payload.sub, { withRefreshTokens: true });
  if (!user) {
    throw ApiError.unauthorized('Invalid or expired refresh token. Please log in again.');
  }

  const incomingHash = hashToken(rawRefreshToken);
  const matchingSession = user.refreshTokens.find((session) => session.tokenHash === incomingHash);

  if (!matchingSession) {
    logger.warn(`Refresh token reuse detected for user ${user._id} — revoking all sessions.`);
    await userRepository.clearRefreshTokens(user._id);
    throw ApiError.unauthorized('Session is no longer valid. Please log in again.');
  }

  await userRepository.removeRefreshTokenByHash(user._id, incomingHash);
  const { accessToken, refreshToken } = await issueTokenPair(user, meta);

  return { user, accessToken, refreshToken, refreshMaxAgeMs: REFRESH_COOKIE_MAX_AGE_MS };
};

/** Logs a user out of the session tied to the given refresh token. Never throws on an already-invalid token. */
const logout = async (rawRefreshToken) => {
  if (!rawRefreshToken) return;

  try {
    const payload = verifyRefreshToken(rawRefreshToken);
    await userRepository.removeRefreshTokenByHash(payload.sub, hashToken(rawRefreshToken));
  } catch {
    // Token already invalid/expired — nothing to clean up server-side.
  }
};

/**
 * Starts a password reset. Always resolves successfully regardless of
 * whether the email exists, so the endpoint can't be used to enumerate
 * registered accounts.
 */
const forgotPassword = async (email) => {
  const user = await userRepository.findByEmail(email);
  if (!user) return;

  const { rawToken, hashedToken } = generateToken();
  user.passwordResetTokenHash = hashedToken;
  user.passwordResetExpires = new Date(Date.now() + config.auth.passwordResetExpiresInMinutes * 60 * 1000);
  await userRepository.save(user);

  const resetUrl = `${config.frontendUrl}/reset-password/${rawToken}`;
  const { subject, html, text } = resetPasswordEmailTemplate({
    name: user.name,
    resetUrl,
    expiresInMinutes: config.auth.passwordResetExpiresInMinutes,
  });
  await sendMail({ to: user.email, subject, html, text });
};

/** Completes a password reset using the raw token emailed to the user. Logs out every session. */
const resetPassword = async (rawToken, newPassword) => {
  const user = await userRepository.findByPasswordResetTokenHash(hashToken(rawToken));

  if (!user) {
    throw ApiError.badRequest('This password reset link is invalid or has expired.');
  }

  user.password = newPassword;
  user.passwordResetTokenHash = null;
  user.passwordResetExpires = null;
  user.refreshTokens = [];
  await userRepository.save(user);

  notificationService.notifyPasswordReset(user._id.toString()).catch(() => {});

  return user;
};

/** Changes the password for an authenticated user. Logs out every other session. */
const changePassword = async (userId, currentPassword, newPassword) => {
  const user = await userRepository.findById(userId, { withPassword: true });
  if (!user) {
    throw ApiError.notFound('User not found.');
  }

  if (!(await comparePassword(currentPassword, user.password))) {
    throw ApiError.unauthorized('Current password is incorrect.');
  }

  user.password = newPassword;
  user.refreshTokens = [];
  await userRepository.save(user);

  notificationService.notifyPasswordChanged(user._id.toString()).catch(() => {});

  return user;
};

/** Updates the mutable subset of a user's profile (name, avatar) — never email/password/role. */
const updateProfile = async (userId, updates) => {
  const allowedUpdates = {};
  if (updates.name !== undefined) allowedUpdates.name = updates.name;
  if (updates.avatar !== undefined) allowedUpdates.avatar = updates.avatar;

  const user = await userRepository.updateById(userId, allowedUpdates);
  if (!user) {
    throw ApiError.notFound('User not found.');
  }

  return user;
};

const getCurrentUser = async (userId) => {
  const user = await userRepository.findById(userId);
  if (!user) {
    throw ApiError.notFound('User not found.');
  }
  return user;
};

module.exports = {
  register,
  verifyEmail,
  login,
  refreshTokens,
  logout,
  forgotPassword,
  resetPassword,
  changePassword,
  updateProfile,
  getCurrentUser,
  REFRESH_COOKIE_MAX_AGE_MS,
};
