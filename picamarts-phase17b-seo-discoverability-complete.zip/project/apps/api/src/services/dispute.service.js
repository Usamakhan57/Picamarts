'use strict';

const ApiError = require('../utils/ApiError');
const disputeRepository = require('../repositories/dispute.repository');
const paymentRepository = require('../repositories/payment.repository');
const commissionRecordRepository = require('../repositories/commissionRecord.repository');
const walletService = require('./wallet.service');
const notificationService = require('./notification.service');
const notificationRepository = require('../repositories/notification.repository');
const { ROLES } = require('../constants/roles');
const {
  DISPUTE_ORIGINS,
  DISPUTE_STATUSES,
  RESOLVED_DISPUTE_STATUSES,
  DISPUTE_PARTICIPANTS,
} = require('../constants/disputeEnums');
const { NOTIFICATION_TYPES, RELATED_ENTITY_TYPES } = require('../constants/notificationEnums');

const idStr = (value) => (value?.toString ? value.toString() : value);
const round2 = (n) => Math.round(n * 100) / 100;

/**
 * Phase 16D, Parts 6-7 — Stripe chargeback synchronization + the
 * marketplace's own Dispute Center. See constants/disputeEnums.js for
 * why both share one `Dispute` model. Wallet reconciliation (Part
 * 5/10) is driven entirely off `status` transitions here, reusing
 * wallet.service.js's Phase 16D hold/release/loss functions — never
 * duplicating Phase 16B/16C's own ledger-write mechanics.
 */

// --------------------------------------------------------------------
// Response shaping
// --------------------------------------------------------------------

const toDisputeResponse = (doc) => ({
  id: idStr(doc._id),
  order: idStr(doc.order),
  payment: doc.payment ? idStr(doc.payment) : null,
  buyer: idStr(doc.buyer),
  seller: idStr(doc.seller),
  origin: doc.origin,
  stripeDisputeId: doc.stripeDisputeId || null,
  reason: doc.reason,
  amount: doc.amount,
  currency: doc.currency,
  status: doc.status,
  evidenceDueBy: doc.evidenceDueBy,
  evidence: (doc.evidence || []).map((e) => ({
    submittedBy: idStr(e.submittedBy),
    role: e.role,
    note: e.note,
    attachments: e.attachments || [],
    submittedAt: e.submittedAt,
  })),
  timeline: (doc.timeline || []).map((t) => ({ status: t.status, note: t.note, changedBy: idStr(t.changedBy), at: t.at })),
  createdAt: doc.createdAt,
  updatedAt: doc.updatedAt,
});

// --------------------------------------------------------------------
// Visibility
// --------------------------------------------------------------------

const assertVisible = (doc, actingUser) => {
  if (actingUser.role === ROLES.ADMIN) return;
  if (doc.buyer.toString() === actingUser.id) return;
  if (doc.seller.toString() === actingUser.id) return;
  throw ApiError.notFound('Dispute not found.');
};

const roleOf = (actingUser) => {
  if (actingUser.role === ROLES.ADMIN) return DISPUTE_PARTICIPANTS.ADMIN;
  if (actingUser.role === ROLES.SELLER) return DISPUTE_PARTICIPANTS.SELLER;
  return DISPUTE_PARTICIPANTS.BUYER;
};

// --------------------------------------------------------------------
// Notifications (Part 8)
// --------------------------------------------------------------------

const notifyDisputeParties = async (dispute, type, title, message) => {
  await Promise.all([
    notificationService.emitNotification({
      recipientId: dispute.buyer,
      type,
      title,
      message,
      relatedEntity: RELATED_ENTITY_TYPES.DISPUTE,
      relatedEntityId: idStr(dispute._id),
    }),
    notificationService.emitNotification({
      recipientId: dispute.seller,
      type,
      title,
      message,
      relatedEntity: RELATED_ENTITY_TYPES.DISPUTE,
      relatedEntityId: idStr(dispute._id),
    }),
  ]);
};

const notifyAdminsDisputeOpened = async (dispute) => {
  const adminIds = await notificationRepository.findAdminIds();
  await Promise.all(
    adminIds.map((adminId) =>
      notificationService.emitNotification({
        recipientId: adminId,
        type: dispute.origin === DISPUTE_ORIGINS.STRIPE_CHARGEBACK ? NOTIFICATION_TYPES.CHARGEBACK_OPENED : NOTIFICATION_TYPES.DISPUTE_OPENED,
        title: dispute.origin === DISPUTE_ORIGINS.STRIPE_CHARGEBACK ? 'New chargeback' : 'New dispute opened',
        message: `A ${dispute.origin === DISPUTE_ORIGINS.STRIPE_CHARGEBACK ? 'chargeback' : 'dispute'} of ${dispute.amount} ${String(dispute.currency).toUpperCase()} needs review.`,
        relatedEntity: RELATED_ENTITY_TYPES.DISPUTE,
        relatedEntityId: idStr(dispute._id),
      })
    )
  );
};

// --------------------------------------------------------------------
// Part 6 — Stripe chargeback synchronization (called from payment.service.js's webhook handler)
// --------------------------------------------------------------------

/** Maps Stripe's own dispute.status values onto this project's unified DISPUTE_STATUSES. */
const mapStripeStatus = (stripeStatus) => {
  switch (stripeStatus) {
    case 'won':
      return DISPUTE_STATUSES.WON;
    case 'lost':
      return DISPUTE_STATUSES.LOST;
    case 'under_review':
    case 'warning_under_review':
      return DISPUTE_STATUSES.UNDER_REVIEW;
    case 'warning_closed':
    case 'charge_refunded':
      return DISPUTE_STATUSES.CLOSED;
    case 'needs_response':
    case 'warning_needs_response':
    default:
      return DISPUTE_STATUSES.OPEN;
  }
};

/**
 * Handles a `charge.dispute.created|updated|closed|funds_withdrawn|funds_reinstated`
 * event already signature-verified and idempotency-gated by
 * payment.service.js#handleStripeWebhook (this function is only ever
 * called from there — it never re-verifies the signature or re-checks
 * WebhookEvent itself, reusing that pipeline entirely).
 *
 * A chargeback is raised against a Stripe Charge/PaymentIntent, which
 * may span MULTIPLE sellers on this marketplace (see Order.sellers) —
 * one Dispute document is created/updated per affected seller,
 * proportional to their share of the order's gross (same "flagged
 * simplification" wallet.service.js#reverseEarningsForRefundRequest
 * already uses for partial refunds).
 */
const syncFromStripeEvent = async (stripeDispute) => {
  const paymentIntentId = typeof stripeDispute.payment_intent === 'string' ? stripeDispute.payment_intent : stripeDispute.payment_intent?.id;
  if (!paymentIntentId) return;

  const payment = await paymentRepository.findByPaymentIntentId(paymentIntentId);
  if (!payment) return;

  const order = await paymentRepository.findOrderById(payment.order);
  if (!order || !order.sellers?.length) return;

  const records = await commissionRecordRepository.listByOrder(order._id);
  if (!records.length) return;

  const totalGross = records.reduce((sum, r) => sum + r.grossAmount, 0);
  const disputeAmount = round2((stripeDispute.amount || 0) / 100);
  const newStatus = mapStripeStatus(stripeDispute.status);
  const evidenceDueBy = stripeDispute.evidence_details?.due_by ? new Date(stripeDispute.evidence_details.due_by * 1000) : null;

  for (const record of records) {
    const sellerShare = totalGross > 0 ? round2(disputeAmount * (record.grossAmount / totalGross)) : 0;

    const existing = await disputeRepository.findByStripeDisputeIdAndSeller(stripeDispute.id, record.seller);
    const wasNew = !existing;
    const previousStatus = existing?.status;

    const dispute = await disputeRepository.upsertByStripeDisputeIdAndSeller(
      stripeDispute.id,
      record.seller,
      {
        order: order._id,
        payment: payment._id,
        buyer: order.buyer,
        seller: record.seller,
        origin: DISPUTE_ORIGINS.STRIPE_CHARGEBACK,
        stripeDisputeId: stripeDispute.id,
        reason: stripeDispute.reason || 'general',
        amount: sellerShare,
        currency: (stripeDispute.currency || payment.currency || 'usd').toLowerCase(),
      },
      {
        $set: { status: newStatus, evidenceDueBy, providerResponse: { id: stripeDispute.id, status: stripeDispute.status } },
        $push: { timeline: { status: newStatus, note: `Synced from Stripe (${stripeDispute.status}).`, changedBy: null, at: new Date() } },
      }
    );

    if (wasNew) {
      await walletService.holdForDispute(dispute);
      notifyAdminsDisputeOpened(dispute).catch(() => {});
      notifyDisputeParties(dispute, NOTIFICATION_TYPES.CHARGEBACK_OPENED, 'Chargeback opened', `A chargeback was opened on order involving your item(s).`).catch(() => {});
    } else if (previousStatus !== newStatus) {
      if (newStatus === DISPUTE_STATUSES.WON || newStatus === DISPUTE_STATUSES.CLOSED) {
        await walletService.releaseDisputeHold(dispute);
      } else if (newStatus === DISPUTE_STATUSES.LOST) {
        await walletService.finalizeDisputeLoss(dispute);
      }
      notifyDisputeParties(dispute, NOTIFICATION_TYPES.DISPUTE_STATUS_CHANGED, 'Chargeback status updated', `Your chargeback is now ${newStatus}.`).catch(() => {});
    }
  }
};

// --------------------------------------------------------------------
// Part 7 — Dispute Center (buyer-opened, marketplace-native)
// --------------------------------------------------------------------

const openBuyerDispute = async (orderId, actingUser, body) => {
  const order = await paymentRepository.findOrderById(orderId);
  if (!order) throw ApiError.notFound('Order not found.');
  if (order.buyer.toString() !== actingUser.id) throw ApiError.notFound('Order not found.');

  const sellerId = body.sellerId;
  if (!order.sellers.some((s) => s.toString() === sellerId)) {
    throw ApiError.badRequest('This seller did not sell any item on this order.');
  }

  const payment = await paymentRepository.findActiveByOrder(orderId);
  const record = await commissionRecordRepository.findByOrderAndSeller(orderId, sellerId);
  const amount = body.amount || record?.netSellerEarnings || 0;

  const dispute = await disputeRepository.create({
    order: order._id,
    payment: payment ? payment._id : null,
    buyer: actingUser.id,
    seller: sellerId,
    origin: DISPUTE_ORIGINS.BUYER_OPENED,
    reason: body.reason,
    amount,
    currency: payment?.currency || 'usd',
    status: DISPUTE_STATUSES.OPEN,
    evidence: body.note ? [{ submittedBy: actingUser.id, role: DISPUTE_PARTICIPANTS.BUYER, note: body.note, attachments: body.attachments || [] }] : [],
    timeline: [{ status: DISPUTE_STATUSES.OPEN, note: 'Dispute opened by buyer.', changedBy: actingUser.id, at: new Date() }],
  });

  await walletService.holdForDispute(dispute);
  notifyAdminsDisputeOpened(dispute).catch(() => {});
  notifyDisputeParties(dispute, NOTIFICATION_TYPES.DISPUTE_OPENED, 'Dispute opened', 'A buyer opened a dispute on an order.').catch(() => {});

  return toDisputeResponse(dispute);
};

/** Buyer or seller adds evidence/a message — moves an OPEN dispute to EVIDENCE_SUBMITTED (ahead of Stripe's own async status sync, for a STRIPE_CHARGEBACK). */
const addEvidence = async (id, actingUser, { note, attachments }) => {
  const dispute = await disputeRepository.findById(id);
  if (!dispute) throw ApiError.notFound('Dispute not found.');
  assertVisible(dispute, actingUser);
  if (RESOLVED_DISPUTE_STATUSES.includes(dispute.status)) {
    throw ApiError.badRequest('This dispute is already resolved.');
  }

  const role = roleOf(actingUser);
  const nextStatus = dispute.status === DISPUTE_STATUSES.OPEN ? DISPUTE_STATUSES.EVIDENCE_SUBMITTED : dispute.status;

  const updated = await disputeRepository.transitionStatus(id, [DISPUTE_STATUSES.OPEN, DISPUTE_STATUSES.UNDER_REVIEW, DISPUTE_STATUSES.EVIDENCE_SUBMITTED], {
    $set: { status: nextStatus },
    $push: {
      evidence: { submittedBy: actingUser.id, role, note: note || '', attachments: attachments || [], submittedAt: new Date() },
      timeline: { status: nextStatus, note: `Evidence submitted by ${role}.`, changedBy: actingUser.id, at: new Date() },
    },
  });
  if (!updated) throw ApiError.conflict('This dispute cannot accept evidence right now.');

  return toDisputeResponse(updated);
};

const getDispute = async (id, actingUser) => {
  const dispute = await disputeRepository.findById(id);
  if (!dispute) throw ApiError.notFound('Dispute not found.');
  assertVisible(dispute, actingUser);
  return toDisputeResponse(dispute);
};

const listMine = async (actingUser, { page, limit } = {}) => {
  const { items, meta } =
    actingUser.role === ROLES.SELLER
      ? await disputeRepository.listForSeller(actingUser.id, { page, limit })
      : await disputeRepository.listForBuyer(actingUser.id, { page, limit });
  return { items: items.map(toDisputeResponse), meta };
};

// --------------------------------------------------------------------
// Part 7 — Admin: review, resolve, close
// --------------------------------------------------------------------

const getAdminQueue = async ({ page, limit, status } = {}) => {
  const filter = {};
  if (status) filter.status = status;
  const { items, meta } = await disputeRepository.listForAdmin(filter, { page, limit });
  return { items: items.map(toDisputeResponse), meta };
};

const getAdminOverview = async () => {
  const byStatus = await disputeRepository.sumByStatus();
  return { byStatus };
};

const markUnderReview = async (id, actingAdmin, note) => {
  const updated = await disputeRepository.transitionStatus(id, [DISPUTE_STATUSES.OPEN, DISPUTE_STATUSES.EVIDENCE_SUBMITTED], {
    $set: { status: DISPUTE_STATUSES.UNDER_REVIEW },
    $push: { timeline: { status: DISPUTE_STATUSES.UNDER_REVIEW, note: note || 'Under admin review.', changedBy: actingAdmin.id, at: new Date() } },
  });
  if (!updated) throw ApiError.conflict('This dispute cannot be moved to under review right now.');
  return toDisputeResponse(updated);
};

/**
 * Resolves a BUYER_OPENED dispute (admin-driven — a STRIPE_CHARGEBACK's
 * outcome instead always comes from Stripe itself via syncFromStripeEvent,
 * never from this endpoint, since the bank — not this platform — makes
 * that call). `outcome` is 'won' (seller keeps the funds, hold released)
 * or 'lost' (buyer wins, hold becomes a permanent loss).
 */
const resolveDispute = async (id, actingAdmin, outcome, note) => {
  const dispute = await disputeRepository.findById(id);
  if (!dispute) throw ApiError.notFound('Dispute not found.');
  if (dispute.origin !== DISPUTE_ORIGINS.BUYER_OPENED) {
    throw ApiError.badRequest('A Stripe chargeback resolves automatically from Stripe and cannot be resolved manually.');
  }
  if (![DISPUTE_STATUSES.WON, DISPUTE_STATUSES.LOST].includes(outcome)) {
    throw ApiError.badRequest('Outcome must be "won" or "lost".');
  }

  const updated = await disputeRepository.transitionStatus(id, [DISPUTE_STATUSES.OPEN, DISPUTE_STATUSES.UNDER_REVIEW, DISPUTE_STATUSES.EVIDENCE_SUBMITTED], {
    $set: { status: outcome },
    $push: { timeline: { status: outcome, note: note || `Resolved: ${outcome}.`, changedBy: actingAdmin.id, at: new Date() } },
  });
  if (!updated) throw ApiError.conflict('This dispute is already resolved.');

  if (outcome === DISPUTE_STATUSES.WON) {
    await walletService.releaseDisputeHold(updated);
  } else {
    await walletService.finalizeDisputeLoss(updated);
  }

  notifyDisputeParties(updated, NOTIFICATION_TYPES.DISPUTE_STATUS_CHANGED, 'Dispute resolved', `Your dispute has been resolved: ${outcome}.`).catch(() => {});
  return toDisputeResponse(updated);
};

const closeDispute = async (id, actingAdmin, note) => {
  const dispute = await disputeRepository.findById(id);
  if (!dispute) throw ApiError.notFound('Dispute not found.');
  if (RESOLVED_DISPUTE_STATUSES.includes(dispute.status)) throw ApiError.conflict('This dispute is already resolved.');

  const updated = await disputeRepository.transitionStatus(id, [DISPUTE_STATUSES.OPEN, DISPUTE_STATUSES.UNDER_REVIEW, DISPUTE_STATUSES.EVIDENCE_SUBMITTED], {
    $set: { status: DISPUTE_STATUSES.CLOSED },
    $push: { timeline: { status: DISPUTE_STATUSES.CLOSED, note: note || 'Closed by admin.', changedBy: actingAdmin.id, at: new Date() } },
  });
  if (!updated) throw ApiError.conflict('This dispute cannot be closed right now.');

  await walletService.releaseDisputeHold(updated);
  notifyDisputeParties(updated, NOTIFICATION_TYPES.DISPUTE_STATUS_CHANGED, 'Dispute closed', 'A dispute on your order has been closed.').catch(() => {});
  return toDisputeResponse(updated);
};

module.exports = {
  syncFromStripeEvent,
  openBuyerDispute,
  addEvidence,
  getDispute,
  listMine,
  getAdminQueue,
  getAdminOverview,
  markUnderReview,
  resolveDispute,
  closeDispute,
};
