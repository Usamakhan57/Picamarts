'use strict';

const ApiError = require('../utils/ApiError');
const config = require('../config');
const stripe = require('../config/stripe');
const paymentRepository = require('../repositories/payment.repository');
// Phase 10.2 — Notification System. Additive, fire-and-forget calls
// only (`.catch(() => {})`) — see order.service.js's identical comment
// for why this never affects payment flow behavior or its tests.
const notificationService = require('../services/notification.service');
// Phase 14.1 — Digital Product Delivery. Additive, fire-and-forget only
// (`.catch(() => {})`) — same integration shape as notificationService
// above; never affects payment flow behavior or its tests.
const digitalDeliveryService = require('../services/digitalDelivery.service');
// Phase 16B — Marketplace Wallet & Commission Engine. Additive,
// fire-and-forget only (`.catch(() => {})`) — same integration shape
// as notificationService/digitalDeliveryService above; a wallet
// bookkeeping failure must never affect payment flow behavior.
const walletService = require('../services/wallet.service');
// Phase 16D — Refunds, Returns, Disputes & Chargebacks. Additive,
// fire-and-forget-safe only via the try/catch already wrapping every
// webhook case below — a dispute-sync failure must never break the
// webhook's 200 response back to Stripe. This is the only file that
// ever calls disputeService.syncFromStripeEvent; the dispute module
// never re-verifies the Stripe signature or re-checks WebhookEvent
// itself, reusing this file's existing pipeline entirely.
const disputeService = require('../services/dispute.service');
const { ROLES } = require('../constants/roles');
const { ORDER_STATUSES } = require('../constants/orderEnums');
const {
  PAYMENT_STATUSES,
  TERMINAL_PAYMENT_STATUSES,
  REFUND_STATUSES,
} = require('../constants/paymentEnums');

/**
 * Phase 9. Step 1 (Payment Model + Stripe Integration: create/confirm/
 * retrieve/cancel a PaymentIntent) and Step 2 (Stripe webhooks +
 * refunds + payment history) both live here.
 *
 * Nothing here modifies Auth/Product/Cart/Checkout/Order files —
 * order.repository.js's own convention (an additive, narrowly-scoped
 * direct query against another module's model) is reused for every
 * place this file needs to reflect a payment result onto an Order;
 * see payment.repository.js.
 */

// --------------------------------------------------------------------
// Response shaping
// --------------------------------------------------------------------

const idStr = (value) => (value?.toString ? value.toString() : value);

const toPaymentResponse = (payment) => ({
  id: idStr(payment._id),
  order: idStr(payment.order),
  buyer: idStr(payment.buyer),
  paymentMethod: payment.paymentMethod,
  provider: payment.provider,
  transactionId: payment.transactionId,
  paymentIntentId: payment.paymentIntentId,
  amount: payment.amount,
  currency: payment.currency,
  status: payment.status,
  refundStatus: payment.refundStatus,
  refundAmount: payment.refundAmount,
  refunds: (payment.refunds || []).map((r) => ({
    stripeRefundId: r.stripeRefundId,
    amount: r.amount,
    status: r.status,
    createdAt: r.createdAt,
  })),
  metadata: payment.metadata,
  createdAt: payment.createdAt,
  updatedAt: payment.updatedAt,
});

// --------------------------------------------------------------------
// Notification helpers (Phase 10.2)
// --------------------------------------------------------------------

/**
 * All three wrap a small `{ id, orderNumber }` lookup (payment.service.js
 * only has an order id, never the order's own display fields) around
 * the actual notification wrapper — and every failure at any step
 * (order not found, notification dispatch error) is swallowed so it
 * can never affect the payment flow that called it.
 */
const notifyPaymentSuccessForOrder = async (payment) => {
  try {
    const order = await paymentRepository.findOrderById(payment.order);
    if (!order) return;
    await notificationService.notifyPaymentSuccessful(toPaymentResponse(payment), {
      id: idStr(order._id),
      orderNumber: order.orderNumber,
    });
  } catch {
    // Best-effort only.
  }
};

const notifyPaymentFailedForOrder = async (payment, reason) => {
  try {
    const order = await paymentRepository.findOrderById(payment.order);
    if (!order) return;
    await notificationService.notifyPaymentFailed(
      toPaymentResponse(payment),
      { id: idStr(order._id), orderNumber: order.orderNumber },
      reason
    );
  } catch {
    // Best-effort only.
  }
};

const notifyRefundForOrder = async (payment, refundAmount, isFullRefund) => {
  try {
    const order = await paymentRepository.findOrderById(payment.order);
    if (!order) return;
    await notificationService.notifyRefundIssued(
      toPaymentResponse(payment),
      { id: idStr(order._id), orderNumber: order.orderNumber },
      refundAmount,
      isFullRefund
    );
  } catch {
    // Best-effort only.
  }
};

// --------------------------------------------------------------------
// Visibility / ownership
// --------------------------------------------------------------------

/** Mirrors Order's own assertOrderVisible pattern: 404 (not 403) for a payment the caller isn't allowed to see. */
const assertPaymentVisible = (payment, actingUser) => {
  if (actingUser.role === ROLES.ADMIN) return;
  if (payment.buyer.toString() === actingUser.id) return;
  throw ApiError.notFound('Payment not found.');
};

/**
 * Confirm/cancel are buyer-initiated actions on the buyer's own
 * payment attempt — unlike retrieval, admin doesn't get to drive
 * someone else's checkout, so this is deliberately stricter than
 * assertPaymentVisible above.
 */
const assertPaymentOwner = (payment, actingUser) => {
  if (payment.buyer.toString() !== actingUser.id) {
    throw ApiError.notFound('Payment not found.');
  }
};

/**
 * Part 8's business rules, enforced against the order itself:
 * cancelled/already-paid/refunded orders can never be paid again.
 * Also doubles as ownership — only the order's own buyer may pay it.
 */
const assertOrderPayable = (order, actingUser) => {
  if (order.buyer.toString() !== actingUser.id && actingUser.role !== ROLES.ADMIN) {
    throw ApiError.notFound('Order not found.');
  }
  if (order.status === ORDER_STATUSES.CANCELLED) {
    throw ApiError.badRequest('This order has been cancelled and cannot be paid.');
  }
  if (order.paymentStatus === 'paid') {
    throw ApiError.badRequest('This order has already been paid.');
  }
  if (order.paymentStatus === 'refunded') {
    throw ApiError.badRequest('This order has been refunded and cannot be paid again.');
  }
};

// --------------------------------------------------------------------
// Stripe amount helpers
// --------------------------------------------------------------------

/** Stripe expects the smallest currency unit (e.g. cents for USD) as an integer. */
const toMinorUnits = (amount) => Math.round(amount * 100);

// --------------------------------------------------------------------
// Create Payment Intent
// --------------------------------------------------------------------

/**
 * Creates (or reuses) a Stripe PaymentIntent for an order.
 *
 *   - amount/currency are ALWAYS derived from the order's own locked
 *     `grandTotal` — there is no client-suppliable amount field, so
 *     "amount must match the locked order total" holds by construction.
 *   - If the order already has a pending/processing/succeeded Payment
 *     record, that SAME record (and its existing PaymentIntent) is
 *     returned instead of creating a new one — this is what prevents
 *     duplicate PaymentIntents piling up against one order from
 *     repeated calls (design decision, flagged: a literal reading of
 *     "Create Payment Intent" could instead always create a fresh
 *     one, but that would let a buyer accumulate several live
 *     intents for the same order).
 */
const createPaymentIntent = async (orderId, actingUser) => {
  const order = await paymentRepository.findOrderById(orderId);
  if (!order) throw ApiError.notFound('Order not found.');
  assertOrderPayable(order, actingUser);

  const existing = await paymentRepository.findActiveByOrder(orderId);
  if (existing) {
    return { payment: toPaymentResponse(existing), clientSecret: existing.providerResponse?.clientSecret || null };
  }

  const amount = order.grandTotal;
  const currency = config.stripe.currency;

  let intent;
  try {
    intent = await stripe.paymentIntents.create({
      amount: toMinorUnits(amount),
      currency,
      automatic_payment_methods: { enabled: true },
      metadata: { orderId: idStr(order._id), buyerId: idStr(order.buyer) },
    });
  } catch (error) {
    throw ApiError.badRequest(`Unable to start payment: ${error.message}`);
  }

  const payment = await paymentRepository.create({
    order: order._id,
    buyer: order.buyer,
    amount,
    currency,
    status: PAYMENT_STATUSES.PENDING,
    paymentIntentId: intent.id,
    providerResponse: {
      id: intent.id,
      status: intent.status,
      clientSecret: intent.client_secret,
    },
  });

  return { payment: toPaymentResponse(payment), clientSecret: intent.client_secret };
};

// --------------------------------------------------------------------
// Confirm Payment
// --------------------------------------------------------------------

/**
 * Confirms a payment's underlying PaymentIntent with Stripe. On
 * success the order is synced atomically (paymentStatus: paid,
 * status: confirmed). On a card/provider error the payment is marked
 * failed and the order's paymentStatus follows it to failed — the
 * order itself stays exactly where it was (still pending), so the
 * buyer can simply try again with createPaymentIntent.
 */
const confirmPayment = async (paymentId, actingUser, { paymentMethodId } = {}) => {
  const payment = await paymentRepository.findById(paymentId);
  if (!payment) throw ApiError.notFound('Payment not found.');
  assertPaymentOwner(payment, actingUser);

  if (TERMINAL_PAYMENT_STATUSES.includes(payment.status)) {
    throw ApiError.badRequest(`This payment is already ${payment.status} and cannot be confirmed.`);
  }

  let intent;
  try {
    intent = await stripe.paymentIntents.confirm(
      payment.paymentIntentId,
      paymentMethodId ? { payment_method: paymentMethodId } : undefined
    );
  } catch (error) {
    payment.status = PAYMENT_STATUSES.FAILED;
    payment.providerResponse = { id: payment.paymentIntentId, status: 'failed', error: error.message };
    await payment.save();
    await paymentRepository.markOrderPaymentFailed(payment.order);
    await notifyPaymentFailedForOrder(payment, error.message);
    throw ApiError.badRequest(`Payment failed: ${error.message}`);
  }

  payment.providerResponse = { id: intent.id, status: intent.status };

  if (intent.status === 'succeeded') {
    payment.status = PAYMENT_STATUSES.SUCCEEDED;
    payment.transactionId = intent.latest_charge ? idStr(intent.latest_charge) : intent.id;
    await payment.save();
    await paymentRepository.markOrderPaid(payment.order, actingUser.id);
    notifyPaymentSuccessForOrder(payment).catch(() => {});
    digitalDeliveryService.deliverForOrder(payment).catch(() => {});
    walletService.recordSaleForOrder(payment).catch(() => {});
  } else if (intent.status === 'requires_action' || intent.status === 'processing') {
    payment.status = PAYMENT_STATUSES.PROCESSING;
    await payment.save();
  } else if (intent.status === 'canceled') {
    payment.status = PAYMENT_STATUSES.CANCELLED;
    await payment.save();
  } else {
    // requires_payment_method, requires_confirmation, etc. — Stripe didn't error, but didn't succeed either.
    payment.status = PAYMENT_STATUSES.FAILED;
    await payment.save();
    await paymentRepository.markOrderPaymentFailed(payment.order);
    notifyPaymentFailedForOrder(payment).catch(() => {});
  }

  return toPaymentResponse(payment);
};

// --------------------------------------------------------------------
// Retrieve Payment
// --------------------------------------------------------------------

/**
 * Returns the local Payment record, refreshed against Stripe's
 * current view of the PaymentIntent first (best-effort — if Stripe
 * can't be reached the local record is still returned as-is rather
 * than failing the read).
 */
const retrievePayment = async (paymentId, actingUser) => {
  const payment = await paymentRepository.findById(paymentId);
  if (!payment) throw ApiError.notFound('Payment not found.');
  assertPaymentVisible(payment, actingUser);

  if (payment.paymentIntentId && !TERMINAL_PAYMENT_STATUSES.includes(payment.status)) {
    try {
      const intent = await stripe.paymentIntents.retrieve(payment.paymentIntentId);
      payment.providerResponse = { id: intent.id, status: intent.status };
      if (intent.status === 'succeeded' && payment.status !== PAYMENT_STATUSES.SUCCEEDED) {
        payment.status = PAYMENT_STATUSES.SUCCEEDED;
        payment.transactionId = intent.latest_charge ? idStr(intent.latest_charge) : intent.id;
        await payment.save();
        await paymentRepository.markOrderPaid(payment.order, actingUser.id);
      } else if (intent.status === 'canceled' && payment.status !== PAYMENT_STATUSES.CANCELLED) {
        payment.status = PAYMENT_STATUSES.CANCELLED;
        await payment.save();
      } else {
        await payment.save();
      }
    } catch (error) {
      // Best-effort refresh only — surface what we already have locally.
    }
  }

  return toPaymentResponse(payment);
};

// --------------------------------------------------------------------
// Cancel Payment Intent
// --------------------------------------------------------------------

/** A succeeded payment can't be "cancelled" here — see processRefund below for reversing a succeeded payment instead. */
const cancelPaymentIntent = async (paymentId, actingUser) => {
  const payment = await paymentRepository.findById(paymentId);
  if (!payment) throw ApiError.notFound('Payment not found.');
  assertPaymentOwner(payment, actingUser);

  if (payment.status === PAYMENT_STATUSES.SUCCEEDED) {
    throw ApiError.badRequest('This payment has already succeeded — cancel is not applicable; use a refund instead.');
  }
  if (payment.status === PAYMENT_STATUSES.CANCELLED) {
    throw ApiError.badRequest('This payment is already cancelled.');
  }

  try {
    await stripe.paymentIntents.cancel(payment.paymentIntentId);
  } catch (error) {
    throw ApiError.badRequest(`Unable to cancel payment: ${error.message}`);
  }

  payment.status = PAYMENT_STATUSES.CANCELLED;
  payment.providerResponse = { id: payment.paymentIntentId, status: 'canceled' };
  await payment.save();

  return toPaymentResponse(payment);
};

// --------------------------------------------------------------------
// Refunds (full or partial)
// --------------------------------------------------------------------

/**
 * Issues a Stripe refund against a succeeded payment. Full or partial:
 * omitting `amount` refunds whatever remains refundable; passing one
 * refunds exactly that much (validated against what's actually left).
 * Restricted to admins at the route level — refunds move real money
 * back out, so this is deliberately not buyer-self-service the way
 * create/confirm/cancel are (design decision, flagged).
 *
 * Only a FULL refund (refundAmount reaches the full payment amount)
 * flips the order itself to `refunded`/`refunded` (paymentStatus +
 * status) via markOrderRefunded — a partial refund is tracked solely
 * on the Payment record's own refundStatus/refundAmount, since Order's
 * paymentStatus enum has no "partially refunded" value and the order
 * is still substantially paid.
 */
const processRefund = async (paymentId, amount, actingUser) => {
  const payment = await paymentRepository.findById(paymentId);
  if (!payment) throw ApiError.notFound('Payment not found.');

  if (payment.status !== PAYMENT_STATUSES.SUCCEEDED) {
    throw ApiError.badRequest('Only a succeeded payment can be refunded.');
  }

  const remaining = Math.round((payment.amount - payment.refundAmount) * 100) / 100;
  if (remaining <= 0) {
    throw ApiError.badRequest('This payment has already been fully refunded.');
  }

  const refundAmount = amount === undefined || amount === null ? remaining : amount;
  if (refundAmount <= 0 || refundAmount > remaining) {
    throw ApiError.badRequest(`Refund amount must be between 0 and the remaining refundable amount (${remaining}).`);
  }

  let refund;
  try {
    refund = await stripe.refunds.create({
      payment_intent: payment.paymentIntentId,
      amount: toMinorUnits(refundAmount),
    });
  } catch (error) {
    throw ApiError.badRequest(`Unable to process refund: ${error.message}`);
  }

  payment.refunds.push({ stripeRefundId: refund.id, amount: refundAmount, status: refund.status, createdAt: new Date() });
  payment.refundAmount = Math.round((payment.refundAmount + refundAmount) * 100) / 100;

  const isFullRefund = payment.refundAmount >= payment.amount;
  payment.refundStatus = isFullRefund ? REFUND_STATUSES.FULL : REFUND_STATUSES.PARTIAL;
  await payment.save();

  if (isFullRefund) {
    await paymentRepository.markOrderRefunded(payment.order, actingUser.id);
    walletService.reverseEarningsForOrder(payment.order).catch(() => {});
  }

  notifyRefundForOrder(payment, refundAmount, isFullRefund).catch(() => {});

  return toPaymentResponse(payment);
};

// --------------------------------------------------------------------
// Payment history
// --------------------------------------------------------------------

/** Buyers see only their own payments; admins see every payment. Mirrors order.service.js#listOrders' role filtering. */
const listPayments = async (actingUser, { status, page, limit } = {}) => {
  const filter = {};
  if (status) filter.status = status;
  if (actingUser.role !== ROLES.ADMIN) filter.buyer = actingUser.id;

  const { items, meta } = await paymentRepository.list(filter, { page, limit, sort: { createdAt: -1 } });
  return { items: items.map(toPaymentResponse), meta };
};

// --------------------------------------------------------------------
// Stripe webhooks
// --------------------------------------------------------------------

/**
 * Verifies the Stripe signature, records the event id (the sole
 * idempotency gate — a redelivered event is a silent no-op rather
 * than being reprocessed), and syncs the matching Payment + Order
 * atomically per event type. `rawBody` MUST be the exact raw request
 * bytes (a Buffer) — see app.js, where this route is mounted with
 * express.raw() ahead of the global JSON body parser specifically so
 * that's what reaches here; a JSON-parsed/re-stringified body will
 * fail signature verification even if its contents are identical.
 */
const handleStripeWebhook = async (rawBody, signature) => {
  let event;
  try {
    event = stripe.webhooks.constructEvent(rawBody, signature, config.stripe.webhookSecret);
  } catch (error) {
    throw ApiError.badRequest(`Webhook signature verification failed: ${error.message}`);
  }

  const isNewEvent = await paymentRepository.recordWebhookEvent(event.id, event.type);
  if (!isNewEvent) {
    return { received: true, duplicate: true };
  }

  const intent = event.data?.object;

  switch (event.type) {
    case 'payment_intent.succeeded': {
      const payment = await paymentRepository.findByPaymentIntentId(intent.id);
      if (payment && payment.status !== PAYMENT_STATUSES.SUCCEEDED) {
        payment.status = PAYMENT_STATUSES.SUCCEEDED;
        payment.transactionId = intent.latest_charge ? idStr(intent.latest_charge) : intent.id;
        payment.providerResponse = { id: intent.id, status: intent.status };
        await payment.save();
        await paymentRepository.markOrderPaid(payment.order, null);
        notifyPaymentSuccessForOrder(payment).catch(() => {});
        digitalDeliveryService.deliverForOrder(payment).catch(() => {});
        walletService.recordSaleForOrder(payment).catch(() => {});
      }
      break;
    }
    case 'payment_intent.payment_failed': {
      const payment = await paymentRepository.findByPaymentIntentId(intent.id);
      if (payment && !TERMINAL_PAYMENT_STATUSES.includes(payment.status)) {
        payment.status = PAYMENT_STATUSES.FAILED;
        payment.providerResponse = { id: intent.id, status: intent.status };
        await payment.save();
        await paymentRepository.markOrderPaymentFailed(payment.order);
        notifyPaymentFailedForOrder(payment).catch(() => {});
      }
      break;
    }
    case 'payment_intent.canceled': {
      const payment = await paymentRepository.findByPaymentIntentId(intent.id);
      if (payment && !TERMINAL_PAYMENT_STATUSES.includes(payment.status)) {
        payment.status = PAYMENT_STATUSES.CANCELLED;
        payment.providerResponse = { id: intent.id, status: intent.status };
        await payment.save();
      }
      break;
    }
    case 'charge.refunded': {
      // Defensive/idempotent sync only — a refund initiated through
      // POST /payments/:paymentId/refund already updates the Payment
      // synchronously; this covers a refund issued directly in the
      // Stripe dashboard instead of through our API.
      const paymentIntentId = intent.payment_intent ? idStr(intent.payment_intent) : null;
      const payment = paymentIntentId ? await paymentRepository.findByPaymentIntentId(paymentIntentId) : null;
      if (payment) {
        const refundedAmount = (intent.amount_refunded || 0) / 100;
        if (refundedAmount > payment.refundAmount) {
          const deltaRefunded = Math.round((refundedAmount - payment.refundAmount) * 100) / 100;
          payment.refundAmount = refundedAmount;
          payment.refundStatus = refundedAmount >= payment.amount ? REFUND_STATUSES.FULL : REFUND_STATUSES.PARTIAL;
          await payment.save();
          if (payment.refundStatus === REFUND_STATUSES.FULL) {
            await paymentRepository.markOrderRefunded(payment.order, null);
            walletService.reverseEarningsForOrder(payment.order).catch(() => {});
          }
          notifyRefundForOrder(payment, deltaRefunded, payment.refundStatus === REFUND_STATUSES.FULL).catch(() => {});
        }
      }
      break;
    }
    // Phase 16D, Part 6 — Stripe dispute/chargeback synchronization.
    // Every dispute lifecycle event Stripe sends funnels through the
    // same handler (syncFromStripeEvent itself derives the right
    // per-seller status transition from `event.data.object.status`) —
    // reusing this file's own signature-verification + WebhookEvent
    // idempotency gate above, never duplicating either.
    case 'charge.dispute.created':
    case 'charge.dispute.updated':
    case 'charge.dispute.closed':
    case 'charge.dispute.funds_withdrawn':
    case 'charge.dispute.funds_reinstated': {
      try {
        await disputeService.syncFromStripeEvent(intent);
      } catch (error) {
        // Best-effort only — never fail the webhook response over a
        // dispute-sync error; Stripe's own dashboard remains the
        // source of truth if this silently falls behind.
      }
      break;
    }
    default:
      // Every other event type is intentionally ignored — recording it
      // above is enough to make a future redelivery a no-op.
      break;
  }

  return { received: true };
};

module.exports = {
  createPaymentIntent,
  confirmPayment,
  retrievePayment,
  cancelPaymentIntent,
  processRefund,
  listPayments,
  handleStripeWebhook,
};
