'use strict';

const ApiError = require('../utils/ApiError');
const refundRequestRepository = require('../repositories/refundRequest.repository');
const paymentRepository = require('../repositories/payment.repository');
const notificationRepository = require('../repositories/notification.repository');
// Phase 9 — reused unmodified. The ONLY place that ever calls Stripe's
// refund API is payment.service.js#processRefund; this file drives the
// buyer-request/admin-approval workflow AROUND that call, never
// duplicating it (per the brief's own "Do NOT duplicate payment code").
const paymentService = require('./payment.service');
const walletService = require('./wallet.service');
const notificationService = require('./notification.service');
const { ROLES } = require('../constants/roles');
const { REFUND_REQUEST_STATUSES, REFUND_REQUEST_TYPES } = require('../constants/refundEnums');
const { PAYMENT_STATUSES, REFUND_STATUSES } = require('../constants/paymentEnums');
const { PAYMENT_STATUSES: ORDER_PAYMENT_STATUSES } = require('../constants/orderEnums');
const { NOTIFICATION_TYPES, RELATED_ENTITY_TYPES } = require('../constants/notificationEnums');

const round2 = (n) => Math.round(n * 100) / 100;
const idStr = (value) => (value?.toString ? value.toString() : value);

// --------------------------------------------------------------------
// Response shaping
// --------------------------------------------------------------------

const toRefundRequestResponse = (doc) => ({
  id: idStr(doc._id),
  order: idStr(doc.order),
  payment: idStr(doc.payment),
  buyer: idStr(doc.buyer),
  type: doc.type,
  items: (doc.items || []).map((i) => ({ orderItem: idStr(i.orderItem), quantity: i.quantity, amount: i.amount })),
  requestedAmount: doc.requestedAmount,
  reason: doc.reason,
  note: doc.note,
  attachments: doc.attachments || [],
  status: doc.status,
  adminReviewedBy: doc.adminReviewedBy ? idStr(doc.adminReviewedBy) : null,
  adminReviewedAt: doc.adminReviewedAt,
  adminNote: doc.adminNote,
  stripeRefundId: doc.stripeRefundId,
  refundedAmount: doc.refundedAmount,
  failureReason: doc.failureReason,
  returnRequest: doc.returnRequest ? idStr(doc.returnRequest) : null,
  timeline: (doc.timeline || []).map((t) => ({ status: t.status, note: t.note, changedBy: idStr(t.changedBy), at: t.at })),
  createdAt: doc.createdAt,
  updatedAt: doc.updatedAt,
});

// --------------------------------------------------------------------
// Visibility
// --------------------------------------------------------------------

const assertVisible = (doc, actingUser) => {
  if (actingUser.role === ROLES.ADMIN) return;
  if (doc.buyer.toString() === actingUser.id) return;
  throw ApiError.notFound('Refund request not found.');
};

// --------------------------------------------------------------------
// Part 8 — Notifications (defined early so create/approve/reject can call them)
// --------------------------------------------------------------------

/** Fans out to every active admin — same pattern as notification.service.js#notifyReviewReported. */
const notifyAdminsRefundRequested = async (request, order) => {
  const adminIds = await notificationRepository.findAdminIds();
  await Promise.all(
    adminIds.map((adminId) =>
      notificationService.emitNotification({
        recipientId: adminId,
        type: NOTIFICATION_TYPES.REFUND_REQUESTED,
        title: 'New refund request',
        message: `A refund of ${request.requestedAmount} was requested for order ${order.orderNumber}.`,
        relatedEntity: RELATED_ENTITY_TYPES.REFUND_REQUEST,
        relatedEntityId: idStr(request._id),
        metadata: { orderNumber: order.orderNumber },
      })
    )
  );
};

const notifyBuyerRefundStatus = async (request, statusLabel) => {
  await notificationService.emitNotification({
    recipientId: request.buyer,
    type: NOTIFICATION_TYPES.REFUND_STATUS_CHANGED,
    title: `Refund ${statusLabel}`,
    message: `Your refund request is now ${statusLabel}.`,
    relatedEntity: RELATED_ENTITY_TYPES.REFUND_REQUEST,
    relatedEntityId: idStr(request._id),
    metadata: { status: statusLabel },
  });
};

// --------------------------------------------------------------------
// Part 1 — Refund Requests (buyer)
// --------------------------------------------------------------------

/**
 * @param {object} body { type, items?, requestedAmount?, reason, note?, attachments? }
 *   `requestedAmount` is required for a partial request unless `items[].amount`
 *   are supplied (in which case it's derived as their sum). A full request
 *   ignores any client-supplied amount and always uses whatever is still
 *   refundable on the payment (mirrors payment.service.js#processRefund's
 *   own "omit amount = refund what remains" rule).
 */
const createRefundRequest = async (orderId, actingUser, body) => {
  const order = await paymentRepository.findOrderById(orderId);
  if (!order) throw ApiError.notFound('Order not found.');
  if (order.buyer.toString() !== actingUser.id) throw ApiError.notFound('Order not found.');
  if (order.paymentStatus !== ORDER_PAYMENT_STATUSES.PAID) {
    throw ApiError.badRequest('Only a paid order can have a refund requested.');
  }

  const payment = await paymentRepository.findActiveByOrder(orderId);
  if (!payment || payment.status !== PAYMENT_STATUSES.SUCCEEDED) {
    throw ApiError.badRequest('No successful payment found for this order.');
  }

  const alreadyOpen = await refundRequestRepository.hasOpenRequest(orderId);
  if (alreadyOpen) throw ApiError.conflict('A refund request is already open for this order.');

  const remaining = round2(payment.amount - payment.refundAmount);
  if (remaining <= 0) throw ApiError.badRequest('This order has already been fully refunded.');

  let requestedAmount;
  if (body.type === REFUND_REQUEST_TYPES.FULL) {
    requestedAmount = remaining;
  } else {
    requestedAmount = body.items?.length ? round2(body.items.reduce((sum, i) => sum + i.amount, 0)) : round2(body.requestedAmount);
    if (!requestedAmount || requestedAmount <= 0 || requestedAmount > remaining) {
      throw ApiError.badRequest(`Requested amount must be between 0 and the remaining refundable amount (${remaining}).`);
    }
  }

  const request = await refundRequestRepository.create({
    order: order._id,
    payment: payment._id,
    buyer: actingUser.id,
    type: body.type,
    items: body.items || [],
    requestedAmount,
    reason: body.reason,
    note: body.note || '',
    attachments: body.attachments || [],
    status: REFUND_REQUEST_STATUSES.PENDING,
    timeline: [{ status: REFUND_REQUEST_STATUSES.PENDING, note: 'Refund requested by buyer.', changedBy: actingUser.id, at: new Date() }],
  });

  await refundRequestRepository.markOrderRefundRequested(order._id, actingUser.id);
  notifyAdminsRefundRequested(request, order).catch(() => {});

  return toRefundRequestResponse(request);
};

const getRefundRequest = async (id, actingUser) => {
  const request = await refundRequestRepository.findById(id);
  if (!request) throw ApiError.notFound('Refund request not found.');
  assertVisible(request, actingUser);
  return toRefundRequestResponse(request);
};

const listMyRefundRequests = async (buyerId, { page, limit } = {}) => {
  const { items, meta } = await refundRequestRepository.listForBuyer(buyerId, { page, limit });
  return { items: items.map(toRefundRequestResponse), meta };
};

/** Only a still-PENDING request may be withdrawn by the buyer themselves. */
const cancelRefundRequest = async (id, actingUser) => {
  const request = await refundRequestRepository.findById(id);
  if (!request) throw ApiError.notFound('Refund request not found.');
  if (request.buyer.toString() !== actingUser.id) throw ApiError.notFound('Refund request not found.');

  const updated = await refundRequestRepository.transitionStatus(id, REFUND_REQUEST_STATUSES.PENDING, {
    $set: { status: REFUND_REQUEST_STATUSES.CANCELLED },
    $push: { timeline: { status: REFUND_REQUEST_STATUSES.CANCELLED, note: 'Cancelled by buyer.', changedBy: actingUser.id, at: new Date() } },
  });
  if (!updated) throw ApiError.conflict('This request is no longer pending and cannot be cancelled.');
  return toRefundRequestResponse(updated);
};

// --------------------------------------------------------------------
// Part 3 — Admin Refund Queue
// --------------------------------------------------------------------

const getAdminQueue = async ({ page, limit, status, q } = {}) => {
  const filter = {};
  if (status) filter.status = status;
  if (q) filter.reason = { $regex: q, $options: 'i' };
  const { items, meta } = await refundRequestRepository.listForAdmin(filter, { page, limit });
  return { items: items.map(toRefundRequestResponse), meta };
};

const getAdminOverview = async () => {
  const byStatus = await refundRequestRepository.sumByStatus();
  return { byStatus };
};

// --------------------------------------------------------------------
// Part 4/5 — Approval -> Stripe refund -> wallet reconciliation
// --------------------------------------------------------------------

/** Runs (or re-runs) the actual Stripe refund + wallet reversal for an APPROVED/FAILED request. */
const processApprovedRequest = async (request, actingAdmin) => {
  const processing = await refundRequestRepository.transitionStatus(
    request._id,
    [REFUND_REQUEST_STATUSES.APPROVED, REFUND_REQUEST_STATUSES.FAILED],
    {
      $set: { status: REFUND_REQUEST_STATUSES.PROCESSING },
      $push: { timeline: { status: REFUND_REQUEST_STATUSES.PROCESSING, note: 'Processing Stripe refund.', changedBy: actingAdmin.id, at: new Date() } },
    }
  );
  if (!processing) throw ApiError.conflict('This request cannot be processed right now.');

  let payment;
  try {
    payment = await paymentService.processRefund(request.payment, request.requestedAmount, actingAdmin);
  } catch (error) {
    const failed = await refundRequestRepository.transitionStatus(request._id, REFUND_REQUEST_STATUSES.PROCESSING, {
      $set: { status: REFUND_REQUEST_STATUSES.FAILED, failureReason: error.message },
      $push: { timeline: { status: REFUND_REQUEST_STATUSES.FAILED, note: error.message, changedBy: actingAdmin.id, at: new Date() } },
    });
    notifyBuyerRefundStatus(failed || request, 'failed').catch(() => {});
    return toRefundRequestResponse(failed || request);
  }

  const isFull = payment.refundStatus === REFUND_STATUSES.FULL;
  if (!isFull) {
    // A FULL refund's wallet reversal already fires inside payment.service.js#processRefund
    // (reverseEarningsForOrder, unchanged from Phase 16B). A PARTIAL
    // refund needs the new proportional reversal this phase adds —
    // request.items[] doesn't currently carry a per-item seller id, so
    // every partial reversal here is order-proportional (see
    // wallet.service.js#reverseEarningsForRefundRequest's own doc comment).
    walletService.reverseEarningsForRefundRequest(request.order, request._id, request.requestedAmount).catch(() => {});
  }

  const latestRefund = payment.refunds[payment.refunds.length - 1];
  const completed = await refundRequestRepository.transitionStatus(request._id, REFUND_REQUEST_STATUSES.PROCESSING, {
    $set: {
      status: REFUND_REQUEST_STATUSES.COMPLETED,
      stripeRefundId: latestRefund?.stripeRefundId || '',
      refundedAmount: request.requestedAmount,
    },
    $push: { timeline: { status: REFUND_REQUEST_STATUSES.COMPLETED, note: 'Refund completed.', changedBy: actingAdmin.id, at: new Date() } },
  });

  notifyBuyerRefundStatus(completed || request, 'completed').catch(() => {});
  return toRefundRequestResponse(completed || request);
};

/**
 * Approving a request immediately attempts the underlying Stripe
 * refund (same "approve = immediately process" shape payout.service.js
 * already established for withdrawals — no separate queue/worker).
 * PENDING -> APPROVED -> PROCESSING -> COMPLETED, or -> FAILED on a
 * Stripe error (retryable via retryRefundRequest).
 */
const approveRefundRequest = async (id, actingAdmin, adminNote) => {
  const approved = await refundRequestRepository.transitionStatus(id, REFUND_REQUEST_STATUSES.PENDING, {
    $set: { status: REFUND_REQUEST_STATUSES.APPROVED, adminReviewedBy: actingAdmin.id, adminReviewedAt: new Date(), adminNote: adminNote || '' },
    $push: { timeline: { status: REFUND_REQUEST_STATUSES.APPROVED, note: adminNote || 'Approved.', changedBy: actingAdmin.id, at: new Date() } },
  });
  if (!approved) throw ApiError.conflict('This request is not pending and cannot be approved.');

  return processApprovedRequest(approved, actingAdmin);
};

const rejectRefundRequest = async (id, actingAdmin, reason) => {
  const rejected = await refundRequestRepository.transitionStatus(id, REFUND_REQUEST_STATUSES.PENDING, {
    $set: { status: REFUND_REQUEST_STATUSES.REJECTED, adminReviewedBy: actingAdmin.id, adminReviewedAt: new Date(), adminNote: reason || '' },
    $push: { timeline: { status: REFUND_REQUEST_STATUSES.REJECTED, note: reason || 'Rejected.', changedBy: actingAdmin.id, at: new Date() } },
  });
  if (!rejected) throw ApiError.conflict('This request is not pending and cannot be rejected.');

  notifyBuyerRefundStatus(rejected, 'rejected').catch(() => {});
  return toRefundRequestResponse(rejected);
};

/** Part 4 — retry a FAILED request's Stripe refund attempt. */
const retryRefundRequest = async (id, actingAdmin) => {
  const request = await refundRequestRepository.findById(id);
  if (!request) throw ApiError.notFound('Refund request not found.');
  if (request.status !== REFUND_REQUEST_STATUSES.FAILED) throw ApiError.conflict('Only a failed request can be retried.');
  return processApprovedRequest(request, actingAdmin);
};

/**
 * Part 3 — bulk admin actions (approve/reject a batch of pending
 * requests at once). Each id is processed independently — one failure
 * (e.g. a stale/non-pending request in the batch) never blocks the
 * rest, mirroring how every per-id transition here already tolerates
 * a conflict on its own.
 */
const bulkAction = async (ids, action, actingAdmin, reason) => {
  const results = await Promise.all(
    ids.map(async (id) => {
      try {
        const outcome = action === 'approve' ? await approveRefundRequest(id, actingAdmin) : await rejectRefundRequest(id, actingAdmin, reason);
        return { id, ok: true, status: outcome.status };
      } catch (error) {
        return { id, ok: false, error: error.message };
      }
    })
  );
  return { results };
};

// --------------------------------------------------------------------
// Part 2 support — a completed ReturnRequest opens a refund request
// --------------------------------------------------------------------

/** Called from return.service.js once a return is marked RECEIVED/COMPLETED — creates the follow-on RefundRequest automatically, reusing this file's own create path rather than duplicating validation. */
const createFromReturn = async (returnRequest, actingUser) => {
  const payment = await paymentRepository.findActiveByOrder(returnRequest.order);
  if (!payment) throw ApiError.badRequest('No payment found for this order.');

  const remaining = round2(payment.amount - payment.refundAmount);

  const request = await refundRequestRepository.create({
    order: returnRequest.order,
    payment: payment._id,
    buyer: returnRequest.buyer,
    type: REFUND_REQUEST_TYPES.FULL,
    requestedAmount: remaining,
    reason: returnRequest.reason,
    note: 'Auto-created from completed return request.',
    attachments: returnRequest.attachments || [],
    status: REFUND_REQUEST_STATUSES.PENDING,
    returnRequest: returnRequest._id,
    timeline: [
      { status: REFUND_REQUEST_STATUSES.PENDING, note: 'Opened automatically after the return was received.', changedBy: actingUser.id, at: new Date() },
    ],
  });

  return toRefundRequestResponse(request);
};

module.exports = {
  createRefundRequest,
  getRefundRequest,
  listMyRefundRequests,
  cancelRefundRequest,
  getAdminQueue,
  getAdminOverview,
  approveRefundRequest,
  rejectRefundRequest,
  retryRefundRequest,
  bulkAction,
  createFromReturn,
  toRefundRequestResponse,
};
