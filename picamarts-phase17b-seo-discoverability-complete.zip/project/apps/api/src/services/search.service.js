'use strict';

const productService = require('./product.service');
const categoryRepository = require('../repositories/category.repository');
const brandRepository = require('../repositories/brand.repository');
const collectionRepository = require('../repositories/collection.repository');
const tagRepository = require('../repositories/tag.repository');
const sellerRepository = require('../repositories/seller.repository');
const { buildSearchQuery, escapeRegex } = require('../utils/searchHelper');
const { SELLER_STATUSES } = require('../constants/sellerStatus');

/**
 * Phase 17A, Part 1 — Advanced Global Search. Products already have a
 * full search/filter/sort implementation (product.service.js, Phase
 * 5) — this module adds the piece that didn't exist yet: a single
 * search surface that ALSO matches categories, brands, collections,
 * tags, and sellers as their own result type (not just as a way to
 * find products), plus lightweight autocomplete suggestions.
 *
 * Each result group is capped small (GROUP_LIMIT) since this backs an
 * autocomplete-style "search everything" box, not a full listing page
 * — a caller who wants the full product result set still uses
 * GET /products?q=... with pagination/filters, unchanged.
 */

const GROUP_LIMIT = 6;
const SUGGESTION_LIMIT = 8;

/** Narrow product card shape reused by both global search and suggestions. */
const toProductResult = (product) => ({
  id: product.id,
  title: product.title,
  slug: product.slug,
  thumbnail: product.thumbnail,
  basePrice: product.basePrice,
  salePrice: product.salePrice,
  currency: product.currency,
});

const toTaxonomyResult = (doc, imageField) => ({
  id: doc._id.toString(),
  name: doc.name,
  slug: doc.slug,
  image: imageField ? doc[imageField] : undefined,
});

const toSellerResult = (seller) => ({
  id: seller._id.toString(),
  storeName: seller.storeName,
  storeSlug: seller.storeSlug,
  logo: seller.logo,
});

/**
 * Cross-entity search. Runs every group's query in parallel — none of
 * them depend on each other's results.
 *
 * @param {string} q
 * @returns {Promise<{ products: object[], categories: object[], brands: object[], collections: object[], tags: object[], sellers: object[] }>}
 */
const globalSearch = async (q) => {
  const term = (q || '').trim();
  if (!term) {
    return { products: [], categories: [], brands: [], collections: [], tags: [], sellers: [] };
  }

  const nameFilter = buildSearchQuery(term, ['name']);
  const listOptions = { page: 1, limit: GROUP_LIMIT, sort: { name: 1 } };

  const [productPage, categoryPage, brandPage, collectionPage, tagPage, sellerPage] = await Promise.all([
    productService.listPublicProducts(
      await productService.buildSearchFilter(term),
      { page: 1, limit: GROUP_LIMIT, sort: { salesCount: -1, views: -1 } }
    ),
    categoryRepository.list({ ...nameFilter, isActive: true }, listOptions),
    brandRepository.list({ ...nameFilter, active: true }, listOptions),
    collectionRepository.list({ ...nameFilter, active: true }, listOptions),
    tagRepository.list(nameFilter, listOptions),
    sellerRepository.list(
      { ...buildSearchQuery(term, ['storeName']), status: SELLER_STATUSES.APPROVED },
      { page: 1, limit: GROUP_LIMIT, sort: { storeName: 1 } }
    ),
  ]);

  return {
    products: productPage.items.map(toProductResult),
    categories: categoryPage.items.map((c) => toTaxonomyResult(c, 'image')),
    brands: brandPage.items.map((b) => toTaxonomyResult(b, 'logo')),
    collections: collectionPage.items.map((c) => toTaxonomyResult(c, 'thumbnail')),
    tags: tagPage.items.map((t) => toTaxonomyResult(t)),
    sellers: sellerPage.items.map(toSellerResult),
  };
};

/**
 * Lightweight autocomplete: product titles (ranked by popularity) plus
 * category/brand names, deduplicated by label, capped at
 * SUGGESTION_LIMIT total. Deliberately not a full search — no
 * pagination, no filters, just enough to populate a dropdown as the
 * buyer types.
 */
const getSuggestions = async (q, limit = SUGGESTION_LIMIT) => {
  const term = (q || '').trim();
  if (!term) return [];

  const pattern = new RegExp(`^${escapeRegex(term)}`, 'i');
  const containsPattern = new RegExp(escapeRegex(term), 'i');

  const [productPage, categories, brands] = await Promise.all([
    productService.listPublicProducts(
      { title: containsPattern },
      { page: 1, limit, sort: { salesCount: -1, views: -1 }, projection: { title: 1, slug: 1 } }
    ),
    categoryRepository.list({ name: pattern, isActive: true }, { page: 1, limit: 3, sort: { name: 1 } }),
    brandRepository.list({ name: pattern, active: true }, { page: 1, limit: 3, sort: { name: 1 } }),
  ]);

  const suggestions = [
    ...productPage.items.map((p) => ({ type: 'product', label: p.title, slug: p.slug, id: p.id })),
    ...categories.items.map((c) => ({ type: 'category', label: c.name, slug: c.slug, id: c._id.toString() })),
    ...brands.items.map((b) => ({ type: 'brand', label: b.name, slug: b.slug, id: b._id.toString() })),
  ];

  // Dedupe by (type, label) and cap to the overall limit.
  const seen = new Set();
  const deduped = [];
  suggestions.forEach((s) => {
    const key = `${s.type}:${s.label.toLowerCase()}`;
    if (!seen.has(key) && deduped.length < limit) {
      seen.add(key);
      deduped.push(s);
    }
  });

  return deduped;
};

module.exports = { globalSearch, getSuggestions, GROUP_LIMIT, SUGGESTION_LIMIT };
