'use strict';

const ApiError = require('../utils/ApiError');
const pageRepository = require('../repositories/page.repository');
const { slugify, withUniqueSuffix } = require('../utils/slugify');
const { ROLES } = require('../constants/roles');
const { CONTENT_STATUSES } = require('../constants/cmsEnums');

/**
 * Phase 10.3 — Page Service (Part 1: CMS Pages).
 *
 * Visibility rule enforced here (not in the repository or controller):
 * anonymous/non-admin callers only ever see `published` pages —
 * regardless of what they pass in `?status=` — a draft page is a 404
 * to them, not a 403, so its existence isn't leaked.
 */

const generateUniqueSlug = async (title) => {
  const base = slugify(title);
  const exists = await pageRepository.existsBySlug(base);
  return exists ? withUniqueSuffix(base) : base;
};

// --------------------------------------------------------------------
// Create
// --------------------------------------------------------------------

const createPage = async (body, actingUser) => {
  const alreadyExists = await pageRepository.existsByType(body.pageType);
  if (alreadyExists) {
    throw ApiError.conflict(`A page for "${body.pageType}" already exists — use update instead of create.`);
  }

  const slug = body.slug ? slugify(body.slug) : await generateUniqueSlug(body.title);
  if (body.slug) {
    const slugTaken = await pageRepository.existsBySlug(slug);
    if (slugTaken) throw ApiError.conflict(`Slug "${slug}" is already in use.`);
  }

  return pageRepository.create({
    ...body,
    slug,
    createdBy: actingUser.id,
    updatedBy: actingUser.id,
  });
};

// --------------------------------------------------------------------
// Reads
// --------------------------------------------------------------------

const assertVisible = (page, actingUser) => {
  if (actingUser?.role === ROLES.ADMIN) return;
  if (page.status !== CONTENT_STATUSES.PUBLISHED) {
    throw ApiError.notFound('Page not found.');
  }
};

const getPageById = async (id, actingUser) => {
  const page = await pageRepository.findById(id);
  if (!page) throw ApiError.notFound('Page not found.');
  assertVisible(page, actingUser);
  return page;
};

const getPageBySlug = async (slug, actingUser) => {
  const page = await pageRepository.findBySlug(slug);
  if (!page) throw ApiError.notFound('Page not found.');
  assertVisible(page, actingUser);
  return page;
};

/** Admin-only lookup by the fixed pageType identifier (e.g. the admin UI's "edit Homepage page" screen). */
const getPageByType = async (pageType) => {
  const page = await pageRepository.findByType(pageType);
  if (!page) throw ApiError.notFound(`No page has been created yet for "${pageType}".`);
  return page;
};

const listPages = async (filter, options, actingUser) => {
  const effectiveFilter = { ...filter };
  if (actingUser?.role !== ROLES.ADMIN) {
    effectiveFilter.status = CONTENT_STATUSES.PUBLISHED;
  }
  return pageRepository.list(effectiveFilter, options);
};

// --------------------------------------------------------------------
// Update / Delete (admin only — enforced at the route level)
// --------------------------------------------------------------------

const updatePage = async (id, body, actingUser) => {
  const existing = await pageRepository.findById(id);
  if (!existing) throw ApiError.notFound('Page not found.');

  const updates = { ...body, updatedBy: actingUser.id };

  if (body.slug !== undefined) {
    const nextSlug = slugify(body.slug);
    if (nextSlug !== existing.slug) {
      const slugTaken = await pageRepository.existsBySlug(nextSlug);
      if (slugTaken) throw ApiError.conflict(`Slug "${nextSlug}" is already in use.`);
    }
    updates.slug = nextSlug;
  }

  // findByIdAndUpdate never runs the model's pre('save') hooks, so the
  // publishedAt-stamping logic there only applies to `.create()` — this
  // mirrors it explicitly for the update path.
  if (
    body.status === CONTENT_STATUSES.PUBLISHED &&
    existing.status !== CONTENT_STATUSES.PUBLISHED &&
    !existing.publishedAt
  ) {
    updates.publishedAt = new Date();
  }

  const page = await pageRepository.updateById(id, updates);
  if (!page) throw ApiError.notFound('Page not found.');
  return page;
};

const deletePage = async (id) => {
  const deleted = await pageRepository.deleteById(id);
  if (!deleted) throw ApiError.notFound('Page not found.');
  return deleted;
};

module.exports = {
  generateUniqueSlug,
  createPage,
  getPageById,
  getPageBySlug,
  getPageByType,
  listPages,
  updatePage,
  deletePage,
};
