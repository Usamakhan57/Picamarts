'use strict';

const ApiError = require('../utils/ApiError');
const cartRepository = require('../repositories/cart.repository');
const productService = require('./product.service');
const { roundToCents } = require('../utils/money');
const config = require('../config');
const { PRODUCT_STATUSES } = require('../constants/productEnums');

/**
 * Phase 7, Part 1 — Shopping Cart. One cart per buyer (see Cart
 * model). Every product lookup on a write path goes through
 * productService.getProductById, so draft/archived/deleted-product
 * visibility and the inventory summary (availableStock, isOutOfStock)
 * are computed in exactly one place — this file only layers the
 * cart-specific rules on top (published-only, quantity vs. available
 * stock, merge-on-duplicate-add, cart totals).
 */

// --------------------------------------------------------------------
// Summary / response shaping
// --------------------------------------------------------------------

/** Effective unit price a buyer actually pays — sale price when set, else base price. */
const effectiveUnitPrice = (product) => (product.salePrice != null ? product.salePrice : product.basePrice);

/**
 * Shapes one populated cart item into the response the client renders.
 * Prices are computed against the product's CURRENT price/stock, not a
 * snapshot — a cart always reflects what checkout would charge right
 * now. `isAvailable` flags a line that could no longer be purchased
 * as-is (unpublished, or quantity now exceeds stock) without blocking
 * the read: GET /cart always succeeds and shows the cart as it is;
 * only the write operations (add/update quantity) reject on these
 * conditions.
 */
const serializeCartItem = (item) => {
  const { product } = item;

  // The referenced product was hard-deleted out from under the cart
  // (shouldn't happen given Product's soft-delete convention, but
  // populate() returns null if the id no longer resolves at all) —
  // surface the line as unavailable rather than letting it crash.
  if (!product) {
    return {
      id: item._id.toString(),
      product: null,
      quantity: item.quantity,
      unitPrice: 0,
      lineSubtotal: 0,
      lineDiscount: 0,
      lineTotal: 0,
      isAvailable: false,
      unavailableReason: 'Product no longer exists.',
    };
  }

  const availableStock = Math.max((product.stock ?? 0) - (product.reservedStock ?? 0), 0);
  const isPublished = product.status === PRODUCT_STATUSES.PUBLISHED;
  const hasEnoughStock = availableStock >= item.quantity;
  const unitPrice = effectiveUnitPrice(product);
  const lineSubtotal = product.basePrice * item.quantity;
  const lineTotal = unitPrice * item.quantity;

  let unavailableReason;
  if (!isPublished) {
    unavailableReason = 'Product is no longer available for purchase.';
  } else if (!hasEnoughStock) {
    unavailableReason = availableStock === 0 ? 'Out of stock.' : `Only ${availableStock} left in stock.`;
  }

  return {
    id: item._id.toString(),
    product: {
      id: product._id.toString(),
      title: product.title,
      slug: product.slug,
      thumbnail: product.thumbnail,
      basePrice: product.basePrice,
      salePrice: product.salePrice,
      currency: product.currency,
      status: product.status,
      availableStock,
    },
    quantity: item.quantity,
    unitPrice,
    lineSubtotal: roundToCents(lineSubtotal),
    lineDiscount: roundToCents(lineSubtotal - lineTotal),
    lineTotal: roundToCents(lineTotal),
    isAvailable: isPublished && hasEnoughStock,
    ...(unavailableReason && { unavailableReason }),
  };
};

/** Aggregates line items into the cart-level totals: Subtotal, Discount, Tax, Shipping, Grand Total. */
const computeSummary = (serializedItems) => {
  const itemCount = serializedItems.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = serializedItems.reduce((sum, item) => sum + item.lineSubtotal, 0);
  const discount = serializedItems.reduce((sum, item) => sum + item.lineDiscount, 0);
  const taxableAmount = subtotal - discount;
  const taxRate = config.cart.taxRatePercent / 100;
  const tax = roundToCents(taxableAmount * taxRate);
  // No shipping charge on an empty cart — the placeholder flat fee only applies once there's something to ship.
  const shipping = itemCount > 0 ? roundToCents(config.cart.shippingFlatFee) : 0;
  const grandTotal = roundToCents(taxableAmount + tax + shipping);

  return {
    itemCount,
    subtotal: roundToCents(subtotal),
    discount: roundToCents(discount),
    tax,
    shipping,
    grandTotal,
  };
};

/** Shapes a full (populated) cart document — or `null` for a buyer with no cart yet — into the API response shape. */
const toCartResponse = (cart) => {
  const items = (cart?.items || []).map(serializeCartItem);
  return {
    id: cart ? cart._id.toString() : null,
    items,
    summary: computeSummary(items),
  };
};

/** Re-fetches the cart populated (for response shaping) after a mutation was saved via the raw/unpopulated doc. */
const respondWith = async (buyerId) => toCartResponse(await cartRepository.findByBuyer(buyerId));

// --------------------------------------------------------------------
// Reads
// --------------------------------------------------------------------

/**
 * Never creates a cart row just to answer a read — a buyer who's only
 * browsed never gets a junk empty cart document persisted for them.
 */
const getCart = async (buyerId) => respondWith(buyerId);

// --------------------------------------------------------------------
// Writes
// --------------------------------------------------------------------

const getOrCreateRawCart = async (buyerId) => (await cartRepository.findRawByBuyer(buyerId)) || cartRepository.createForBuyer(buyerId);

/**
 * Validates a product is addable/orderable at all — published, and
 * (via productService's inventory summary) not out of stock. Reuses
 * productService.getProductById so draft/archived/deleted visibility
 * and availableStock/isOutOfStock are computed in exactly one place,
 * not re-derived here.
 */
const assertProductPurchasable = async (productId, actingUser) => {
  const product = await productService.getProductById(productId, actingUser);

  if (product.status !== PRODUCT_STATUSES.PUBLISHED) {
    throw ApiError.badRequest('Only published products can be added to the cart.');
  }
  if (product.isOutOfStock) {
    throw ApiError.badRequest('This product is out of stock.');
  }

  return product;
};

/**
 * Adds a product to the buyer's cart, creating the cart if this is
 * their first item. If the product is already in the cart, the
 * requested quantity is ADDED to the existing line instead of creating
 * a duplicate entry — the combined quantity is what gets checked
 * against available stock.
 */
const addItemToCart = async (buyerId, { productId, quantity }, actingUser) => {
  const product = await assertProductPurchasable(productId, actingUser);

  const cartDoc = await getOrCreateRawCart(buyerId);
  const existing = cartDoc.items.find((item) => item.product.toString() === productId);
  const requestedTotal = (existing?.quantity || 0) + quantity;

  if (requestedTotal > product.availableStock) {
    throw ApiError.badRequest(`Only ${product.availableStock} unit(s) available.`);
  }

  if (existing) {
    existing.quantity = requestedTotal;
  } else {
    cartDoc.items.push({ product: productId, quantity });
  }

  await cartDoc.save();
  return respondWith(buyerId);
};

/**
 * Sets a cart line to an absolute quantity — this single endpoint
 * covers both "increase" and "decrease" since the caller sends the new
 * total, not a delta. Removing an item entirely is DELETE
 * /cart/items/:itemId, not quantity 0 — the validator requires
 * quantity >= 1 here.
 */
const updateItemQuantity = async (buyerId, itemId, quantity, actingUser) => {
  const cartDoc = await cartRepository.findRawByBuyer(buyerId);
  const item = cartDoc?.items.id(itemId);
  if (!item) {
    throw ApiError.notFound('Cart item not found.');
  }

  const product = await assertProductPurchasable(item.product.toString(), actingUser);
  if (quantity > product.availableStock) {
    throw ApiError.badRequest(`Only ${product.availableStock} unit(s) available.`);
  }

  item.quantity = quantity;
  await cartDoc.save();
  return respondWith(buyerId);
};

/** Removes a single line from the cart. */
const removeItem = async (buyerId, itemId) => {
  const cartDoc = await cartRepository.findRawByBuyer(buyerId);
  const item = cartDoc?.items.id(itemId);
  if (!item) {
    throw ApiError.notFound('Cart item not found.');
  }

  item.deleteOne();
  await cartDoc.save();
  return respondWith(buyerId);
};

/** Empties the cart. A buyer with no cart yet is already "empty" — treated as a no-op success, not a 404. */
const clearCart = async (buyerId) => {
  const cartDoc = await cartRepository.findRawByBuyer(buyerId);
  if (!cartDoc) return toCartResponse(null);

  cartDoc.items = [];
  await cartDoc.save();
  return toCartResponse(cartDoc);
};

module.exports = {
  getCart,
  addItemToCart,
  updateItemQuantity,
  removeItem,
  clearCart,
};
