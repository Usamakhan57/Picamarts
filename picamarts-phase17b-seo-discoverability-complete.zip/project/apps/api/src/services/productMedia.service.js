'use strict';

const ApiError = require('../utils/ApiError');
const productRepository = require('../repositories/product.repository');
const { assertOwnership, toEnrichedProduct } = require('./product.service');
const { uploadBufferToCloudinary, deleteFromCloudinary } = require('../utils/cloudinaryUpload');
const { PRODUCT_STATUSES, PRODUCT_TYPES } = require('../constants/productEnums');
const { MAX_GALLERY_IMAGES, MAX_DOWNLOAD_FILES } = require('../constants/productMedia');
// Phase 12, Part 3 — Image Processing queue. A single additive,
// fire-and-forget call after a successful thumbnail upload (`.catch(()
// => {})`), the same integration shape Phase 10.2 used for notification
// hooks on Order/Payment/Review — never awaited, never allowed to affect
// the upload response.
const imageProcessingQueue = require('../queues/imageProcessing.queue');

/**
 * Phase 6, Feature 1 — Image Upload (thumbnail replace + gallery add),
 * Feature 4 — Image Ordering, Feature 5 — Set Featured Image, and
 * Feature 6 — Remove Gallery Image. Replace-in-place (Feature 7)
 * builds on top of this in a later step.
 *
 * Reuses productRepository.findById/updateById as-is (no repository
 * changes needed — these are the same fetch-mutate-save helpers
 * Product CRUD already uses) and product.service.js's assertOwnership
 * (now exported) instead of duplicating the ownership check.
 */

/** Fetches the product and confirms it's a live (non-deleted) one the caller is allowed to modify. */
const getOwnedProduct = async (productId, actingUser) => {
  const product = await productRepository.findById(productId);
  if (!product || product.status === PRODUCT_STATUSES.DELETED) {
    throw ApiError.notFound('Product not found.');
  }
  assertOwnership(product, actingUser);
  return product;
};

/** Shapes a Cloudinary upload response into the productImageSchema fields. */
const toImageRecord = (uploadResult, extra = {}) => ({
  url: uploadResult.secure_url,
  publicId: uploadResult.public_id,
  width: uploadResult.width || 0,
  height: uploadResult.height || 0,
  format: uploadResult.format || '',
  bytes: uploadResult.bytes || 0,
  resourceType: uploadResult.resource_type === 'video' ? 'video' : 'image',
  uploadedAt: uploadResult.created_at ? new Date(uploadResult.created_at) : new Date(),
  ...extra,
});

/**
 * Replaces the product's single thumbnail. If one already existed, its
 * Cloudinary asset is deleted first so uploads never leave orphaned
 * storage behind — a product only ever has one live thumbnail.
 *
 * @param {string} productId
 * @param {Express.Multer.File} file
 * @param {{ id: string, role: string }} actingUser
 */
const uploadThumbnail = async (productId, file, actingUser) => {
  const product = await getOwnedProduct(productId, actingUser);

  const previousPublicId = product.thumbnail?.publicId;

  const uploadResult = await uploadBufferToCloudinary(file, { folder: 'products/thumbnails' });

  if (previousPublicId) {
    // Best-effort cleanup — a failed delete of the old asset shouldn't
    // block the new thumbnail from being saved.
    await deleteFromCloudinary(previousPublicId).catch(() => {});
  }

  const updated = await productRepository.updateById(productId, { thumbnail: toImageRecord(uploadResult) });

  imageProcessingQueue
    .addImageOptimizationJob({ publicId: uploadResult.public_id, url: uploadResult.secure_url })
    .catch(() => {});

  return updated.thumbnail;
};

/**
 * Appends one or more images to the product's gallery. Rejects the
 * whole batch (no partial upload) if it would push the gallery past
 * MAX_GALLERY_IMAGES, so the caller gets one clear error instead of a
 * partially-applied gallery.
 *
 * @param {string} productId
 * @param {Express.Multer.File[]} files
 * @param {{ id: string, role: string }} actingUser
 */
const uploadGalleryImages = async (productId, files, actingUser) => {
  if (!files || files.length === 0) {
    throw ApiError.badRequest('At least one image file is required.');
  }

  const product = await getOwnedProduct(productId, actingUser);

  const existingCount = product.gallery.length;
  if (existingCount + files.length > MAX_GALLERY_IMAGES) {
    throw ApiError.badRequest(
      `A product can have at most ${MAX_GALLERY_IMAGES} gallery images (${existingCount} already uploaded, ${files.length} submitted).`
    );
  }

  const uploadResults = await Promise.all(
    files.map((file) => uploadBufferToCloudinary(file, { folder: 'products/gallery' }))
  );

  const newImages = uploadResults.map((result, index) =>
    toImageRecord(result, { position: existingCount + index })
  );

  const updated = await productRepository.updateById(productId, { gallery: [...product.gallery, ...newImages] });
  return updated.gallery;
};

/**
 * Reorders the gallery to match `orderedImageIds` exactly — the caller
 * sends the full list of gallery image ids in the desired order, and
 * each item's `position` is reassigned to its index in that list. The
 * gallery array itself is also rebuilt in that order, so array order
 * and `position` never drift apart.
 *
 * Rejects anything that isn't an exact permutation of the product's
 * current gallery ids (missing, extra, or duplicated ids) — a partial
 * reorder would leave some images with an undefined position relative
 * to the rest.
 *
 * @param {string} productId
 * @param {string[]} orderedImageIds
 * @param {{ id: string, role: string }} actingUser
 */
const reorderGalleryImages = async (productId, orderedImageIds, actingUser) => {
  const product = await getOwnedProduct(productId, actingUser);

  const currentIds = product.gallery.map((image) => image._id.toString());

  const hasDuplicates = new Set(orderedImageIds).size !== orderedImageIds.length;
  const isSameSet =
    orderedImageIds.length === currentIds.length && currentIds.every((id) => orderedImageIds.includes(id));

  if (hasDuplicates || !isSameSet) {
    throw ApiError.badRequest('The order must include every existing gallery image id exactly once.');
  }

  const byId = new Map(product.gallery.map((image) => [image._id.toString(), image]));
  const reordered = orderedImageIds.map((id, index) => {
    const image = byId.get(id).toObject();
    image.position = index;
    return image;
  });

  const updated = await productRepository.updateById(productId, { gallery: reordered });
  return updated.gallery;
};

/**
 * Promotes an existing gallery image to become the product's
 * thumbnail. Non-destructive: if a thumbnail already existed, it's
 * demoted into the gallery (appended at the end) rather than deleted —
 * "set featured" swaps which image leads, it doesn't discard anything.
 * Remaining gallery positions are recompacted afterward so there's
 * never a gap where the promoted image used to sit.
 *
 * @param {string} productId
 * @param {string} imageId - a gallery image's _id
 * @param {{ id: string, role: string }} actingUser
 */
const setFeaturedImage = async (productId, imageId, actingUser) => {
  const product = await getOwnedProduct(productId, actingUser);

  const targetIndex = product.gallery.findIndex((image) => image._id.toString() === imageId);
  if (targetIndex === -1) {
    throw ApiError.notFound('Gallery image not found.');
  }

  const promoted = product.gallery[targetIndex].toObject();
  const remainingGallery = product.gallery.filter((_, index) => index !== targetIndex).map((image) => image.toObject());

  const previousThumbnail = product.thumbnail?.publicId ? product.thumbnail.toObject() : null;
  if (previousThumbnail) {
    // Demoted into the gallery — drop its old _id/position so it gets a
    // fresh id (thumbnail and gallery ids are separate id spaces) and
    // the correct trailing position once recompacted below.
    delete previousThumbnail._id;
    remainingGallery.push(previousThumbnail);
  }

  const recompactedGallery = remainingGallery.map((image, index) => ({ ...image, position: index }));

  // The promoted image becomes the thumbnail; its gallery-only fields
  // (_id, position) don't carry over — a thumbnail id space is separate
  // from gallery ids, and a thumbnail has no position.
  // eslint-disable-next-line no-unused-vars
  const { _id, position, ...newThumbnail } = promoted;

  const updated = await productRepository.updateById(productId, {
    thumbnail: newThumbnail,
    gallery: recompactedGallery,
  });

  return { thumbnail: updated.thumbnail, gallery: updated.gallery };
};

/**
 * Deletes a single gallery image. Its Cloudinary asset is removed
 * first — same best-effort trade-off uploadThumbnail already makes
 * (a failed remote delete shouldn't block the image from disappearing
 * from the product the caller is looking at) — then the image's
 * metadata is dropped from the gallery and the remaining images are
 * recompacted (0..n-1) so no position gap is left where it used to sit.
 *
 * @param {string} productId
 * @param {string} imageId - a gallery image's _id
 * @param {{ id: string, role: string }} actingUser
 */
const removeGalleryImage = async (productId, imageId, actingUser) => {
  const product = await getOwnedProduct(productId, actingUser);

  const targetIndex = product.gallery.findIndex((image) => image._id.toString() === imageId);
  if (targetIndex === -1) {
    throw ApiError.notFound('Gallery image not found.');
  }

  const target = product.gallery[targetIndex];
  if (target.publicId) {
    await deleteFromCloudinary(target.publicId).catch(() => {});
  }

  const remainingGallery = product.gallery
    .filter((_, index) => index !== targetIndex)
    .map((image, index) => ({ ...image.toObject(), position: index }));

  const updated = await productRepository.updateById(productId, { gallery: remainingGallery });
  return updated.gallery;
};

/**
 * Replaces an existing gallery image's file in place (Feature 6.2).
 * Unlike removeGalleryImage/reorderGalleryImages, this never touches
 * the image's `_id` or `position` — it's the same gallery slot with a
 * new file behind it, not a remove-then-add.
 *
 * Ordering matters here for safety:
 *   1. Upload the new file to Cloudinary first.
 *   2. Try to save the product with the new record swapped in.
 *   3. Only on DB-save success do we delete the OLD Cloudinary asset
 *      (best-effort, same trade-off as the other media ops).
 *   4. If the DB save throws, roll back by deleting the NEW asset we
 *      just uploaded, then rethrow — the product document (and the
 *      old image) is left completely unchanged, and no orphaned
 *      Cloudinary asset is left behind either way.
 *
 * @param {string} productId
 * @param {string} imageId - a gallery image's _id
 * @param {Express.Multer.File} file
 * @param {{ id: string, role: string }} actingUser
 */
const replaceGalleryImage = async (productId, imageId, file, actingUser) => {
  const product = await getOwnedProduct(productId, actingUser);

  const targetIndex = product.gallery.findIndex((image) => image._id.toString() === imageId);
  if (targetIndex === -1) {
    throw ApiError.notFound('Gallery image not found.');
  }

  const target = product.gallery[targetIndex].toObject();

  // Upload BEFORE touching anything else — if this throws, the
  // existing image is left completely untouched, no cleanup needed.
  const uploadResult = await uploadBufferToCloudinary(file, { folder: 'products/gallery' });

  // Same slot, same id, same position, same alt text — only the
  // Cloudinary-derived metadata changes.
  const replacement = toImageRecord(uploadResult, {
    _id: target._id,
    position: target.position,
    alt: target.alt,
  });

  const newGallery = product.gallery.map((image, index) =>
    index === targetIndex ? replacement : image.toObject()
  );

  let updated;
  try {
    updated = await productRepository.updateById(productId, { gallery: newGallery });
  } catch (error) {
    // DB save failed — roll back the newly uploaded asset so it never
    // becomes an orphan, then let the caller see the original error.
    await deleteFromCloudinary(uploadResult.public_id).catch(() => {});
    throw error;
  }

  if (!updated) {
    // Product vanished between the initial fetch and the save (e.g.
    // deleted concurrently) — same rollback, reported as 404.
    await deleteFromCloudinary(uploadResult.public_id).catch(() => {});
    throw ApiError.notFound('Product not found.');
  }

  if (target.publicId && target.publicId !== uploadResult.public_id) {
    // Old asset is only ever removed after the new one is safely saved.
    await deleteFromCloudinary(target.publicId).catch(() => {});
  }

  return toEnrichedProduct(updated);
};

// ---------------------------------------------------------------------
// Phase 14.1, Part 2/3 — Digital Asset Upload + Secure Storage.
// Uploaded with `type: 'authenticated'` so Cloudinary itself refuses
// the plain secure_url — the only way to actually fetch one of these
// afterward is a signed, expiring URL (see
// utils/cloudinaryUpload.js#getSignedDownloadUrl, used by
// digitalDelivery.service.js). Mirrors uploadGalleryImages'
// batch-reject-if-over-limit shape exactly.
// ---------------------------------------------------------------------

/** Appends one or more downloadable assets to a digital/both-type product. Rejects the whole batch if it would exceed MAX_DOWNLOAD_FILES. */
const uploadDownloadFiles = async (productId, files, actingUser) => {
  if (!files || files.length === 0) {
    throw ApiError.badRequest('At least one file is required.');
  }

  const product = await getOwnedProduct(productId, actingUser);

  if (product.type === PRODUCT_TYPES.PHYSICAL) {
    throw ApiError.badRequest('Only digital or hybrid products can have downloadable files.');
  }

  const existingCount = product.downloadFiles.length;
  if (existingCount + files.length > MAX_DOWNLOAD_FILES) {
    throw ApiError.badRequest(
      `A product can have at most ${MAX_DOWNLOAD_FILES} downloadable files (${existingCount} already uploaded, ${files.length} submitted).`
    );
  }

  const uploadResults = await Promise.all(
    files.map((file) =>
      uploadBufferToCloudinary(file, {
        folder: 'products/downloads',
        resourceType: 'auto',
        type: 'authenticated', // Part 3 — never publicly reachable by url alone
      })
    )
  );

  const newFiles = uploadResults.map((result, index) => ({
    url: result.secure_url,
    publicId: result.public_id,
    resourceType: result.resource_type === 'video' ? 'video' : result.resource_type === 'image' ? 'image' : 'raw',
    label: files[index].originalname || '',
    size: result.bytes || 0,
  }));

  const totalFileSize = [...product.downloadFiles, ...newFiles].reduce((sum, f) => sum + (f.size || 0), 0);

  const updated = await productRepository.updateById(productId, {
    downloadFiles: [...product.downloadFiles, ...newFiles],
    fileSize: totalFileSize,
  });
  return updated.downloadFiles;
};

/** Removes a single downloadable asset. Existing buyers keep their already-delivered files — Download records hold their own frozen snapshot (see models/Download.js), unaffected by this. */
const removeDownloadFile = async (productId, fileId, actingUser) => {
  const product = await getOwnedProduct(productId, actingUser);

  const targetIndex = product.downloadFiles.findIndex((f) => f._id.toString() === fileId);
  if (targetIndex === -1) {
    throw ApiError.notFound('Download file not found.');
  }

  const target = product.downloadFiles[targetIndex];
  if (target.publicId) {
    await deleteFromCloudinary(target.publicId, target.resourceType || 'raw').catch(() => {});
  }

  const remainingFiles = product.downloadFiles.filter((_, index) => index !== targetIndex);
  const totalFileSize = remainingFiles.reduce((sum, f) => sum + (f.size || 0), 0);

  const updated = await productRepository.updateById(productId, {
    downloadFiles: remainingFiles,
    fileSize: totalFileSize,
  });
  return updated.downloadFiles;
};

module.exports = {
  uploadThumbnail,
  uploadGalleryImages,
  reorderGalleryImages,
  setFeaturedImage,
  removeGalleryImage,
  replaceGalleryImage,
  uploadDownloadFiles,
  removeDownloadFile,
};
