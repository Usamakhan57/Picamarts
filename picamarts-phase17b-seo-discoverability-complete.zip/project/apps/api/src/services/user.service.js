'use strict';

const ApiError = require('../utils/ApiError');
const userRepository = require('../repositories/user.repository');
const { ROLES } = require('../constants/roles');

/**
 * Phase 15C, Part 3 — Admin User Management. Deliberately read +
 * moderate-only (list/search/filter/paginate, view, suspend, activate,
 * delete) — there is no admin-editable name/email/password form here;
 * those stay self-service via /auth/profile and /auth/change-password,
 * exactly as the "do not modify Authentication" rule intends.
 */

const listUsers = (filter = {}, options = {}) => userRepository.list(filter, options);

const getUserById = async (id) => {
  const user = await userRepository.findById(id);
  if (!user) throw ApiError.notFound('User not found.');
  return user;
};

/**
 * Suspends a user account. Setting `isActive: false` takes effect
 * immediately for any live session — `protect` middleware and the
 * login flow both already reject an inactive user (auth.middleware.js /
 * auth.service.js), so no changes to Authentication are needed here.
 * Clearing refresh tokens on top makes any refresh-cookie retry a hard
 * 401 instead of a slow expiry.
 */
const suspendUser = async (id, actingAdminId) => {
  if (String(id) === String(actingAdminId)) {
    throw ApiError.badRequest('You cannot suspend your own account.');
  }

  const user = await getUserById(id);
  if (!user.isActive) throw ApiError.badRequest('This user is already suspended.');

  await userRepository.clearRefreshTokens(id);
  return userRepository.updateById(id, { isActive: false });
};

const activateUser = async (id) => {
  const user = await getUserById(id);
  if (user.isActive) throw ApiError.badRequest('This user is already active.');
  return userRepository.updateById(id, { isActive: true });
};

/**
 * Hard-deletes a user account. Deliberately simple (matches the brief's
 * "Delete (if backend supports)" allowance): no cascading cleanup of a
 * deleted user's orders/reviews/seller profile — those keep their
 * existing `buyer`/`seller`/`user` reference pointing at a since-deleted
 * document, same as any other reference-integrity gap already present
 * in this schema design (e.g. Order.buyer is never re-validated after
 * creation). Flagged as a known limitation, not fixed here since
 * touching Order/Review/Seller's own models is out of scope.
 */
const deleteUser = async (id, actingAdminId) => {
  if (String(id) === String(actingAdminId)) {
    throw ApiError.badRequest('You cannot delete your own account.');
  }

  const user = await getUserById(id);
  if (user.role === ROLES.ADMIN) {
    throw ApiError.forbidden('Admin accounts cannot be deleted from this screen.');
  }

  await userRepository.deleteById(id);
  return user;
};

module.exports = { listUsers, getUserById, suspendUser, activateUser, deleteUser };
