'use strict';

const ApiError = require('../utils/ApiError');
const recentlyViewedRepository = require('../repositories/recentlyViewed.repository');
const { MAX_RECENTLY_VIEWED_ITEMS } = require('../models/RecentlyViewed');

/**
 * Phase 17A, Part 5 — Recently Viewed. Tracks the authenticated
 * buyer's last MAX_RECENTLY_VIEWED_ITEMS distinct products viewed,
 * newest first. Recording is called fire-and-forget from
 * product.controller.js#getById/getBySlug (same
 * `.catch(() => {})` convention already established for
 * digitalDeliveryService/notificationService in payment.service.js)
 * so a logging failure never breaks the product page itself.
 */

// --------------------------------------------------------------------
// Response shaping
// --------------------------------------------------------------------

const serializeItem = (item) => {
  const { product } = item;

  if (!product) {
    return { id: item._id.toString(), product: null, unavailableReason: 'Product no longer exists.', viewedAt: item.viewedAt };
  }

  return {
    id: item._id.toString(),
    product: {
      id: product._id.toString(),
      title: product.title,
      slug: product.slug,
      thumbnail: product.thumbnail,
      basePrice: product.basePrice,
      salePrice: product.salePrice,
      currency: product.currency,
      status: product.status,
    },
    viewedAt: item.viewedAt,
  };
};

const toResponse = (doc) => ({
  itemCount: doc?.items?.length || 0,
  items: (doc?.items || []).map(serializeItem),
});

// --------------------------------------------------------------------
// Reads
// --------------------------------------------------------------------

/** Never creates a row just to answer a read — same convention as Wishlist/Cart. */
const getRecentlyViewed = async (buyerId) => toResponse(await recentlyViewedRepository.findByBuyer(buyerId));

// --------------------------------------------------------------------
// Writes
// --------------------------------------------------------------------

const getOrCreateRawDoc = async (buyerId) =>
  (await recentlyViewedRepository.findRawByBuyer(buyerId)) || recentlyViewedRepository.createForBuyer(buyerId);

/**
 * Records a view: re-viewing an already-tracked product moves it back
 * to the front rather than creating a second entry. Trims to
 * MAX_RECENTLY_VIEWED_ITEMS on every write so the list never grows
 * unbounded.
 */
const recordView = async (buyerId, productId) => {
  const doc = await getOrCreateRawDoc(buyerId);

  doc.items = doc.items.filter((item) => item.product.toString() !== productId);
  doc.items.unshift({ product: productId, viewedAt: new Date() });
  doc.items = doc.items.slice(0, MAX_RECENTLY_VIEWED_ITEMS);

  await doc.save();
};

const removeItem = async (buyerId, productId) => {
  const doc = await recentlyViewedRepository.findRawByBuyer(buyerId);
  const item = doc?.items.find((entry) => entry.product.toString() === productId);
  if (!item) {
    throw ApiError.notFound('Recently viewed item not found.');
  }

  item.deleteOne();
  await doc.save();
  return getRecentlyViewed(buyerId);
};

/** A buyer with no history yet is already "empty" — no-op success, not a 404 (same convention as Wishlist/Cart). */
const clear = async (buyerId) => {
  const doc = await recentlyViewedRepository.findRawByBuyer(buyerId);
  if (!doc) return toResponse(null);

  doc.items = [];
  await doc.save();
  return toResponse(doc);
};

module.exports = { getRecentlyViewed, recordView, removeItem, clear };
