'use strict';

const ApiError = require('../utils/ApiError');
const digitalDeliveryRepository = require('../repositories/digitalDelivery.repository');
const { getSignedDownloadUrl } = require('../utils/cloudinaryUpload');
const { generateLicenseKey } = require('../utils/licenseKey');
const { ROLES } = require('../constants/roles');
const { PRODUCT_TYPES } = require('../constants/productEnums');
const { DOWNLOAD_STATUSES, DOWNLOAD_URL_TTL_MINUTES } = require('../constants/digitalDeliveryEnums');
// Additive, fire-and-forget only (`.catch(() => {})` at every call site) —
// same integration shape notification.service.js itself established for
// Order/Payment/Review; see that file's own comment.
const notificationService = require('./notification.service');

/**
 * Phase 14.1 — Digital Product Delivery.
 *
 * This file owns everything about turning a paid order into buyer-
 * accessible files: automatic delivery on payment success (Part 8),
 * purchase validation + secure signed downloads (Parts 4/5), download
 * limits/expiry (Part 6), license key assignment (Part 7), and the
 * seller/admin monitoring surface (Parts 10/11/12).
 *
 * It never modifies Order/Payment/Product's own files — every read of
 * those models goes through digitalDelivery.repository.js's additive,
 * narrowly-scoped direct queries (the same convention
 * payment.repository.js established for touching Order).
 */

const idStr = (value) => (value?.toString ? value.toString() : value);

// --------------------------------------------------------------------
// Response shaping
// --------------------------------------------------------------------

const toDownloadResponse = (download, product) => ({
  id: idStr(download._id ?? download.id),
  order: idStr(download.order),
  product: product
    ? { id: idStr(product._id ?? product.id), title: product.title, slug: product.slug, thumbnail: product.thumbnail }
    : idStr(download.product),
  files: (download.files || []).map((f) => ({
    id: idStr(f._id),
    label: f.label,
    size: f.size,
  })),
  licenseKey: download.licenseKey,
  maxDownloads: download.maxDownloads,
  downloadCount: download.downloadCount,
  expiresAt: download.expiresAt,
  status: download.status,
  revokedReason: download.revokedReason || '',
  purchasedAt: download.createdAt,
});

// --------------------------------------------------------------------
// Part 8 — Digital Order Delivery (auto-run on payment success)
// --------------------------------------------------------------------

/**
 * Called once, right after a payment succeeds (see payment.service.js's
 * two success paths — confirmPayment and the Stripe webhook — both
 * call this the same additive, fire-and-forget way they already call
 * notifyPaymentSuccessForOrder). For every digital/hybrid line item in
 * the order that hasn't already been delivered, creates a Download
 * record (files snapshot + optional license key + download policy),
 * then notifies the buyer.
 *
 * Idempotent: safe to call twice for the same order (e.g. a
 * confirmPayment response racing a webhook redelivery) — the unique
 * {order, orderItemId} index on Download, backed by an explicit
 * pre-check here, means a duplicate call is a silent no-op per item.
 */
const deliverForOrder = async (payment) => {
  const order = await digitalDeliveryRepository.findOrderById(payment.order);
  if (!order) return;

  for (const item of order.items) {
    // eslint-disable-next-line no-await-in-loop
    const product = await digitalDeliveryRepository.findProductById(item.product);
    if (!product) continue;
    if (product.type === PRODUCT_TYPES.PHYSICAL) continue; // Part 1 — physical-only products are never delivered digitally
    if (!product.downloadFiles || product.downloadFiles.length === 0) continue; // digital/both but the seller hasn't uploaded assets yet

    // eslint-disable-next-line no-await-in-loop
    const existing = await digitalDeliveryRepository.findDownloadByOrderItem(order._id, item._id);
    if (existing) continue; // already delivered — idempotency guard

    const expiresAt =
      product.downloadExpiryDays != null
        ? new Date(Date.now() + product.downloadExpiryDays * 24 * 60 * 60 * 1000)
        : null;

    const files = product.downloadFiles.map((f) => ({
      sourceFileId: f._id,
      url: f.url,
      publicId: f.publicId,
      resourceType: f.resourceType || 'raw',
      label: f.label,
      size: f.size,
    }));

    let download;
    try {
      // eslint-disable-next-line no-await-in-loop
      download = await digitalDeliveryRepository.createDownload({
        order: order._id,
        orderItemId: item._id,
        product: product._id,
        buyer: order.buyer,
        seller: item.seller,
        files,
        licenseKey: product.licenses && product.licenses.length > 0 ? generateLicenseKey() : null,
        maxDownloads: product.downloadLimit != null ? product.downloadLimit : null,
        expiresAt,
      });
    } catch (error) {
      if (error?.code === 11000) continue; // lost the idempotency race to a concurrent call — fine, the other call delivered it
      throw error;
    }

    // Part 13/14 — notify + email, best-effort (never affects payment flow).
    notificationService
      .notifyDigitalFilesReady(order.buyer, download, product)
      .catch(() => {});
    if (download.licenseKey) {
      notificationService
        .notifyLicenseAssigned(order.buyer, download, product)
        .catch(() => {});
    }
  }
};

// --------------------------------------------------------------------
// Part 9 — Customer Downloads ("My Downloads")
// --------------------------------------------------------------------

const listMyDownloads = async (buyerId) => {
  const { items } = await digitalDeliveryRepository.listDownloadsByBuyer(buyerId, { limit: 100 });
  const products = await Promise.all(items.map((d) => digitalDeliveryRepository.findProductById(d.product)));
  return items.map((d, i) => toDownloadResponse(d, products[i]));
};

// --------------------------------------------------------------------
// Parts 4/5/15 — Purchase Validation + Secure Downloads
// --------------------------------------------------------------------

const assertCanAccessDownload = (download, actingUser) => {
  if (actingUser.role === ROLES.ADMIN) return;
  if (download.buyer.toString() !== actingUser.id) {
    throw ApiError.forbidden('You do not have permission to access this download.');
  }
};

/**
 * Validates ownership + revoked/expired/limit state, generates a
 * signed, short-lived Cloudinary URL for one purchased file, logs the
 * redemption (Part 12), and increments the download's usage counter.
 * Every rejection reason here is exactly what Part 4/15 asks to be
 * prevented: no ownership, revoked, expired, over the limit.
 */
const redeemDownload = async (downloadId, fileId, actingUser, requestMeta = {}) => {
  const download = await digitalDeliveryRepository.findDownloadById(downloadId);
  if (!download) throw ApiError.notFound('Download not found.');

  assertCanAccessDownload(download, actingUser);

  if (download.status === DOWNLOAD_STATUSES.REVOKED) {
    throw ApiError.forbidden(download.revokedReason || 'This download has been revoked.');
  }
  if (download.expiresAt && download.expiresAt.getTime() < Date.now()) {
    throw ApiError.badRequest('This download link has expired.');
  }
  if (download.maxDownloads != null && download.downloadCount >= download.maxDownloads) {
    throw ApiError.badRequest('You have reached the maximum number of downloads for this purchase.');
  }

  const file = download.files.find((f) => f._id.toString() === fileId);
  if (!file) throw ApiError.notFound('File not found in this download.');

  const { url, expiresAt } = getSignedDownloadUrl(
    { publicId: file.publicId, resourceType: file.resourceType },
    DOWNLOAD_URL_TTL_MINUTES * 60
  );

  await digitalDeliveryRepository.incrementDownloadCount(download._id);
  await digitalDeliveryRepository.createDownloadLog({
    download: download._id,
    user: actingUser.id,
    product: download.product,
    fileId: file._id,
    ipAddress: requestMeta.ipAddress || '',
    userAgent: requestMeta.userAgent || '',
  });

  return { url, expiresAt, downloadCount: download.downloadCount + 1, maxDownloads: download.maxDownloads };
};

// --------------------------------------------------------------------
// Parts 10/11 — Seller/Admin monitoring
// --------------------------------------------------------------------

const assertCanManageDownload = (download, actingUser) => {
  if (actingUser.role === ROLES.ADMIN) return;
  if (actingUser.role === ROLES.SELLER && download.seller.toString() === actingUser.id) return;
  throw ApiError.forbidden('You do not have permission to manage this download.');
};

/** Admin: revoke any download. Seller: revoke only a download on their own product. */
const revokeDownload = async (downloadId, reason, actingUser) => {
  const download = await digitalDeliveryRepository.findDownloadById(downloadId);
  if (!download) throw ApiError.notFound('Download not found.');
  assertCanManageDownload(download, actingUser);

  const updated = await digitalDeliveryRepository.revokeDownload(downloadId, { reason, revokedBy: actingUser.id });
  return toDownloadResponse(updated);
};

/** Admin only — reverses an accidental/appealed revocation. */
const reinstateDownload = async (downloadId, actingUser) => {
  if (actingUser.role !== ROLES.ADMIN) {
    throw ApiError.forbidden('Only an admin can reinstate a revoked download.');
  }
  const download = await digitalDeliveryRepository.findDownloadById(downloadId);
  if (!download) throw ApiError.notFound('Download not found.');

  const updated = await digitalDeliveryRepository.reinstateDownload(downloadId);
  return toDownloadResponse(updated);
};

/** Seller sees only their own products' delivery stats; admin sees everything. */
const getDeliveryStats = async (actingUser) => {
  const matchFilter = actingUser.role === ROLES.ADMIN ? {} : { seller: actingUser.id };
  const stats = await digitalDeliveryRepository.aggregateDownloadStatsByProduct(matchFilter);

  const products = await Promise.all(stats.map((s) => digitalDeliveryRepository.findProductById(s._id)));
  return stats.map((s, i) => ({
    product: products[i] ? { id: idStr(products[i]._id), title: products[i].title } : idStr(s._id),
    totalPurchases: s.totalPurchases,
    totalDownloads: s.totalDownloads,
    revoked: s.revoked,
  }));
};

// --------------------------------------------------------------------
// Part 12 — Download History
// --------------------------------------------------------------------

/** Seller: logs for downloads on their own products only. Admin: everything, optionally filtered by user/product/download. */
const listDownloadLogs = async (query, actingUser) => {
  const { page, limit, downloadId, productId, userId } = query;
  const options = { page: Number(page) || 1, limit: Number(limit) || 20 };

  if (actingUser.role === ROLES.ADMIN) {
    const filter = {};
    if (downloadId) filter.download = downloadId;
    if (productId) filter.product = productId;
    if (userId) filter.user = userId;
    return digitalDeliveryRepository.listAllLogs(filter, options);
  }

  if (actingUser.role === ROLES.SELLER) {
    if (!downloadId) {
      throw ApiError.badRequest('A downloadId is required to view its history as a seller.');
    }
    const download = await digitalDeliveryRepository.findDownloadById(downloadId);
    if (!download) throw ApiError.notFound('Download not found.');
    assertCanManageDownload(download, actingUser);
    return digitalDeliveryRepository.listLogsByDownload(downloadId, options);
  }

  throw ApiError.forbidden('You do not have permission to view download logs.');
};

/** Admin/seller listing of Download records themselves (distinct from the redemption log above) — powers the dashboards in Parts 10/11. */
const listDeliveries = async (query, actingUser) => {
  const { page, limit, productId, status } = query;
  const options = { page: Number(page) || 1, limit: Number(limit) || 20 };
  const extraFilter = {};
  if (productId) extraFilter.product = productId;
  if (status) extraFilter.status = status;

  const { items, meta } =
    actingUser.role === ROLES.ADMIN
      ? await digitalDeliveryRepository.listAllDownloads(extraFilter, options)
      : await digitalDeliveryRepository.listDownloadsBySeller(actingUser.id, extraFilter, options);

  const products = await Promise.all(items.map((d) => digitalDeliveryRepository.findProductById(d.product)));
  return { items: items.map((d, i) => toDownloadResponse(d, products[i])), meta };
};

module.exports = {
  deliverForOrder,
  listMyDownloads,
  redeemDownload,
  revokeDownload,
  reinstateDownload,
  getDeliveryStats,
  listDownloadLogs,
  listDeliveries,
  toDownloadResponse,
};
