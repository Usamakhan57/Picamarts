'use strict';

const ApiError = require('../utils/ApiError');
const brandRepository = require('../repositories/brand.repository');
const { slugify, withUniqueSuffix } = require('../utils/slugify');

const generateUniqueSlug = async (name) => {
  const base = slugify(name);
  const exists = await brandRepository.existsBySlug(base);
  return exists ? withUniqueSuffix(base) : base;
};

const createBrand = async (data) => {
  const slug = data.slug ? slugify(data.slug) : await generateUniqueSlug(data.name);
  return brandRepository.create({ ...data, slug });
};

const getBrandById = async (id) => {
  const brand = await brandRepository.findById(id);
  if (!brand) throw ApiError.notFound('Brand not found.');
  return brand;
};

const getBrandBySlug = async (slug) => {
  const brand = await brandRepository.findBySlug(slug);
  if (!brand) throw ApiError.notFound('Brand not found.');
  return brand;
};

const listBrands = (filter = {}, options = {}) => brandRepository.list(filter, options);

const updateBrand = async (id, updates) => {
  const brand = await brandRepository.updateById(id, updates);
  if (!brand) throw ApiError.notFound('Brand not found.');
  return brand;
};

const deleteBrand = async (id) => {
  const deleted = await brandRepository.deleteById(id);
  if (!deleted) throw ApiError.notFound('Brand not found.');
  return deleted;
};

module.exports = { generateUniqueSlug, createBrand, getBrandById, getBrandBySlug, listBrands, updateBrand, deleteBrand };
