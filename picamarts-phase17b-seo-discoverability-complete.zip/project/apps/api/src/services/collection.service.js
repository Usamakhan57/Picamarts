'use strict';

const ApiError = require('../utils/ApiError');
const collectionRepository = require('../repositories/collection.repository');
const { slugify, withUniqueSuffix } = require('../utils/slugify');

const generateUniqueSlug = async (name) => {
  const base = slugify(name);
  const exists = await collectionRepository.existsBySlug(base);
  return exists ? withUniqueSuffix(base) : base;
};

const createCollection = async (data) => {
  const slug = data.slug ? slugify(data.slug) : await generateUniqueSlug(data.name);
  return collectionRepository.create({ ...data, slug });
};

const getCollectionById = async (id) => {
  const collection = await collectionRepository.findById(id);
  if (!collection) throw ApiError.notFound('Collection not found.');
  return collection;
};

const getCollectionBySlug = async (slug) => {
  const collection = await collectionRepository.findBySlug(slug);
  if (!collection) throw ApiError.notFound('Collection not found.');
  return collection;
};

const listCollections = (filter = {}, options = {}) => collectionRepository.list(filter, options);

const updateCollection = async (id, updates) => {
  const collection = await collectionRepository.updateById(id, updates);
  if (!collection) throw ApiError.notFound('Collection not found.');
  return collection;
};

const deleteCollection = async (id) => {
  const deleted = await collectionRepository.deleteById(id);
  if (!deleted) throw ApiError.notFound('Collection not found.');
  return deleted;
};

module.exports = {
  generateUniqueSlug,
  createCollection,
  getCollectionById,
  getCollectionBySlug,
  listCollections,
  updateCollection,
  deleteCollection,
};
