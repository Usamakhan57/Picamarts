'use strict';

const ApiError = require('../utils/ApiError');
const productService = require('./product.service');
const productRepository = require('../repositories/product.repository');
const recommendationRepository = require('../repositories/recommendation.repository');
const { PRODUCT_STATUSES } = require('../constants/productEnums');

/**
 * Phase 17A.2, Part 1 — Recommendation Engine. Reuses
 * product.service.js#listPublicProducts for every "fetch published
 * products, enriched, by filter" step — no new product-fetching path
 * is introduced. Co-occurrence counting (Frequently Bought Together,
 * Customers Also Viewed) lives in recommendation.repository.js since
 * it's a raw aggregation over Order/RecentlyViewed, not a Product
 * query.
 */

const DEFAULT_LIMIT = 8;

/** Fetches published products by id, in no particular guaranteed order (Mongo doesn't preserve $in order) — callers that need ranked order re-sort by the id list themselves (see below). */
const fetchPublishedByIds = async (ids, limit) => {
  if (!ids.length) return [];
  const { items } = await productService.listPublicProducts({ _id: { $in: ids } }, { limit: limit || ids.length });
  return items;
};

/** Re-orders a fetched product list to match a ranked id list (co-occurrence count order, category-priority order, etc.) — Mongo's own $in doesn't preserve input order. */
const reorderByIds = (products, orderedIds) => {
  const byId = new Map(products.map((p) => [String(p.id), p]));
  return orderedIds.map((id) => byId.get(String(id))).filter(Boolean);
};

// --------------------------------------------------------------------
// Related Products
// --------------------------------------------------------------------

/** Same category OR overlapping tags, excluding the product itself. Ranked by rating then sales — a simple "people also browse this kind of thing" signal, no purchase data required. */
const getRelatedProducts = async (productId, limit = DEFAULT_LIMIT) => {
  const product = await productRepository.findById(productId);
  if (!product || product.status === PRODUCT_STATUSES.DELETED) {
    throw ApiError.notFound('Product not found.');
  }

  const orClauses = [{ category: product.category }];
  if (product.tags?.length) orClauses.push({ tags: { $in: product.tags } });

  const { items } = await productService.listPublicProducts(
    { _id: { $ne: product._id }, $or: orClauses },
    { limit, sort: { ratingAverage: -1, salesCount: -1 } }
  );
  return items;
};

// --------------------------------------------------------------------
// Frequently Bought Together
// --------------------------------------------------------------------

const getFrequentlyBoughtTogether = async (productId, limit = 6) => {
  const rows = await recommendationRepository.getFrequentlyBoughtTogetherIds(productId, limit);
  const ids = rows.map((r) => r._id);
  const products = await fetchPublishedByIds(ids, limit);
  return reorderByIds(products, ids);
};

// --------------------------------------------------------------------
// Customers Also Viewed
// --------------------------------------------------------------------

const getAlsoViewed = async (productId, limit = 6) => {
  const rows = await recommendationRepository.getAlsoViewedIds(productId, limit);
  const ids = rows.map((r) => r._id);
  const products = await fetchPublishedByIds(ids, limit);
  return reorderByIds(products, ids);
};

// --------------------------------------------------------------------
// Trending Products — thin pass-through to the existing Phase 5 feed
// (product.service.js#listTrendingProducts) so callers of the
// recommendation surface don't need to know it isn't a new function.
// --------------------------------------------------------------------

const getTrending = async (limit = 12) => {
  const { items } = await productService.listTrendingProducts({ limit });
  return items;
};

// --------------------------------------------------------------------
// Personalized Recommendations
// --------------------------------------------------------------------

/**
 * Combines three signals for an authenticated buyer, in priority order
 * (purchase history > wishlist contents > recently-viewed), dedupes
 * the category list, then returns published products from those
 * categories — excluding anything the buyer has already purchased —
 * ranked by rating then sales. A buyer with no signal at all yet (no
 * orders, empty wishlist, no browsing history) falls back to Trending
 * so the endpoint never returns an empty result for a brand-new buyer.
 */
const getPersonalized = async (buyerId, limit = 12) => {
  const [purchasedCategoryIds, wishlistCategoryIds, viewedCategoryIds, purchasedProductIds] = await Promise.all([
    recommendationRepository.getPurchasedCategoryIds(buyerId),
    recommendationRepository.getWishlistCategoryIds(buyerId),
    recommendationRepository.getRecentlyViewedCategoryIds(buyerId),
    recommendationRepository.getPurchasedProductIds(buyerId),
  ]);

  const seen = new Set();
  const categoryIds = [];
  [...purchasedCategoryIds, ...wishlistCategoryIds, ...viewedCategoryIds].forEach((id) => {
    const key = id.toString();
    if (!seen.has(key)) {
      seen.add(key);
      categoryIds.push(id);
    }
  });

  if (!categoryIds.length) {
    return getTrending(limit);
  }

  const { items } = await productService.listPublicProducts(
    { category: { $in: categoryIds }, _id: { $nin: purchasedProductIds } },
    { limit, sort: { ratingAverage: -1, salesCount: -1 } }
  );

  return items;
};

module.exports = {
  getRelatedProducts,
  getFrequentlyBoughtTogether,
  getAlsoViewed,
  getTrending,
  getPersonalized,
};
