'use strict';

const ApiError = require('../utils/ApiError');
const searchHistoryRepository = require('../repositories/searchHistory.repository');
const { MAX_SEARCH_HISTORY_ITEMS } = require('../models/SearchHistory');

/**
 * Phase 17A, Part 1 — Search History / Recent Searches. Tracks the
 * authenticated buyer's last MAX_SEARCH_HISTORY_ITEMS distinct search
 * terms, newest first, case-insensitively deduplicated (searching
 * "Laptop" then "laptop" moves the one entry to the front rather than
 * storing both). Recording is called fire-and-forget from
 * search.controller.js so a logging failure never breaks a search.
 */

const toResponse = (doc) => ({
  itemCount: doc?.items?.length || 0,
  items: (doc?.items || []).map((item) => ({ id: item._id.toString(), query: item.query, searchedAt: item.searchedAt })),
});

const getHistory = async (buyerId) => toResponse(await searchHistoryRepository.findByBuyer(buyerId));

const getOrCreateRawDoc = async (buyerId) =>
  (await searchHistoryRepository.findByBuyer(buyerId)) || searchHistoryRepository.createForBuyer(buyerId);

/** No-ops on a blank/whitespace-only query rather than storing noise. */
const recordSearch = async (buyerId, rawQuery) => {
  const query = (rawQuery || '').trim();
  if (!query) return;

  const doc = await getOrCreateRawDoc(buyerId);

  doc.items = doc.items.filter((item) => item.query.toLowerCase() !== query.toLowerCase());
  doc.items.unshift({ query, searchedAt: new Date() });
  doc.items = doc.items.slice(0, MAX_SEARCH_HISTORY_ITEMS);

  await doc.save();
};

const removeEntry = async (buyerId, entryId) => {
  const doc = await searchHistoryRepository.findByBuyer(buyerId);
  const item = doc?.items.id(entryId);
  if (!item) {
    throw ApiError.notFound('Search history entry not found.');
  }

  item.deleteOne();
  await doc.save();
  return getHistory(buyerId);
};

/** A buyer with no history yet is already "empty" — no-op success, not a 404. */
const clear = async (buyerId) => {
  const doc = await searchHistoryRepository.findByBuyer(buyerId);
  if (!doc) return toResponse(null);

  doc.items = [];
  await doc.save();
  return toResponse(doc);
};

module.exports = { getHistory, recordSearch, removeEntry, clear };
