'use strict';

const ApiError = require('../utils/ApiError');
const newsletterRepository = require('../repositories/newsletter.repository');
const { generateToken, hashToken } = require('../utils/cryptoToken');
const { NEWSLETTER_STATUSES } = require('../constants/cmsEnums');

/**
 * Phase 10.3 — Newsletter Service (Part 5).
 *
 * Duplicate handling (Part 9's "Duplicate Newsletter Emails"
 * validation): subscribing an email that is CURRENTLY subscribed is
 * rejected with 409 — an explicit duplicate. Subscribing an email that
 * previously unsubscribed is treated as re-opting in, not a duplicate,
 * since it's the same person choosing to receive mail again.
 */

const subscribe = async (email) => {
  const existing = await newsletterRepository.findByEmail(email);
  const { rawToken, hashedToken } = generateToken();

  if (!existing) {
    const subscriber = await newsletterRepository.create({
      email,
      status: NEWSLETTER_STATUSES.SUBSCRIBED,
      subscribedAt: new Date(),
      unsubscribeTokenHash: hashedToken,
    });
    return { subscriber, unsubscribeToken: rawToken };
  }

  if (existing.status === NEWSLETTER_STATUSES.SUBSCRIBED) {
    throw ApiError.conflict('This email is already subscribed.');
  }

  // Previously unsubscribed — re-opting in, not a duplicate.
  existing.status = NEWSLETTER_STATUSES.SUBSCRIBED;
  existing.subscribedAt = new Date();
  existing.unsubscribedAt = null;
  existing.unsubscribeTokenHash = hashedToken;
  await newsletterRepository.save(existing);

  return { subscriber: existing, unsubscribeToken: rawToken };
};

/** Unsubscribing an already-unsubscribed address is a silent no-op success — never an error for re-clicking an old link. */
const unsubscribeByEmail = async (email) => {
  const existing = await newsletterRepository.findByEmail(email);
  if (!existing) {
    throw ApiError.notFound('No subscription found for this email.');
  }

  if (existing.status === NEWSLETTER_STATUSES.UNSUBSCRIBED) {
    return existing;
  }

  existing.status = NEWSLETTER_STATUSES.UNSUBSCRIBED;
  existing.unsubscribedAt = new Date();
  await newsletterRepository.save(existing);
  return existing;
};

/** One-click unsubscribe via the token emailed at subscribe time — never requires login. */
const unsubscribeByToken = async (rawToken) => {
  const subscriber = await newsletterRepository.findByUnsubscribeTokenHash(hashToken(rawToken));
  if (!subscriber) {
    throw ApiError.badRequest('This unsubscribe link is invalid or has already been used.');
  }

  if (subscriber.status !== NEWSLETTER_STATUSES.UNSUBSCRIBED) {
    subscriber.status = NEWSLETTER_STATUSES.UNSUBSCRIBED;
    subscriber.unsubscribedAt = new Date();
    await newsletterRepository.save(subscriber);
  }

  return subscriber;
};

const listSubscribers = (filter = {}, options = {}) => newsletterRepository.list(filter, options);

/** Returns every matching subscriber, unpaginated — the controller shapes this into a CSV download. */
const exportSubscribers = (filter = {}) => newsletterRepository.findAll(filter);

module.exports = { subscribe, unsubscribeByEmail, unsubscribeByToken, listSubscribers, exportSubscribers };
