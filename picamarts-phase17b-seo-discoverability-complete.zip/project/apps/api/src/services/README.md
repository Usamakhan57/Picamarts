# services/

Business logic lives here — validation beyond schema shape, orchestration
across multiple repositories, transactions, and side effects like sending
an email or emitting a socket event.

Services call `repositories/` for data access; they never import a
Mongoose model directly. `auth.service.js` (Phase 2) was the first one.

Phase 3 adds `category.service.js`, `collection.service.js`,
`brand.service.js`, `tag.service.js`, and `license.service.js` — thin
layers handling slug generation and basic relational integrity (e.g. a
category's parent must exist, a category with children can't be
deleted). `product.service.js` is a scaffold only (slug helper), by
design: Phase 3 limits Product to its schema, with full catalog
business logic (publish workflow, stock rules, ownership checks, ...)
deferred to a later phase.

Phase 5 adds `seller.service.js` — seller application/profile
management, verification document resubmission, dashboard stats (via
a read-only `Product` count query), and the admin approval workflow
(approve/reject/suspend/reinstate), each of which emails the seller
using the existing `emails/mailer.js` + template pattern.
