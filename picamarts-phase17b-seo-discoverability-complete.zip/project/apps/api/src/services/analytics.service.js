'use strict';

const mongoose = require('mongoose');
const ApiError = require('../utils/ApiError');
const analyticsRepository = require('../repositories/analytics.repository');
const { ROLES } = require('../constants/roles');
const { REVENUE_GROUP_BY, PRODUCT_ANALYTICS_TYPES, EXPORTABLE_REPORTS, ADMIN_ONLY_REPORTS } = require('../constants/analyticsEnums');
const { dateRangeMatch } = require('../utils/dateBuckets');
const { buildCsv, buildXlsxBuffer, buildPdfBuffer } = require('../utils/reportExport');

/**
 * Phase 11 — Analytics & Admin Reports (Part 13's authorization rules
 * live here, not in the route layer, the same way order.service.js's
 * assertOrderVisible/role checks sit above a route that only asserts
 * "authenticated + admin-or-seller"):
 *
 *   - admin  — full, unscoped access to every report; may optionally
 *     narrow to one seller via `filters.sellerId` for drill-down.
 *   - seller — every report is force-scoped to their OWN store; any
 *     `sellerId` they pass is ignored (never trusted from the client).
 *   - buyer  — routes never grant this role access in the first place
 *     (see analytics.routes.js authorize(...) calls); nothing here
 *     needs to re-check it.
 */

const toObjectId = (id) => (id ? new mongoose.Types.ObjectId(id) : id);

// --------------------------------------------------------------------
// Scope builders (Part 11 filters + Part 13 authorization)
// --------------------------------------------------------------------

/** Effective seller id to scope to — the acting seller's own id always wins over any client-supplied `sellerId`. */
const effectiveSellerId = (actingUser, filters) => {
  if (actingUser.role === ROLES.SELLER) return actingUser.id;
  return filters.sellerId || null; // admin drill-down, optional
};

/** Match fragment for Order-level aggregates (sales, order counts/stats, revenue trend). */
const buildOrderMatch = (actingUser, filters) => {
  const sellerId = effectiveSellerId(actingUser, filters);
  const match = { ...dateRangeMatch(filters, 'createdAt') };
  if (sellerId) match.sellers = toObjectId(sellerId);
  if (filters.orderStatus) match.status = filters.orderStatus;
  return match;
};

/** Match fragment for the item-level revenue breakdowns (category/seller/product) — same scoping, expressed via `items.seller`. */
const buildItemMatch = (actingUser, filters) => {
  const sellerId = effectiveSellerId(actingUser, filters);
  const match = { ...dateRangeMatch(filters, 'createdAt') };
  if (sellerId) match['items.seller'] = toObjectId(sellerId);
  return match;
};

/** Match fragment for Product-level aggregates (product analytics, product counts). */
const buildProductMatch = (actingUser, filters) => {
  const sellerId = effectiveSellerId(actingUser, filters);
  const match = {};
  if (sellerId) match.seller = toObjectId(sellerId);
  if (filters.categoryId) match.category = toObjectId(filters.categoryId);
  return match;
};

/** Match fragment for Payment-level aggregates (admin only — Payment has no seller field of its own). */
const buildPaymentMatch = (filters) => {
  const match = { ...dateRangeMatch(filters, 'createdAt') };
  if (filters.paymentStatus) match.status = filters.paymentStatus;
  return match;
};

/** Match fragment for Review-level aggregates. */
const buildReviewMatch = (filters) => ({ ...dateRangeMatch(filters, 'createdAt') });

/** Throws 403 for a report that is platform-wide/admin-only when the caller isn't an admin. Defense in depth alongside the route-level `authorize(...)` guard. */
const assertAdminOnly = (actingUser, reportName) => {
  if (actingUser.role !== ROLES.ADMIN) {
    throw ApiError.forbidden(`${reportName} analytics are available to admins only.`);
  }
};

// --------------------------------------------------------------------
// Part 1 — Admin Dashboard
// --------------------------------------------------------------------

const getDashboard = async (actingUser, filters = {}) => {
  const orderMatch = buildOrderMatch(actingUser, filters);
  const productMatch = buildProductMatch(actingUser, filters);
  const isAdmin = actingUser.role === ROLES.ADMIN;
  const sellerId = effectiveSellerId(actingUser, filters);

  const [revenue, orders, products] = await Promise.all([
    analyticsRepository.getRevenueSummary(orderMatch),
    analyticsRepository.getOrderCounts(orderMatch),
    analyticsRepository.getProductCounts(productMatch),
  ]);

  const response = { revenue, orders, products };

  // Customers/sellers are platform-wide concepts — only meaningful
  // (and only permitted) on the unscoped admin dashboard.
  if (isAdmin && !sellerId) {
    const [customers, sellers] = await Promise.all([
      analyticsRepository.getCustomerCounts(),
      analyticsRepository.getSellerCounts(),
    ]);
    response.customers = customers;
    response.sellers = sellers;
  }

  return response;
};

// --------------------------------------------------------------------
// Part 2 — Sales Analytics
// --------------------------------------------------------------------

const getSalesAnalytics = async (actingUser, filters = {}) => {
  const period = filters.period || 'monthly';
  const orderMatch = buildOrderMatch(actingUser, filters);
  const series = await analyticsRepository.getSalesSeries(orderMatch, period);
  return { period, series };
};

// --------------------------------------------------------------------
// Part 3 — Order Analytics
// --------------------------------------------------------------------

const getOrderAnalytics = async (actingUser, filters = {}) => {
  const period = filters.period || 'monthly';
  const orderMatch = buildOrderMatch(actingUser, filters);

  const [byStatus, byDate, stats] = await Promise.all([
    analyticsRepository.getOrdersByStatus(orderMatch),
    analyticsRepository.getOrdersByDate(orderMatch, period),
    analyticsRepository.getOrderStats(orderMatch),
  ]);

  return { byStatus, byDate, ...stats };
};

// --------------------------------------------------------------------
// Part 4 — Revenue Analytics
// --------------------------------------------------------------------

const getRevenueAnalytics = async (actingUser, filters = {}) => {
  const groupBy = filters.groupBy || REVENUE_GROUP_BY.TREND;
  const period = filters.period || 'monthly';

  switch (groupBy) {
    case REVENUE_GROUP_BY.CATEGORY:
      return { groupBy, breakdown: await analyticsRepository.getRevenueByCategory(buildItemMatch(actingUser, filters)) };
    case REVENUE_GROUP_BY.SELLER: {
      assertAdminOnly(actingUser, 'Revenue-by-seller');
      return { groupBy, breakdown: await analyticsRepository.getRevenueBySeller(buildItemMatch(actingUser, filters)) };
    }
    case REVENUE_GROUP_BY.PRODUCT:
      return { groupBy, breakdown: await analyticsRepository.getRevenueByProduct(buildItemMatch(actingUser, filters)) };
    case REVENUE_GROUP_BY.PAYMENT_METHOD: {
      assertAdminOnly(actingUser, 'Revenue-by-payment-method');
      return { groupBy, breakdown: await analyticsRepository.getRevenueByPaymentMethod(buildPaymentMatch(filters)) };
    }
    case REVENUE_GROUP_BY.TREND:
    default:
      return { groupBy: REVENUE_GROUP_BY.TREND, period, series: await analyticsRepository.getRevenueTrend(buildOrderMatch(actingUser, filters), period) };
  }
};

// --------------------------------------------------------------------
// Part 5 — Product Analytics
// --------------------------------------------------------------------

const getProductAnalytics = async (actingUser, filters = {}) => {
  const type = filters.type || PRODUCT_ANALYTICS_TYPES.BEST_SELLING;
  const productMatch = buildProductMatch(actingUser, filters);
  const limit = filters.limit;

  const handlers = {
    [PRODUCT_ANALYTICS_TYPES.BEST_SELLING]: analyticsRepository.getBestSellingProducts,
    [PRODUCT_ANALYTICS_TYPES.MOST_VIEWED]: analyticsRepository.getMostViewedProducts,
    [PRODUCT_ANALYTICS_TYPES.HIGHEST_RATED]: analyticsRepository.getHighestRatedProducts,
    [PRODUCT_ANALYTICS_TYPES.LOW_STOCK]: analyticsRepository.getLowStockProducts,
    [PRODUCT_ANALYTICS_TYPES.OUT_OF_STOCK]: analyticsRepository.getOutOfStockProducts,
    // Phase 17A.2 — most-wishlisted, scoped the same way as every other type here.
    [PRODUCT_ANALYTICS_TYPES.MOST_WISHLISTED]: analyticsRepository.getMostWishlistedProducts,
  };

  const items = await handlers[type](productMatch, limit);
  return { type, items };
};

// --------------------------------------------------------------------
// Part 6 — Seller Analytics (admin only)
// --------------------------------------------------------------------

const getSellerAnalytics = async (actingUser, filters = {}) => {
  assertAdminOnly(actingUser, 'Seller');

  const [performance, growth] = await Promise.all([
    analyticsRepository.getSellerPerformance(filters.sellerId, filters.limit),
    analyticsRepository.getSellerGrowth(filters.period || 'monthly'),
  ]);

  return { sellers: performance, growth };
};

// --------------------------------------------------------------------
// Part 7 — Customer Analytics (admin only)
// --------------------------------------------------------------------

const getCustomerAnalytics = async (actingUser, filters = {}) => {
  assertAdminOnly(actingUser, 'Customer');

  const [newCustomers, returning, topBuyers] = await Promise.all([
    analyticsRepository.getNewCustomersSeries(filters.period || 'monthly'),
    analyticsRepository.getReturningCustomerStats(),
    analyticsRepository.getTopBuyers(filters.limit || 20),
  ]);

  const totalConsidered = returning.returning + returning.oneTime;
  const purchaseFrequency = totalConsidered > 0 ? Math.round((topBuyers.reduce((sum, b) => sum + b.orderCount, 0) / topBuyers.length || 0) * 100) / 100 : 0;

  return {
    newCustomers,
    returningCustomers: returning.returning,
    oneTimeCustomers: returning.oneTime,
    topBuyers,
    averagePurchaseFrequency: purchaseFrequency,
  };
};

// --------------------------------------------------------------------
// Part 8 — Payment Analytics (admin only)
// --------------------------------------------------------------------

const getPaymentAnalytics = async (actingUser, filters = {}) => {
  assertAdminOnly(actingUser, 'Payment');
  return analyticsRepository.getPaymentStats(buildPaymentMatch(filters));
};

// --------------------------------------------------------------------
// Part 9 — Review Analytics
// --------------------------------------------------------------------

const getReviewAnalytics = async (actingUser, filters = {}) => {
  const sellerId = effectiveSellerId(actingUser, filters);
  return analyticsRepository.getReviewStats(buildReviewMatch(filters), sellerId);
};

// --------------------------------------------------------------------
// Part 10 — Report Export (Part 12: reuses the exact same report
// builders as the JSON endpoints above, just flattened to rows)
// --------------------------------------------------------------------

/** Flattens each report type's response into `{ title, columns, rows }` for the CSV/XLSX/PDF renderers. */
const buildExportTable = async (actingUser, report, filters) => {
  switch (report) {
    case EXPORTABLE_REPORTS.SALES: {
      const { series } = await getSalesAnalytics(actingUser, filters);
      return {
        title: 'Sales Report',
        columns: [
          { key: 'label', label: 'Period' },
          { key: 'revenue', label: 'Revenue' },
          { key: 'orders', label: 'Orders' },
        ],
        rows: series,
      };
    }
    case EXPORTABLE_REPORTS.ORDERS: {
      const { byDate } = await getOrderAnalytics(actingUser, filters);
      return {
        title: 'Orders Report',
        columns: [
          { key: 'label', label: 'Period' },
          { key: 'count', label: 'Order Count' },
        ],
        rows: byDate,
      };
    }
    case EXPORTABLE_REPORTS.REVENUE: {
      const result = await getRevenueAnalytics(actingUser, filters);
      const rows = result.series || result.breakdown || [];
      const columns = result.series
        ? [
            { key: 'label', label: 'Period' },
            { key: 'revenue', label: 'Revenue' },
            { key: 'orders', label: 'Orders' },
          ]
        : Object.keys(rows[0] || {}).map((key) => ({ key, label: key }));
      return { title: 'Revenue Report', columns, rows };
    }
    case EXPORTABLE_REPORTS.PRODUCTS: {
      const { items } = await getProductAnalytics(actingUser, filters);
      const columns = Object.keys(items[0] || { productId: '', title: '' }).map((key) => ({ key, label: key }));
      return { title: 'Product Report', columns, rows: items };
    }
    case EXPORTABLE_REPORTS.SELLERS: {
      const { sellers } = await getSellerAnalytics(actingUser, filters);
      return {
        title: 'Seller Report',
        columns: [
          { key: 'storeName', label: 'Store' },
          { key: 'status', label: 'Status' },
          { key: 'revenue', label: 'Revenue' },
          { key: 'orderCount', label: 'Orders' },
          { key: 'unitsSold', label: 'Units Sold' },
          { key: 'productCount', label: 'Products' },
          { key: 'averageRating', label: 'Avg Rating' },
        ],
        rows: sellers,
      };
    }
    case EXPORTABLE_REPORTS.CUSTOMERS: {
      const { topBuyers } = await getCustomerAnalytics(actingUser, filters);
      return {
        title: 'Customer Report',
        columns: [
          { key: 'name', label: 'Name' },
          { key: 'email', label: 'Email' },
          { key: 'lifetimeValue', label: 'Lifetime Value' },
          { key: 'orderCount', label: 'Orders' },
          { key: 'firstOrderAt', label: 'First Order' },
          { key: 'lastOrderAt', label: 'Last Order' },
        ],
        rows: topBuyers,
      };
    }
    case EXPORTABLE_REPORTS.PAYMENTS: {
      const stats = await getPaymentAnalytics(actingUser, filters);
      return {
        title: 'Payment Report',
        columns: Object.keys(stats).map((key) => ({ key, label: key })),
        rows: [stats],
      };
    }
    case EXPORTABLE_REPORTS.REVIEWS: {
      const { mostReviewedProducts } = await getReviewAnalytics(actingUser, filters);
      return {
        title: 'Review Report',
        columns: [
          { key: 'title', label: 'Product' },
          { key: 'reviewCount', label: 'Reviews' },
          { key: 'averageRating', label: 'Avg Rating' },
        ],
        rows: mostReviewedProducts,
      };
    }
    default:
      throw ApiError.badRequest(`Unknown report type: ${report}`);
  }
};

/**
 * @returns {Promise<{ filename: string, buffer: Buffer|string }>}
 */
const exportReport = async (actingUser, { report, format, ...filters }) => {
  if (ADMIN_ONLY_REPORTS.includes(report)) {
    assertAdminOnly(actingUser, report[0].toUpperCase() + report.slice(1));
  }

  const { title, columns, rows } = await buildExportTable(actingUser, report, filters);
  const filenameBase = `${report}-report-${Date.now()}`;

  if (format === 'xlsx') {
    return { filename: `${filenameBase}.xlsx`, buffer: await buildXlsxBuffer(title, columns, rows) };
  }
  if (format === 'pdf') {
    return { filename: `${filenameBase}.pdf`, buffer: await buildPdfBuffer(title, columns, rows) };
  }
  return { filename: `${filenameBase}.csv`, buffer: buildCsv(columns, rows) };
};

// --------------------------------------------------------------------
// Phase 17A.2 — Marketplace Growth: Trending Categories/Brands, Search
// Analytics. Same admin-or-seller (auto-scoped) access as Part 5
// Product Analytics for the first two; Search Analytics is platform-
// wide only (a search term has no seller to scope to), so it follows
// Part 6/7/8's admin-only pattern instead.
// --------------------------------------------------------------------

const getCategoryAnalytics = async (actingUser, filters = {}) => {
  const productMatch = buildProductMatch(actingUser, filters);
  const windowDays = filters.windowDays || 30;
  return { windowDays, categories: await analyticsRepository.getTrendingCategories(productMatch, windowDays, filters.limit || 10) };
};

const getBrandAnalytics = async (actingUser, filters = {}) => {
  const productMatch = buildProductMatch(actingUser, filters);
  const windowDays = filters.windowDays || 30;
  return { windowDays, brands: await analyticsRepository.getTrendingBrands(productMatch, windowDays, filters.limit || 10) };
};

const getSearchAnalytics = async (actingUser, filters = {}) => {
  assertAdminOnly(actingUser, 'Search');
  return { terms: await analyticsRepository.getSearchAnalytics(filters.limit || 20) };
};

module.exports = {
  getDashboard,
  getSalesAnalytics,
  getOrderAnalytics,
  getRevenueAnalytics,
  getProductAnalytics,
  getSellerAnalytics,
  getCustomerAnalytics,
  getPaymentAnalytics,
  getReviewAnalytics,
  getCategoryAnalytics,
  getBrandAnalytics,
  getSearchAnalytics,
  exportReport,
  // exported for unit testing the scope builders in isolation
  buildOrderMatch,
  buildItemMatch,
  buildProductMatch,
  buildPaymentMatch,
  buildReviewMatch,
  effectiveSellerId,
};
