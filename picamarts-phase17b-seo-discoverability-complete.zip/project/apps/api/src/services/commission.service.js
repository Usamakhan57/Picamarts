'use strict';

const ApiError = require('../utils/ApiError');
const Product = require('../models/Product');
const platformSettingsRepository = require('../repositories/platformSettings.repository');
const categoryRepository = require('../repositories/category.repository');
const sellerRepository = require('../repositories/seller.repository');
const { COMMISSION_SOURCES } = require('../constants/walletEnums');

/**
 * Phase 16B — Marketplace Wallet & Commission Engine.
 *
 * Part 3 (resolution chain) + Part 4 (per-order calculation, pure —
 * persistence is wallet.service.js's job, this only computes numbers)
 * + Part 5 (admin settings CRUD). Reads `Product` directly for each
 * order item's category — the same additive, narrowly-scoped
 * cross-module read convention `analytics.service.js`/
 * `shipment.repository.js` already established; `Product`'s own
 * files are never touched.
 *
 * Resolution order for a single item: seller's own `commissionRate`
 * override (Seller.js) → that item's product category's own
 * `commissionRate` (Category.js) → `PlatformSettings.defaultCommissionRate`.
 * A `null` at any level means "no override here, keep going down".
 */

const round2 = (n) => Math.round(n * 100) / 100;

// --------------------------------------------------------------------
// Part 3 — resolution chain
// --------------------------------------------------------------------

/** Resolves the single effective rate + its source for one item, given the seller's own override and that item's category. */
const resolveCommissionRate = (sellerOverride, categoryRate, globalRate) => {
  if (typeof sellerOverride === 'number' && sellerOverride !== null) {
    return { rate: sellerOverride, source: COMMISSION_SOURCES.SELLER_OVERRIDE };
  }
  if (typeof categoryRate === 'number' && categoryRate !== null) {
    return { rate: categoryRate, source: COMMISSION_SOURCES.CATEGORY };
  }
  return { rate: globalRate, source: COMMISSION_SOURCES.GLOBAL };
};

// --------------------------------------------------------------------
// Part 4 — per-order, per-seller calculation (pure computation)
// --------------------------------------------------------------------

/**
 * Computes one CommissionRecord-shaped result per distinct seller on
 * the order. `order.items` is the real, already-locked line items
 * (lineTotal is what the buyer actually paid per line) — nothing here
 * re-derives pricing, it only applies a commission rate on top of
 * already-settled amounts.
 *
 * @returns {Promise<Array<{ seller, grossAmount, commissionRate, commissionSource, commissionAmount, netSellerEarnings, platformEarnings }>>}
 */
const calculateForOrder = async (order) => {
  const settings = await platformSettingsRepository.getOrCreate();
  const globalRate = settings.defaultCommissionRate;

  const productIds = [...new Set(order.items.map((item) => item.product.toString()))];
  const products = await Product.find({ _id: { $in: productIds } }, 'category').lean().exec();
  const categoryByProduct = new Map(products.map((p) => [p._id.toString(), p.category ? p.category.toString() : null]));

  const categoryIds = [...new Set([...categoryByProduct.values()].filter(Boolean))];
  const categories = await Promise.all(categoryIds.map((id) => categoryRepository.findById(id)));
  const categoryRateById = new Map(categoryIds.map((id, i) => [id, categories[i]?.commissionRate ?? null]));

  const sellerIds = [...new Set(order.items.map((item) => item.seller.toString()))];
  const sellerOverrideById = new Map();
  await Promise.all(
    sellerIds.map(async (sellerId) => {
      const seller = await sellerRepository.findByUserId(sellerId);
      sellerOverrideById.set(sellerId, seller?.commissionRate ?? null);
    })
  );

  const bySeller = new Map();

  for (const item of order.items) {
    const sellerId = item.seller.toString();
    const categoryId = categoryByProduct.get(item.product.toString());
    const categoryRate = categoryId ? categoryRateById.get(categoryId) : null;
    const { rate, source } = resolveCommissionRate(sellerOverrideById.get(sellerId), categoryRate, globalRate);

    const itemCommission = round2((item.lineTotal * rate) / 100);

    if (!bySeller.has(sellerId)) {
      bySeller.set(sellerId, { seller: sellerId, grossAmount: 0, commissionAmount: 0, sources: new Set() });
    }
    const entry = bySeller.get(sellerId);
    entry.grossAmount = round2(entry.grossAmount + item.lineTotal);
    entry.commissionAmount = round2(entry.commissionAmount + itemCommission);
    entry.sources.add(source);
  }

  return [...bySeller.values()].map((entry) => {
    const netSellerEarnings = round2(entry.grossAmount - entry.commissionAmount);
    const effectiveRate = entry.grossAmount > 0 ? round2((entry.commissionAmount / entry.grossAmount) * 100) : 0;
    return {
      seller: entry.seller,
      grossAmount: entry.grossAmount,
      commissionRate: effectiveRate,
      commissionSource: entry.sources.size > 1 ? COMMISSION_SOURCES.MIXED : [...entry.sources][0],
      commissionAmount: entry.commissionAmount,
      netSellerEarnings,
      platformEarnings: entry.commissionAmount,
    };
  });
};

// --------------------------------------------------------------------
// Part 5 — Admin Commission Settings
// --------------------------------------------------------------------

const getGlobalSettings = async () => {
  const settings = await platformSettingsRepository.getOrCreate();
  return { defaultCommissionRate: settings.defaultCommissionRate, updatedAt: settings.updatedAt };
};

const updateGlobalSettings = async (rate, adminId) => {
  const settings = await platformSettingsRepository.update({ defaultCommissionRate: rate, updatedBy: adminId });
  return { defaultCommissionRate: settings.defaultCommissionRate, updatedAt: settings.updatedAt };
};

const setCategoryCommission = async (categoryId, rate) => {
  const category = await categoryRepository.updateById(categoryId, { commissionRate: rate });
  if (!category) throw ApiError.notFound('Category not found.');
  return { categoryId: category.id, commissionRate: category.commissionRate };
};

const setSellerCommissionOverride = async (sellerId, rate) => {
  const seller = await sellerRepository.updateById(sellerId, { commissionRate: rate });
  if (!seller) throw ApiError.notFound('Seller not found.');
  return { sellerId: seller.id, commissionRate: seller.commissionRate };
};

module.exports = {
  resolveCommissionRate,
  calculateForOrder,
  getGlobalSettings,
  updateGlobalSettings,
  setCategoryCommission,
  setSellerCommissionOverride,
};
