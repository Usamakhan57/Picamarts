'use strict';

const ApiError = require('../utils/ApiError');
const shippingProfileRepository = require('../repositories/shippingProfile.repository');
const { ROLES } = require('../constants/roles');
const { SHIPPING_ZONE_TYPES, SHIPPING_RATE_TYPES } = require('../constants/shippingEnums');

/**
 * Phase 14.2, Part 1/2/3 — Shipping Profiles, Zones, and Rates. A
 * seller-owned configuration assignable to their physical products
 * (see Product.shippingProfile). This file also owns the pure
 * shipping-cost calculation checkout.service.js#estimateShipping
 * calls — kept here rather than in checkout.service.js so the pricing
 * rules live next to the schema that defines them.
 */

const idStr = (value) => (value?.toString ? value.toString() : value);

// --------------------------------------------------------------------
// Response shaping
// --------------------------------------------------------------------

const toRateResponse = (rate) => ({
  id: idStr(rate._id),
  methodName: rate.methodName,
  type: rate.type,
  baseRate: rate.baseRate,
  perUnitRate: rate.perUnitRate,
  freeOverAmount: rate.freeOverAmount,
  estimatedDeliveryDays: rate.estimatedDeliveryDays,
  active: rate.active,
});

const toZoneResponse = (zone) => ({
  id: idStr(zone._id),
  name: zone.name,
  type: zone.type,
  countries: zone.countries,
  states: zone.states,
  regions: zone.regions,
  postalCodes: zone.postalCodes,
  rates: (zone.rates || []).map(toRateResponse),
});

const toProfileResponse = (profile) => ({
  id: idStr(profile._id),
  seller: idStr(profile.seller),
  name: profile.name,
  processingTime: profile.processingTime,
  shippingMethod: profile.shippingMethod,
  shippingOrigin: profile.shippingOrigin,
  weightUnit: profile.weightUnit,
  sizeUnit: profile.sizeUnit,
  freeShipping: profile.freeShipping,
  zones: (profile.zones || []).map(toZoneResponse),
  active: profile.active,
  createdAt: profile.createdAt,
  updatedAt: profile.updatedAt,
});

// --------------------------------------------------------------------
// Ownership
// --------------------------------------------------------------------

const assertOwnership = (profile, actingUser) => {
  if (actingUser.role === ROLES.ADMIN) return;
  if (profile.seller.toString() !== actingUser.id) {
    throw ApiError.forbidden('You do not have permission to manage this shipping profile.');
  }
};

const getOwnedProfile = async (profileId, actingUser) => {
  const profile = await shippingProfileRepository.findById(profileId);
  if (!profile) throw ApiError.notFound('Shipping profile not found.');
  assertOwnership(profile, actingUser);
  return profile;
};

// --------------------------------------------------------------------
// CRUD
// --------------------------------------------------------------------

const createProfile = async (payload, actingUser) => {
  const seller = actingUser.role === ROLES.ADMIN && payload.seller ? payload.seller : actingUser.id;
  const profile = await shippingProfileRepository.create({ ...payload, seller });
  return toProfileResponse(profile);
};

const listMyProfiles = async (actingUser, options) => {
  const { items, meta } = await shippingProfileRepository.listBySeller(actingUser.id, options);
  return { items: items.map(toProfileResponse), meta };
};

/** Admin — every profile, optionally filtered by seller. */
const listAllProfiles = async (filter, options) => {
  const { items, meta } = await shippingProfileRepository.listAll(filter, options);
  return { items: items.map(toProfileResponse), meta };
};

const getProfileById = async (profileId, actingUser) => {
  const profile = await getOwnedProfile(profileId, actingUser);
  return toProfileResponse(profile);
};

const updateProfile = async (profileId, updates, actingUser) => {
  await getOwnedProfile(profileId, actingUser);
  const updated = await shippingProfileRepository.updateById(profileId, updates);
  if (!updated) throw ApiError.notFound('Shipping profile not found.');
  return toProfileResponse(updated);
};

const deleteProfile = async (profileId, actingUser) => {
  await getOwnedProfile(profileId, actingUser);
  await shippingProfileRepository.deleteById(profileId);
};

// --------------------------------------------------------------------
// Part 5 — shipping-cost calculation (called by checkout.service.js)
// --------------------------------------------------------------------

/** A zone "matches" a destination if it's worldwide, or its country/state list includes the destination's. Region/postal-code zones are structurally supported (Part 2) but not matched against here — future-ready, documented in models/ShippingProfile.js. */
const zoneMatchesDestination = (zone, destination = {}) => {
  if (zone.type === SHIPPING_ZONE_TYPES.WORLDWIDE) return true;
  if (zone.type === SHIPPING_ZONE_TYPES.COUNTRY) {
    return destination.country ? zone.countries.some((c) => c.toLowerCase() === destination.country.toLowerCase()) : false;
  }
  if (zone.type === SHIPPING_ZONE_TYPES.STATE) {
    return destination.state ? zone.states.some((s) => s.toLowerCase() === destination.state.toLowerCase()) : false;
  }
  return false; // region / postal_code — not matched in this pass
};

const computeRateCost = (rate, { totalWeight, totalQuantity, orderSubtotal }) => {
  if (rate.freeOverAmount != null && orderSubtotal >= rate.freeOverAmount) return 0;

  switch (rate.type) {
    case SHIPPING_RATE_TYPES.FREE:
      return 0;
    case SHIPPING_RATE_TYPES.WEIGHT_BASED:
      return Math.max(0, rate.baseRate + rate.perUnitRate * totalWeight);
    case SHIPPING_RATE_TYPES.QUANTITY_BASED:
      return Math.max(0, rate.baseRate + rate.perUnitRate * totalQuantity);
    case SHIPPING_RATE_TYPES.ORDER_TOTAL_BASED:
      return Math.max(0, rate.baseRate + rate.perUnitRate * orderSubtotal);
    case SHIPPING_RATE_TYPES.FLAT:
    default:
      return Math.max(0, rate.baseRate);
  }
};

/**
 * Computes every available shipping method for one seller's group of
 * physical line items against a destination. Returns [] if the
 * profile is inactive, has no matching zone, or the matching zone has
 * no active rates — the caller (checkout.service.js) treats an empty
 * list as "no shipping option available for this destination yet".
 */
const calculateMethodsForProfile = (profile, destination, cartTotals) => {
  if (!profile || !profile.active) return [];

  if (profile.freeShipping) {
    return [
      {
        profileId: idStr(profile._id),
        methodName: 'Free Shipping',
        cost: 0,
        estimatedDeliveryDays: profile.processingTime,
      },
    ];
  }

  const matchingZones = (profile.zones || []).filter((zone) => zoneMatchesDestination(zone, destination));
  const methods = [];
  matchingZones.forEach((zone) => {
    (zone.rates || [])
      .filter((rate) => rate.active)
      .forEach((rate) => {
        methods.push({
          profileId: idStr(profile._id),
          zoneId: idStr(zone._id),
          rateId: idStr(rate._id),
          methodName: rate.methodName,
          cost: Math.round(computeRateCost(rate, cartTotals) * 100) / 100,
          estimatedDeliveryDays: rate.estimatedDeliveryDays,
        });
      });
  });
  return methods;
};

module.exports = {
  toProfileResponse,
  createProfile,
  listMyProfiles,
  listAllProfiles,
  getProfileById,
  updateProfile,
  deleteProfile,
  calculateMethodsForProfile,
};
