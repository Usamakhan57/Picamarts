'use strict';

const ApiError = require('../utils/ApiError');
const walletRepository = require('../repositories/wallet.repository');
const commissionRecordRepository = require('../repositories/commissionRecord.repository');
const commissionService = require('../services/commission.service');
const paymentRepository = require('../repositories/payment.repository');
const sellerRepository = require('../repositories/seller.repository');
const { LEDGER_DIRECTIONS, LEDGER_CATEGORIES } = require('../constants/walletEnums');

/**
 * Phase 16B — Marketplace Wallet & Commission Engine.
 *
 * The only place that writes to Wallet/WalletLedgerEntry/CommissionRecord.
 * Reuses `paymentRepository.findOrderById` (Phase 9, unmodified) and
 * `sellerRepository.findByUserId`/`findByIdWithUser` (Phase 5/15C,
 * unmodified) rather than re-querying Order/Seller directly — same
 * "reuse an existing repository export" instruction this delivery was
 * given.
 *
 * Explicitly OUT of scope here (Phase 16C+): payout/transfer execution,
 * withdrawal requests, dispute handling. `totalWithdrawn` always stays
 * 0 — nothing in this file ever changes it.
 */

const round2 = (n) => Math.round(n * 100) / 100;
const idStr = (value) => (value?.toString ? value.toString() : value);

// --------------------------------------------------------------------
// Part 1/2/4 — sale → commission → wallet credit (fires on payment success)
// --------------------------------------------------------------------

/**
 * Credits every seller on a now-paid order with their net earnings,
 * recording a permanent CommissionRecord plus a SALE credit +
 * COMMISSION_DEDUCTION debit ledger pair for each. Idempotent per
 * seller: `CommissionRecord`'s unique (order, seller) index rejects a
 * duplicate insert (e.g. a redelivered Stripe webhook event), which is
 * treated as "already processed" and silently skipped for that seller
 * only — Part 8's "prevent duplicate credits/commissions".
 *
 * Called fire-and-forget from payment.service.js's webhook handler,
 * the exact same way digitalDeliveryService/notificationService
 * already are — see payment.service.js's `payment_intent.succeeded`
 * case.
 */
const recordSaleForOrder = async (payment) => {
  const order = await paymentRepository.findOrderById(payment.order);
  if (!order || !order.items?.length) return;

  const results = await commissionService.calculateForOrder(order);

  for (const result of results) {
    try {
      const record = await commissionRecordRepository.create({
        order: order._id,
        seller: result.seller,
        grossAmount: result.grossAmount,
        commissionRate: result.commissionRate,
        commissionSource: result.commissionSource,
        commissionAmount: result.commissionAmount,
        netSellerEarnings: result.netSellerEarnings,
        platformEarnings: result.platformEarnings,
      });

      await walletRepository.getOrCreateForSeller(result.seller);

      const afterCredit = await walletRepository.applyBalanceDelta(result.seller, { availableDelta: result.grossAmount });
      await walletRepository.createLedgerEntry({
        seller: result.seller,
        wallet: afterCredit._id,
        direction: LEDGER_DIRECTIONS.CREDIT,
        category: LEDGER_CATEGORIES.SALE,
        amount: result.grossAmount,
        balanceAfter: afterCredit.availableBalance,
        order: order._id,
        commissionRecord: record._id,
        note: `Sale — order ${order.orderNumber}`,
      });

      const afterCommission = await walletRepository.applyBalanceDelta(result.seller, {
        availableDelta: -result.commissionAmount,
        totalEarningsDelta: result.netSellerEarnings,
      });
      await walletRepository.createLedgerEntry({
        seller: result.seller,
        wallet: afterCommission._id,
        direction: LEDGER_DIRECTIONS.DEBIT,
        category: LEDGER_CATEGORIES.COMMISSION_DEDUCTION,
        amount: result.commissionAmount,
        balanceAfter: afterCommission.availableBalance,
        order: order._id,
        commissionRecord: record._id,
        note: `Commission (${result.commissionRate}%, ${result.commissionSource}) — order ${order.orderNumber}`,
      });
    } catch (error) {
      // Duplicate-key on the (order, seller) unique index = already
      // processed (a redelivered webhook event) — a silent no-op for
      // this seller. Any other error is swallowed too: this whole
      // function is always invoked fire-and-forget (`.catch(() => {})`
      // at the call site), matching notificationService/
      // digitalDeliveryService's own established convention — a wallet
      // bookkeeping failure must never surface as a failed payment.
    }
  }
};

// --------------------------------------------------------------------
// Refund reversal (fires on an existing, already-firing FULL-refund signal)
// --------------------------------------------------------------------

/**
 * Reverses every seller's net earnings for an order that has just
 * become FULLY refunded — one REFUND_ADJUSTMENT debit per seller,
 * idempotent (skips a seller who already has a REFUND_ADJUSTMENT entry
 * for this order). Deliberately reacts only to a FULL refund (the one
 * unambiguous, already-firing signal in this codebase —
 * `paymentRepository.markOrderRefunded`); partial refunds do not adjust
 * wallets in this phase (Refund Processing itself is out of scope —
 * see the delivery notes for why).
 *
 * Called fire-and-forget from payment.service.js's two existing
 * `markOrderRefunded` call sites (the explicit admin refund endpoint,
 * and the defensive webhook sync path).
 */
const reverseEarningsForOrder = async (orderId) => {
  const records = await commissionRecordRepository.listByOrder(orderId);

  for (const record of records) {
    try {
      const alreadyReversed = await walletRepository.hasEntryForOrder(record.seller, orderId, LEDGER_CATEGORIES.REFUND_ADJUSTMENT);
      if (alreadyReversed) continue;

      const afterDebit = await walletRepository.applyBalanceDelta(record.seller, {
        availableDelta: -record.netSellerEarnings,
        totalEarningsDelta: -record.netSellerEarnings,
      });
      await walletRepository.createLedgerEntry({
        seller: record.seller,
        wallet: afterDebit._id,
        direction: LEDGER_DIRECTIONS.DEBIT,
        category: LEDGER_CATEGORIES.REFUND_ADJUSTMENT,
        amount: record.netSellerEarnings,
        balanceAfter: afterDebit.availableBalance,
        order: orderId,
        commissionRecord: record._id,
        note: 'Order fully refunded — earnings reversed.',
      });
    } catch {
      // Best-effort, matches recordSaleForOrder's own error handling.
    }
  }
};

// --------------------------------------------------------------------
// Phase 16D, Part 5 — Partial-refund wallet reconciliation
// --------------------------------------------------------------------

/**
 * Reverses each affected seller's PROPORTIONAL share of a PARTIAL
 * refund — Phase 16B's `reverseEarningsForOrder` only ever handles a
 * FULL refund (the order's `netSellerEarnings` is reversed outright);
 * this fills that gap for Phase 16D's refund-request workflow.
 *
 * Design decision (flagged): a seller's share of `refundAmount` is
 * computed as `refundAmount * (record.netSellerEarnings / totalGrossAmount)`
 * — i.e. proportional to that seller's share of the ORDER's total
 * gross, at that seller's own already-resolved commission rate. This
 * assumes a partial refund isn't itemized to one specific seller's
 * products only; if it is (a `RefundRequest.items` targeting one
 * seller's line items), refund.service.js instead passes just that
 * seller's own record so the full requested amount reverses against
 * them alone (see refund.service.js#applyWalletReversal).
 *
 * Idempotent per (seller, refundRequest) via WalletLedgerEntry's new
 * `refundRequest` ref field — NOT per order, since an order can have
 * more than one partial refund request over its lifetime.
 */
const reverseEarningsForRefundRequest = async (orderId, refundRequestId, refundAmount, { onlySeller } = {}) => {
  const allRecords = await commissionRecordRepository.listByOrder(orderId);
  const records = onlySeller ? allRecords.filter((r) => idStr(r.seller) === idStr(onlySeller)) : allRecords;
  if (!records.length) return;

  const totalGross = allRecords.reduce((sum, r) => sum + r.grossAmount, 0);
  if (totalGross <= 0) return;

  for (const record of records) {
    try {
      const alreadyReversed = await walletRepository.hasEntryForRef(
        record.seller,
        'refundRequest',
        refundRequestId,
        LEDGER_CATEGORIES.REFUND_ADJUSTMENT
      );
      if (alreadyReversed) continue;

      const share = onlySeller
        ? Math.min(refundAmount, record.netSellerEarnings)
        : round2(refundAmount * (record.netSellerEarnings / totalGross));
      if (share <= 0) continue;

      const afterDebit = await walletRepository.applyBalanceDelta(record.seller, {
        availableDelta: -share,
        totalEarningsDelta: -share,
      });
      await walletRepository.createLedgerEntry({
        seller: record.seller,
        wallet: afterDebit._id,
        direction: LEDGER_DIRECTIONS.DEBIT,
        category: LEDGER_CATEGORIES.REFUND_ADJUSTMENT,
        amount: share,
        balanceAfter: afterDebit.availableBalance,
        order: orderId,
        commissionRecord: record._id,
        refundRequest: refundRequestId,
        note: 'Partial refund — earnings reversed proportionally.',
      });
    } catch {
      // Best-effort, matches reverseEarningsForOrder's own error handling.
    }
  }
};

// --------------------------------------------------------------------
// Phase 16D, Part 5/10 — Dispute & chargeback wallet reconciliation
// --------------------------------------------------------------------

/** Reserves (debits) the seller's net earnings on the disputed order the instant a chargeback/dispute opens — "balance locking IS the ledger", same mechanism as Phase 16C's withdrawal hold. Idempotent per (seller, dispute). */
const holdForDispute = async (dispute) => {
  const record = await commissionRecordRepository.findByOrderAndSeller(dispute.order, dispute.seller);
  const amount = record ? Math.min(dispute.amount, record.netSellerEarnings) : dispute.amount;
  if (amount <= 0) return;

  const already = await walletRepository.hasEntryForRef(dispute.seller, 'dispute', dispute._id, LEDGER_CATEGORIES.DISPUTE_HOLD);
  if (already) return;

  const after = await walletRepository.applyBalanceDelta(dispute.seller, { availableDelta: -amount });
  await walletRepository.createLedgerEntry({
    seller: dispute.seller,
    wallet: after._id,
    direction: LEDGER_DIRECTIONS.DEBIT,
    category: LEDGER_CATEGORIES.DISPUTE_HOLD,
    amount,
    balanceAfter: after.availableBalance,
    order: dispute.order,
    dispute: dispute._id,
    note: `Dispute opened (${dispute.reason}) — earnings held pending outcome.`,
  });
};

/** Releases a dispute hold exactly — fired on a WON or otherwise-non-loss CLOSED outcome. Idempotent per (seller, dispute). */
const releaseDisputeHold = async (dispute) => {
  const alreadyHeld = await walletRepository.hasEntryForRef(dispute.seller, 'dispute', dispute._id, LEDGER_CATEGORIES.DISPUTE_HOLD);
  if (!alreadyHeld) return;
  const alreadyReleased = await walletRepository.hasEntryForRef(dispute.seller, 'dispute', dispute._id, LEDGER_CATEGORIES.DISPUTE_RELEASE);
  if (alreadyReleased) return;

  const record = await commissionRecordRepository.findByOrderAndSeller(dispute.order, dispute.seller);
  const amount = record ? Math.min(dispute.amount, record.netSellerEarnings) : dispute.amount;
  if (amount <= 0) return;

  const after = await walletRepository.applyBalanceDelta(dispute.seller, { availableDelta: amount });
  await walletRepository.createLedgerEntry({
    seller: dispute.seller,
    wallet: after._id,
    direction: LEDGER_DIRECTIONS.CREDIT,
    category: LEDGER_CATEGORIES.DISPUTE_RELEASE,
    amount,
    balanceAfter: after.availableBalance,
    order: dispute.order,
    dispute: dispute._id,
    note: 'Dispute resolved in seller\u2019s favor — hold released.',
  });
};

/** Zero-amount audit marker recorded once a dispute is LOST — the held funds simply stay debited (same "amount: 0, informational" convention as recordClosingBalanceSnapshot/WITHDRAWAL_COMPLETED). Idempotent per (seller, dispute). */
const finalizeDisputeLoss = async (dispute) => {
  const already = await walletRepository.hasEntryForRef(dispute.seller, 'dispute', dispute._id, LEDGER_CATEGORIES.DISPUTE_LOST);
  if (already) return;

  const wallet = await walletRepository.getOrCreateForSeller(dispute.seller);
  await walletRepository.createLedgerEntry({
    seller: dispute.seller,
    wallet: wallet._id,
    direction: LEDGER_DIRECTIONS.DEBIT,
    category: LEDGER_CATEGORIES.DISPUTE_LOST,
    amount: 0,
    balanceAfter: wallet.availableBalance,
    order: dispute.order,
    dispute: dispute._id,
    note: 'Dispute lost — held earnings forfeited.',
  });
};

// --------------------------------------------------------------------
// Part 2 — Manual Admin Adjustments + Closing Balance snapshot
// --------------------------------------------------------------------

const recordManualAdjustment = async (sellerId, { direction, amount, note }, adminId) => {
  if (amount <= 0) throw ApiError.badRequest('Adjustment amount must be greater than 0.');

  await walletRepository.getOrCreateForSeller(sellerId);
  const signedDelta = direction === LEDGER_DIRECTIONS.CREDIT ? amount : -amount;
  const totalEarningsDelta = direction === LEDGER_DIRECTIONS.CREDIT ? amount : -amount;

  const updated = await walletRepository.applyBalanceDelta(sellerId, { availableDelta: signedDelta, totalEarningsDelta });
  const entry = await walletRepository.createLedgerEntry({
    seller: sellerId,
    wallet: updated._id,
    direction,
    category: LEDGER_CATEGORIES.MANUAL_ADJUSTMENT,
    amount,
    balanceAfter: updated.availableBalance,
    note: note || 'Manual admin adjustment.',
    createdBy: adminId,
  });

  return { wallet: toWalletResponse(updated), entry: toLedgerEntryResponse(entry) };
};

/** Snapshots the seller's current available+pending totals as a single CLOSING_BALANCE ledger entry — an on-demand admin action (e.g. month-end reconciliation), not a scheduled job. */
const recordClosingBalanceSnapshot = async (sellerId, adminId) => {
  const summary = await getWalletSummary(sellerId);
  const wallet = await walletRepository.getOrCreateForSeller(sellerId);

  const entry = await walletRepository.createLedgerEntry({
    seller: sellerId,
    wallet: wallet._id,
    direction: LEDGER_DIRECTIONS.CREDIT,
    category: LEDGER_CATEGORIES.CLOSING_BALANCE,
    amount: 0,
    balanceAfter: wallet.availableBalance,
    note: `Closing balance snapshot — available ${summary.availableBalance}, pending (of which) ${summary.pendingBalance}.`,
    createdBy: adminId,
  });

  return toLedgerEntryResponse(entry);
};

// --------------------------------------------------------------------
// Part 1/6 — Wallet Summary (Available / Pending / Total Earnings / Total Withdrawn)
// --------------------------------------------------------------------

const toWalletResponse = (wallet) => ({
  seller: idStr(wallet.seller),
  availableBalance: round2(wallet.availableBalance),
  totalEarnings: round2(wallet.totalEarnings),
  totalWithdrawn: round2(wallet.totalWithdrawn),
  // Phase 16C — sum of currently-open withdrawal requests' held amounts.
  lockedBalance: round2(wallet.lockedBalance || 0),
});

const toLedgerEntryResponse = (entry) => ({
  id: idStr(entry._id ?? entry.id),
  direction: entry.direction,
  category: entry.category,
  amount: entry.amount,
  balanceAfter: entry.balanceAfter,
  order: entry.order ? idStr(entry.order) : null,
  note: entry.note,
  createdAt: entry.createdAt,
});

/**
 * `availableBalance`/`totalEarnings`/`totalWithdrawn` are the wallet's
 * own running, `$inc`-maintained totals (source of truth for the
 * seller's real current balance). `pendingBalance` is computed live,
 * every call, from the immutable ledger — NOT a separate pot on top of
 * `availableBalance`, but a description of how much of that same
 * balance came from sales within the current calendar month (i.e. a
 * "still recent" subset, not additional money) — see the ledger being
 * immutable (Part 2) is exactly why this can't be a mutated/moved
 * field: nothing ever changes a written entry's month.
 */
const getWalletSummary = async (sellerId) => {
  const wallet = await walletRepository.getOrCreateForSeller(sellerId);

  const monthStart = new Date(Date.UTC(new Date().getUTCFullYear(), new Date().getUTCMonth(), 1));
  const recentEntries = await walletRepository.listSinceForSeller(sellerId, monthStart);
  const pendingBalance = round2(walletRepository.netAmount(recentEntries));

  await walletRepository.cachePendingSnapshot(sellerId, pendingBalance);

  return { ...toWalletResponse(wallet), pendingBalance };
};

const getLedgerHistory = async (sellerId, { page, limit } = {}) => {
  const { items, meta } = await walletRepository.listForSeller(sellerId, { page, limit });
  return { items: items.map(toLedgerEntryResponse), meta };
};

// --------------------------------------------------------------------
// Part 7 — Admin Finance Dashboard
// --------------------------------------------------------------------

const getAdminOverview = async () => {
  const [walletTotals, commissionTotals] = await Promise.all([
    walletRepository.sumAllWallets(),
    commissionRecordRepository.sumPlatformWide(),
  ]);

  return {
    marketplaceRevenue: round2(commissionTotals.grossAmount),
    totalCommission: round2(commissionTotals.commissionAmount),
    sellerEarnings: round2(commissionTotals.netSellerEarnings),
    walletTotals: {
      totalAvailable: round2(walletTotals.totalAvailable),
      totalPending: round2(walletTotals.totalPending),
      totalEarnings: round2(walletTotals.totalEarnings),
      totalWithdrawn: round2(walletTotals.totalWithdrawn),
      walletCount: walletTotals.walletCount,
    },
  };
};

/** Admin drill-down into one specific seller's wallet — reuses the seller's own summary/history functions. */
const getAdminSellerWallet = async (sellerId) => {
  const seller = await sellerRepository.findByIdWithUser(sellerId);
  if (!seller) throw ApiError.notFound('Seller not found.');

  const summary = await getWalletSummary(seller.user.id || seller.user);
  const commissionTotals = await commissionRecordRepository.sumForSeller(seller.user.id || seller.user);

  return { storeName: seller.storeName, summary, commissionTotals: { ...commissionTotals } };
};

module.exports = {
  recordSaleForOrder,
  reverseEarningsForOrder,
  reverseEarningsForRefundRequest,
  holdForDispute,
  releaseDisputeHold,
  finalizeDisputeLoss,
  recordManualAdjustment,
  recordClosingBalanceSnapshot,
  getWalletSummary,
  getLedgerHistory,
  getAdminOverview,
  getAdminSellerWallet,
};
