'use strict';

const ApiError = require('../utils/ApiError');
const blogPostRepository = require('../repositories/blogPost.repository');
const { slugify, withUniqueSuffix } = require('../utils/slugify');
const { ROLES } = require('../constants/roles');
const { CONTENT_STATUSES } = require('../constants/cmsEnums');

const DEFAULT_RELATED_LIMIT = 4;
const MAX_RELATED_LIMIT = 12;

const generateUniqueSlug = async (title) => {
  const base = slugify(title);
  const exists = await blogPostRepository.existsBySlug(base);
  return exists ? withUniqueSuffix(base) : base;
};

// --------------------------------------------------------------------
// Create
// --------------------------------------------------------------------

const createPost = async (body, actingUser) => {
  const slug = body.slug ? slugify(body.slug) : await generateUniqueSlug(body.title);
  if (body.slug) {
    const taken = await blogPostRepository.existsBySlug(slug);
    if (taken) throw ApiError.conflict(`Slug "${slug}" is already in use.`);
  }

  return blogPostRepository.create({ ...body, slug, author: actingUser.id });
};

// --------------------------------------------------------------------
// Visibility
// --------------------------------------------------------------------

const assertVisible = (post, actingUser) => {
  if (actingUser?.role === ROLES.ADMIN) return;
  if (post.status !== CONTENT_STATUSES.PUBLISHED) {
    throw ApiError.notFound('Blog post not found.');
  }
};

// --------------------------------------------------------------------
// Reads
// --------------------------------------------------------------------

const getPostById = async (id, actingUser) => {
  const post = await blogPostRepository.findById(id);
  if (!post) throw ApiError.notFound('Blog post not found.');
  assertVisible(post, actingUser);
  return post;
};

const getPostBySlug = async (slug, actingUser) => {
  const post = await blogPostRepository.findBySlug(slug);
  if (!post) throw ApiError.notFound('Blog post not found.');
  assertVisible(post, actingUser);
  return post;
};

const listPosts = async (filter, options, actingUser) => {
  const effectiveFilter = { ...filter };
  if (actingUser?.role !== ROLES.ADMIN) {
    effectiveFilter.status = CONTENT_STATUSES.PUBLISHED;
  }
  return blogPostRepository.list(effectiveFilter, options);
};

/** Public — always scoped to published posts regardless of caller, since it's meant for a "you might also like" reader-facing widget. */
const getRelatedPosts = async (slug, limit = DEFAULT_RELATED_LIMIT) => {
  const post = await blogPostRepository.findBySlug(slug);
  if (!post || post.status !== CONTENT_STATUSES.PUBLISHED) {
    throw ApiError.notFound('Blog post not found.');
  }

  const boundedLimit = Math.min(Math.max(1, Number(limit) || DEFAULT_RELATED_LIMIT), MAX_RELATED_LIMIT);
  return blogPostRepository.findRelated(post, boundedLimit);
};

const listTags = () => blogPostRepository.listDistinctTags();

// --------------------------------------------------------------------
// Update / Delete (admin only — enforced at the route level)
// --------------------------------------------------------------------

const updatePost = async (id, body, actingUser) => {
  const existing = await blogPostRepository.findById(id);
  if (!existing) throw ApiError.notFound('Blog post not found.');

  const updates = { ...body };

  if (body.slug !== undefined) {
    const nextSlug = slugify(body.slug);
    if (nextSlug !== existing.slug) {
      const taken = await blogPostRepository.existsBySlug(nextSlug);
      if (taken) throw ApiError.conflict(`Slug "${nextSlug}" is already in use.`);
    }
    updates.slug = nextSlug;
  }

  // findByIdAndUpdate skips the model's pre('save') hook — see
  // page.service.js#updatePage for the identical rationale.
  if (
    body.status === CONTENT_STATUSES.PUBLISHED &&
    existing.status !== CONTENT_STATUSES.PUBLISHED &&
    !existing.publishedAt
  ) {
    updates.publishedAt = new Date();
  }

  const post = await blogPostRepository.updateById(id, updates);
  if (!post) throw ApiError.notFound('Blog post not found.');
  return post;
};

const deletePost = async (id) => {
  const deleted = await blogPostRepository.deleteById(id);
  if (!deleted) throw ApiError.notFound('Blog post not found.');
  return deleted;
};

module.exports = {
  generateUniqueSlug,
  createPost,
  getPostById,
  getPostBySlug,
  listPosts,
  getRelatedPosts,
  listTags,
  updatePost,
  deletePost,
};
