'use strict';

const ApiError = require('../utils/ApiError');
const { uploadBufferToCloudinary } = require('../utils/cloudinaryUpload');

const MAX_ATTACHMENTS = 5;

/**
 * Phase 16D — shared by refund/return/dispute evidence uploads (Part 1's
 * "Refund attachments", Part 2's return photos, Part 7's dispute
 * evidence) so the actual Cloudinary call exists in exactly one place,
 * reusing the same `uploadBufferToCloudinary` util productMedia.service.js
 * already established — never a second upload implementation.
 *
 * @param {Express.Multer.File[]} files
 * @returns {Promise<string[]>} secure_urls
 */
const uploadAttachments = async (files) => {
  if (!files || files.length === 0) {
    throw ApiError.badRequest('At least one file is required.');
  }
  if (files.length > MAX_ATTACHMENTS) {
    throw ApiError.badRequest(`At most ${MAX_ATTACHMENTS} attachments may be uploaded at once.`);
  }

  const results = await Promise.all(files.map((file) => uploadBufferToCloudinary(file, { folder: 'disputes-refunds/attachments' })));
  return results.map((r) => r.secure_url);
};

module.exports = { uploadAttachments, MAX_ATTACHMENTS };
