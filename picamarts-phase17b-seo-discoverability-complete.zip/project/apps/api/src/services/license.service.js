'use strict';

const ApiError = require('../utils/ApiError');
const licenseRepository = require('../repositories/license.repository');

const createLicense = async (data) => {
  const alreadyExists = await licenseRepository.existsByName(data.name);
  if (alreadyExists) {
    throw ApiError.conflict('A license with this name already exists.');
  }
  return licenseRepository.create(data);
};

const getLicenseById = async (id) => {
  const license = await licenseRepository.findById(id);
  if (!license) throw ApiError.notFound('License not found.');
  return license;
};

const listLicenses = (filter = {}, options = {}) => licenseRepository.list(filter, options);

const updateLicense = async (id, updates) => {
  const license = await licenseRepository.updateById(id, updates);
  if (!license) throw ApiError.notFound('License not found.');
  return license;
};

const deleteLicense = async (id) => {
  const deleted = await licenseRepository.deleteById(id);
  if (!deleted) throw ApiError.notFound('License not found.');
  return deleted;
};

module.exports = { createLicense, getLicenseById, listLicenses, updateLicense, deleteLicense };
