'use strict';

const ApiError = require('../utils/ApiError');
const cartService = require('./cart.service');

/**
 * Phase 8, Part 1 — Checkout. Deliberately NOT a persisted resource:
 * there's no separate Checkout/CheckoutSession model here. Every check
 * this module needs — published status, current stock, current price
 * — is already computed by cart.service.js's getCart() (the exact
 * same logic GET /cart uses to flag stale lines as `isAvailable:
 * false`). Checkout only adds the STRICT reading of those flags: a
 * blocking issue here is a hard 400 on POST /checkout, whereas GET
 * /cart treats the same condition as informational.
 *
 * "Lock product prices at checkout" is satisfied by computing prices
 * fresh at the moment of the call and returning that exact snapshot to
 * the caller — the durable lock happens when Phase 8 Part 2's POST
 * /orders persists this same computed snapshot into the Order
 * document at creation time. Because nothing is persisted here, Part
 * 2 will re-run this same evaluation at order-creation time rather
 * than consuming a token from this step — the two calls happen back
 * to back in a normal checkout flow, so the cart can't have changed
 * in between under any realistic client.
 */

/** Human-readable blocking reasons for a cart that isn't ready to become an order. */
const evaluateCart = (cart) => {
  const issues = [];

  if (cart.items.length === 0) {
    issues.push('Your cart is empty.');
  }

  cart.items.forEach((item) => {
    if (!item.isAvailable) {
      const label = item.product?.title || 'An item in your cart';
      issues.push(`${label}: ${item.unavailableReason || 'no longer available.'}`);
    }
  });

  return issues;
};

/** Reshapes a cart item into the checkout response shape — `unitPrice` becomes the explicit `lockedPrice`, and the now-redundant availability flags are dropped (everything here has already passed strict validation). */
const toLockedItem = (item) => ({
  id: item.id,
  product: item.product,
  quantity: item.quantity,
  lockedPrice: item.unitPrice,
  lineSubtotal: item.lineSubtotal,
  lineDiscount: item.lineDiscount,
  lineTotal: item.lineTotal,
});

/**
 * GET /checkout/summary — a soft preview. Always succeeds (even on an
 * empty or problem-laden cart) so the UI can show the cart alongside
 * WHY checkout isn't available yet, the same way GET /cart shows
 * stale lines without blocking the read.
 */
const getCheckoutSummary = async (buyerId) => {
  const cart = await cartService.getCart(buyerId);
  const blockingIssues = evaluateCart(cart);

  return {
    items: cart.items,
    summary: cart.summary,
    canCheckout: blockingIssues.length === 0,
    blockingIssues,
  };
};

/**
 * POST /checkout — the strict version. Rejects with every blocking
 * issue (400) if the cart isn't checkout-ready; otherwise returns the
 * locked summary the client proceeds to POST /orders with.
 */
const checkout = async (buyerId) => {
  const cart = await cartService.getCart(buyerId);
  const issues = evaluateCart(cart);

  if (issues.length > 0) {
    throw ApiError.badRequest('Cart is not ready for checkout.', issues);
  }

  return {
    items: cart.items.map(toLockedItem),
    summary: cart.summary,
    lockedAt: new Date(),
  };
};

// ---------------------------------------------------------------------
// Phase 14.2, Part 5 — Checkout Shipping. Additive: getCheckoutSummary
// and checkout() above are completely untouched. This is a PREVIEW
// only — it tells the buyer what shipping would cost before they pay,
// but (since Cart.js/Order.js are both out of scope this phase) the
// order's own persisted `shipping` field still comes from Cart's
// existing (always-zero) computation, exactly as before. Documented
// as a known gap, same pattern already used for the license-selection
// gap in cart.service.js's own history.
// ---------------------------------------------------------------------
const productRepository = require('../repositories/product.repository');
const shippingProfileRepository = require('../repositories/shippingProfile.repository');
const shippingProfileService = require('./shippingProfile.service');
const { PRODUCT_TYPES } = require('../constants/productEnums');

/**
 * Computes available shipping methods + an estimated cost/delivery
 * window for the buyer's current cart against a destination. Digital-
 * only carts return `shippingRequired: false` immediately. Physical
 * items without an assigned ShippingProfile fall back into an
 * "unconfigured" bucket the UI can flag to the buyer, rather than
 * silently charging nothing.
 */
const estimateShipping = async (buyerId, destination = {}) => {
  const cart = await cartService.getCart(buyerId);
  if (!cart.items.length) return { shippingRequired: false, methods: [], unconfiguredItems: [] };

  const products = await Promise.all(cart.items.map((item) => productRepository.findById(item.product.id)));

  const physicalGroups = new Map(); // shippingProfile id -> { profile, totalWeight, totalQuantity, orderSubtotal }
  const unconfiguredItems = [];
  let shippingRequired = false;

  cart.items.forEach((item, index) => {
    const product = products[index];
    if (!product) return;
    const isPhysical = product.type === PRODUCT_TYPES.PHYSICAL || product.type === PRODUCT_TYPES.BOTH;
    if (!isPhysical) return;

    shippingRequired = true;

    if (!product.shippingProfile) {
      unconfiguredItems.push({ productId: product._id.toString(), title: product.title });
      return;
    }

    const profileId = product.shippingProfile.toString();
    const group = physicalGroups.get(profileId) || { profileId, totalWeight: 0, totalQuantity: 0, orderSubtotal: 0 };
    group.totalWeight += (product.weight?.value || 0) * item.quantity;
    group.totalQuantity += item.quantity;
    group.orderSubtotal += item.lineTotal;
    physicalGroups.set(profileId, group);
  });

  if (!shippingRequired) return { shippingRequired: false, methods: [], unconfiguredItems: [] };

  const profileIds = [...physicalGroups.keys()];
  const profiles = await Promise.all(profileIds.map((id) => shippingProfileRepository.findById(id)));

  const methods = [];
  profiles.forEach((profile, index) => {
    if (!profile) return;
    const totals = physicalGroups.get(profileIds[index]);
    methods.push(
      ...shippingProfileService.calculateMethodsForProfile(profile, destination, {
        totalWeight: totals.totalWeight,
        totalQuantity: totals.totalQuantity,
        orderSubtotal: totals.orderSubtotal,
      })
    );
  });

  return { shippingRequired: true, methods, unconfiguredItems };
};

module.exports = { getCheckoutSummary, checkout, estimateShipping };
