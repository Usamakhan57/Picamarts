'use strict';

const ApiError = require('../utils/ApiError');
const tagRepository = require('../repositories/tag.repository');
const { slugify, withUniqueSuffix } = require('../utils/slugify');

const generateUniqueSlug = async (name) => {
  const base = slugify(name);
  const exists = await tagRepository.findBySlug(base);
  return exists ? withUniqueSuffix(base) : base;
};

const createTag = async (data) => {
  const alreadyExists = await tagRepository.existsByName(data.name);
  if (alreadyExists) {
    throw ApiError.conflict('A tag with this name already exists.');
  }

  const slug = data.slug ? slugify(data.slug) : await generateUniqueSlug(data.name);
  return tagRepository.create({ ...data, slug });
};

const getTagById = async (id) => {
  const tag = await tagRepository.findById(id);
  if (!tag) throw ApiError.notFound('Tag not found.');
  return tag;
};

const listTags = (filter = {}, options = {}) => tagRepository.list(filter, options);

const updateTag = async (id, updates) => {
  const tag = await tagRepository.updateById(id, updates);
  if (!tag) throw ApiError.notFound('Tag not found.');
  return tag;
};

const deleteTag = async (id) => {
  const deleted = await tagRepository.deleteById(id);
  if (!deleted) throw ApiError.notFound('Tag not found.');
  return deleted;
};

module.exports = { generateUniqueSlug, createTag, getTagById, listTags, updateTag, deleteTag };
