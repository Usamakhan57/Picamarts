'use strict';

const ApiError = require('../utils/ApiError');
const returnRequestRepository = require('../repositories/returnRequest.repository');
const paymentRepository = require('../repositories/payment.repository');
const refundService = require('./refund.service');
const notificationService = require('./notification.service');
const { ROLES } = require('../constants/roles');
const { RETURN_REQUEST_STATUSES } = require('../constants/refundEnums');
const { PAYMENT_STATUSES: ORDER_PAYMENT_STATUSES } = require('../constants/orderEnums');
const { NOTIFICATION_TYPES, RELATED_ENTITY_TYPES } = require('../constants/notificationEnums');

const idStr = (value) => (value?.toString ? value.toString() : value);

/**
 * Phase 16D, Part 2 — the physical return workflow. Deliberately kept
 * separate from refund.service.js (a return is about the PHYSICAL
 * item coming back; a refund is about the MONEY going back) — the two
 * are linked only at the one seam Part 2's own brief describes
 * ("Return completion" -> money back): see completeReturn below,
 * which calls refundService.createFromReturn rather than duplicating
 * any refund logic.
 */

// --------------------------------------------------------------------
// Response shaping
// --------------------------------------------------------------------

const toReturnRequestResponse = (doc) => ({
  id: idStr(doc._id),
  order: idStr(doc.order),
  buyer: idStr(doc.buyer),
  seller: idStr(doc.seller),
  items: (doc.items || []).map((i) => ({ orderItem: idStr(i.orderItem), quantity: i.quantity })),
  reason: doc.reason,
  note: doc.note,
  attachments: doc.attachments || [],
  status: doc.status,
  reviewedBy: doc.reviewedBy ? idStr(doc.reviewedBy) : null,
  reviewedAt: doc.reviewedAt,
  reviewNote: doc.reviewNote,
  returnShipping: doc.returnShipping
    ? {
        carrier: doc.returnShipping.carrier,
        trackingNumber: doc.returnShipping.trackingNumber,
        trackingUrl: doc.returnShipping.trackingUrl,
        shippedAt: doc.returnShipping.shippedAt,
      }
    : null,
  receivedAt: doc.receivedAt,
  completedAt: doc.completedAt,
  refundRequest: doc.refundRequest ? idStr(doc.refundRequest) : null,
  timeline: (doc.timeline || []).map((t) => ({ status: t.status, note: t.note, changedBy: idStr(t.changedBy), at: t.at })),
  createdAt: doc.createdAt,
  updatedAt: doc.updatedAt,
});

// --------------------------------------------------------------------
// Visibility
// --------------------------------------------------------------------

const assertVisible = (doc, actingUser) => {
  if (actingUser.role === ROLES.ADMIN) return;
  if (doc.buyer.toString() === actingUser.id) return;
  if (doc.seller.toString() === actingUser.id) return;
  throw ApiError.notFound('Return request not found.');
};

// --------------------------------------------------------------------
// Notifications (Part 8)
// --------------------------------------------------------------------

const notifyReturnStatus = (returnRequest, recipientId, statusLabel) =>
  notificationService.emitNotification({
    recipientId,
    type: returnRequest.status === RETURN_REQUEST_STATUSES.REQUESTED ? NOTIFICATION_TYPES.RETURN_REQUESTED : NOTIFICATION_TYPES.RETURN_STATUS_CHANGED,
    title: `Return ${statusLabel}`,
    message: `A return request for your order is now ${statusLabel}.`,
    relatedEntity: RELATED_ENTITY_TYPES.RETURN_REQUEST,
    relatedEntityId: idStr(returnRequest._id),
    metadata: { status: statusLabel },
  });

// --------------------------------------------------------------------
// Buyer — request a return
// --------------------------------------------------------------------

const createReturnRequest = async (orderId, actingUser, body) => {
  const order = await paymentRepository.findOrderById(orderId);
  if (!order) throw ApiError.notFound('Order not found.');
  if (order.buyer.toString() !== actingUser.id) throw ApiError.notFound('Order not found.');
  if (order.paymentStatus !== ORDER_PAYMENT_STATUSES.PAID) {
    throw ApiError.badRequest('Only a paid order can be returned.');
  }

  const sellerId = body.sellerId;
  if (!order.sellers.some((s) => s.toString() === sellerId)) {
    throw ApiError.badRequest('This seller did not sell any item on this order.');
  }

  const alreadyOpen = await returnRequestRepository.hasOpenRequest(orderId, sellerId);
  if (alreadyOpen) throw ApiError.conflict('A return request is already open for this order and seller.');

  const request = await returnRequestRepository.create({
    order: order._id,
    buyer: actingUser.id,
    seller: sellerId,
    items: body.items || [],
    reason: body.reason,
    note: body.note || '',
    attachments: body.attachments || [],
    status: RETURN_REQUEST_STATUSES.REQUESTED,
    timeline: [{ status: RETURN_REQUEST_STATUSES.REQUESTED, note: 'Return requested by buyer.', changedBy: actingUser.id, at: new Date() }],
  });

  notifyReturnStatus(request, sellerId, 'requested').catch(() => {});
  return toReturnRequestResponse(request);
};

const getReturnRequest = async (id, actingUser) => {
  const request = await returnRequestRepository.findById(id);
  if (!request) throw ApiError.notFound('Return request not found.');
  assertVisible(request, actingUser);
  return toReturnRequestResponse(request);
};

const listMyReturnRequests = async (buyerId, { page, limit } = {}) => {
  const { items, meta } = await returnRequestRepository.listForBuyer(buyerId, { page, limit });
  return { items: items.map(toReturnRequestResponse), meta };
};

const cancelReturnRequest = async (id, actingUser) => {
  const request = await returnRequestRepository.findById(id);
  if (!request) throw ApiError.notFound('Return request not found.');
  if (request.buyer.toString() !== actingUser.id) throw ApiError.notFound('Return request not found.');

  const updated = await returnRequestRepository.transitionStatus(id, RETURN_REQUEST_STATUSES.REQUESTED, {
    $set: { status: RETURN_REQUEST_STATUSES.CANCELLED },
    $push: { timeline: { status: RETURN_REQUEST_STATUSES.CANCELLED, note: 'Cancelled by buyer.', changedBy: actingUser.id, at: new Date() } },
  });
  if (!updated) throw ApiError.conflict('This request is no longer in a cancellable state.');
  return toReturnRequestResponse(updated);
};

/** Buyer records their outbound shipment tracking once the return is approved. */
const addReturnShipping = async (id, actingUser, { carrier, trackingNumber, trackingUrl }) => {
  const request = await returnRequestRepository.findById(id);
  if (!request) throw ApiError.notFound('Return request not found.');
  if (request.buyer.toString() !== actingUser.id) throw ApiError.notFound('Return request not found.');

  const updated = await returnRequestRepository.transitionStatus(id, RETURN_REQUEST_STATUSES.APPROVED, {
    $set: {
      status: RETURN_REQUEST_STATUSES.RETURN_SHIPPED,
      returnShipping: { carrier, trackingNumber, trackingUrl: trackingUrl || '', shippedAt: new Date() },
    },
    $push: { timeline: { status: RETURN_REQUEST_STATUSES.RETURN_SHIPPED, note: `Shipped via ${carrier} (${trackingNumber}).`, changedBy: actingUser.id, at: new Date() } },
  });
  if (!updated) throw ApiError.conflict('This return must be approved before shipping tracking can be added.');

  notifyReturnStatus(updated, updated.seller, 'shipped back').catch(() => {});
  return toReturnRequestResponse(updated);
};

// --------------------------------------------------------------------
// Seller/Admin — review, receive, complete
// --------------------------------------------------------------------

const assertReviewer = (request, actingUser) => {
  if (actingUser.role === ROLES.ADMIN) return;
  if (actingUser.role === ROLES.SELLER && request.seller.toString() === actingUser.id) return;
  throw ApiError.notFound('Return request not found.');
};

const approveReturnRequest = async (id, actingUser, note) => {
  const request = await returnRequestRepository.findById(id);
  if (!request) throw ApiError.notFound('Return request not found.');
  assertReviewer(request, actingUser);

  const updated = await returnRequestRepository.transitionStatus(id, RETURN_REQUEST_STATUSES.REQUESTED, {
    $set: { status: RETURN_REQUEST_STATUSES.APPROVED, reviewedBy: actingUser.id, reviewedAt: new Date(), reviewNote: note || '' },
    $push: { timeline: { status: RETURN_REQUEST_STATUSES.APPROVED, note: note || 'Approved.', changedBy: actingUser.id, at: new Date() } },
  });
  if (!updated) throw ApiError.conflict('This request is not pending and cannot be approved.');

  notifyReturnStatus(updated, updated.buyer, 'approved').catch(() => {});
  return toReturnRequestResponse(updated);
};

const rejectReturnRequest = async (id, actingUser, reason) => {
  const request = await returnRequestRepository.findById(id);
  if (!request) throw ApiError.notFound('Return request not found.');
  assertReviewer(request, actingUser);

  const updated = await returnRequestRepository.transitionStatus(id, RETURN_REQUEST_STATUSES.REQUESTED, {
    $set: { status: RETURN_REQUEST_STATUSES.REJECTED, reviewedBy: actingUser.id, reviewedAt: new Date(), reviewNote: reason || '' },
    $push: { timeline: { status: RETURN_REQUEST_STATUSES.REJECTED, note: reason || 'Rejected.', changedBy: actingUser.id, at: new Date() } },
  });
  if (!updated) throw ApiError.conflict('This request is not pending and cannot be rejected.');

  notifyReturnStatus(updated, updated.buyer, 'rejected').catch(() => {});
  return toReturnRequestResponse(updated);
};

const markReceived = async (id, actingUser) => {
  const request = await returnRequestRepository.findById(id);
  if (!request) throw ApiError.notFound('Return request not found.');
  assertReviewer(request, actingUser);

  const updated = await returnRequestRepository.transitionStatus(id, RETURN_REQUEST_STATUSES.RETURN_SHIPPED, {
    $set: { status: RETURN_REQUEST_STATUSES.RECEIVED, receivedAt: new Date() },
    $push: { timeline: { status: RETURN_REQUEST_STATUSES.RECEIVED, note: 'Returned item received.', changedBy: actingUser.id, at: new Date() } },
  });
  if (!updated) throw ApiError.conflict('This return must be shipped before it can be marked received.');

  notifyReturnStatus(updated, updated.buyer, 'received').catch(() => {});
  return toReturnRequestResponse(updated);
};

/** Part 2's "Return completion" — also opens the follow-on RefundRequest (Part 2/1 seam), and reactivates Order's dead-code `returned` status. */
const completeReturn = async (id, actingUser) => {
  const request = await returnRequestRepository.findById(id);
  if (!request) throw ApiError.notFound('Return request not found.');
  assertReviewer(request, actingUser);

  const updated = await returnRequestRepository.transitionStatus(id, RETURN_REQUEST_STATUSES.RECEIVED, {
    $set: { status: RETURN_REQUEST_STATUSES.COMPLETED, completedAt: new Date() },
    $push: { timeline: { status: RETURN_REQUEST_STATUSES.COMPLETED, note: 'Return completed.', changedBy: actingUser.id, at: new Date() } },
  });
  if (!updated) throw ApiError.conflict('This return must be received before it can be completed.');

  await returnRequestRepository.markOrderReturned(updated.order, actingUser.id);

  let refundRequest = null;
  try {
    refundRequest = await refundService.createFromReturn(updated, actingUser);
    await returnRequestRepository.transitionStatus(id, RETURN_REQUEST_STATUSES.COMPLETED, {
      $set: { refundRequest: refundRequest.id },
    });
  } catch {
    // A refund request may already be open on this order (Part 8's
    // duplicate-prevention correctly rejecting it) — the return itself
    // still completes; an admin can open the refund manually if needed.
  }

  notifyReturnStatus(updated, updated.buyer, 'completed').catch(() => {});
  return { ...toReturnRequestResponse(updated), refundRequest: refundRequest ? refundRequest.id : updated.refundRequest };
};

// --------------------------------------------------------------------
// Listings
// --------------------------------------------------------------------

const listForSeller = async (sellerId, { page, limit } = {}) => {
  const { items, meta } = await returnRequestRepository.listForSeller(sellerId, { page, limit });
  return { items: items.map(toReturnRequestResponse), meta };
};

const getAdminQueue = async ({ page, limit, status } = {}) => {
  const filter = {};
  if (status) filter.status = status;
  const { items, meta } = await returnRequestRepository.listForAdmin(filter, { page, limit });
  return { items: items.map(toReturnRequestResponse), meta };
};

const getAdminOverview = async () => {
  const byStatus = await returnRequestRepository.sumByStatus();
  return { byStatus };
};

module.exports = {
  createReturnRequest,
  getReturnRequest,
  listMyReturnRequests,
  cancelReturnRequest,
  addReturnShipping,
  approveReturnRequest,
  rejectReturnRequest,
  markReceived,
  completeReturn,
  listForSeller,
  getAdminQueue,
  getAdminOverview,
};
