'use strict';

const ApiError = require('../utils/ApiError');
const blogCategoryRepository = require('../repositories/blogCategory.repository');
const { slugify, withUniqueSuffix } = require('../utils/slugify');

const generateUniqueSlug = async (name) => {
  const base = slugify(name);
  const exists = await blogCategoryRepository.existsBySlug(base);
  return exists ? withUniqueSuffix(base) : base;
};

const createCategory = async (data) => {
  const slug = data.slug ? slugify(data.slug) : await generateUniqueSlug(data.name);
  const taken = await blogCategoryRepository.existsBySlug(slug);
  if (taken) throw ApiError.conflict(`Slug "${slug}" is already in use.`);
  return blogCategoryRepository.create({ ...data, slug });
};

const getCategoryById = async (id) => {
  const category = await blogCategoryRepository.findById(id);
  if (!category) throw ApiError.notFound('Blog category not found.');
  return category;
};

const getCategoryBySlug = async (slug) => {
  const category = await blogCategoryRepository.findBySlug(slug);
  if (!category) throw ApiError.notFound('Blog category not found.');
  return category;
};

const listCategories = (filter = {}, options = {}) => blogCategoryRepository.list(filter, options);

const updateCategory = async (id, updates) => {
  if (updates.slug !== undefined) {
    const nextSlug = slugify(updates.slug);
    const existing = await blogCategoryRepository.findById(id);
    if (!existing) throw ApiError.notFound('Blog category not found.');
    if (nextSlug !== existing.slug) {
      const taken = await blogCategoryRepository.existsBySlug(nextSlug);
      if (taken) throw ApiError.conflict(`Slug "${nextSlug}" is already in use.`);
    }
    updates = { ...updates, slug: nextSlug };
  }

  const category = await blogCategoryRepository.updateById(id, updates);
  if (!category) throw ApiError.notFound('Blog category not found.');
  return category;
};

const deleteCategory = async (id) => {
  const deleted = await blogCategoryRepository.deleteById(id);
  if (!deleted) throw ApiError.notFound('Blog category not found.');
  return deleted;
};

module.exports = {
  generateUniqueSlug,
  createCategory,
  getCategoryById,
  getCategoryBySlug,
  listCategories,
  updateCategory,
  deleteCategory,
};
