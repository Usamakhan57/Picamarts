'use strict';

const ApiError = require('../utils/ApiError');
const config = require('../config');
const stripe = require('../config/stripe');
const sellerRepository = require('../repositories/seller.repository');
const sellerService = require('../services/seller.service');
const userRepository = require('../repositories/user.repository');
const { ONBOARDING_STATUSES } = require('../constants/stripeConnectEnums');

/**
 * Phase 16A — Marketplace Finance, Stripe Connect Foundation.
 *
 * Scope: create a seller's Connect Express account, generate/refresh
 * the Account Link (Stripe-hosted onboarding), and retrieve/cache the
 * account's current status. This is intentionally the FULL scope —
 * no wallet, commission, payout, refund, or dispute logic lives here;
 * those are separate Phase 16 sub-phases that will build on top of
 * `Seller.stripeAccount.accountId` once it exists.
 *
 * Reuses the existing Stripe client (`config/stripe.js`, Phase 9) and
 * the existing `sellerRepository.findByUserId`/`updateById` (Phase 5) —
 * neither is modified. `seller.service.js#getSellerByUserId` (also
 * unmodified) is reused so this throws the exact same "No seller
 * profile found" 404 as every other seller self-service endpoint when
 * a `role: seller` user hasn't actually applied yet.
 */

const idStr = (value) => (value?.toString ? value.toString() : value);

/** Derives our own simple status from Stripe's underlying booleans/requirements — see stripeConnectEnums.js for why this exists. */
const deriveOnboardingStatus = (account) => {
  const disabledReason = account.requirements?.disabled_reason || '';
  const currentlyDue = account.requirements?.currently_due || [];

  if (disabledReason || (account.details_submitted && currentlyDue.length > 0)) {
    return ONBOARDING_STATUSES.RESTRICTED;
  }
  if (account.details_submitted && account.charges_enabled && account.payouts_enabled) {
    return ONBOARDING_STATUSES.COMPLETE;
  }
  return ONBOARDING_STATUSES.PENDING;
};

const toStripeAccountResponse = (seller) => ({
  accountId: seller.stripeAccount?.accountId || '',
  onboardingStatus: seller.stripeAccount?.onboardingStatus || ONBOARDING_STATUSES.NOT_STARTED,
  chargesEnabled: !!seller.stripeAccount?.chargesEnabled,
  payoutsEnabled: !!seller.stripeAccount?.payoutsEnabled,
  detailsSubmitted: !!seller.stripeAccount?.detailsSubmitted,
  currentlyDue: seller.stripeAccount?.currentlyDue || [],
  disabledReason: seller.stripeAccount?.disabledReason || '',
  connectedAt: seller.stripeAccount?.connectedAt || null,
  lastSyncedAt: seller.stripeAccount?.lastSyncedAt || null,
});

/** Persists a Stripe Account object's live fields onto the seller's cached `stripeAccount`, and returns the refreshed seller doc. */
const syncFromStripeAccount = async (sellerId, account) => {
  const onboardingStatus = deriveOnboardingStatus(account);

  return sellerRepository.updateById(sellerId, {
    stripeAccount: {
      accountId: account.id,
      onboardingStatus,
      chargesEnabled: !!account.charges_enabled,
      payoutsEnabled: !!account.payouts_enabled,
      detailsSubmitted: !!account.details_submitted,
      currentlyDue: account.requirements?.currently_due || [],
      disabledReason: account.requirements?.disabled_reason || '',
      connectedAt: new Date(account.created * 1000),
      lastSyncedAt: new Date(),
    },
  });
};

/**
 * Creates a new Stripe Connect Express account for the seller if one
 * doesn't exist yet — idempotent: calling this again for a seller who
 * already has an `accountId` just returns their current cached state,
 * it never creates a second Stripe account.
 */
const createAccount = async (userId) => {
  const seller = await sellerService.getSellerByUserId(userId);

  if (seller.stripeAccount?.accountId) {
    return toStripeAccountResponse(seller);
  }

  const owner = await userRepository.findById(userId);

  const account = await stripe.accounts.create({
    type: 'express',
    email: owner?.email,
    business_type: 'individual',
    business_profile: {
      name: seller.storeName,
      url: seller.website || undefined,
    },
    capabilities: {
      card_payments: { requested: true },
      transfers: { requested: true },
    },
    metadata: {
      sellerId: idStr(seller._id),
      userId: idStr(userId),
    },
  });

  const updated = await syncFromStripeAccount(seller.id, account);
  return toStripeAccountResponse(updated);
};

/**
 * Creates a fresh Stripe-hosted Account Link for onboarding. Account
 * Links expire quickly (a few minutes) and are single-use, so this
 * same call covers both "start onboarding" and "refresh/retry after
 * an expired link" — there's no separate state to track for a retry,
 * Stripe just needs a new link either way.
 */
const createOnboardingLink = async (userId) => {
  const seller = await sellerService.getSellerByUserId(userId);

  if (!seller.stripeAccount?.accountId) {
    throw ApiError.badRequest('No Stripe Connect account exists yet for this seller. Create one first.');
  }

  const accountLink = await stripe.accountLinks.create({
    account: seller.stripeAccount.accountId,
    type: 'account_onboarding',
    return_url: `${config.frontendUrl}/seller/settings/payouts?stripe=return`,
    refresh_url: `${config.frontendUrl}/seller/settings/payouts?stripe=refresh`,
  });

  return { url: accountLink.url, expiresAt: new Date(accountLink.expires_at * 1000) };
};

/**
 * Live status retrieval: always re-fetches the Account object from
 * Stripe (the only real source of truth for charges_enabled/
 * payouts_enabled/requirements) and re-syncs the local cache before
 * responding, so the dashboard never shows a stale "pending" after
 * the seller finishes onboarding on Stripe's side.
 */
const getAccountStatus = async (userId) => {
  const seller = await sellerService.getSellerByUserId(userId);

  if (!seller.stripeAccount?.accountId) {
    return toStripeAccountResponse(seller);
  }

  const account = await stripe.accounts.retrieve(seller.stripeAccount.accountId);
  const updated = await syncFromStripeAccount(seller.id, account);
  return toStripeAccountResponse(updated);
};

module.exports = {
  createAccount,
  createOnboardingLink,
  getAccountStatus,
  // exported for unit testing in isolation
  deriveOnboardingStatus,
  toStripeAccountResponse,
};
