'use strict';

const ApiError = require('../utils/ApiError');
const shipmentRepository = require('../repositories/shipment.repository');
// Additive, fire-and-forget only (`.catch(() => {})` at every call
// site) — same integration shape order.service.js/payment.service.js
// themselves use; never affects the shipment flow's own return value.
const notificationService = require('../services/notification.service');
const { ROLES } = require('../constants/roles');
const { SHIPMENT_STATUSES } = require('../constants/shippingEnums');

/**
 * Phase 14.2, Part 7/8/9/10 — Shipment Records, Customer Tracking,
 * Seller Shipping Dashboard, Admin Shipping Dashboard. Every read of
 * the parent Order goes through shipment.repository.js's additive
 * direct queries — this file never imports order.service.js, and
 * order.service.js/controller.js/validator.js/routes.js are never
 * modified by this phase.
 */

const idStr = (value) => (value?.toString ? value.toString() : value);

// --------------------------------------------------------------------
// Response shaping
// --------------------------------------------------------------------

const toShipmentResponse = (shipment) => ({
  id: idStr(shipment._id),
  order: idStr(shipment.order),
  orderNumber: shipment.orderNumber,
  seller: idStr(shipment.seller),
  buyer: idStr(shipment.buyer),
  items: (shipment.items || []).map((i) => ({
    orderItemId: idStr(i.orderItemId),
    product: idStr(i.product),
    title: i.title,
    quantity: i.quantity,
  })),
  carrier: shipment.carrier,
  trackingNumber: shipment.trackingNumber,
  trackingUrl: shipment.trackingUrl,
  status: shipment.status,
  shipmentDate: shipment.shipmentDate,
  estimatedDelivery: shipment.estimatedDelivery,
  deliveryDate: shipment.deliveryDate,
  notes: shipment.notes,
  timeline: (shipment.timeline || []).map((t) => ({ status: t.status, note: t.note, changedBy: idStr(t.changedBy), at: t.at })),
  createdAt: shipment.createdAt,
  updatedAt: shipment.updatedAt,
});

/** Minimal order-response-shape notifyOrderStatusChanged needs ({id, buyer, orderNumber}) — built from a directly-read Order doc, never order.service.js's own toOrderResponse. */
const toMinimalOrderContext = (order) => ({ id: idStr(order._id), buyer: idStr(order.buyer), orderNumber: order.orderNumber });

// --------------------------------------------------------------------
// Ownership
// --------------------------------------------------------------------

const assertCanManageShipment = (shipment, actingUser) => {
  if (actingUser.role === ROLES.ADMIN) return;
  if (actingUser.role === ROLES.SELLER && shipment.seller.toString() === actingUser.id) return;
  throw ApiError.forbidden('You do not have permission to manage this shipment.');
};

const assertCanViewShipment = (shipment, actingUser) => {
  if (actingUser.role === ROLES.ADMIN) return;
  if (actingUser.role === ROLES.SELLER && shipment.seller.toString() === actingUser.id) return;
  if (actingUser.role === ROLES.BUYER && shipment.buyer.toString() === actingUser.id) return;
  throw ApiError.notFound('Shipment not found.');
};

// --------------------------------------------------------------------
// Notification helpers — best-effort, mirrors order.service.js's own
// notifyOrderStatusChanged.catch(() => {}) call sites exactly.
// --------------------------------------------------------------------

const notifyOrderSync = (order, shipmentStatus) => {
  const orderContext = toMinimalOrderContext(order);
  const ORDER_STATUS_FOR = { shipped: 'shipped', in_transit: 'shipped', delivered: 'delivered', returned: 'returned' };
  const mapped = ORDER_STATUS_FOR[shipmentStatus];
  if (mapped) notificationService.notifyOrderStatusChanged(orderContext, mapped).catch(() => {});
};

// --------------------------------------------------------------------
// Part 7 — creation
// --------------------------------------------------------------------

/**
 * Creates a shipment for some (or all) of an order's line items —
 * partial fulfillment is supported: pass `orderItemIds` to ship only a
 * subset, or omit it to ship every item belonging to the acting
 * seller. Providing a `trackingNumber` up front moves the shipment
 * (and the order) straight to `shipped`; otherwise it starts `pending`.
 */
const createShipment = async (orderId, payload, actingUser) => {
  const order = await shipmentRepository.findOrderById(orderId);
  if (!order) throw ApiError.notFound('Order not found.');

  const isSeller = actingUser.role === ROLES.SELLER && order.sellers.some((s) => s.toString() === actingUser.id);
  if (!isSeller && actingUser.role !== ROLES.ADMIN) {
    throw ApiError.notFound('Order not found.');
  }

  const sellerId = actingUser.role === ROLES.SELLER ? actingUser.id : payload.seller;
  if (!sellerId) throw ApiError.badRequest('An admin must specify which seller this shipment belongs to.');

  const candidateItems = order.items.filter((item) => item.seller.toString() === sellerId);
  const selectedItems =
    payload.orderItemIds && payload.orderItemIds.length > 0
      ? candidateItems.filter((item) => payload.orderItemIds.includes(item._id.toString()))
      : candidateItems;

  if (selectedItems.length === 0) {
    throw ApiError.badRequest('No matching order items found for this seller.');
  }

  const initialStatus = payload.trackingNumber ? SHIPMENT_STATUSES.SHIPPED : SHIPMENT_STATUSES.PENDING;
  const now = new Date();

  const shipment = await shipmentRepository.create({
    order: order._id,
    orderNumber: order.orderNumber,
    seller: sellerId,
    buyer: order.buyer,
    items: selectedItems.map((item) => ({ orderItemId: item._id, product: item.product, title: item.titleSnapshot, quantity: item.quantity })),
    carrier: payload.carrier || '',
    trackingNumber: payload.trackingNumber || '',
    trackingUrl: payload.trackingUrl || '',
    status: initialStatus,
    shipmentDate: initialStatus === SHIPMENT_STATUSES.SHIPPED ? now : null,
    estimatedDelivery: payload.estimatedDelivery || null,
    notes: payload.notes || '',
    timeline: [{ status: initialStatus, note: 'Shipment created.', changedBy: actingUser.id, at: now }],
  });

  if (initialStatus === SHIPMENT_STATUSES.SHIPPED) {
    await shipmentRepository.syncOrderStatus(order._id, SHIPMENT_STATUSES.SHIPPED, actingUser.id);
    notifyOrderSync(order, SHIPMENT_STATUSES.SHIPPED);
    if (payload.trackingNumber) {
      notificationService.notifyTrackingAdded(toMinimalOrderContext(order), toShipmentResponse(shipment)).catch(() => {});
    }
  }

  return toShipmentResponse(shipment);
};

// --------------------------------------------------------------------
// Part 9 — status/tracking updates
// --------------------------------------------------------------------

const updateShipmentStatus = async (shipmentId, newStatus, meta, actingUser) => {
  const shipment = await shipmentRepository.findById(shipmentId);
  if (!shipment) throw ApiError.notFound('Shipment not found.');
  assertCanManageShipment(shipment, actingUser);

  const update = { status: newStatus };
  const now = new Date();
  if (newStatus === SHIPMENT_STATUSES.SHIPPED && !shipment.shipmentDate) update.shipmentDate = now;
  if (newStatus === SHIPMENT_STATUSES.DELIVERED) update.deliveryDate = now;
  if (meta?.notes != null) update.notes = meta.notes;

  const updated = await shipmentRepository.updateById(shipmentId, update, {
    status: newStatus,
    note: meta?.note || `Status changed to ${newStatus}.`,
    changedBy: actingUser.id,
    at: now,
  });

  const order = await shipmentRepository.syncOrderStatus(shipment.order, newStatus, actingUser.id);
  if (order) notifyOrderSync(order, newStatus);

  return toShipmentResponse(updated);
};

const addTracking = async (shipmentId, { carrier, trackingNumber, trackingUrl }, actingUser) => {
  const shipment = await shipmentRepository.findById(shipmentId);
  if (!shipment) throw ApiError.notFound('Shipment not found.');
  assertCanManageShipment(shipment, actingUser);

  const wasPending = shipment.status === SHIPMENT_STATUSES.PENDING;
  const now = new Date();
  const update = { carrier, trackingNumber, trackingUrl };
  if (wasPending) {
    update.status = SHIPMENT_STATUSES.SHIPPED;
    update.shipmentDate = now;
  }

  const updated = await shipmentRepository.updateById(shipmentId, update, {
    status: wasPending ? SHIPMENT_STATUSES.SHIPPED : shipment.status,
    note: 'Tracking number added.',
    changedBy: actingUser.id,
    at: now,
  });

  const order = await shipmentRepository.findOrderById(shipment.order);
  if (order) {
    if (wasPending) {
      await shipmentRepository.syncOrderStatus(shipment.order, SHIPMENT_STATUSES.SHIPPED, actingUser.id);
      notifyOrderSync(order, SHIPMENT_STATUSES.SHIPPED);
    }
    notificationService.notifyTrackingAdded(toMinimalOrderContext(order), toShipmentResponse(updated)).catch(() => {});
  }

  return toShipmentResponse(updated);
};

// --------------------------------------------------------------------
// Part 8 — customer tracking / reads
// --------------------------------------------------------------------

const getShipmentById = async (shipmentId, actingUser) => {
  const shipment = await shipmentRepository.findById(shipmentId);
  if (!shipment) throw ApiError.notFound('Shipment not found.');
  assertCanViewShipment(shipment, actingUser);
  return toShipmentResponse(shipment);
};

const listShipmentsForOrder = async (orderId, actingUser) => {
  const order = await shipmentRepository.findOrderById(orderId);
  if (!order) throw ApiError.notFound('Order not found.');

  const canView =
    actingUser.role === ROLES.ADMIN ||
    (actingUser.role === ROLES.BUYER && order.buyer.toString() === actingUser.id) ||
    (actingUser.role === ROLES.SELLER && order.sellers.some((s) => s.toString() === actingUser.id));
  if (!canView) throw ApiError.notFound('Order not found.');

  const shipments = await shipmentRepository.listByOrder(orderId);
  return shipments.map(toShipmentResponse);
};

const listMyShipments = async (buyerId) => {
  const { items } = await shipmentRepository.listByBuyer(buyerId, { limit: 100 });
  return items.map(toShipmentResponse);
};

// --------------------------------------------------------------------
// Part 9 — "Orders to Ship"
// --------------------------------------------------------------------

const listOrdersToShip = async (sellerId) => {
  const orders = await shipmentRepository.listShippableOrdersForSeller(sellerId);
  return orders.map((order) => ({
    id: idStr(order._id),
    orderNumber: order.orderNumber,
    status: order.status,
    createdAt: order.createdAt,
    items: order.items
      .filter((item) => item.seller.toString() === sellerId)
      .map((item) => ({ id: idStr(item._id), product: idStr(item.product), title: item.titleSnapshot, quantity: item.quantity })),
  }));
};

// --------------------------------------------------------------------
// Parts 9/10 — dashboards
// --------------------------------------------------------------------

const listShipments = async (query, actingUser) => {
  const { page, limit, status } = query;
  const options = { page: Number(page) || 1, limit: Number(limit) || 20 };
  const filter = status ? { status } : {};

  const { items, meta } =
    actingUser.role === ROLES.ADMIN
      ? await shipmentRepository.listAll(filter, options)
      : await shipmentRepository.listBySeller(actingUser.id, filter, options);

  return { items: items.map(toShipmentResponse), meta };
};

/** Admin only — quick counts for the dashboard landing view, plus delayed shipments (past their estimate, not yet delivered). */
const getAdminOverview = async () => {
  const { items: all } = await shipmentRepository.listAll({}, { limit: 500 });
  const now = Date.now();
  const counts = { pending: 0, shipped: 0, in_transit: 0, delivered: 0, returned: 0 };
  let delayed = 0;
  all.forEach((s) => {
    counts[s.status] = (counts[s.status] || 0) + 1;
    if (s.estimatedDelivery && s.status !== SHIPMENT_STATUSES.DELIVERED && s.status !== SHIPMENT_STATUSES.RETURNED && s.estimatedDelivery.getTime() < now) {
      delayed += 1;
    }
  });
  return { counts, delayed, total: all.length };
};

module.exports = {
  createShipment,
  updateShipmentStatus,
  addTracking,
  getShipmentById,
  listShipmentsForOrder,
  listMyShipments,
  listOrdersToShip,
  listShipments,
  getAdminOverview,
  toShipmentResponse,
};
