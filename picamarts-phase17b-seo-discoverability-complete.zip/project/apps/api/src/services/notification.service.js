'use strict';

const mongoose = require('mongoose');
const config = require('../config');
const logger = require('../utils/logger');
const ApiError = require('../utils/ApiError');
const notificationRepository = require('../repositories/notification.repository');
const { sendMail } = require('../emails/mailer');
const orderConfirmationEmail = require('../emails/templates/orderConfirmationEmail');
const paymentSuccessEmail = require('../emails/templates/paymentSuccessEmail');
const paymentFailureEmail = require('../emails/templates/paymentFailureEmail');
const refundIssuedEmail = require('../emails/templates/refundIssuedEmail');
const adminAnnouncementEmail = require('../emails/templates/adminAnnouncementEmail');
const filesReadyEmail = require('../emails/templates/filesReadyEmail');
const licenseAssignedEmail = require('../emails/templates/licenseAssignedEmail');
const downloadExpiringEmail = require('../emails/templates/downloadExpiringEmail');
const orderProcessingEmail = require('../emails/templates/orderProcessingEmail');
const orderShippedEmail = require('../emails/templates/orderShippedEmail');
const orderDeliveredEmail = require('../emails/templates/orderDeliveredEmail');
const trackingAddedEmail = require('../emails/templates/trackingAddedEmail');
const { ROLES } = require('../constants/roles');
const {
  NOTIFICATION_TYPES,
  DEFAULT_PRIORITY_BY_TYPE,
  RELATED_ENTITY_TYPES,
  EMAIL_ELIGIBLE_TYPES,
  ADMIN_BROADCAST_TYPES,
  NOTIFICATION_SORT_OPTIONS,
} = require('../constants/notificationEnums');

/**
 * Phase 10.2 — Notification System.
 *
 * This file has two halves:
 *   1. API-facing functions (list/get/markAsRead/markAllAsRead/delete/
 *      deleteAll/unreadCount/preferences/broadcast) called by
 *      notification.controller.js.
 *   2. Event wrapper functions (notifyOrderCreated, notifyPaymentFailed,
 *      etc.) called from Order/Payment/Review/Auth as a single
 *      additive, fire-and-forget line at the point a business event
 *      succeeds — see the "Notification integration" section of
 *      apps/api/README.md for why this is the chosen integration shape and why it never touches those modules'
 *      actual business logic.
 */

// --------------------------------------------------------------------
// Response shaping
// --------------------------------------------------------------------

const idStr = (value) => (value?.toString ? value.toString() : value);

const toNotificationResponse = (notification) => ({
  id: idStr(notification._id ?? notification.id),
  recipient: idStr(notification.recipient),
  sender: notification.sender ? idStr(notification.sender) : null,
  type: notification.type,
  title: notification.title,
  message: notification.message,
  relatedEntity: notification.relatedEntity,
  relatedEntityId: notification.relatedEntityId ? idStr(notification.relatedEntityId) : null,
  priority: notification.priority,
  isRead: notification.isRead,
  readAt: notification.readAt,
  metadata: notification.metadata || {},
  createdAt: notification.createdAt,
  updatedAt: notification.updatedAt,
});

const buildSortOption = (sort) => (sort === NOTIFICATION_SORT_OPTIONS.OLDEST ? { createdAt: 1 } : { createdAt: -1 });

// --------------------------------------------------------------------
// Ownership
// --------------------------------------------------------------------

/** Mirrors Order/Payment's own visibility pattern: 404 (not 403) for a notification the caller doesn't own. Admins may view any. */
const assertNotificationOwner = (notification, actingUser) => {
  if (actingUser.role === ROLES.ADMIN) return;
  if (notification.recipient.toString() === actingUser.id) return;
  throw ApiError.notFound('Notification not found.');
};

// ======================================================================
// PART 1 — API-facing functions
// ======================================================================

/** GET /notifications — the caller's own notifications, paginated, optionally filtered to read/unread. */
const listNotifications = async (actingUser, { page, limit, sort, isRead } = {}) => {
  const readFilter = isRead === undefined ? undefined : isRead === 'true' || isRead === true;

  const { items, meta } = await notificationRepository.listByRecipient(actingUser.id, {
    page,
    limit,
    sort: buildSortOption(sort),
    isRead: readFilter,
  });

  return { items: items.map(toNotificationResponse), meta };
};

/** GET /notifications/:id */
const getNotificationById = async (notificationId, actingUser) => {
  const notification = await notificationRepository.findById(notificationId);
  if (!notification) throw ApiError.notFound('Notification not found.');
  assertNotificationOwner(notification, actingUser);
  return toNotificationResponse(notification);
};

/** PATCH /notifications/:id/read */
const markAsRead = async (notificationId, actingUser) => {
  const notification = await notificationRepository.findById(notificationId);
  if (!notification) throw ApiError.notFound('Notification not found.');
  assertNotificationOwner(notification, actingUser);

  const updated = await notificationRepository.markAsRead(notificationId);
  return toNotificationResponse(updated);
};

/** PATCH /notifications/read-all — marks every one of the caller's own unread notifications as read. */
const markAllAsRead = async (actingUser) => {
  const result = await notificationRepository.markAllAsRead(actingUser.id);
  return { matched: result.matchedCount ?? result.n ?? 0, modified: result.modifiedCount ?? result.nModified ?? 0 };
};

/** DELETE /notifications/:id */
const deleteNotification = async (notificationId, actingUser) => {
  const notification = await notificationRepository.findById(notificationId);
  if (!notification) throw ApiError.notFound('Notification not found.');
  assertNotificationOwner(notification, actingUser);

  await notificationRepository.deleteById(notificationId);
};

/** DELETE /notifications — clears every one of the caller's own notifications. */
const deleteAllNotifications = async (actingUser) => {
  const result = await notificationRepository.deleteAllByRecipient(actingUser.id);
  return { deleted: result.deletedCount ?? 0 };
};

/** GET /notifications/unread-count */
const getUnreadCount = async (actingUser) => {
  const count = await notificationRepository.countUnread(actingUser.id);
  return { unreadCount: count };
};

// --------------------------------------------------------------------
// Preferences
// --------------------------------------------------------------------

/** GET /notifications/preferences */
const getPreferences = async (actingUser) => {
  const pref = await notificationRepository.getPreference(actingUser.id);
  return {
    emailEnabled: pref.emailEnabled,
    inAppEnabled: pref.inAppEnabled,
  };
};

/** PATCH /notifications/preferences */
const updatePreferences = async (actingUser, { emailEnabled, inAppEnabled }) => {
  const updates = {};
  if (emailEnabled !== undefined) updates.emailEnabled = emailEnabled;
  if (inAppEnabled !== undefined) updates.inAppEnabled = inAppEnabled;

  const pref = await notificationRepository.upsertPreference(actingUser.id, updates);
  return {
    emailEnabled: pref.emailEnabled,
    inAppEnabled: pref.inAppEnabled,
  };
};

// --------------------------------------------------------------------
// Admin broadcast
// --------------------------------------------------------------------

/**
 * POST /notifications/broadcast — admin only.
 *
 * `target` selects the audience:
 *   'all'     — every active buyer and seller (never other admins)
 *   'buyers'  — every active buyer
 *   'sellers' — every active seller
 *   an array of explicit user ids
 *
 * Respects each recipient's own inApp/email preference exactly like
 * any other notification — a broadcast does not bypass opt-outs.
 */
const broadcastNotification = async (body, actingUser) => {
  const { type, title, message, target = 'all', sendEmail = false, priority } = body;

  if (!ADMIN_BROADCAST_TYPES.includes(type)) {
    throw ApiError.badRequest(`type must be one of: ${ADMIN_BROADCAST_TYPES.join(', ')}`);
  }

  let recipientIds;
  if (Array.isArray(target)) {
    recipientIds = target;
  } else if (target === 'buyers') {
    recipientIds = await notificationRepository.findUserIdsByRole(ROLES.BUYER);
  } else if (target === 'sellers') {
    recipientIds = await notificationRepository.findUserIdsByRole(ROLES.SELLER);
  } else {
    const [buyers, sellers] = await Promise.all([
      notificationRepository.findUserIdsByRole(ROLES.BUYER),
      notificationRepository.findUserIdsByRole(ROLES.SELLER),
    ]);
    recipientIds = [...buyers, ...sellers];
  }

  const results = await Promise.all(
    recipientIds.map((recipientId) =>
      emitNotification({
        recipientId,
        senderId: actingUser.id,
        type,
        title,
        message,
        relatedEntity: RELATED_ENTITY_TYPES.SYSTEM,
        priority,
        buildEmail: sendEmail
          ? (contact) => adminAnnouncementEmail({ name: contact.name, title, message })
          : null,
      })
    )
  );

  return { targeted: recipientIds.length, sent: results.filter(Boolean).length };
};

// ======================================================================
// PART 2 — Internal dispatch core
// ======================================================================

/**
 * Shared entry point for every automatically-generated notification.
 *
 * Guards against attempting a real database write when no MongoDB
 * connection is active (readyState !== 1) — this project's sandbox
 * (and its full existing test suite) deliberately runs without a live
 * DB, and Mongoose would otherwise buffer the operation for up to 10s
 * before timing out. Every caller (the notify* wrappers below) invokes
 * this without awaiting the result and with `.catch(() => {})`, so a
 * skipped or failed notification NEVER affects the order/payment/
 * review/auth flow that triggered it — see the header comment above.
 *
 * @param {object} params
 * @param {string} params.recipientId
 * @param {string} [params.senderId]
 * @param {string} params.type
 * @param {string} params.title
 * @param {string} params.message
 * @param {string} [params.relatedEntity]
 * @param {string} [params.relatedEntityId]
 * @param {string} [params.priority]
 * @param {object} [params.metadata]
 * @param {(contact: { name: string, email: string }) => { subject: string, html: string, text: string }} [params.buildEmail]
 *   Only called (and only ever emailed) when the type is email-eligible
 *   AND the recipient has emailEnabled — lets callers build the email
 *   body lazily, using the recipient's real name once it's fetched.
 */
const emitNotification = async ({
  recipientId,
  senderId = null,
  type,
  title,
  message,
  relatedEntity = null,
  relatedEntityId = null,
  priority,
  metadata = {},
  buildEmail = null,
}) => {
  if (mongoose.connection.readyState !== 1) {
    logger.debug(`Notification "${type}" skipped — no active database connection.`);
    return null;
  }

  if (!recipientId) return null;

  try {
    const pref = await notificationRepository.getPreference(recipientId);

    let created = null;
    if (pref.inAppEnabled) {
      created = await notificationRepository.create({
        recipient: recipientId,
        sender: senderId,
        type,
        title,
        message,
        relatedEntity,
        relatedEntityId,
        priority: priority || DEFAULT_PRIORITY_BY_TYPE[type] || undefined,
        metadata,
      });
    }

    if (buildEmail && pref.emailEnabled && EMAIL_ELIGIBLE_TYPES.includes(type)) {
      const contact = await notificationRepository.findUserContactById(recipientId);
      if (contact?.email) {
        const { subject, html, text } = buildEmail(contact);
        await sendMail({ to: contact.email, subject, html, text });
      }
    }

    return created;
  } catch (error) {
    logger.warn(`Failed to emit notification "${type}" for user ${recipientId}: ${error.message}`);
    return null;
  }
};

// ======================================================================
// PART 3 — Event wrappers (called from Order/Payment/Review/Auth)
// ======================================================================

// ----- Orders -----------------------------------------------------

/** Called once, right after an order is created. */
const notifyOrderCreated = (order) =>
  emitNotification({
    recipientId: order.buyer,
    type: NOTIFICATION_TYPES.ORDER_CREATED,
    title: 'Order placed',
    message: `Your order ${order.orderNumber} has been placed successfully.`,
    relatedEntity: RELATED_ENTITY_TYPES.ORDER,
    relatedEntityId: order.id,
    metadata: { orderNumber: order.orderNumber, grandTotal: order.grandTotal },
    buildEmail: (contact) =>
      orderConfirmationEmail({
        name: contact.name,
        orderNumber: order.orderNumber,
        grandTotal: order.grandTotal,
        itemCount: order.items.length,
        orderUrl: `${config.frontendUrl}/orders/${order.id}`,
      }),
  });

const ORDER_STATUS_NOTIFICATION_TYPE = {
  confirmed: NOTIFICATION_TYPES.ORDER_CONFIRMED,
  processing: NOTIFICATION_TYPES.ORDER_PROCESSING,
  packed: NOTIFICATION_TYPES.ORDER_PACKED,
  shipped: NOTIFICATION_TYPES.ORDER_SHIPPED,
  delivered: NOTIFICATION_TYPES.ORDER_DELIVERED,
  cancelled: NOTIFICATION_TYPES.ORDER_CANCELLED,
};

const ORDER_STATUS_TITLE = {
  confirmed: 'Order confirmed',
  processing: 'Order is being processed',
  packed: 'Order packed',
  shipped: 'Order shipped',
  delivered: 'Order delivered',
  cancelled: 'Order cancelled',
};

/** Phase 14.2, Part 12 — only these four statuses get an email (in-app notification still fires for every mapped status above); `packed`/`confirmed`/`cancelled` stay in-app only, per the brief's literal template list. */
const ORDER_STATUS_EMAIL_BUILDER = {
  processing: (order, contact) =>
    orderProcessingEmail({ name: contact.name, orderNumber: order.orderNumber, orderUrl: `${config.frontendUrl}/orders/${order.id}` }),
  shipped: (order, contact) =>
    orderShippedEmail({ name: contact.name, orderNumber: order.orderNumber, orderUrl: `${config.frontendUrl}/orders/${order.id}` }),
  delivered: (order, contact) =>
    orderDeliveredEmail({ name: contact.name, orderNumber: order.orderNumber, orderUrl: `${config.frontendUrl}/orders/${order.id}` }),
};

/**
 * Called after an order's status successfully changes. Statuses with
 * no mapped notification type (e.g. an admin-only transition not
 * listed in the brief) are silently no-ops — this is a lookup table,
 * not a validation gate.
 */
const notifyOrderStatusChanged = (order, newStatus) => {
  const type = ORDER_STATUS_NOTIFICATION_TYPE[newStatus];
  if (!type) return Promise.resolve(null);

  const emailBuilder = ORDER_STATUS_EMAIL_BUILDER[newStatus];

  return emitNotification({
    recipientId: order.buyer,
    type,
    title: ORDER_STATUS_TITLE[newStatus],
    message: `Your order ${order.orderNumber} is now ${newStatus}.`,
    relatedEntity: RELATED_ENTITY_TYPES.ORDER,
    relatedEntityId: order.id,
    metadata: { orderNumber: order.orderNumber, status: newStatus },
    buildEmail: emailBuilder ? (contact) => emailBuilder(order, contact) : undefined,
  });
};

/** Phase 14.2, Part 11/12 — fired separately from notifyOrderStatusChanged since adding a tracking number isn't itself an order-status transition (it can happen on an already-`shipped` order). */
const notifyTrackingAdded = (orderContext, shipment) =>
  emitNotification({
    recipientId: orderContext.buyer,
    type: NOTIFICATION_TYPES.TRACKING_ADDED,
    title: 'Tracking number added',
    message: `Tracking is now available for order ${orderContext.orderNumber}.`,
    relatedEntity: RELATED_ENTITY_TYPES.SHIPMENT,
    relatedEntityId: shipment.id,
    metadata: { orderNumber: orderContext.orderNumber, carrier: shipment.carrier, trackingNumber: shipment.trackingNumber },
    buildEmail: (contact) =>
      trackingAddedEmail({
        name: contact.name,
        orderNumber: orderContext.orderNumber,
        carrier: shipment.carrier,
        trackingNumber: shipment.trackingNumber,
        trackingUrl: shipment.trackingUrl,
        orderUrl: `${config.frontendUrl}/orders/${orderContext.id}`,
      }),
  });

// ----- Payments -----------------------------------------------------

/** `orderContext` is a small `{ id, orderNumber }` shape — callers already have both without an extra DB round trip. */
const notifyPaymentSuccessful = (payment, orderContext) =>
  emitNotification({
    recipientId: payment.buyer,
    type: NOTIFICATION_TYPES.PAYMENT_SUCCESSFUL,
    title: 'Payment successful',
    message: `Your payment of ${payment.amount} ${String(payment.currency).toUpperCase()} for order ${orderContext.orderNumber} was successful.`,
    relatedEntity: RELATED_ENTITY_TYPES.PAYMENT,
    relatedEntityId: payment.id,
    metadata: { orderNumber: orderContext.orderNumber, amount: payment.amount, currency: payment.currency },
    buildEmail: (contact) =>
      paymentSuccessEmail({
        name: contact.name,
        orderNumber: orderContext.orderNumber,
        amount: payment.amount,
        currency: payment.currency,
        orderUrl: `${config.frontendUrl}/orders/${orderContext.id}`,
      }),
  });

const notifyPaymentFailed = (payment, orderContext, reason) =>
  emitNotification({
    recipientId: payment.buyer,
    type: NOTIFICATION_TYPES.PAYMENT_FAILED,
    title: 'Payment failed',
    message: `Your payment for order ${orderContext.orderNumber} could not be processed.`,
    relatedEntity: RELATED_ENTITY_TYPES.PAYMENT,
    relatedEntityId: payment.id,
    metadata: { orderNumber: orderContext.orderNumber, reason: reason || null },
    buildEmail: (contact) =>
      paymentFailureEmail({
        name: contact.name,
        orderNumber: orderContext.orderNumber,
        reason,
        retryUrl: `${config.frontendUrl}/orders/${orderContext.id}`,
      }),
  });

const notifyRefundIssued = (payment, orderContext, refundAmount, isFullRefund) =>
  emitNotification({
    recipientId: payment.buyer,
    type: NOTIFICATION_TYPES.REFUND_ISSUED,
    title: 'Refund issued',
    message: `A refund of ${refundAmount} ${String(payment.currency).toUpperCase()} has been issued for order ${orderContext.orderNumber}.`,
    relatedEntity: RELATED_ENTITY_TYPES.PAYMENT,
    relatedEntityId: payment.id,
    metadata: { orderNumber: orderContext.orderNumber, refundAmount, isFullRefund },
    buildEmail: (contact) =>
      refundIssuedEmail({
        name: contact.name,
        orderNumber: orderContext.orderNumber,
        refundAmount,
        currency: payment.currency,
        isFullRefund,
      }),
  });

// ----- Digital Delivery (Phase 14.1) --------------------------------

/** Called once per delivered digital line item, right after deliverForOrder creates its Download record. */
const notifyDigitalFilesReady = (buyerId, download, product) =>
  emitNotification({
    recipientId: buyerId,
    type: NOTIFICATION_TYPES.DIGITAL_FILES_READY,
    title: 'Your files are ready',
    message: `${product.title} is ready to download.`,
    relatedEntity: RELATED_ENTITY_TYPES.DOWNLOAD,
    relatedEntityId: idStr(download._id),
    metadata: { productId: idStr(product._id), productTitle: product.title },
    buildEmail: (contact) =>
      filesReadyEmail({
        name: contact.name,
        productTitle: product.title,
        downloadsUrl: `${config.frontendUrl}/downloads`,
      }),
  });

/** Called only when the delivered item's product has one or more licenses configured (a license key was generated). */
const notifyLicenseAssigned = (buyerId, download, product) =>
  emitNotification({
    recipientId: buyerId,
    type: NOTIFICATION_TYPES.LICENSE_ASSIGNED,
    title: 'License key assigned',
    message: `Your license key for ${product.title} is ready.`,
    relatedEntity: RELATED_ENTITY_TYPES.DOWNLOAD,
    relatedEntityId: idStr(download._id),
    metadata: { productId: idStr(product._id), productTitle: product.title },
    buildEmail: (contact) =>
      licenseAssignedEmail({
        name: contact.name,
        productTitle: product.title,
        licenseKey: download.licenseKey,
        downloadsUrl: `${config.frontendUrl}/downloads`,
      }),
  });

/** Not yet scheduled by a job in this pass — exists so a future maintenance job can call it the same way jobs/maintenance.job.js runs other housekeeping on a schedule. */
const notifyDownloadExpiring = (buyerId, download, product) =>
  emitNotification({
    recipientId: buyerId,
    type: NOTIFICATION_TYPES.DOWNLOAD_EXPIRING,
    title: 'Download expiring soon',
    message: `Your download access for ${product.title} expires soon.`,
    relatedEntity: RELATED_ENTITY_TYPES.DOWNLOAD,
    relatedEntityId: idStr(download._id),
    metadata: { productId: idStr(product._id), productTitle: product.title, expiresAt: download.expiresAt },
    buildEmail: (contact) =>
      downloadExpiringEmail({
        name: contact.name,
        productTitle: product.title,
        expiresAt: download.expiresAt ? new Date(download.expiresAt).toLocaleDateString() : '',
        downloadsUrl: `${config.frontendUrl}/downloads`,
      }),
  });

// ----- Reviews -----------------------------------------------------

/** Notifies the product's seller that a new review came in. */
const notifyReviewReceived = (sellerId, review, productTitle) =>
  emitNotification({
    recipientId: sellerId,
    type: NOTIFICATION_TYPES.REVIEW_RECEIVED,
    title: 'New review received',
    message: `${productTitle} received a new ${review.rating}-star review.`,
    relatedEntity: RELATED_ENTITY_TYPES.REVIEW,
    relatedEntityId: review.id,
    metadata: { rating: review.rating, product: review.product },
  });

/** Notifies the reviewer that an admin restored their previously-hidden review. */
const notifyReviewApproved = (review) =>
  emitNotification({
    recipientId: review.reviewer?.id || review.reviewer,
    type: NOTIFICATION_TYPES.REVIEW_APPROVED,
    title: 'Your review was approved',
    message: 'Your review is now visible to other shoppers.',
    relatedEntity: RELATED_ENTITY_TYPES.REVIEW,
    relatedEntityId: review.id,
  });

/** Notifies the reviewer that an admin hid their review. */
const notifyReviewHidden = (review) =>
  emitNotification({
    recipientId: review.reviewer?.id || review.reviewer,
    type: NOTIFICATION_TYPES.REVIEW_HIDDEN,
    title: 'Your review was hidden',
    message: 'One of your reviews was hidden by a moderator and is no longer publicly visible.',
    relatedEntity: RELATED_ENTITY_TYPES.REVIEW,
    relatedEntityId: review.id,
  });

/** Fans out to every active admin when a review is reported for the first time. */
const notifyReviewReported = async (review) => {
  const adminIds = await notificationRepository.findAdminIds();
  return Promise.all(
    adminIds.map((adminId) =>
      emitNotification({
        recipientId: adminId,
        type: NOTIFICATION_TYPES.REVIEW_REPORTED,
        title: 'Review reported',
        message: 'A review was reported and may need moderation.',
        relatedEntity: RELATED_ENTITY_TYPES.REVIEW,
        relatedEntityId: review.id,
      })
    )
  );
};

// ----- Authentication -----------------------------------------------------

const notifyEmailVerified = (userId) =>
  emitNotification({
    recipientId: userId,
    type: NOTIFICATION_TYPES.EMAIL_VERIFIED,
    title: 'Email verified',
    message: 'Your email address has been verified.',
    relatedEntity: RELATED_ENTITY_TYPES.USER,
    relatedEntityId: userId,
  });

const notifyPasswordChanged = (userId) =>
  emitNotification({
    recipientId: userId,
    type: NOTIFICATION_TYPES.PASSWORD_CHANGED,
    title: 'Password changed',
    message: 'Your password was changed. If this wasn\u2019t you, please contact support immediately.',
    relatedEntity: RELATED_ENTITY_TYPES.USER,
    relatedEntityId: userId,
  });

/** Reset-completion confirmation — the reset *link* email is already sent by auth.service.js#forgotPassword; this is the follow-up once the reset actually completes. */
const notifyPasswordReset = (userId) =>
  emitNotification({
    recipientId: userId,
    type: NOTIFICATION_TYPES.PASSWORD_RESET,
    title: 'Password reset',
    message: 'Your password was reset successfully.',
    relatedEntity: RELATED_ENTITY_TYPES.USER,
    relatedEntityId: userId,
    buildEmail: (contact) =>
      adminAnnouncementEmail({
        name: contact.name,
        title: 'Your password was reset',
        message: 'This confirms your PicaMarts password was just reset. If you did not do this, please contact support immediately.',
      }),
  });

module.exports = {
  // API-facing
  listNotifications,
  getNotificationById,
  markAsRead,
  markAllAsRead,
  deleteNotification,
  deleteAllNotifications,
  getUnreadCount,
  getPreferences,
  updatePreferences,
  broadcastNotification,
  // Event wrappers
  notifyOrderCreated,
  notifyOrderStatusChanged,
  notifyPaymentSuccessful,
  notifyPaymentFailed,
  notifyRefundIssued,
  notifyDigitalFilesReady,
  notifyLicenseAssigned,
  notifyDownloadExpiring,
  notifyTrackingAdded,
  notifyReviewReceived,
  notifyReviewApproved,
  notifyReviewHidden,
  notifyReviewReported,
  notifyEmailVerified,
  notifyPasswordChanged,
  notifyPasswordReset,
  // Exported for tests only
  emitNotification,
};
