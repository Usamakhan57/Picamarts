'use strict';

const config = require('../config');
const sitemapRepository = require('../repositories/sitemap.repository');
const { PAGE_TYPES } = require('../constants/cmsEnums');

/**
 * Phase 17B — SEO & Discoverability, Part 1 (Technical SEO).
 *
 * Sitemap index at /sitemap.xml fans out to per-type child sitemaps —
 * products (chunked, since a marketplace catalogue can exceed the
 * 50,000-URL/50MB sitemap protocol limit long before a static export
 * would), categories, brands, collections, and static/CMS pages.
 * Every URL here is read-only/lean (see sitemap.repository.js) —
 * nothing in this file writes anything or touches an existing
 * repository, service, or controller.
 */

const SITE_URL = (config.frontendUrl || '').replace(/\/+$/, '');
// The sitemap/robots endpoints themselves are served by this API (mounted at
// the app root — see routes/sitemap.routes.js), not by the SPA build, so the
// sitemap-index's own <loc> entries point back to this service, not the site.
const API_URL = (config.apiUrl || '').replace(/\/+$/, '');
const PRODUCTS_PER_SITEMAP = 5000;

/** Only static pages that actually have a live frontend route get listed — see App.jsx's route table. */
const PAGE_TYPE_TO_PATH = {
  [PAGE_TYPES.HOMEPAGE]: '/',
  [PAGE_TYPES.ABOUT_US]: '/about',
  [PAGE_TYPES.CONTACT_US]: '/contact',
  [PAGE_TYPES.PRIVACY_POLICY]: '/privacy',
  [PAGE_TYPES.TERMS_CONDITIONS]: '/terms',
  [PAGE_TYPES.FAQ]: '/faq',
  [PAGE_TYPES.REFUND_POLICY]: '/refund-policy',
};

/** Fixed, always-crawlable marketing/browse routes with no backing DB collection of their own. */
const STATIC_ROUTES = [
  { path: '/', changefreq: 'daily', priority: '1.0' },
  { path: '/shop', changefreq: 'daily', priority: '0.9' },
  { path: '/categories', changefreq: 'weekly', priority: '0.7' },
  { path: '/collections', changefreq: 'weekly', priority: '0.7' },
  { path: '/blog', changefreq: 'daily', priority: '0.6' },
];

const xmlEscape = (value = '') =>
  String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');

const isoDate = (date) => (date instanceof Date ? date : new Date(date || Date.now())).toISOString();

const toAbsoluteUrl = (path) => `${SITE_URL}${path.startsWith('/') ? path : `/${path}`}`;

/** @param {{loc:string, lastmod?:string|Date, changefreq?:string, priority?:string}[]} urls */
const buildUrlsetXml = (urls) => {
  const body = urls
    .map((u) => {
      const lastmod = u.lastmod ? `<lastmod>${isoDate(u.lastmod)}</lastmod>` : '';
      const changefreq = u.changefreq ? `<changefreq>${u.changefreq}</changefreq>` : '';
      const priority = u.priority ? `<priority>${u.priority}</priority>` : '';
      return `<url><loc>${xmlEscape(u.loc)}</loc>${lastmod}${changefreq}${priority}</url>`;
    })
    .join('');
  return `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${body}</urlset>`;
};

/** @param {{loc:string, lastmod?:string|Date}[]} sitemaps */
const buildSitemapIndexXml = (sitemaps) => {
  const body = sitemaps
    .map((s) => `<sitemap><loc>${xmlEscape(s.loc)}</loc>${s.lastmod ? `<lastmod>${isoDate(s.lastmod)}</lastmod>` : ''}</sitemap>`)
    .join('');
  return `<?xml version="1.0" encoding="UTF-8"?><sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${body}</sitemapindex>`;
};

const getSitemapIndex = async () => {
  const productCount = await sitemapRepository.countProducts();
  const productChunks = Math.max(1, Math.ceil(productCount / PRODUCTS_PER_SITEMAP));
  const now = new Date();

  const sitemaps = [
    ...Array.from({ length: productChunks }, (_, i) => ({
      loc: `${API_URL}/sitemaps/products-${i + 1}.xml`,
      lastmod: now,
    })),
    { loc: `${API_URL}/sitemaps/categories.xml`, lastmod: now },
    { loc: `${API_URL}/sitemaps/brands.xml`, lastmod: now },
    { loc: `${API_URL}/sitemaps/collections.xml`, lastmod: now },
    { loc: `${API_URL}/sitemaps/pages.xml`, lastmod: now },
  ];

  return buildSitemapIndexXml(sitemaps);
};

const getProductsSitemap = async (page = 1) => {
  const pageNum = Math.max(1, Number.parseInt(page, 10) || 1);
  const skip = (pageNum - 1) * PRODUCTS_PER_SITEMAP;
  const products = await sitemapRepository.findProductsPage(skip, PRODUCTS_PER_SITEMAP);

  return buildUrlsetXml(
    products.map((p) => ({
      loc: toAbsoluteUrl(`/product/${p.slug}`),
      lastmod: p.updatedAt,
      changefreq: 'weekly',
      priority: '0.8',
    }))
  );
};

const getCategoriesSitemap = async () => {
  const categories = await sitemapRepository.findAllCategories();
  return buildUrlsetXml(
    categories.map((c) => ({
      loc: toAbsoluteUrl(`/category/${c.slug}`),
      lastmod: c.updatedAt,
      changefreq: 'weekly',
      priority: '0.7',
    }))
  );
};

const getBrandsSitemap = async () => {
  const brands = await sitemapRepository.findAllBrands();
  // Disclosed gap: the storefront has no dedicated brand landing page
  // (no `/brand/:slug` route exists in App.jsx) — Brand is currently
  // only a filterable product attribute, browsed via the Shop page's
  // brand checkbox filter. Rather than link to a page that 404s, this
  // points each brand at that same real, working filtered view
  // (`/shop?brand=<id>`, now readable on load — see ShopPage.jsx).
  // Seo.jsx's canonical still resolves that URL back to plain `/shop`
  // (standard practice for a parameterized filter view), so this adds
  // a genuine crawl/discovery path without risking duplicate-content
  // issues. A real `/brand/:slug` page remains a good follow-up.
  return buildUrlsetXml(
    brands.map((b) => ({
      loc: toAbsoluteUrl(`/shop?brand=${b._id}`),
      lastmod: b.updatedAt,
      changefreq: 'weekly',
      priority: '0.5',
    }))
  );
};

const getCollectionsSitemap = async () => {
  const collections = await sitemapRepository.findAllCollections();
  // Disclosed gap, same shape as the brand one above: the storefront's
  // CollectionsPage.jsx is still driven by mock data and there is no
  // `/collections/:slug` detail route in App.jsx. This links each real
  // Collection document at the working `/shop?collection=<id>` filter
  // (now wired — see ShopPage.jsx / api.js#buildProductQuery) instead of
  // a URL that would 404. A real collection landing page remains a good
  // follow-up.
  return buildUrlsetXml(
    collections.map((c) => ({
      loc: toAbsoluteUrl(`/shop?collection=${c._id}`),
      lastmod: c.updatedAt,
      changefreq: 'weekly',
      priority: '0.5',
    }))
  );
};

const getPagesSitemap = async () => {
  const [pages, posts] = await Promise.all([
    sitemapRepository.findAllPublishedPages(),
    sitemapRepository.findAllPublishedBlogPosts(),
  ]);

  const cmsUrls = pages
    .filter((p) => PAGE_TYPE_TO_PATH[p.pageType])
    .map((p) => ({
      loc: toAbsoluteUrl(PAGE_TYPE_TO_PATH[p.pageType]),
      lastmod: p.updatedAt,
      changefreq: 'monthly',
      priority: p.pageType === PAGE_TYPES.HOMEPAGE ? '1.0' : '0.5',
    }));

  const blogUrls = posts.map((post) => ({
    loc: toAbsoluteUrl(`/blog/${post.slug}`),
    lastmod: post.updatedAt,
    changefreq: 'monthly',
    priority: '0.5',
  }));

  // Static marketing/browse routes de-duplicated against anything CMS already covers (homepage/about/contact all come from Page docs above).
  const coveredPaths = new Set(cmsUrls.map((u) => u.loc));
  const staticUrls = STATIC_ROUTES.filter((r) => !coveredPaths.has(toAbsoluteUrl(r.path))).map((r) => ({
    loc: toAbsoluteUrl(r.path),
    changefreq: r.changefreq,
    priority: r.priority,
  }));

  return buildUrlsetXml([...staticUrls, ...cmsUrls, ...blogUrls]);
};

module.exports = {
  buildUrlsetXml,
  buildSitemapIndexXml,
  getSitemapIndex,
  getProductsSitemap,
  getCategoriesSitemap,
  getBrandsSitemap,
  getCollectionsSitemap,
  getPagesSitemap,
};
