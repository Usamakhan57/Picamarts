'use strict';

const ApiError = require('../utils/ApiError');
const orderRepository = require('../repositories/order.repository');
const productRepository = require('../repositories/product.repository');
const checkoutService = require('./checkout.service');
const cartService = require('./cart.service');
// Phase 10.2 — Notification System. A single additive, fire-and-forget
// call per state transition below (`.catch(() => {})`) — never awaited,
// never allowed to affect the order flow's own return value or errors.
// See notification.service.js's `emitNotification` for why this is safe
// to leave in the existing (DB-less) test environment.
const notificationService = require('./notification.service');
const { ROLES } = require('../constants/roles');
const {
  ORDER_STATUSES,
  SELLER_UPDATABLE_ORDER_STATUSES,
  TERMINAL_ORDER_STATUSES,
} = require('../constants/orderEnums');

/**
 * Phase 8, Part 2 — Orders. Order creation reuses
 * checkoutService.checkout() for every validation Checkout already
 * performs (empty cart, published-only, stock availability, pricing) —
 * this file never re-derives any of that. It only adds what's unique
 * to becoming an order: snapshotting product/seller data, atomically
 * reserving stock, generating the order number, and persisting.
 */

// --------------------------------------------------------------------
// Response shaping
// --------------------------------------------------------------------

const idStr = (value) => (value?.toString ? value.toString() : value);

const toOrderItemResponse = (item) => ({
  id: idStr(item._id),
  product: idStr(item.product),
  seller: idStr(item.seller),
  title: item.titleSnapshot,
  sku: item.skuSnapshot,
  thumbnail: item.thumbnailSnapshot,
  quantity: item.quantity,
  lockedPrice: item.lockedPrice,
  lineSubtotal: item.lineSubtotal,
  lineDiscount: item.lineDiscount,
  lineTotal: item.lineTotal,
});

const toOrderResponse = (order) => ({
  id: idStr(order._id),
  orderNumber: order.orderNumber,
  buyer: idStr(order.buyer),
  sellers: order.sellers.map(idStr),
  items: order.items.map(toOrderItemResponse),
  subtotal: order.subtotal,
  discount: order.discount,
  tax: order.tax,
  shipping: order.shipping,
  grandTotal: order.grandTotal,
  paymentStatus: order.paymentStatus,
  status: order.status,
  shippingAddress: order.shippingAddress,
  billingAddress: order.billingAddress,
  notes: order.notes,
  timeline: order.timeline.map((entry) => ({
    status: entry.status,
    note: entry.note,
    changedBy: idStr(entry.changedBy),
    at: entry.at,
  })),
  createdAt: order.createdAt,
  updatedAt: order.updatedAt,
});

// --------------------------------------------------------------------
// Visibility (who may see/act on a given order)
// --------------------------------------------------------------------

/** Mirrors Product's assertVisible pattern: a 404 (not a 403) for a hidden order, so its existence isn't leaked to an unrelated caller. */
const assertOrderVisible = (order, actingUser) => {
  if (actingUser.role === ROLES.ADMIN) return;
  if (actingUser.role === ROLES.BUYER && order.buyer.toString() === actingUser.id) return;
  if (actingUser.role === ROLES.SELLER && order.sellers.some((s) => s.toString() === actingUser.id)) return;
  throw ApiError.notFound('Order not found.');
};

// --------------------------------------------------------------------
// Order number generation
// --------------------------------------------------------------------

const generateOrderNumber = async () => {
  const year = new Date().getFullYear();
  const seq = await orderRepository.getNextOrderSequence(year);
  return `ORD-${year}-${String(seq).padStart(6, '0')}`;
};

// --------------------------------------------------------------------
// Creation
// --------------------------------------------------------------------

/**
 * Creates an order from the buyer's current cart.
 *
 *   1. checkoutService.checkout() re-validates and prices the cart —
 *      throws 400 with every blocking issue if it isn't ready (empty,
 *      unpublished/out-of-stock/over-quantity items). Nothing about
 *      that check is duplicated here.
 *   2. For each locked item, the full product doc is fetched (for
 *      seller/SKU — fields Cart/Checkout never needed) and stock is
 *      decremented ATOMICALLY and CONDITIONALLY (see
 *      order.repository.js#decrementProductStock) — this is the real
 *      "prevent overselling" guarantee, safe even if two buyers race
 *      to check out the last unit at the same instant.
 *   3. If anything fails partway (a later item is out of stock, the
 *      order fails to save, ...), every stock decrement already made
 *      in this call is rolled back before the error propagates — no
 *      order is left half-reserved.
 *   4. Only once the order is safely persisted is the cart cleared,
 *      and that clear is best-effort — a failure there doesn't undo
 *      the (already real) order.
 */
const createOrder = async (buyerId, { shippingAddress, billingAddress, notes }, actingUser) => {
  const locked = await checkoutService.checkout(buyerId);

  const decremented = [];
  let order;

  try {
    const orderItems = [];
    const sellerIds = new Set();

    for (const item of locked.items) {
      const product = await productRepository.findById(item.product.id);
      if (!product) {
        throw ApiError.badRequest(`${item.product.title || 'A product'} in your cart no longer exists.`);
      }

      const updatedProduct = await orderRepository.decrementProductStock(product._id, item.quantity);
      if (!updatedProduct) {
        throw ApiError.badRequest(`Insufficient stock for ${product.title}.`);
      }
      decremented.push({ productId: product._id, quantity: item.quantity });

      sellerIds.add(product.seller.toString());
      orderItems.push({
        product: product._id,
        seller: product.seller,
        titleSnapshot: product.title,
        skuSnapshot: product.sku || '',
        thumbnailSnapshot: { url: product.thumbnail?.url || '' },
        quantity: item.quantity,
        lockedPrice: item.lockedPrice,
        lineSubtotal: item.lineSubtotal,
        lineDiscount: item.lineDiscount,
        lineTotal: item.lineTotal,
      });
    }

    const orderNumber = await generateOrderNumber();

    order = await orderRepository.create({
      buyer: buyerId,
      sellers: [...sellerIds],
      orderNumber,
      items: orderItems,
      subtotal: locked.summary.subtotal,
      discount: locked.summary.discount,
      tax: locked.summary.tax,
      shipping: locked.summary.shipping,
      grandTotal: locked.summary.grandTotal,
      shippingAddress,
      billingAddress: billingAddress || shippingAddress,
      notes: notes || '',
      timeline: [{ status: ORDER_STATUSES.PENDING, note: 'Order placed.', changedBy: actingUser.id, at: new Date() }],
    });
  } catch (error) {
    // Roll back every stock decrement already made in this call — a
    // partial order is never left holding reserved inventory.
    await Promise.all(decremented.map((d) => orderRepository.restoreProductStock(d.productId, d.quantity)));
    throw error;
  }

  // Best-effort — the order is already safely persisted, so a failure
  // to clear the cart afterward doesn't undo it or fail the request.
  await cartService.clearCart(buyerId).catch(() => {});

  const response = toOrderResponse(order);
  notificationService.notifyOrderCreated(response).catch(() => {});
  return response;
};

// --------------------------------------------------------------------
// Reads
// --------------------------------------------------------------------

/** Buyers see only their own orders; sellers see orders containing at least one of their products; admins see everything. */
const listOrders = async (actingUser, { status, page, limit } = {}) => {
  const filter = {};
  if (status) filter.status = status;

  if (actingUser.role === ROLES.BUYER) filter.buyer = actingUser.id;
  else if (actingUser.role === ROLES.SELLER) filter.sellers = actingUser.id;
  // admin: no additional filter — sees every order

  const { items, meta } = await orderRepository.list(filter, { page, limit, sort: { createdAt: -1 } });
  return { items: items.map(toOrderResponse), meta };
};

const getOrderById = async (orderId, actingUser) => {
  const order = await orderRepository.findById(orderId);
  if (!order) throw ApiError.notFound('Order not found.');
  assertOrderVisible(order, actingUser);
  return toOrderResponse(order);
};

// --------------------------------------------------------------------
// Status transitions
// --------------------------------------------------------------------

/**
 * Admin may set any status. A seller may set fulfillment-related
 * statuses only (confirmed/processing/packed/shipped/delivered), and
 * only on an order that includes at least one of their products.
 * Neither can move a terminal order (cancelled/refunded) anywhere.
 */
const updateOrderStatus = async (orderId, newStatus, actingUser) => {
  const order = await orderRepository.findById(orderId);
  if (!order) throw ApiError.notFound('Order not found.');

  if (actingUser.role === ROLES.SELLER) {
    const isSeller = order.sellers.some((s) => s.toString() === actingUser.id);
    if (!isSeller) throw ApiError.notFound('Order not found.');
    if (!SELLER_UPDATABLE_ORDER_STATUSES.includes(newStatus)) {
      throw ApiError.forbidden('Sellers can only update fulfillment-related statuses.');
    }
  } else if (actingUser.role !== ROLES.ADMIN) {
    throw ApiError.forbidden('You do not have permission to update this order.');
  }

  if (TERMINAL_ORDER_STATUSES.includes(order.status)) {
    throw ApiError.badRequest(`Order is already ${order.status} and can no longer be updated.`);
  }

  order.status = newStatus;
  order.timeline.push({
    status: newStatus,
    note: `Status changed to ${newStatus}.`,
    changedBy: actingUser.id,
    at: new Date(),
  });
  await order.save();

  const response = toOrderResponse(order);
  notificationService.notifyOrderStatusChanged(response, newStatus).catch(() => {});
  return response;
};

/**
 * A buyer may cancel only their own PENDING orders. An admin may
 * cancel any order that isn't already cancelled/refunded. Either way,
 * every unit this order had reserved is restored to stock — the same
 * inventory primitive order creation used to reserve it.
 */
const cancelOrder = async (orderId, actingUser) => {
  const order = await orderRepository.findById(orderId);
  if (!order) throw ApiError.notFound('Order not found.');

  if (actingUser.role === ROLES.BUYER) {
    if (order.buyer.toString() !== actingUser.id) throw ApiError.notFound('Order not found.');
    if (order.status !== ORDER_STATUSES.PENDING) {
      throw ApiError.badRequest('Only pending orders can be cancelled.');
    }
  } else if (actingUser.role !== ROLES.ADMIN) {
    throw ApiError.forbidden('You do not have permission to cancel this order.');
  }

  if (TERMINAL_ORDER_STATUSES.includes(order.status)) {
    throw ApiError.badRequest(`Order is already ${order.status}.`);
  }

  await Promise.all(order.items.map((item) => orderRepository.restoreProductStock(item.product, item.quantity)));

  order.status = ORDER_STATUSES.CANCELLED;
  order.timeline.push({
    status: ORDER_STATUSES.CANCELLED,
    note: 'Order cancelled.',
    changedBy: actingUser.id,
    at: new Date(),
  });
  await order.save();

  const response = toOrderResponse(order);
  notificationService.notifyOrderStatusChanged(response, ORDER_STATUSES.CANCELLED).catch(() => {});
  return response;
};

module.exports = {
  createOrder,
  listOrders,
  getOrderById,
  updateOrderStatus,
  cancelOrder,
};
