'use strict';

const ApiError = require('../utils/ApiError');
const productRepository = require('../repositories/product.repository');
const { slugify } = require('../utils/slugify');
const { buildSearchQuery, escapeRegex } = require('../utils/searchHelper');
const { PRODUCT_STATUSES, WRITABLE_PRODUCT_STATUS_VALUES } = require('../constants/productEnums');
const { ROLES } = require('../constants/roles');

/**
 * Phase 5 — Product CRUD (feature 1), listing (feature 2), search
 * (feature 3), filters (feature 4), status transitions (feature 7),
 * inventory (feature 8), featured-product feeds (feature 9),
 * publish-time validation (feature 10), and a card-view projection for
 * those feeds (feature 15 — Performance).
 */

// --------------------------------------------------------------------
// Slug / SKU generation
// --------------------------------------------------------------------

/**
 * Generates an SEO-friendly, unique slug from a title. On collision,
 * appends a sequential numeric suffix: iphone-15, iphone-15-2,
 * iphone-15-3, ... (never a random suffix — sequential is what makes
 * the slug predictable/readable for a product catalog).
 *
 * @param {string} title
 * @param {string} [excludeId] - product id to exclude (used on update)
 */
const generateUniqueSlug = async (title, excludeId) => {
  const base = slugify(title);
  let candidate = base;
  let suffix = 2;

  // eslint-disable-next-line no-await-in-loop
  while (await productRepository.existsBySlug(candidate, excludeId)) {
    candidate = `${base}-${suffix}`;
    suffix += 1;
  }

  return candidate;
};

/** Generates a unique SKU when the seller doesn't provide one. */
const generateUniqueSku = async () => {
  let candidate;
  let taken = true;

  while (taken) {
    candidate = `SKU-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
    // eslint-disable-next-line no-await-in-loop
    taken = await productRepository.existsBySku(candidate);
  }

  return candidate;
};

// --------------------------------------------------------------------
// Search
// --------------------------------------------------------------------

/** Fields searched directly on the Product document itself — case-insensitive, partial match (see utils/searchHelper). */
const DIRECT_SEARCH_FIELDS = ['title', 'slug', 'description', 'sku'];

/**
 * Builds the Mongo filter fragment for a free-text product search
 * across name, slug, description, SKU (direct fields) plus brand,
 * category, and tag names (resolved to ids first, since Product only
 * stores references). Case-insensitive, partial match throughout.
 * Returns `{}` (no-op) when there's no search term, so callers can
 * always spread the result into their query without branching.
 *
 * @param {string} q - raw value from `req.query.q`
 */
const buildSearchFilter = async (q) => {
  if (!q || !q.trim()) return {};

  const pattern = new RegExp(escapeRegex(q.trim()), 'i');
  const directClause = buildSearchQuery(q, DIRECT_SEARCH_FIELDS);
  const { brandIds, categoryIds, tagIds } = await productRepository.findRelatedIdsByName(pattern);

  const orClauses = [...(directClause.$or || [])];
  if (brandIds.length) orClauses.push({ brand: { $in: brandIds } });
  if (categoryIds.length) orClauses.push({ category: { $in: categoryIds } });
  if (tagIds.length) orClauses.push({ tags: { $in: tagIds } });

  return { $or: orClauses };
};

// --------------------------------------------------------------------
// Inventory
// --------------------------------------------------------------------

/**
 * Computes the derived inventory fields on top of the stored
 * stock/reservedStock/lowStockThreshold/allowBackorder values:
 *   - availableStock: stock minus whatever's reserved, never negative
 *   - isLowStock: some stock left, but at or under the threshold
 *   - isOutOfStock: nothing available and backorders aren't allowed
 *
 * Accepts a plain object (a lean list item, or a hydrated document
 * already converted via `.toJSON()`) and returns a new plain object —
 * never mutates its input.
 */
const withInventorySummary = (product) => {
  const stock = product.stock ?? 0;
  const reservedStock = product.reservedStock ?? 0;
  const lowStockThreshold = product.lowStockThreshold ?? 0;
  const availableStock = Math.max(stock - reservedStock, 0);

  return {
    ...product,
    availableStock,
    isLowStock: availableStock > 0 && availableStock <= lowStockThreshold,
    isOutOfStock: availableStock <= 0 && !product.allowBackorder,
  };
};

/** Converts a hydrated Mongoose document to the same plain-object shape lean() list items already have, then attaches the inventory summary. */
const toEnrichedProduct = (productDoc) => withInventorySummary(productDoc.toJSON());

// --------------------------------------------------------------------
// Ownership / visibility
// --------------------------------------------------------------------

/** Admin can touch any product; a seller may only touch their own. */
const assertOwnership = (product, actingUser) => {
  if (actingUser.role === ROLES.ADMIN) return;
  if (product.seller.toString() !== actingUser.id) {
    throw ApiError.forbidden('You do not have permission to manage this product.');
  }
};

/**
 * Only `published` is public. `draft` and `archived` are visible to
 * their owner or an admin only (`deleted` is handled by the caller —
 * it never reaches here). Reports 404 rather than 403 for a hidden
 * product so its existence isn't leaked to an unrelated caller.
 */
const assertVisible = (product, actingUser) => {
  if (product.status !== PRODUCT_STATUSES.PUBLISHED) {
    const isOwner = Boolean(actingUser) && product.seller.toString() === actingUser.id;
    const isAdmin = Boolean(actingUser) && actingUser.role === ROLES.ADMIN;
    if (!isOwner && !isAdmin) {
      throw ApiError.notFound('Product not found.');
    }
  }
};

/**
 * A product can only go `published` once it has at least a thumbnail
 * image — a draft can be built up without one, but it can't go live
 * without a photo. Category is already required unconditionally at the
 * schema level, so this only needs to check the image.
 *
 * @param {string} status - the status the product will end up with
 * @param {{ url?: string }} [thumbnail] - the thumbnail it will end up with
 */
const assertPublishRequirements = (status, thumbnail) => {
  if (status === PRODUCT_STATUSES.PUBLISHED && !thumbnail?.url) {
    throw ApiError.badRequest('A thumbnail image is required to publish a product.');
  }
};

// --------------------------------------------------------------------
// CRUD
// --------------------------------------------------------------------

/**
 * @param {object} data - validated request body
 * @param {{ id: string, role: string }} actingUser
 */
const createProduct = async (data, actingUser) => {
  const payload = { ...data };

  if (actingUser.role === ROLES.SELLER) {
    // A seller can only ever create a product for themselves — never
    // trust a `seller` field they submitted (mass-assignment guard).
    payload.seller = actingUser.id;
  } else if (!payload.seller) {
    throw ApiError.badRequest('Seller is required.');
  }

  assertPublishRequirements(payload.status, payload.thumbnail);

  if (payload.slug) {
    const candidate = slugify(payload.slug);
    if (await productRepository.existsBySlug(candidate)) {
      throw ApiError.conflict('A product with this slug already exists.');
    }
    payload.slug = candidate;
  } else {
    payload.slug = await generateUniqueSlug(payload.title);
  }

  if (payload.sku) {
    const candidate = payload.sku.trim().toUpperCase();
    if (await productRepository.existsBySku(candidate)) {
      throw ApiError.conflict('A product with this SKU already exists.');
    }
    payload.sku = candidate;
  } else {
    payload.sku = await generateUniqueSku();
  }

  const created = await productRepository.create(payload);
  return toEnrichedProduct(created);
};

const getProductById = async (id, actingUser) => {
  const product = await productRepository.findById(id);
  if (!product || product.status === PRODUCT_STATUSES.DELETED) {
    throw ApiError.notFound('Product not found.');
  }
  assertVisible(product, actingUser);
  return toEnrichedProduct(product);
};

const getProductBySlug = async (slug, actingUser) => {
  const product = await productRepository.findBySlug(slug);
  if (!product || product.status === PRODUCT_STATUSES.DELETED) {
    throw ApiError.notFound('Product not found.');
  }
  assertVisible(product, actingUser);
  return toEnrichedProduct(product);
};

/** Fetches a page from the repository and enriches every item with the inventory summary — shared by every listing function below. */
const fetchEnrichedList = async (filter, options) => {
  const { items, meta } = await productRepository.list(filter, options);
  return { items: items.map(withInventorySummary), meta };
};

/** Public catalog — published products only, regardless of any status filter the caller sent. */
const listPublicProducts = (filter = {}, options = {}) =>
  fetchEnrichedList({ ...filter, status: PRODUCT_STATUSES.PUBLISHED }, options);

/** A seller's own catalog (any status except deleted). Admins may also call this for a given sellerId. */
const listSellerProducts = async (sellerId, filter, options, actingUser) => {
  const isAdmin = actingUser.role === ROLES.ADMIN;
  const isOwner = actingUser.id === sellerId;
  if (!isAdmin && !isOwner) {
    throw ApiError.forbidden('You do not have permission to view these products.');
  }

  return fetchEnrichedList({ ...filter, seller: sellerId, status: { $ne: PRODUCT_STATUSES.DELETED } }, options);
};

/** Admin catalog view — sees every product, including drafts. Pass status: 'deleted' explicitly to view the trash. */
const listAdminProducts = (filter = {}, options = {}) => fetchEnrichedList(filter, options);

// --------------------------------------------------------------------
// Featured products (Feature 9) — curated public feeds, each a fixed
// filter/sort on top of the same published-only catalog. Options only
// ever carries page/limit here (see the curatedListQuerySchema
// validator) — sort is fixed per feed, not client-controlled.
// --------------------------------------------------------------------

/**
 * A narrower field set for the curated feeds below — they render a
 * catalog card, not a full product page, so there's no need to pull
 * long descriptions, galleries, download files, dimensions, or SEO
 * fields off disk for every item on every page. Deliberately NOT
 * applied to listPublicProducts/listSellerProducts/listAdminProducts:
 * those existed before this projection was added and an already-built
 * frontend may depend on fields outside this shortlist, so widening
 * their payload is left alone rather than risk silently breaking it.
 */
const CARD_PROJECTION = {
  title: 1,
  slug: 1,
  shortDescription: 1,
  thumbnail: 1,
  seller: 1,
  category: 1,
  brand: 1,
  tags: 1,
  type: 1,
  condition: 1,
  basePrice: 1,
  salePrice: 1,
  currency: 1,
  stock: 1,
  reservedStock: 1,
  lowStockThreshold: 1,
  allowBackorder: 1,
  status: 1,
  featured: 1,
  views: 1,
  salesCount: 1,
  ratingAverage: 1,
  ratingCount: 1,
  createdAt: 1,
  updatedAt: 1,
};

/** How far back "trending" looks. There's no event-tracking system yet, so this is a heuristic: recently listed AND already getting views/sales, not a true recent-velocity metric. */
const TRENDING_WINDOW_DAYS = 30;

/** Manually flagged by a seller/admin (the `featured` field) — newest first. */
const listFeaturedProducts = (options = {}) =>
  fetchEnrichedList(
    { status: PRODUCT_STATUSES.PUBLISHED, featured: true },
    { ...options, sort: { createdAt: -1 }, projection: CARD_PROJECTION }
  );

/** Published within the trending window, ranked by views then sales — see TRENDING_WINDOW_DAYS. */
const listTrendingProducts = (options = {}) => {
  const since = new Date(Date.now() - TRENDING_WINDOW_DAYS * 24 * 60 * 60 * 1000);
  return fetchEnrichedList(
    { status: PRODUCT_STATUSES.PUBLISHED, createdAt: { $gte: since } },
    { ...options, sort: { views: -1, salesCount: -1 }, projection: CARD_PROJECTION }
  );
};

/** All-time most-viewed published products. */
const listPopularProducts = (options = {}) =>
  fetchEnrichedList(
    { status: PRODUCT_STATUSES.PUBLISHED },
    { ...options, sort: { views: -1 }, projection: CARD_PROJECTION }
  );

/** Most recently published products. */
const listLatestProducts = (options = {}) =>
  fetchEnrichedList(
    { status: PRODUCT_STATUSES.PUBLISHED },
    { ...options, sort: { createdAt: -1 }, projection: CARD_PROJECTION }
  );

const updateProduct = async (id, updates, actingUser) => {
  const product = await productRepository.findById(id);
  if (!product || product.status === PRODUCT_STATUSES.DELETED) {
    throw ApiError.notFound('Product not found.');
  }
  assertOwnership(product, actingUser);

  const payload = { ...updates };

  if (actingUser.role !== ROLES.ADMIN) {
    // Sellers can't reassign a product to another seller.
    delete payload.seller;
  }

  assertPublishRequirements(
    payload.status !== undefined ? payload.status : product.status,
    payload.thumbnail !== undefined ? payload.thumbnail : product.thumbnail
  );

  if (payload.slug !== undefined) {
    const candidate = slugify(payload.slug);
    if (await productRepository.existsBySlug(candidate, id)) {
      throw ApiError.conflict('A product with this slug already exists.');
    }
    payload.slug = candidate;
  } else if (payload.title && payload.title !== product.title) {
    // Pre-empt the model's auto-slug hook with a checked, unique value
    // so a title change can't collide silently (E11000) on save.
    payload.slug = await generateUniqueSlug(payload.title, id);
  }

  if (payload.sku !== undefined) {
    const candidate = payload.sku.trim().toUpperCase();
    if (await productRepository.existsBySku(candidate, id)) {
      throw ApiError.conflict('A product with this SKU already exists.');
    }
    payload.sku = candidate;
  }

  const updated = await productRepository.updateById(id, payload);
  return toEnrichedProduct(updated);
};

/**
 * Dedicated status transition (draft/published/archived only —
 * `deleted` can never be set this way, only through
 * softDeleteProduct). A clearer, narrower alternative to sending
 * `status` through the general-purpose updateProduct when that's the
 * only thing changing.
 */
const changeProductStatus = async (id, status, actingUser) => {
  if (!WRITABLE_PRODUCT_STATUS_VALUES.includes(status)) {
    throw ApiError.badRequest('Invalid status.');
  }

  const product = await productRepository.findById(id);
  if (!product || product.status === PRODUCT_STATUSES.DELETED) {
    throw ApiError.notFound('Product not found.');
  }
  assertOwnership(product, actingUser);
  assertPublishRequirements(status, product.thumbnail);

  const updated = await productRepository.updateById(id, { status });
  return toEnrichedProduct(updated);
};

/** Soft delete only — a deleted product is never physically removed, just hidden behind status: 'deleted'. */
const softDeleteProduct = async (id, actingUser) => {
  const product = await productRepository.findById(id);
  if (!product || product.status === PRODUCT_STATUSES.DELETED) {
    throw ApiError.notFound('Product not found.');
  }
  assertOwnership(product, actingUser);
  return productRepository.softDeleteById(id);
};

/** Phase 17A, Part 2 — thin pass-through so callers (product.controller.js) never import the repository directly. */
const findSellerIdsByMinRating = (minRating) => productRepository.findSellerIdsByMinRating(minRating);

module.exports = {
  generateUniqueSlug,
  generateUniqueSku,
  buildSearchFilter,
  findSellerIdsByMinRating,
  withInventorySummary,
  toEnrichedProduct,
  assertOwnership,
  createProduct,
  getProductById,
  getProductBySlug,
  listPublicProducts,
  listSellerProducts,
  listAdminProducts,
  listFeaturedProducts,
  listTrendingProducts,
  listPopularProducts,
  listLatestProducts,
  updateProduct,
  changeProductStatus,
  softDeleteProduct,
};
