'use strict';

const ApiError = require('../utils/ApiError');
const contactMessageRepository = require('../repositories/contactMessage.repository');
const { CONTACT_STATUSES } = require('../constants/cmsEnums');

/** Phase 10.3 — Contact Management Service (Part 4). Public submit; every read/write past that is admin-only, enforced at the route level. */

const submitMessage = (body) =>
  contactMessageRepository.create({
    name: body.name,
    email: body.email,
    phone: body.phone || '',
    subject: body.subject || '',
    message: body.message,
  });

const getMessageById = async (id) => {
  const message = await contactMessageRepository.findById(id);
  if (!message) throw ApiError.notFound('Contact message not found.');
  return message;
};

const listMessages = (filter = {}, options = {}) => contactMessageRepository.list(filter, options);

/**
 * Updates status/adminNotes. Moving into `resolved` stamps
 * `resolvedAt`/`resolvedBy` once, the first time only — re-resolving
 * (or resolving again after a reopen) never overwrites the original
 * resolution record.
 */
const updateMessageStatus = async (id, body, actingUser) => {
  const existing = await contactMessageRepository.findById(id);
  if (!existing) throw ApiError.notFound('Contact message not found.');

  const updates = {};
  if (body.status !== undefined) updates.status = body.status;
  if (body.adminNotes !== undefined) updates.adminNotes = body.adminNotes;

  if (body.status === CONTACT_STATUSES.RESOLVED && existing.status !== CONTACT_STATUSES.RESOLVED) {
    updates.resolvedAt = new Date();
    updates.resolvedBy = actingUser.id;
  }

  const message = await contactMessageRepository.updateById(id, updates);
  if (!message) throw ApiError.notFound('Contact message not found.');
  return message;
};

const deleteMessage = async (id) => {
  const deleted = await contactMessageRepository.deleteById(id);
  if (!deleted) throw ApiError.notFound('Contact message not found.');
  return deleted;
};

module.exports = { submitMessage, getMessageById, listMessages, updateMessageStatus, deleteMessage };
