'use strict';

const ApiError = require('../utils/ApiError');
const categoryRepository = require('../repositories/category.repository');
const { slugify, withUniqueSuffix } = require('../utils/slugify');

/**
 * Foundation-level service for Phase 3. Deliberately limited to slug
 * generation and basic relational integrity (parent must exist, a
 * category with children can't be deleted) — the full admin catalog
 * workflow (bulk reorder, menu builder, etc.) is business logic for a
 * later phase and is not implemented here.
 */

/** Generates a slug from a name, appending a random suffix on collision. */
const generateUniqueSlug = async (name) => {
  const base = slugify(name);
  const exists = await categoryRepository.existsBySlug(base);
  return exists ? withUniqueSuffix(base) : base;
};

const createCategory = async (data) => {
  if (data.parentCategory) {
    const parent = await categoryRepository.findById(data.parentCategory);
    if (!parent) {
      throw ApiError.badRequest('Parent category not found.');
    }
  }

  const slug = data.slug ? slugify(data.slug) : await generateUniqueSlug(data.name);
  return categoryRepository.create({ ...data, slug });
};

const getCategoryById = async (id) => {
  const category = await categoryRepository.findById(id);
  if (!category) throw ApiError.notFound('Category not found.');
  return category;
};

const getCategoryBySlug = async (slug) => {
  const category = await categoryRepository.findBySlug(slug);
  if (!category) throw ApiError.notFound('Category not found.');
  return category;
};

const listCategories = (filter = {}, options = {}) => categoryRepository.list(filter, options);

const getChildren = (parentId = null) => categoryRepository.findChildren(parentId);

const updateCategory = async (id, updates) => {
  if (updates.parentCategory) {
    if (updates.parentCategory === id) {
      throw ApiError.badRequest('A category cannot be its own parent.');
    }
    const parent = await categoryRepository.findById(updates.parentCategory);
    if (!parent) {
      throw ApiError.badRequest('Parent category not found.');
    }
  }

  const category = await categoryRepository.updateById(id, updates);
  if (!category) throw ApiError.notFound('Category not found.');
  return category;
};

/** Refuses to delete a category that still has child categories, to avoid orphaning the tree. */
const deleteCategory = async (id) => {
  const childCount = await categoryRepository.countChildren(id);
  if (childCount > 0) {
    throw ApiError.conflict('Cannot delete a category that still has subcategories.');
  }

  const deleted = await categoryRepository.deleteById(id);
  if (!deleted) throw ApiError.notFound('Category not found.');
  return deleted;
};

module.exports = {
  generateUniqueSlug,
  createCategory,
  getCategoryById,
  getCategoryBySlug,
  listCategories,
  getChildren,
  updateCategory,
  deleteCategory,
};
