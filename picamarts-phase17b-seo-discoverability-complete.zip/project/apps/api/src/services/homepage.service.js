'use strict';

const homepageRepository = require('../repositories/homepage.repository');

/**
 * Phase 10.3 — Homepage CMS Service (Part 3).
 *
 * A fresh install has no HomepageConfig document yet — `getHomepageConfig`
 * returns a sensible empty default shape without persisting anything
 * (same "don't write just to answer a read" convention notification
 * preferences already use), so the public homepage endpoint and the
 * admin editing screen both get a stable shape to render immediately.
 */
const emptyDefault = () => ({
  heroBanner: { title: '', subtitle: '', image: { url: '', publicId: '' }, ctaText: '', ctaLink: '' },
  featuredCategories: [],
  featuredProducts: [],
  testimonials: [],
  promotionalSections: [],
  faqSection: [],
  footerContent: { aboutText: '', socialLinks: [], contactInfo: { email: '', phone: '', address: '' }, copyrightText: '' },
  seo: {},
});

const getHomepageConfig = async () => {
  const config = await homepageRepository.findSingleton();
  return config || emptyDefault();
};

const updateHomepageConfig = async (updates, actingUser) =>
  homepageRepository.upsertSingleton({ ...updates, updatedBy: actingUser.id });

module.exports = { getHomepageConfig, updateHomepageConfig };
