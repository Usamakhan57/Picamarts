'use strict';

const ApiError = require('../utils/ApiError');
const sellerRepository = require('../repositories/seller.repository');
const userRepository = require('../repositories/user.repository');
const Product = require('../models/Product');
const { PRODUCT_STATUSES } = require('../constants/productEnums');
const { SELLER_STATUSES } = require('../constants/sellerStatus');
const { slugify, withUniqueSuffix } = require('../utils/slugify');
const { sendMail, sendAdminMail } = require('../emails/mailer');
const config = require('../config');
const sellerApplicationReceivedEmail = require('../emails/templates/sellerApplicationReceivedEmail');
const sellerApprovedEmail = require('../emails/templates/sellerApprovedEmail');
const sellerRejectedEmail = require('../emails/templates/sellerRejectedEmail');
const sellerSuspendedEmail = require('../emails/templates/sellerSuspendedEmail');

/**
 * Fields a seller may edit themselves. Everything status/commission/
 * verification-review related is admin-only and set through the
 * dedicated workflow actions below instead.
 */
const SELF_EDITABLE_FIELDS = ['storeName', 'storeDescription', 'logo', 'banner', 'phone', 'website', 'socialLinks'];

const generateUniqueSlug = async (storeName) => {
  const base = slugify(storeName);
  const exists = await sellerRepository.existsBySlug(base);
  return exists ? withUniqueSuffix(base) : base;
};

const pickAllowedUpdates = (updates, allowedFields) =>
  allowedFields.reduce((acc, field) => {
    if (updates[field] !== undefined) acc[field] = updates[field];
    return acc;
  }, {});

/**
 * Submits a new seller application for the authenticated user. A user
 * may only have one seller profile — reapplying after a rejection is
 * done via `submitVerificationDocument`, not by calling this again.
 */
const applyAsSeller = async (userId, data) => {
  const alreadyApplied = await sellerRepository.existsByUserId(userId);
  if (alreadyApplied) {
    throw ApiError.conflict('A seller application already exists for this account.');
  }

  const slug = await generateUniqueSlug(data.storeName);

  const seller = await sellerRepository.create({
    ...pickAllowedUpdates(data, SELF_EDITABLE_FIELDS),
    user: userId,
    storeSlug: slug,
    verificationDocument: data.verificationDocument,
    submittedAt: new Date(),
  });

  const user = await userRepository.findById(userId);
  const { subject, html, text } = sellerApplicationReceivedEmail({ name: user.name, storeName: seller.storeName });
  await sendMail({ to: user.email, subject, html, text });
  await sendAdminMail({
    subject: `New seller application: ${seller.storeName}`,
    html: `<p>${user.name} (${user.email}) applied to sell as "${seller.storeName}". Review it in the admin dashboard.</p>`,
    text: `${user.name} (${user.email}) applied to sell as "${seller.storeName}". Review it in the admin dashboard.`,
  });

  return seller;
};

const getSellerByUserId = async (userId) => {
  const seller = await sellerRepository.findByUserId(userId);
  if (!seller) throw ApiError.notFound('No seller profile found for this account.');
  return seller;
};

const getSellerById = async (id) => {
  const seller = await sellerRepository.findById(id);
  if (!seller) throw ApiError.notFound('Seller not found.');
  return seller;
};

/** Public storefront lookup — only surfaces approved stores. */
const getPublicStoreBySlug = async (slug) => {
  const seller = await sellerRepository.findBySlug(slug);
  if (!seller || seller.status !== SELLER_STATUSES.APPROVED) {
    throw ApiError.notFound('Store not found.');
  }
  return seller;
};

const listSellers = (filter = {}, options = {}) => sellerRepository.listWithUser(filter, options);

/**
 * Admin detail view only (Phase 15C, Part 4) — returns the seller with
 * its owning user's name/email populated. Kept separate from
 * `getSellerById` above, which the approve/reject/suspend/reinstate
 * workflow relies on returning a plain `user` id.
 */
const getSellerByIdForAdmin = async (id) => {
  const seller = await sellerRepository.findByIdWithUser(id);
  if (!seller) throw ApiError.notFound('Seller not found.');
  return seller;
};

/** Self-service profile update — store details only, never status/commission. */
const updateOwnProfile = async (userId, updates) => {
  const seller = await getSellerByUserId(userId);
  const allowedUpdates = pickAllowedUpdates(updates, SELF_EDITABLE_FIELDS);

  if (allowedUpdates.storeName && allowedUpdates.storeName !== seller.storeName) {
    allowedUpdates.storeSlug = await generateUniqueSlug(allowedUpdates.storeName);
  }

  return sellerRepository.updateById(seller.id, allowedUpdates);
};

/**
 * Submits (or resubmits) a verification document. Resubmitting after a
 * rejection moves the application back to `pending` for another review;
 * it has no effect on an already-approved or suspended seller's status.
 */
const submitVerificationDocument = async (userId, document) => {
  const seller = await getSellerByUserId(userId);

  const update = {
    verificationDocument: document,
    submittedAt: new Date(),
  };

  if (seller.status === SELLER_STATUSES.REJECTED) {
    update.status = SELLER_STATUSES.PENDING;
    update.statusReason = '';
    update.reviewedAt = null;
    update.reviewedBy = null;
  }

  return sellerRepository.updateById(seller.id, update);
};

/**
 * Seller's own dashboard: their store profile plus a lightweight product
 * count breakdown by status. Reads `Product` directly (read-only
 * aggregation) — full product CRUD/business logic is out of scope for
 * this phase and arrives separately.
 */
const getDashboard = async (userId) => {
  const seller = await getSellerByUserId(userId);

  const [draft, published, archived, total] = await Promise.all([
    Product.countDocuments({ seller: userId, status: PRODUCT_STATUSES.DRAFT }),
    Product.countDocuments({ seller: userId, status: PRODUCT_STATUSES.PUBLISHED }),
    Product.countDocuments({ seller: userId, status: PRODUCT_STATUSES.ARCHIVED }),
    Product.countDocuments({ seller: userId }),
  ]);

  return {
    seller,
    products: { total, draft, published, archived },
  };
};

// ---------------------------------------------------------------------
// Admin workflow
// ---------------------------------------------------------------------

const approveSeller = async (id, adminId) => {
  const seller = await getSellerById(id);

  const updated = await sellerRepository.updateById(id, {
    status: SELLER_STATUSES.APPROVED,
    statusReason: '',
    reviewedAt: new Date(),
    reviewedBy: adminId,
  });

  const user = await userRepository.findById(seller.user);
  const { subject, html, text } = sellerApprovedEmail({
    name: user.name,
    storeName: seller.storeName,
    dashboardUrl: `${config.frontendUrl}/seller/dashboard`,
  });
  await sendMail({ to: user.email, subject, html, text });

  return updated;
};

const rejectSeller = async (id, adminId, reason = '') => {
  const seller = await getSellerById(id);

  const updated = await sellerRepository.updateById(id, {
    status: SELLER_STATUSES.REJECTED,
    statusReason: reason,
    reviewedAt: new Date(),
    reviewedBy: adminId,
  });

  const user = await userRepository.findById(seller.user);
  const { subject, html, text } = sellerRejectedEmail({ name: user.name, storeName: seller.storeName, reason });
  await sendMail({ to: user.email, subject, html, text });

  return updated;
};

const suspendSeller = async (id, adminId, reason = '') => {
  const seller = await getSellerById(id);

  if (seller.status !== SELLER_STATUSES.APPROVED) {
    throw ApiError.badRequest('Only an approved seller can be suspended.');
  }

  const updated = await sellerRepository.updateById(id, {
    status: SELLER_STATUSES.SUSPENDED,
    statusReason: reason,
    reviewedAt: new Date(),
    reviewedBy: adminId,
  });

  const user = await userRepository.findById(seller.user);
  const { subject, html, text } = sellerSuspendedEmail({ name: user.name, storeName: seller.storeName, reason });
  await sendMail({ to: user.email, subject, html, text });

  return updated;
};

const reinstateSeller = async (id, adminId) => {
  const seller = await getSellerById(id);

  if (seller.status !== SELLER_STATUSES.SUSPENDED) {
    throw ApiError.badRequest('Only a suspended seller can be reinstated.');
  }

  const updated = await sellerRepository.updateById(id, {
    status: SELLER_STATUSES.APPROVED,
    statusReason: '',
    reviewedAt: new Date(),
    reviewedBy: adminId,
  });

  const user = await userRepository.findById(seller.user);
  const { subject, html, text } = sellerApprovedEmail({
    name: user.name,
    storeName: seller.storeName,
    dashboardUrl: `${config.frontendUrl}/seller/dashboard`,
  });
  await sendMail({ to: user.email, subject, html, text });

  return updated;
};

/** Admin-only field updates (e.g. correcting a commission rate). */
const updateSellerByAdmin = async (id, updates) => {
  const allowedUpdates = pickAllowedUpdates(updates, ['commissionRate', 'storeName', 'storeDescription']);
  const seller = await sellerRepository.updateById(id, allowedUpdates);
  if (!seller) throw ApiError.notFound('Seller not found.');
  return seller;
};

const deleteSeller = async (id) => {
  const deleted = await sellerRepository.deleteById(id);
  if (!deleted) throw ApiError.notFound('Seller not found.');
  return deleted;
};

module.exports = {
  generateUniqueSlug,
  applyAsSeller,
  getSellerByUserId,
  getSellerById,
  getPublicStoreBySlug,
  listSellers,
  getSellerByIdForAdmin,
  updateOwnProfile,
  submitVerificationDocument,
  getDashboard,
  approveSeller,
  rejectSeller,
  suspendSeller,
  reinstateSeller,
  updateSellerByAdmin,
  deleteSeller,
};
