'use strict';

const crypto = require('crypto');
const ApiError = require('../utils/ApiError');
const config = require('../config');
const stripe = require('../config/stripe');
const walletRepository = require('../repositories/wallet.repository');
const withdrawalRequestRepository = require('../repositories/withdrawalRequest.repository');
const sellerRepository = require('../repositories/seller.repository');
const { LEDGER_DIRECTIONS, LEDGER_CATEGORIES } = require('../constants/walletEnums');
const { PAYOUT_STATUSES } = require('../constants/payoutEnums');

/**
 * Phase 16C — Seller Payouts & Stripe Transfers.
 *
 * The only place that writes to WithdrawalRequest, and the only place
 * (outside wallet.service.js) that writes Wallet/WalletLedgerEntry.
 * Reuses the existing Stripe client (`config/stripe.js`, unmodified)
 * and `sellerRepository.findByUserId` (unmodified) — no new Stripe
 * client construction, per the brief's "do not duplicate Stripe
 * client logic".
 *
 * Explicitly OUT of scope here (Phase 16D): refund processing,
 * returns, disputes, chargebacks, buyer refund workflow.
 */

const round2 = (n) => Math.round(n * 100) / 100;
const idStr = (value) => (value?.toString ? value.toString() : value);
/** Stripe expects the smallest currency unit (e.g. cents for USD) as an integer — mirrors payment.service.js's own toMinorUnits, kept local so this module has zero coupling to payment.service.js internals. */
const toMinorUnits = (amount) => Math.round(amount * 100);

// --------------------------------------------------------------------
// Response shaping
// --------------------------------------------------------------------

const toRequestResponse = (r) => ({
  id: idStr(r._id ?? r.id),
  seller: idStr(r.seller),
  amount: round2(r.amount),
  currency: r.currency,
  status: r.status,
  stripeTransferId: r.stripeTransferId || '',
  attemptCount: r.attemptCount || 0,
  failureReason: r.failureReason || '',
  note: r.note || '',
  adminNote: r.adminNote || '',
  requestedAt: r.requestedAt,
  reviewedAt: r.reviewedAt || null,
  completedAt: r.completedAt || null,
  cancelledAt: r.cancelledAt || null,
  createdAt: r.createdAt,
});

// --------------------------------------------------------------------
// Part 1/2 — Create / Cancel withdrawal requests (with balance locking)
// --------------------------------------------------------------------

/**
 * Creates a withdrawal request and immediately locks the requested
 * amount out of `availableBalance` into `lockedBalance` (the "balance
 * locking" Part 2 asks for — a single WITHDRAWAL_HOLD ledger debit,
 * not a separate reservation system). Requires the seller to have a
 * usable Stripe Connect destination (Part 3 needs somewhere to send
 * the transfer) and rejects a second concurrent open request (Part
 * 1's "prevent duplicate requests").
 */
const createWithdrawalRequest = async (sellerId, { amount, note }) => {
  if (!(amount > 0)) throw ApiError.badRequest('Withdrawal amount must be greater than 0.');

  const seller = await sellerRepository.findByUserId(sellerId);
  if (!seller) throw ApiError.notFound('No seller profile found.');
  if (!seller.stripeAccount?.accountId) {
    throw ApiError.badRequest('Connect a payout account with Stripe before requesting a withdrawal.');
  }
  if (!seller.stripeAccount?.payoutsEnabled) {
    throw ApiError.badRequest('Your Stripe payout account is not yet enabled to receive transfers. Finish onboarding first.');
  }

  const alreadyOpen = await withdrawalRequestRepository.hasOpenRequest(sellerId);
  if (alreadyOpen) {
    throw ApiError.conflict('You already have an active withdrawal request in progress.');
  }

  const wallet = await walletRepository.getOrCreateForSeller(sellerId);
  if (amount > wallet.availableBalance) {
    throw ApiError.badRequest('Withdrawal amount exceeds your available balance.');
  }

  const request = await withdrawalRequestRepository.create({
    seller: sellerId,
    wallet: wallet._id,
    amount,
    currency: config.stripe.currency,
    status: PAYOUT_STATUSES.PENDING,
    stripeAccountId: seller.stripeAccount.accountId,
    idempotencyKey: `payout_${crypto.randomUUID()}`,
    note: note || '',
    requestedAt: new Date(),
  });

  const afterHold = await walletRepository.applyBalanceDelta(sellerId, { availableDelta: -amount, lockedDelta: amount });
  await walletRepository.createLedgerEntry({
    seller: sellerId,
    wallet: afterHold._id,
    direction: LEDGER_DIRECTIONS.DEBIT,
    category: LEDGER_CATEGORIES.WITHDRAWAL_HOLD,
    amount,
    balanceAfter: afterHold.availableBalance,
    note: `Withdrawal requested — held pending approval.`,
  });

  return toRequestResponse(request);
};

/** Releases a request's lock back into `availableBalance` — shared by cancel/reject/failure-that-gives-up paths. */
const releaseLock = async (sellerId, amount, note) => {
  const afterRelease = await walletRepository.applyBalanceDelta(sellerId, { availableDelta: amount, lockedDelta: -amount });
  await walletRepository.createLedgerEntry({
    seller: sellerId,
    wallet: afterRelease._id,
    direction: LEDGER_DIRECTIONS.CREDIT,
    category: LEDGER_CATEGORIES.WITHDRAWAL_RELEASE,
    amount,
    balanceAfter: afterRelease.availableBalance,
    note,
  });
};

/** Seller cancels their own request — only while it's still PENDING (Part 1's "before processing"). */
const cancelWithdrawalRequest = async (sellerId, requestId) => {
  const request = await withdrawalRequestRepository.findById(requestId);
  if (!request || idStr(request.seller) !== idStr(sellerId)) throw ApiError.notFound('Withdrawal request not found.');

  const updated = await withdrawalRequestRepository.transitionStatus(requestId, PAYOUT_STATUSES.PENDING, {
    status: PAYOUT_STATUSES.CANCELLED,
    cancelledAt: new Date(),
  });
  if (!updated) throw ApiError.conflict('Only a pending request can be cancelled.');

  await releaseLock(sellerId, request.amount, 'Withdrawal request cancelled by seller.');
  return toRequestResponse(updated);
};

// --------------------------------------------------------------------
// Part 3/5/8 — Stripe Transfer execution (approve → process → complete/fail, + retry)
// --------------------------------------------------------------------

/**
 * Attempts the actual Stripe Transfer for a request already in
 * APPROVED or FAILED status, moving it through PROCESSING to either
 * COMPLETED or back to FAILED. Idempotent across retries: the SAME
 * `idempotencyKey` is sent on every attempt (Part 8's "prevent double
 * transfers" — a network-timeout-then-retry can't create two real
 * Stripe transfers for one request).
 */
const processPayout = async (request) => {
  const processing = await withdrawalRequestRepository.transitionStatus(request._id, request.status, {
    status: PAYOUT_STATUSES.PROCESSING,
    $inc: { attemptCount: 1 },
  });
  if (!processing) throw ApiError.conflict('Request is no longer in a processable state.');

  try {
    const transfer = await stripe.transfers.create(
      {
        amount: toMinorUnits(request.amount),
        currency: request.currency,
        destination: request.stripeAccountId,
        metadata: { withdrawalRequestId: idStr(request._id), sellerId: idStr(request.seller) },
      },
      { idempotencyKey: request.idempotencyKey }
    );

    const completed = await withdrawalRequestRepository.transitionStatus(request._id, PAYOUT_STATUSES.PROCESSING, {
      status: PAYOUT_STATUSES.COMPLETED,
      stripeTransferId: transfer.id,
      failureReason: '',
      completedAt: new Date(),
    });

    const afterComplete = await walletRepository.applyBalanceDelta(request.seller, {
      lockedDelta: -request.amount,
      totalWithdrawnDelta: request.amount,
    });
    await walletRepository.createLedgerEntry({
      seller: request.seller,
      wallet: afterComplete._id,
      direction: LEDGER_DIRECTIONS.DEBIT,
      category: LEDGER_CATEGORIES.WITHDRAWAL_COMPLETED,
      // Zero-amount informational marker — the funds already left
      // `availableBalance` at hold time (see class comment / WITHDRAWAL_HOLD),
      // so a nonzero entry here would double-count against
      // pendingBalance's live ledger sum. Same convention
      // wallet.service.js#recordClosingBalanceSnapshot already uses.
      amount: 0,
      balanceAfter: afterComplete.availableBalance,
      note: `Payout completed — Stripe transfer ${transfer.id}.`,
    });

    return toRequestResponse(completed);
  } catch (error) {
    const failed = await withdrawalRequestRepository.transitionStatus(request._id, PAYOUT_STATUSES.PROCESSING, {
      status: PAYOUT_STATUSES.FAILED,
      failureReason: error.message || 'Stripe transfer failed.',
    });
    return toRequestResponse(failed || request);
  }
};

/** Admin approves a PENDING request and immediately attempts the transfer. */
const approveWithdrawalRequest = async (requestId, adminId) => {
  const approved = await withdrawalRequestRepository.transitionStatus(requestId, PAYOUT_STATUSES.PENDING, {
    status: PAYOUT_STATUSES.APPROVED,
    reviewedAt: new Date(),
    reviewedBy: adminId,
  });
  if (!approved) throw ApiError.conflict('Only a pending request can be approved.');

  return processPayout(approved);
};

/** Admin rejects a PENDING request and releases its balance lock. */
const rejectWithdrawalRequest = async (requestId, adminId, adminNote) => {
  const rejected = await withdrawalRequestRepository.transitionStatus(requestId, PAYOUT_STATUSES.PENDING, {
    status: PAYOUT_STATUSES.REJECTED,
    reviewedAt: new Date(),
    reviewedBy: adminId,
    adminNote: adminNote || '',
  });
  if (!rejected) throw ApiError.conflict('Only a pending request can be rejected.');

  await releaseLock(rejected.seller, rejected.amount, `Withdrawal request rejected by admin.${adminNote ? ` Reason: ${adminNote}` : ''}`);
  return toRequestResponse(rejected);
};

/** Admin retries a FAILED request's Stripe transfer (Part 5's "retry failed payouts"). */
const retryWithdrawalRequest = async (requestId) => {
  const request = await withdrawalRequestRepository.findById(requestId);
  if (!request || request.status !== PAYOUT_STATUSES.FAILED) {
    throw ApiError.conflict('Only a failed request can be retried.');
  }
  return processPayout(request);
};

// --------------------------------------------------------------------
// Part 6 — Seller payout history
// --------------------------------------------------------------------

const getSellerRequests = async (sellerId, { page, limit } = {}) => {
  const { items, meta } = await withdrawalRequestRepository.listForSeller(sellerId, { page, limit });
  return { items: items.map(toRequestResponse), meta };
};

// --------------------------------------------------------------------
// Part 4/7 — Admin payout queue + finance dashboard totals
// --------------------------------------------------------------------

const getAdminQueue = async ({ status, page, limit } = {}) => {
  const filter = status ? { status } : {};
  const { items, meta } = await withdrawalRequestRepository.listForAdmin(filter, { page, limit });
  return { items: items.map(toRequestResponse), meta };
};

const getAdminPayoutOverview = async () => {
  const byStatus = await withdrawalRequestRepository.sumByStatus();
  const totalsFor = (status) => byStatus[status] || { total: 0, count: 0 };

  return {
    pending: totalsFor(PAYOUT_STATUSES.PENDING),
    approved: totalsFor(PAYOUT_STATUSES.APPROVED),
    processing: totalsFor(PAYOUT_STATUSES.PROCESSING),
    completed: totalsFor(PAYOUT_STATUSES.COMPLETED),
    failed: totalsFor(PAYOUT_STATUSES.FAILED),
    rejected: totalsFor(PAYOUT_STATUSES.REJECTED),
    cancelled: totalsFor(PAYOUT_STATUSES.CANCELLED),
    totalPaid: round2(totalsFor(PAYOUT_STATUSES.COMPLETED).total),
    totalPending: round2(
      totalsFor(PAYOUT_STATUSES.PENDING).total + totalsFor(PAYOUT_STATUSES.APPROVED).total + totalsFor(PAYOUT_STATUSES.PROCESSING).total
    ),
  };
};

module.exports = {
  createWithdrawalRequest,
  cancelWithdrawalRequest,
  approveWithdrawalRequest,
  rejectWithdrawalRequest,
  retryWithdrawalRequest,
  getSellerRequests,
  getAdminQueue,
  getAdminPayoutOverview,
  // exported for unit testing in isolation
  processPayout,
  toRequestResponse,
};
