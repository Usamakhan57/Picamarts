'use strict';

const ApiError = require('../utils/ApiError');
const wishlistRepository = require('../repositories/wishlist.repository');
const productService = require('./product.service');
const cartService = require('./cart.service');

/**
 * Phase 7, Part 2 — Wishlist. Every buyer's DEFAULT wishlist (see
 * Wishlist model), mirroring Cart's structure. Every add goes through
 * productService.getProductById so a buyer can only wishlist a
 * product they could actually see (draft/archived/deleted products
 * 404 exactly like everywhere else) — that check is never duplicated
 * here.
 *
 * Phase 17A.2, Part 2 — Wishlist Enhancements adds multiple named
 * wishlists per buyer, public/private + shareable links, moving items
 * between wishlists, and per-wishlist analytics — all in the second
 * half of this file, operating on an ARBITRARY wishlist id rather than
 * just the default. Nothing above that section changed.
 */

// --------------------------------------------------------------------
// Response shaping
// --------------------------------------------------------------------

/** Shapes one populated wishlist item for the response. */
const serializeWishlistItem = (item) => {
  const { product } = item;

  if (!product) {
    return { id: item._id.toString(), product: null, unavailableReason: 'Product no longer exists.' };
  }

  return {
    id: item._id.toString(),
    product: {
      id: product._id.toString(),
      title: product.title,
      slug: product.slug,
      thumbnail: product.thumbnail,
      basePrice: product.basePrice,
      salePrice: product.salePrice,
      currency: product.currency,
      status: product.status,
    },
    addedAt: item.createdAt,
  };
};

/** Shapes a full (populated) wishlist document — or `null` for a buyer with no wishlist yet — into the API response shape. */
const toWishlistResponse = (wishlist) => ({
  id: wishlist ? wishlist._id.toString() : null,
  itemCount: wishlist?.items?.length || 0,
  items: (wishlist?.items || []).map(serializeWishlistItem),
});

/** Summary shape for the "list my wishlists" view (Phase 17A.2) — no items, just enough to render a picker/list. */
const toWishlistSummary = (wishlist) => ({
  id: wishlist._id.toString(),
  name: wishlist.name,
  description: wishlist.description,
  isDefault: wishlist.isDefault,
  isPublic: wishlist.isPublic,
  shareToken: wishlist.isPublic ? wishlist.shareToken : null,
  itemCount: wishlist.items.length,
  createdAt: wishlist.createdAt,
  updatedAt: wishlist.updatedAt,
});

/** Full detail shape (rename/visibility metadata + items) for GET /wishlists/:id and the shared-link view. */
const toWishlistDetail = (wishlist) => ({ ...toWishlistSummary(wishlist), ...toWishlistResponse(wishlist) });

/** 404s (never 403) on a wishlist that doesn't belong to the caller — same "don't leak existence" convention product.service.js#assertVisible uses. */
const assertOwnership = (wishlist, buyerId) => {
  if (!wishlist || wishlist.buyer.toString() !== buyerId) {
    throw ApiError.notFound('Wishlist not found.');
  }
};

/** Re-fetches the buyer's DEFAULT wishlist populated (for response shaping) after a mutation was saved via the raw/unpopulated doc. */
const respondWith = async (buyerId) => toWishlistResponse(await wishlistRepository.findByBuyer(buyerId));

// --------------------------------------------------------------------
// Reads (default wishlist)
// --------------------------------------------------------------------

/** Never creates a wishlist row just to answer a read — same convention as Cart. */
const getWishlist = async (buyerId) => respondWith(buyerId);

// --------------------------------------------------------------------
// Writes (default wishlist)
// --------------------------------------------------------------------

const getOrCreateRawWishlist = async (buyerId) =>
  (await wishlistRepository.findRawByBuyer(buyerId)) || wishlistRepository.createForBuyer(buyerId);

/**
 * Adds a product to the buyer's default wishlist. Idempotent on
 * duplicates — a product already saved just returns the wishlist
 * unchanged rather than erroring, since "add to wishlist" is normally
 * a toggle-style action in the UI, not a strict create.
 */
const addItem = async (buyerId, productId, actingUser) => {
  await productService.getProductById(productId, actingUser);

  const wishlistDoc = await getOrCreateRawWishlist(buyerId);
  const alreadySaved = wishlistDoc.items.some((item) => item.product.toString() === productId);

  if (!alreadySaved) {
    wishlistDoc.items.push({ product: productId });
    await wishlistDoc.save();
  }

  return respondWith(buyerId);
};

/** Removes a single product from the default wishlist by product id (not by line id — see wishlist.routes.js). */
const removeItem = async (buyerId, productId) => {
  const wishlistDoc = await wishlistRepository.findRawByBuyer(buyerId);
  const item = wishlistDoc?.items.find((entry) => entry.product.toString() === productId);
  if (!item) {
    throw ApiError.notFound('Wishlist item not found.');
  }

  item.deleteOne();
  await wishlistDoc.save();
  return respondWith(buyerId);
};

/** Empties the default wishlist. A buyer with no wishlist yet is already "empty" — no-op success, not a 404 (same convention as Cart). */
const clearWishlist = async (buyerId) => {
  const wishlistDoc = await wishlistRepository.findRawByBuyer(buyerId);
  if (!wishlistDoc) return toWishlistResponse(null);

  wishlistDoc.items = [];
  await wishlistDoc.save();
  return toWishlistResponse(wishlistDoc);
};

/**
 * Moves a wishlist item into the buyer's cart: adds it to the cart
 * FIRST (quantity 1) — this is where published/stock rules are
 * enforced (via cartService, not re-implemented here) and can reject
 * the move — and only removes it from the wishlist once that succeeds,
 * so a rejected move leaves the wishlist untouched.
 */
const moveItemToCart = async (buyerId, productId, actingUser) => {
  const wishlistDoc = await wishlistRepository.findRawByBuyer(buyerId);
  const item = wishlistDoc?.items.find((entry) => entry.product.toString() === productId);
  if (!item) {
    throw ApiError.notFound('Wishlist item not found.');
  }

  const cart = await cartService.addItemToCart(buyerId, { productId, quantity: 1 }, actingUser);

  item.deleteOne();
  await wishlistDoc.save();

  return { wishlist: await respondWith(buyerId), cart };
};

// --------------------------------------------------------------------
// Phase 17A.2, Part 2 — Wishlist Enhancements (multiple wishlists,
// public/private, shared links, move-between-wishlists, analytics)
// --------------------------------------------------------------------

/** Every wishlist the buyer owns — the default always sorted first (see wishlist.repository.js#findAllByBuyer). */
const listWishlists = async (buyerId) => {
  const wishlists = await wishlistRepository.findAllByBuyer(buyerId);
  return wishlists.map(toWishlistSummary);
};

const createWishlist = async (buyerId, { name, description }) => {
  const created = await wishlistRepository.create(buyerId, { name, description });
  return toWishlistSummary(created);
};

const getWishlistById = async (buyerId, wishlistId) => {
  const wishlist = await wishlistRepository.findByIdPopulated(wishlistId);
  assertOwnership(wishlist, buyerId);
  return toWishlistDetail(wishlist);
};

/** Renames and/or updates the description — never touches isDefault/isPublic/shareToken (those go through setVisibility). */
const renameWishlist = async (buyerId, wishlistId, { name, description }) => {
  const existing = await wishlistRepository.findById(wishlistId);
  assertOwnership(existing, buyerId);

  const update = {};
  if (name !== undefined) update.name = name;
  if (description !== undefined) update.description = description;

  const updated = await wishlistRepository.updateById(wishlistId, update);
  return toWishlistSummary(updated);
};

/**
 * Toggles public/private. The share token is generated exactly once —
 * the first time a wishlist is EVER made public — and then kept
 * stable across later unpublish/republish cycles, so a link a buyer
 * already shared keeps working if they turn sharing back on.
 */
const setVisibility = async (buyerId, wishlistId, isPublic) => {
  const existing = await wishlistRepository.findById(wishlistId);
  assertOwnership(existing, buyerId);

  const update = { isPublic };
  if (isPublic && !existing.shareToken) {
    update.shareToken = wishlistRepository.generateShareToken();
  }

  const updated = await wishlistRepository.updateById(wishlistId, update);
  return toWishlistSummary(updated);
};

/** The default wishlist can never be deleted — a buyer always has at least one to land on. */
const deleteWishlist = async (buyerId, wishlistId) => {
  const existing = await wishlistRepository.findById(wishlistId);
  assertOwnership(existing, buyerId);
  if (existing.isDefault) {
    throw ApiError.badRequest('The default wishlist cannot be deleted.');
  }
  await wishlistRepository.deleteById(wishlistId);
};

/** Public, unauthenticated read — 404s for an invalid token or a wishlist that was since made private again (the repository query itself only ever matches isPublic: true). Owner identity is deliberately never exposed. */
const getSharedWishlist = async (token) => {
  const wishlist = await wishlistRepository.findByShareToken(token);
  if (!wishlist) {
    throw ApiError.notFound('This wishlist is not available.');
  }

  const detail = toWishlistDetail(wishlist);
  return { name: detail.name, description: detail.description, itemCount: detail.itemCount, items: detail.items };
};

/** Same idempotent-on-duplicate behavior as the default-wishlist addItem, generalized to any of the buyer's wishlists. */
const addItemToWishlist = async (buyerId, wishlistId, productId, actingUser) => {
  const existing = await wishlistRepository.findById(wishlistId);
  assertOwnership(existing, buyerId);
  await productService.getProductById(productId, actingUser);

  const alreadySaved = existing.items.some((item) => item.product.toString() === productId);
  if (!alreadySaved) {
    existing.items.push({ product: productId });
    await existing.save();
  }

  return toWishlistDetail(await wishlistRepository.findByIdPopulated(wishlistId));
};

const removeItemFromWishlist = async (buyerId, wishlistId, productId) => {
  const existing = await wishlistRepository.findById(wishlistId);
  assertOwnership(existing, buyerId);

  const item = existing.items.find((entry) => entry.product.toString() === productId);
  if (!item) {
    throw ApiError.notFound('Wishlist item not found.');
  }

  item.deleteOne();
  await existing.save();
  return toWishlistDetail(await wishlistRepository.findByIdPopulated(wishlistId));
};

/**
 * "Move Products" — removes the item from the source wishlist and
 * adds it to the destination, idempotently (same as addItem: if it's
 * already in the destination, the move just removes it from the
 * source rather than erroring). Both wishlists must belong to the
 * caller; the source item must actually exist there.
 */
const moveItem = async (buyerId, fromWishlistId, productId, toWishlistId) => {
  if (fromWishlistId === toWishlistId) {
    throw ApiError.badRequest('Source and destination wishlists must be different.');
  }

  const [source, destination] = await Promise.all([
    wishlistRepository.findById(fromWishlistId),
    wishlistRepository.findById(toWishlistId),
  ]);
  assertOwnership(source, buyerId);
  assertOwnership(destination, buyerId);

  const item = source.items.find((entry) => entry.product.toString() === productId);
  if (!item) {
    throw ApiError.notFound('Wishlist item not found.');
  }

  const alreadyInDestination = destination.items.some((entry) => entry.product.toString() === productId);
  if (!alreadyInDestination) {
    destination.items.push({ product: productId });
    await destination.save();
  }

  item.deleteOne();
  await source.save();

  return {
    source: toWishlistDetail(await wishlistRepository.findByIdPopulated(fromWishlistId)),
    destination: toWishlistDetail(await wishlistRepository.findByIdPopulated(toWishlistId)),
  };
};

/**
 * Lightweight, self-contained analytics for one wishlist — total
 * value at CURRENT prices (not price-at-add-time, since that isn't
 * tracked), how many items were added in the last 7 days, and the
 * oldest/newest item timestamps. No new collection — everything is
 * derived from the wishlist's own populated items.
 */
const getWishlistAnalytics = async (buyerId, wishlistId) => {
  const wishlist = await wishlistRepository.findByIdPopulated(wishlistId);
  assertOwnership(wishlist, buyerId);

  const validItems = wishlist.items.filter((item) => item.product);
  const totalValue = validItems.reduce((sum, item) => {
    const price = item.product.salePrice != null ? item.product.salePrice : item.product.basePrice;
    return sum + (price || 0);
  }, 0);

  const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  const addedLast7Days = wishlist.items.filter((item) => item.createdAt >= sevenDaysAgo).length;

  const timestamps = wishlist.items.map((item) => item.createdAt).sort((a, b) => a - b);

  return {
    itemCount: wishlist.items.length,
    unavailableCount: wishlist.items.length - validItems.length,
    totalValue: Math.round(totalValue * 100) / 100,
    currency: validItems[0]?.product.currency || 'USD',
    addedLast7Days,
    oldestItemAddedAt: timestamps[0] || null,
    newestItemAddedAt: timestamps[timestamps.length - 1] || null,
  };
};

module.exports = {
  getWishlist,
  addItem,
  removeItem,
  clearWishlist,
  moveItemToCart,
  listWishlists,
  createWishlist,
  getWishlistById,
  renameWishlist,
  setVisibility,
  deleteWishlist,
  getSharedWishlist,
  addItemToWishlist,
  removeItemFromWishlist,
  moveItem,
  getWishlistAnalytics,
};
