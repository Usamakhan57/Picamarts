'use strict';

const ApiError = require('../utils/ApiError');
const reviewRepository = require('../repositories/review.repository');
const productRepository = require('../repositories/product.repository');
// Phase 10.2 — Notification System. Additive, fire-and-forget calls
// only (`.catch(() => {})`) — see order.service.js's identical comment.
const notificationService = require('./notification.service');
const { ROLES } = require('../constants/roles');
const { REVIEW_STATUSES, REVIEW_SORT_OPTIONS } = require('../constants/reviewEnums');

/**
 * Phase 10.1 — Product Reviews & Ratings.
 *
 * Business rules enforced here (not in the repository or controller):
 *   - Only verified buyers (paid order containing the product) can create.
 *   - One active review per buyer per product (deleted = allowed to re-submit).
 *   - Buyers can edit/delete only their own reviews.
 *   - Admins can hide, restore, or delete any review.
 *   - Sellers are read-only on reviews.
 *   - Rating aggregation (average + distribution) is recomputed after
 *     every create / update / delete.
 *   - helpfulCount is incremented atomically; a user can vote once
 *     (idempotency enforced via the `reports` field pattern is NOT used
 *     here — helpfulCount is a simple counter; de-duplication of helpful
 *     votes is a future enhancement and explicitly out of scope for 10.1).
 */

// --------------------------------------------------------------------
// Response shaping
// --------------------------------------------------------------------

const idStr = (v) => (v?.toString ? v.toString() : v);

const toReviewResponse = (review) => ({
  id: idStr(review._id),
  product: idStr(review.product?._id ?? review.product),
  reviewer: review.reviewer?.name
    ? { id: idStr(review.reviewer._id ?? review.reviewer), name: review.reviewer.name }
    : idStr(review.reviewer),
  order: idStr(review.order),
  rating: review.rating,
  title: review.title,
  body: review.body,
  images: (review.images ?? []).map((img) => ({
    id: idStr(img._id),
    url: img.url,
    alt: img.alt,
  })),
  verifiedPurchase: review.verifiedPurchase,
  helpfulCount: review.helpfulCount,
  reportCount: (review.reports ?? []).length,
  status: review.status,
  createdAt: review.createdAt,
  updatedAt: review.updatedAt,
});

/**
 * Phase 15C, Part 9 — Admin review moderation queue only. Same shape as
 * toReviewResponse, but with `product` populated (title/slug/thumbnail)
 * since an admin browsing reviews across the whole catalog needs to see
 * which product each review belongs to — toReviewResponse itself stays
 * untouched (it's shared with the public product-scoped listing, where
 * the product is already known from the URL).
 */
const toAdminReviewResponse = (review) => ({
  ...toReviewResponse(review),
  reviewer: review.reviewer?.name
    ? { id: idStr(review.reviewer._id ?? review.reviewer), name: review.reviewer.name, email: review.reviewer.email }
    : idStr(review.reviewer),
  product: review.product?.title
    ? {
        id: idStr(review.product._id),
        title: review.product.title,
        slug: review.product.slug,
        thumbnail: review.product.thumbnail,
      }
    : idStr(review.product),
});

// --------------------------------------------------------------------
// Sort helper
// --------------------------------------------------------------------

const buildSortOption = (sort) => {
  switch (sort) {
    case REVIEW_SORT_OPTIONS.OLDEST:
      return { createdAt: 1 };
    case REVIEW_SORT_OPTIONS.HELPFUL:
      return { helpfulCount: -1, createdAt: -1 };
    case REVIEW_SORT_OPTIONS.HIGHEST:
      return { rating: -1, createdAt: -1 };
    case REVIEW_SORT_OPTIONS.LOWEST:
      return { rating: 1, createdAt: -1 };
    case REVIEW_SORT_OPTIONS.NEWEST:
    default:
      return { createdAt: -1 };
  }
};

// --------------------------------------------------------------------
// Create review
// --------------------------------------------------------------------

/**
 * POST /products/:id/reviews
 *
 * Only a verified buyer (paid order with this product) may submit.
 * One active (non-deleted) review per buyer per product.
 *
 * @param {string} productId
 * @param {object} body   - { rating, title?, body, images? }
 * @param {object} actingUser - { id, role }
 */
const createReview = async (productId, body, actingUser) => {
  // 1. Role check — only buyers may submit reviews.
  if (actingUser.role !== ROLES.BUYER) {
    throw ApiError.forbidden('Only buyers can submit reviews.');
  }

  // 2. Product must exist and be published.
  const product = await productRepository.findById(productId);
  if (!product) {
    throw ApiError.notFound('Product not found.');
  }
  if (product.status !== 'published') {
    throw ApiError.badRequest('Reviews can only be submitted for published products.');
  }

  // 3. Verified purchase check — must have at least one paid order.
  const purchaseOrder = await reviewRepository.findVerifiedPurchaseOrder(actingUser.id, productId);
  if (!purchaseOrder) {
    throw ApiError.forbidden('You can only review products you have purchased and paid for.');
  }

  // 4. Duplicate check — one active review per buyer per product.
  const existing = await reviewRepository.findActiveByReviewerAndProduct(actingUser.id, productId);
  if (existing) {
    throw ApiError.conflict('You have already reviewed this product.');
  }

  // 5. Create the review.
  const review = await reviewRepository.create({
    product: productId,
    reviewer: actingUser.id,
    order: purchaseOrder._id,
    rating: body.rating,
    title: body.title ?? '',
    body: body.body ?? '',
    images: body.images ?? [],
    verifiedPurchase: true,
    status: REVIEW_STATUSES.PUBLISHED,
  });

  // 6. Recompute product rating.
  await reviewRepository.recalculateProductRating(product._id);

  // Populate reviewer name for the response.
  const populated = await reviewRepository.findByIdPopulated(review._id);
  const response = toReviewResponse(populated);
  notificationService.notifyReviewReceived(product.seller, response, product.title).catch(() => {});
  return response;
};

// --------------------------------------------------------------------
// List reviews
// --------------------------------------------------------------------

/**
 * GET /products/:id/reviews
 *
 * Public listing. Admins can see all statuses; everyone else only sees
 * published reviews. Includes aggregated rating summary.
 *
 * @param {string} productId
 * @param {object} query - { page, limit, sort, rating? }
 * @param {object|null} actingUser - null for anonymous
 */
/**
 * Phase 15C, Part 9 — Admin review moderation queue. Cross-product
 * (unlike listReviews below, which requires a productId) — reuses the
 * same generic reviewRepository.list the product-scoped listing already
 * uses, just without a product filter forced in. Includes hidden
 * reviews by default (admin needs to see what's already been
 * moderated) — pass `status` to narrow.
 */
const listAllReviewsForAdmin = async (filter = {}, options = {}) => {
  const populate = [
    { path: 'reviewer', select: 'name email' },
    { path: 'product', select: 'title slug thumbnail' },
  ];

  const { items, meta } = await reviewRepository.list(filter, { ...options, populate });
  return { items: items.map(toAdminReviewResponse), meta };
};

const listReviews = async (productId, query, actingUser) => {
  const product = await productRepository.findById(productId);
  if (!product) {
    throw ApiError.notFound('Product not found.');
  }

  const { page = 1, limit = 20, sort, rating } = query;

  const isAdmin = actingUser?.role === ROLES.ADMIN;

  const filter = {
    product: product._id,
    // Admin sees all non-deleted; others see only published.
    ...(isAdmin
      ? { status: { $ne: REVIEW_STATUSES.DELETED } }
      : { status: REVIEW_STATUSES.PUBLISHED }),
    // Optional star filter.
    ...(rating ? { rating: Number(rating) } : {}),
  };

  const populate = [{ path: 'reviewer', select: 'name' }];

  const { items, meta } = await reviewRepository.list(filter, {
    page,
    limit,
    sort: buildSortOption(sort),
    populate,
  });

  const summary = await reviewRepository.getRatingDistribution(product._id);

  return {
    items: items.map(toReviewResponse),
    summary: {
      ratingAverage: summary.ratingAverage,
      ratingCount: summary.ratingCount,
      distribution: summary.distribution,
    },
    meta,
  };
};

// --------------------------------------------------------------------
// Update review
// --------------------------------------------------------------------

/**
 * PATCH /reviews/:reviewId
 *
 * Buyer can edit their own published review (rating, title, body, images).
 * Admin can update status (hide/publish) and moderationNote.
 *
 * @param {string} reviewId
 * @param {object} body
 * @param {object} actingUser
 */
const updateReview = async (reviewId, body, actingUser) => {
  const review = await reviewRepository.findById(reviewId);
  if (!review || review.status === REVIEW_STATUSES.DELETED) {
    throw ApiError.notFound('Review not found.');
  }

  const previousStatus = review.status;
  let moderationTransition = null;

  if (actingUser.role === ROLES.BUYER) {
    // Buyer may only edit their own review.
    if (review.reviewer.toString() !== actingUser.id) {
      throw ApiError.forbidden('You can only edit your own reviews.');
    }
    // Buyers cannot change moderation status.
    const { rating, title, body: reviewBody, images } = body;
    if (rating !== undefined) review.rating = rating;
    if (title !== undefined) review.title = title;
    if (reviewBody !== undefined) review.body = reviewBody;
    if (images !== undefined) review.images = images;
  } else if (actingUser.role === ROLES.ADMIN) {
    // Admin can change status and add a moderation note.
    const { status, moderationNote, rating, title, body: reviewBody, images } = body;
    if (status !== undefined) {
      if (status === REVIEW_STATUSES.DELETED) {
        throw ApiError.badRequest('Use the DELETE endpoint to remove a review.');
      }
      review.status = status;
      if (status !== previousStatus) moderationTransition = status;
    }
    if (moderationNote !== undefined) review.moderationNote = moderationNote;
    if (rating !== undefined) review.rating = rating;
    if (title !== undefined) review.title = title;
    if (reviewBody !== undefined) review.body = reviewBody;
    if (images !== undefined) review.images = images;
  } else {
    throw ApiError.forbidden('You do not have permission to update this review.');
  }

  await review.save();

  // Recompute ratings in case star value or status changed.
  await reviewRepository.recalculateProductRating(review.product);

  const populated = await reviewRepository.findByIdPopulated(review._id);
  const response = toReviewResponse(populated);

  if (moderationTransition === REVIEW_STATUSES.PUBLISHED) {
    notificationService.notifyReviewApproved(response).catch(() => {});
  } else if (moderationTransition === REVIEW_STATUSES.HIDDEN) {
    notificationService.notifyReviewHidden(response).catch(() => {});
  }

  return response;
};

// --------------------------------------------------------------------
// Delete review
// --------------------------------------------------------------------

/**
 * DELETE /reviews/:reviewId
 *
 * Buyers can delete only their own reviews.
 * Admins can delete any review.
 * Soft-delete: sets status to 'deleted'.
 *
 * @param {string} reviewId
 * @param {object} actingUser
 */
const deleteReview = async (reviewId, actingUser) => {
  const review = await reviewRepository.findById(reviewId);
  if (!review || review.status === REVIEW_STATUSES.DELETED) {
    throw ApiError.notFound('Review not found.');
  }

  if (actingUser.role === ROLES.BUYER) {
    if (review.reviewer.toString() !== actingUser.id) {
      throw ApiError.forbidden('You can only delete your own reviews.');
    }
  } else if (actingUser.role !== ROLES.ADMIN) {
    throw ApiError.forbidden('You do not have permission to delete this review.');
  }

  const productId = review.product;
  await reviewRepository.softDelete(reviewId);

  // Recompute product rating excluding the deleted review.
  await reviewRepository.recalculateProductRating(productId);
};

// --------------------------------------------------------------------
// Helpful vote
// --------------------------------------------------------------------

/**
 * POST /reviews/:reviewId/helpful
 *
 * Increments the helpful counter. Any authenticated user can vote.
 * De-duplication of votes is a future enhancement (out of scope for 10.1).
 *
 * @param {string} reviewId
 */
const markHelpful = async (reviewId) => {
  const review = await reviewRepository.findById(reviewId);
  if (!review || review.status !== REVIEW_STATUSES.PUBLISHED) {
    throw ApiError.notFound('Review not found.');
  }

  review.helpfulCount += 1;
  await review.save();

  const populated = await reviewRepository.findByIdPopulated(review._id);
  return toReviewResponse(populated);
};

// --------------------------------------------------------------------
// Report review
// --------------------------------------------------------------------

/**
 * POST /reviews/:reviewId/report
 *
 * Authenticated users can flag a published review. Idempotent —
 * a second report from the same user is silently ignored.
 *
 * @param {string} reviewId
 * @param {object} body   - { reason? }
 * @param {object} actingUser
 */
const reportReview = async (reviewId, body, actingUser) => {
  const review = await reviewRepository.findById(reviewId);
  if (!review || review.status !== REVIEW_STATUSES.PUBLISHED) {
    throw ApiError.notFound('Review not found.');
  }

  // Idempotent — do not add a second report from the same user.
  const alreadyReported = review.reports.some((r) => r.reporter.toString() === actingUser.id);
  if (!alreadyReported) {
    review.reports.push({
      reporter: actingUser.id,
      reason: body.reason ?? '',
      reportedAt: new Date(),
    });
    await review.save();
    notificationService.notifyReviewReported({ id: idStr(review._id) }).catch(() => {});
  }

  return { reported: true, reportCount: review.reports.length };
};

module.exports = {
  createReview,
  listReviews,
  listAllReviewsForAdmin,
  updateReview,
  deleteReview,
  markHelpful,
  reportReview,
};
