'use strict';

const baseLayout = require('./baseLayout');

/**
 * Phase 10.2 — Notification System (Part 5, "Payment Failure").
 * @param {{ name: string, orderNumber: string, reason?: string, retryUrl: string }} params
 * @returns {{ subject: string, html: string, text: string }}
 */
const paymentFailureEmail = ({ name, orderNumber, reason, retryUrl }) => {
  const subject = `Payment failed — ${orderNumber}`;

  const bodyHtml = `
    <p>Hi ${name},</p>
    <p>We weren't able to process your payment for order <strong>${orderNumber}</strong>.</p>
    ${reason ? `<p style="background:#fef2f2;border-radius:6px;padding:16px;margin:20px 0;color:#991b1b;">${reason}</p>` : ''}
    <p style="text-align:center;margin:24px 0;">
      <a href="${retryUrl}" style="background:#111827;color:#ffffff;padding:12px 24px;border-radius:6px;text-decoration:none;display:inline-block;">
        Try Payment Again
      </a>
    </p>
    <p>Your order is still reserved — no further action is needed until you're ready to retry.</p>
  `;

  const text = `Hi ${name}, your payment for order ${orderNumber} failed${reason ? ` (${reason})` : ''}. Retry here: ${retryUrl}`;

  return { subject, html: baseLayout({ title: subject, bodyHtml }), text };
};

module.exports = paymentFailureEmail;
