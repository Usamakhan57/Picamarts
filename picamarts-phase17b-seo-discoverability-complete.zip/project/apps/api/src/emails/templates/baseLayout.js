'use strict';

/**
 * Wraps inner HTML in a minimal, inbox-safe email shell. Business emails
 * (welcome, order confirmation, password reset, etc.) will call this and
 * pass their own body content in the next phase.
 *
 * @param {{ title: string, bodyHtml: string, appName?: string }} params
 * @returns {string} full HTML document
 */
const baseLayout = ({ title, bodyHtml, appName = 'PicaMarts' }) => `
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>${title}</title>
  </head>
  <body style="margin:0;padding:0;background-color:#f4f4f5;font-family:Arial,Helvetica,sans-serif;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="padding:24px 0;">
      <tr>
        <td align="center">
          <table role="presentation" width="480" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:8px;overflow:hidden;">
            <tr>
              <td style="padding:24px;border-bottom:1px solid #eee;">
                <strong style="font-size:18px;">${appName}</strong>
              </td>
            </tr>
            <tr>
              <td style="padding:24px;color:#27272a;font-size:14px;line-height:1.6;">
                ${bodyHtml}
              </td>
            </tr>
            <tr>
              <td style="padding:16px 24px;color:#9ca3af;font-size:12px;border-top:1px solid #eee;">
                &copy; ${new Date().getFullYear()} ${appName}. All rights reserved.
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </body>
</html>
`;

module.exports = baseLayout;
