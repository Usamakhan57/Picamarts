'use strict';

const baseLayout = require('./baseLayout');

/**
 * Sent when an admin rejects a seller application.
 *
 * @param {{ name: string, storeName: string, reason?: string }} params
 * @returns {{ subject: string, html: string, text: string }}
 */
const sellerRejectedEmail = ({ name, storeName, reason }) => {
  const subject = 'Update on your seller application';

  const bodyHtml = `
    <p>Hi ${name},</p>
    <p>Thanks for your interest in selling on PicaMarts. After review, we're unable to approve "<strong>${storeName}</strong>" at this time.</p>
    ${reason ? `<p><strong>Reason:</strong> ${reason}</p>` : ''}
    <p>You're welcome to update your application and resubmit for another review.</p>
  `;

  const text = `Hi ${name}, your seller application for "${storeName}" was not approved.${
    reason ? ` Reason: ${reason}` : ''
  } You can update and resubmit your application.`;

  return { subject, html: baseLayout({ title: subject, bodyHtml }), text };
};

module.exports = sellerRejectedEmail;
