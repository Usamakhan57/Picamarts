'use strict';

const baseLayout = require('./baseLayout');

/**
 * Phase 10.2 — Notification System (Part 5, "Refund Issued").
 * @param {{ name: string, orderNumber: string, refundAmount: number, currency: string, isFullRefund: boolean }} params
 * @returns {{ subject: string, html: string, text: string }}
 */
const refundIssuedEmail = ({ name, orderNumber, refundAmount, currency, isFullRefund }) => {
  const subject = `Refund issued — ${orderNumber}`;

  const bodyHtml = `
    <p>Hi ${name},</p>
    <p>${isFullRefund ? 'A full refund' : 'A partial refund'} has been issued for order <strong>${orderNumber}</strong>.</p>
    <p style="background:#f4f4f5;border-radius:6px;padding:16px;margin:20px 0;">
      <strong>Refund amount:</strong> ${Number(refundAmount).toFixed(2)} ${String(currency).toUpperCase()}
    </p>
    <p>Refunds typically appear on your original payment method within 5–10 business days.</p>
  `;

  const text = `Hi ${name}, a ${isFullRefund ? 'full' : 'partial'} refund of ${Number(refundAmount).toFixed(2)} ${String(currency).toUpperCase()} has been issued for order ${orderNumber}.`;

  return { subject, html: baseLayout({ title: subject, bodyHtml }), text };
};

module.exports = refundIssuedEmail;
