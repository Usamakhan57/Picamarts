'use strict';

const baseLayout = require('./baseLayout');

/**
 * Phase 10.2 — Notification System (Part 5, "Payment Success").
 * @param {{ name: string, orderNumber: string, amount: number, currency: string, orderUrl: string }} params
 * @returns {{ subject: string, html: string, text: string }}
 */
const paymentSuccessEmail = ({ name, orderNumber, amount, currency, orderUrl }) => {
  const subject = `Payment received — ${orderNumber}`;

  const bodyHtml = `
    <p>Hi ${name},</p>
    <p>We've successfully received your payment for order <strong>${orderNumber}</strong>.</p>
    <p style="background:#f0fdf4;border-radius:6px;padding:16px;margin:20px 0;">
      <strong>Amount charged:</strong> ${Number(amount).toFixed(2)} ${String(currency).toUpperCase()}
    </p>
    <p style="text-align:center;margin:24px 0;">
      <a href="${orderUrl}" style="background:#111827;color:#ffffff;padding:12px 24px;border-radius:6px;text-decoration:none;display:inline-block;">
        View Order
      </a>
    </p>
  `;

  const text = `Hi ${name}, your payment of ${Number(amount).toFixed(2)} ${String(currency).toUpperCase()} for order ${orderNumber} was successful. View it here: ${orderUrl}`;

  return { subject, html: baseLayout({ title: subject, bodyHtml }), text };
};

module.exports = paymentSuccessEmail;
