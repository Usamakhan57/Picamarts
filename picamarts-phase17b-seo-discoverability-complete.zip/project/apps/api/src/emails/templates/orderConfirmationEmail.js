'use strict';

const baseLayout = require('./baseLayout');

/**
 * Phase 10.2 — Notification System (Part 5, "Order Confirmation").
 * @param {{ name: string, orderNumber: string, grandTotal: number, itemCount: number, orderUrl: string }} params
 * @returns {{ subject: string, html: string, text: string }}
 */
const orderConfirmationEmail = ({ name, orderNumber, grandTotal, itemCount, orderUrl }) => {
  const subject = `Order confirmed — ${orderNumber}`;

  const bodyHtml = `
    <p>Hi ${name},</p>
    <p>Thanks for your order! We've received it and it's now being processed.</p>
    <p style="background:#f4f4f5;border-radius:6px;padding:16px;margin:20px 0;">
      <strong>Order number:</strong> ${orderNumber}<br/>
      <strong>Items:</strong> ${itemCount}<br/>
      <strong>Total:</strong> $${Number(grandTotal).toFixed(2)}
    </p>
    <p style="text-align:center;margin:24px 0;">
      <a href="${orderUrl}" style="background:#111827;color:#ffffff;padding:12px 24px;border-radius:6px;text-decoration:none;display:inline-block;">
        View Order
      </a>
    </p>
    <p>We'll email you again as soon as your order ships.</p>
  `;

  const text = `Hi ${name}, your order ${orderNumber} (${itemCount} item(s), $${Number(grandTotal).toFixed(2)}) has been confirmed. View it here: ${orderUrl}`;

  return { subject, html: baseLayout({ title: subject, bodyHtml }), text };
};

module.exports = orderConfirmationEmail;
