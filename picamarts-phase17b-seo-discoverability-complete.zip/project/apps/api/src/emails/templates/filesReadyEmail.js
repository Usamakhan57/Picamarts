'use strict';

const baseLayout = require('./baseLayout');

/**
 * Phase 14.1, Part 14 — "Files Ready" email, sent right after a digital
 * purchase is delivered.
 * @param {{ name: string, productTitle: string, downloadsUrl: string }} params
 * @returns {{ subject: string, html: string, text: string }}
 */
const filesReadyEmail = ({ name, productTitle, downloadsUrl }) => {
  const subject = `Your files are ready — ${productTitle}`;

  const bodyHtml = `
    <p>Hi ${name},</p>
    <p>Your purchase of <strong>${productTitle}</strong> is ready to download.</p>
    <p style="text-align:center;margin:24px 0;">
      <a href="${downloadsUrl}" style="background:#111827;color:#ffffff;padding:12px 24px;border-radius:6px;text-decoration:none;display:inline-block;">
        Go to My Downloads
      </a>
    </p>
  `;

  const text = `Hi ${name}, your purchase of ${productTitle} is ready to download: ${downloadsUrl}`;

  return { subject, html: baseLayout({ title: subject, bodyHtml }), text };
};

module.exports = filesReadyEmail;
