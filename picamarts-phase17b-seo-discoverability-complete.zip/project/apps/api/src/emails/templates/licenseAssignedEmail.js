'use strict';

const baseLayout = require('./baseLayout');

/**
 * Phase 14.1, Part 14 — "License Included" email, sent when a purchase
 * that includes a license key is delivered.
 * @param {{ name: string, productTitle: string, licenseKey: string, downloadsUrl: string }} params
 * @returns {{ subject: string, html: string, text: string }}
 */
const licenseAssignedEmail = ({ name, productTitle, licenseKey, downloadsUrl }) => {
  const subject = `Your license key — ${productTitle}`;

  const bodyHtml = `
    <p>Hi ${name},</p>
    <p>Here's your license key for <strong>${productTitle}</strong>:</p>
    <p style="background:#f0fdf4;border-radius:6px;padding:16px;margin:20px 0;font-family:monospace;font-size:16px;letter-spacing:1px;">
      ${licenseKey}
    </p>
    <p>Keep this somewhere safe — you can also find it any time in My Downloads.</p>
    <p style="text-align:center;margin:24px 0;">
      <a href="${downloadsUrl}" style="background:#111827;color:#ffffff;padding:12px 24px;border-radius:6px;text-decoration:none;display:inline-block;">
        Go to My Downloads
      </a>
    </p>
  `;

  const text = `Hi ${name}, your license key for ${productTitle} is: ${licenseKey}. View it any time: ${downloadsUrl}`;

  return { subject, html: baseLayout({ title: subject, bodyHtml }), text };
};

module.exports = licenseAssignedEmail;
