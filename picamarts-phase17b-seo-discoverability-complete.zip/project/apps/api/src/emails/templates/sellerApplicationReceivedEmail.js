'use strict';

const baseLayout = require('./baseLayout');

/**
 * Sent to the applicant right after they submit a seller application.
 *
 * @param {{ name: string, storeName: string }} params
 * @returns {{ subject: string, html: string, text: string }}
 */
const sellerApplicationReceivedEmail = ({ name, storeName }) => {
  const subject = 'Your seller application was received';

  const bodyHtml = `
    <p>Hi ${name},</p>
    <p>Thanks for applying to sell on PicaMarts with your store "<strong>${storeName}</strong>".</p>
    <p>Our team will review your application shortly. We'll email you as soon as a decision is made.</p>
    <p>In the meantime, feel free to finish filling out your store profile from your seller dashboard.</p>
  `;

  const text = `Hi ${name}, your seller application for "${storeName}" was received and is pending review. We'll email you once a decision is made.`;

  return { subject, html: baseLayout({ title: subject, bodyHtml }), text };
};

module.exports = sellerApplicationReceivedEmail;
