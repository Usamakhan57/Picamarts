'use strict';

const baseLayout = require('./baseLayout');

/**
 * Phase 14.2, Part 12 — "Tracking Number" email.
 * @param {{ name: string, orderNumber: string, carrier: string, trackingNumber: string, trackingUrl: string, orderUrl: string }} params
 */
const trackingAddedEmail = ({ name, orderNumber, carrier, trackingNumber, trackingUrl, orderUrl }) => {
  const subject = `Tracking added — ${orderNumber}`;
  const bodyHtml = `
    <p>Hi ${name},</p>
    <p>Tracking is now available for order <strong>${orderNumber}</strong>.</p>
    <p style="background:#f0fdf4;border-radius:6px;padding:16px;margin:20px 0;">
      <strong>Carrier:</strong> ${carrier || 'N/A'}<br/>
      <strong>Tracking number:</strong> ${trackingNumber}
    </p>
    <p style="text-align:center;margin:24px 0;">
      <a href="${trackingUrl || orderUrl}" style="background:#111827;color:#ffffff;padding:12px 24px;border-radius:6px;text-decoration:none;display:inline-block;">Track Package</a>
    </p>
  `;
  const text = `Hi ${name}, tracking for order ${orderNumber}: ${carrier || ''} ${trackingNumber}. ${trackingUrl || orderUrl}`;
  return { subject, html: baseLayout({ title: subject, bodyHtml }), text };
};

module.exports = trackingAddedEmail;
