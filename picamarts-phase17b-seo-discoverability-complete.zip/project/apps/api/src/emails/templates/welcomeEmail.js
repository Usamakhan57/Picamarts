'use strict';

const baseLayout = require('./baseLayout');

/**
 * @param {{ name: string, appUrl: string }} params
 * @returns {{ subject: string, html: string, text: string }}
 */
const welcomeEmail = ({ name, appUrl }) => {
  const subject = 'Welcome to PicaMarts!';

  const bodyHtml = `
    <p>Hi ${name},</p>
    <p>Your email is verified and your account is ready to go. We're glad you're here.</p>
    <p style="text-align:center;margin:24px 0;">
      <a href="${appUrl}" style="background:#111827;color:#ffffff;padding:12px 24px;border-radius:6px;text-decoration:none;display:inline-block;">
        Start Exploring
      </a>
    </p>
    <p>If you have any questions, just reply to this email — we're happy to help.</p>
  `;

  const text = `Hi ${name}, your email is verified and your PicaMarts account is ready: ${appUrl}`;

  return { subject, html: baseLayout({ title: subject, bodyHtml }), text };
};

module.exports = welcomeEmail;
