'use strict';

const baseLayout = require('./baseLayout');

/**
 * Phase 10.2 — Notification System (Part 5, "Admin Announcement").
 * Shared by broadcast_notification / system_announcement /
 * maintenance_notice — all three are admin-authored, free-text
 * messages; only the subject prefix differs.
 *
 * @param {{ name: string, title: string, message: string }} params
 * @returns {{ subject: string, html: string, text: string }}
 */
const adminAnnouncementEmail = ({ name, title, message }) => {
  const subject = title;

  const bodyHtml = `
    <p>Hi ${name},</p>
    <p style="white-space:pre-line;">${message}</p>
  `;

  const text = `Hi ${name}, ${message}`;

  return { subject, html: baseLayout({ title: subject, bodyHtml }), text };
};

module.exports = adminAnnouncementEmail;
