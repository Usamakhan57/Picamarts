'use strict';

const baseLayout = require('./baseLayout');

/**
 * Sent when an admin suspends a previously-approved seller.
 *
 * @param {{ name: string, storeName: string, reason?: string }} params
 * @returns {{ subject: string, html: string, text: string }}
 */
const sellerSuspendedEmail = ({ name, storeName, reason }) => {
  const subject = 'Your store has been suspended';

  const bodyHtml = `
    <p>Hi ${name},</p>
    <p>Your store "<strong>${storeName}</strong>" has been suspended and is temporarily unavailable to buyers.</p>
    ${reason ? `<p><strong>Reason:</strong> ${reason}</p>` : ''}
    <p>Please contact support if you believe this was a mistake or would like more information.</p>
  `;

  const text = `Hi ${name}, your store "${storeName}" has been suspended.${
    reason ? ` Reason: ${reason}` : ''
  } Please contact support for more information.`;

  return { subject, html: baseLayout({ title: subject, bodyHtml }), text };
};

module.exports = sellerSuspendedEmail;
