'use strict';

const baseLayout = require('./baseLayout');

/**
 * Phase 14.1, Part 14 — "Download Expiry Reminder" email. Not yet
 * scheduled by a job in this pass (see digitalDelivery.service.js's
 * header comment on scope) — the template exists and is wired to a
 * notification type so a future maintenance job can call it, the same
 * way jobs/maintenance.job.js already runs on a schedule for other
 * housekeeping.
 * @param {{ name: string, productTitle: string, expiresAt: string, downloadsUrl: string }} params
 * @returns {{ subject: string, html: string, text: string }}
 */
const downloadExpiringEmail = ({ name, productTitle, expiresAt, downloadsUrl }) => {
  const subject = `Your download is expiring soon — ${productTitle}`;

  const bodyHtml = `
    <p>Hi ${name},</p>
    <p>Your download access for <strong>${productTitle}</strong> expires on <strong>${expiresAt}</strong>. Grab your files before then.</p>
    <p style="text-align:center;margin:24px 0;">
      <a href="${downloadsUrl}" style="background:#111827;color:#ffffff;padding:12px 24px;border-radius:6px;text-decoration:none;display:inline-block;">
        Go to My Downloads
      </a>
    </p>
  `;

  const text = `Hi ${name}, your download access for ${productTitle} expires on ${expiresAt}. Download it here: ${downloadsUrl}`;

  return { subject, html: baseLayout({ title: subject, bodyHtml }), text };
};

module.exports = downloadExpiringEmail;
