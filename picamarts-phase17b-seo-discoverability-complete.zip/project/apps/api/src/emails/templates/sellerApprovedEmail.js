'use strict';

const baseLayout = require('./baseLayout');

/**
 * Sent when an admin approves a seller application.
 *
 * @param {{ name: string, storeName: string, dashboardUrl: string }} params
 * @returns {{ subject: string, html: string, text: string }}
 */
const sellerApprovedEmail = ({ name, storeName, dashboardUrl }) => {
  const subject = 'Your store is approved!';

  const bodyHtml = `
    <p>Hi ${name},</p>
    <p>Great news — "<strong>${storeName}</strong>" has been approved and is now live on PicaMarts.</p>
    <p style="text-align:center;margin:24px 0;">
      <a href="${dashboardUrl}" style="background:#111827;color:#ffffff;padding:12px 24px;border-radius:6px;text-decoration:none;display:inline-block;">
        Go to Seller Dashboard
      </a>
    </p>
    <p>You can now start listing products from your seller dashboard.</p>
  `;

  const text = `Hi ${name}, "${storeName}" has been approved and is live on PicaMarts. Visit your seller dashboard: ${dashboardUrl}`;

  return { subject, html: baseLayout({ title: subject, bodyHtml }), text };
};

module.exports = sellerApprovedEmail;
