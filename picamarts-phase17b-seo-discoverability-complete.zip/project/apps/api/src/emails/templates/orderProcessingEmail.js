'use strict';

const baseLayout = require('./baseLayout');

/**
 * Phase 14.2, Part 12 — "Order Processing" email.
 * @param {{ name: string, orderNumber: string, orderUrl: string }} params
 */
const orderProcessingEmail = ({ name, orderNumber, orderUrl }) => {
  const subject = `Your order is being processed — ${orderNumber}`;
  const bodyHtml = `
    <p>Hi ${name},</p>
    <p>Good news — order <strong>${orderNumber}</strong> is now being processed and will be packed for shipping soon.</p>
    <p style="text-align:center;margin:24px 0;">
      <a href="${orderUrl}" style="background:#111827;color:#ffffff;padding:12px 24px;border-radius:6px;text-decoration:none;display:inline-block;">View Order</a>
    </p>
  `;
  const text = `Hi ${name}, your order ${orderNumber} is now being processed. View it here: ${orderUrl}`;
  return { subject, html: baseLayout({ title: subject, bodyHtml }), text };
};

module.exports = orderProcessingEmail;
