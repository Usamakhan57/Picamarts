'use strict';

const baseLayout = require('./baseLayout');

/**
 * Phase 14.2, Part 12 — "Order Delivered" email.
 * @param {{ name: string, orderNumber: string, orderUrl: string }} params
 */
const orderDeliveredEmail = ({ name, orderNumber, orderUrl }) => {
  const subject = `Your order has been delivered — ${orderNumber}`;
  const bodyHtml = `
    <p>Hi ${name},</p>
    <p>Order <strong>${orderNumber}</strong> has been delivered. We hope you love it!</p>
    <p style="text-align:center;margin:24px 0;">
      <a href="${orderUrl}" style="background:#111827;color:#ffffff;padding:12px 24px;border-radius:6px;text-decoration:none;display:inline-block;">View Order</a>
    </p>
  `;
  const text = `Hi ${name}, your order ${orderNumber} has been delivered. View it here: ${orderUrl}`;
  return { subject, html: baseLayout({ title: subject, bodyHtml }), text };
};

module.exports = orderDeliveredEmail;
