'use strict';

const baseLayout = require('./baseLayout');

/**
 * @param {{ name: string, verifyUrl: string, expiresInHours: number }} params
 * @returns {{ subject: string, html: string, text: string }}
 */
const verificationEmail = ({ name, verifyUrl, expiresInHours }) => {
  const subject = 'Verify your email address';

  const bodyHtml = `
    <p>Hi ${name},</p>
    <p>Thanks for signing up. Please verify your email address to activate your account.</p>
    <p style="text-align:center;margin:24px 0;">
      <a href="${verifyUrl}" style="background:#111827;color:#ffffff;padding:12px 24px;border-radius:6px;text-decoration:none;display:inline-block;">
        Verify Email
      </a>
    </p>
    <p>Or copy and paste this link into your browser:</p>
    <p style="word-break:break-all;color:#6b7280;">${verifyUrl}</p>
    <p>This link expires in ${expiresInHours} hours. If you didn't create this account, you can safely ignore this email.</p>
  `;

  const text = `Hi ${name}, verify your email using this link (expires in ${expiresInHours} hours): ${verifyUrl}`;

  return { subject, html: baseLayout({ title: subject, bodyHtml }), text };
};

module.exports = verificationEmail;
