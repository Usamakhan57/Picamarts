'use strict';

const baseLayout = require('./baseLayout');

/**
 * @param {{ name: string, resetUrl: string, expiresInMinutes: number }} params
 * @returns {{ subject: string, html: string, text: string }}
 */
const resetPasswordEmail = ({ name, resetUrl, expiresInMinutes }) => {
  const subject = 'Reset your password';

  const bodyHtml = `
    <p>Hi ${name},</p>
    <p>We received a request to reset your password. Click the button below to choose a new one.</p>
    <p style="text-align:center;margin:24px 0;">
      <a href="${resetUrl}" style="background:#111827;color:#ffffff;padding:12px 24px;border-radius:6px;text-decoration:none;display:inline-block;">
        Reset Password
      </a>
    </p>
    <p>Or copy and paste this link into your browser:</p>
    <p style="word-break:break-all;color:#6b7280;">${resetUrl}</p>
    <p>This link expires in ${expiresInMinutes} minutes. If you didn't request a password reset, you can safely ignore this email — your password will not be changed.</p>
  `;

  const text = `Hi ${name}, reset your password using this link (expires in ${expiresInMinutes} minutes): ${resetUrl}`;

  return { subject, html: baseLayout({ title: subject, bodyHtml }), text };
};

module.exports = resetPasswordEmail;
