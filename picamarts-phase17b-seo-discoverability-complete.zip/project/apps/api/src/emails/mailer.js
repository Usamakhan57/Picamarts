'use strict';

const nodemailer = require('nodemailer');
const config = require('../config');
const logger = require('../utils/logger');
const emailQueue = require('../queues/email.queue');

let transporter;

const getTransporter = () => {
  if (transporter) return transporter;

  transporter = nodemailer.createTransport({
    host: config.mail.host,
    port: config.mail.port,
    secure: config.mail.secure,
    auth: config.mail.user ? { user: config.mail.user, pass: config.mail.pass } : undefined,
  });

  return transporter;
};

/**
 * Sends a single email immediately over SMTP. This is the ORIGINAL
 * `sendMail` body from before Phase 12 — unchanged, and now also the
 * function workers/email.worker.js calls to actually deliver a queued
 * job. Swallows and logs transport errors as a warning rather than
 * throwing, so a broken SMTP config never crashes whatever triggered
 * the send.
 *
 * @param {{ to: string, subject: string, html: string, text?: string }} options
 * @returns {Promise<boolean>} whether the send succeeded
 */
const deliverMailDirect = async ({ to, subject, html, text }) => {
  if (!config.mail.host || !config.mail.user) {
    logger.warn(`SMTP not configured — skipped email "${subject}" to ${to}.`);
    return false;
  }

  try {
    await getTransporter().sendMail({
      from: config.mail.from,
      to,
      subject,
      html,
      text,
    });
    return true;
  } catch (error) {
    logger.error(`Failed to send email "${subject}" to ${to}: ${error.message}`);
    return false;
  }
};

/**
 * Sends a single email. Phase 12, Part 3: transparently enqueues onto
 * the BullMQ email queue (retried with backoff, dead-lettered on
 * exhaustion — see queues/email.queue.js and workers/email.worker.js)
 * so SMTP round-trips never sit on a request's response path. Falls
 * back to sending immediately via `deliverMailDirect` whenever queues
 * are disabled (no Redis configured, `QUEUE_ENABLED=false`, or
 * `NODE_ENV=test`) or the enqueue attempt itself throws — callers keep
 * the exact same "await a boolean" contract either way, and every
 * existing caller (auth/seller/notification services) needed zero
 * changes for this.
 *
 * All outgoing email uses the configured production From address:
 *   support@picamarts.com  (or EMAIL_FROM env override)
 *
 * @param {{ to: string, subject: string, html: string, text?: string }} options
 * @returns {Promise<boolean>} whether the email was sent (or successfully queued)
 */
const sendMail = async ({ to, subject, html, text }) => {
  try {
    const job = await emailQueue.addEmailJob({ to, subject, html, text });
    if (job) return true;
  } catch (error) {
    logger.warn(`Failed to enqueue email "${subject}" to ${to} — sending directly instead: ${error.message}`);
  }

  return deliverMailDirect({ to, subject, html, text });
};

/**
 * Sends an admin notification to the configured ADMIN_EMAIL address.
 * Use this for internal alerts (new seller signup, flagged content, etc.)
 * that should go to admin@picamarts.com rather than a specific user.
 *
 * @param {{ subject: string, html: string, text?: string }} options
 * @returns {Promise<boolean>}
 */
const sendAdminMail = async ({ subject, html, text }) => {
  return sendMail({ to: config.mail.adminEmail, subject, html, text });
};

module.exports = { sendMail, sendAdminMail, getTransporter, deliverMailDirect };
