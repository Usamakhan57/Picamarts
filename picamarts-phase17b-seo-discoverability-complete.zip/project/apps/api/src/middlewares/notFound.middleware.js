'use strict';

const ApiError = require('../utils/ApiError');

/**
 * Catches any request that didn't match a route and forwards a 404
 * ApiError to the central error handler, instead of Express's default
 * plain-text 404 page.
 */
const notFound = (req, res, next) => {
  next(ApiError.notFound(`Route not found: ${req.method} ${req.originalUrl}`));
};

module.exports = notFound;
