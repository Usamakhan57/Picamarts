'use strict';

const config = require('../config');
const { cacheGet, cacheSet, cacheInvalidatePattern } = require('../utils/cache');
const logger = require('../utils/logger');

/**
 * Phase 12, Part 2 — API caching. Two middlewares, meant to be added
 * directly in a resource's route file (the same way `validate(...)` or
 * `authorize(...)` are composed) — neither one touches the
 * controller/service/repository layers of the resource it caches.
 *
 *   cacheResponse(namespace, ttl?) — on a cacheable GET, serves a
 *     cached body if present; otherwise lets the request through and
 *     caches the controller's JSON response afterward. Also sets a
 *     `Cache-Control: public, max-age=<ttl>` response header either
 *     way (Phase 12, Part 4) so browsers/CDNs in front of the API can
 *     cache the same response themselves.
 *   invalidateCache(namespace) — on a write route, clears every cached
 *     entry under that namespace before the request reaches the
 *     controller, so the next read is guaranteed fresh.
 *
 * Only ever applied to public, non-personalized GET reads (categories,
 * brands, collections, tags, homepage) — anything scoped to `req.user`
 * is deliberately never cached this way.
 */

/** Cache key includes the full query string so different filters/pages never collide. */
const buildKey = (namespace, req) => `${namespace}:${req.originalUrl}`;

/**
 * @param {string} namespace - cache key prefix for this resource, e.g. 'categories'
 * @param {number} [ttlSeconds] - defaults to config.redis.cacheTtlSeconds (see utils/cache.js)
 */
const cacheResponse = (namespace, ttlSeconds = config.redis.cacheTtlSeconds) => async (req, res, next) => {
  if (req.method !== 'GET') return next();

  res.setHeader('Cache-Control', `public, max-age=${ttlSeconds}`);

  const key = buildKey(namespace, req);

  const cached = await cacheGet(key);
  if (cached) {
    res.setHeader('X-Cache', 'HIT');
    return res.status(cached.status).json(cached.body);
  }

  res.setHeader('X-Cache', 'MISS');

  // Wrap res.json so a successful response is cached on the way out,
  // without the controller needing any awareness of caching at all.
  const originalJson = res.json.bind(res);
  res.json = (body) => {
    if (res.statusCode < 400) {
      cacheSet(key, { status: res.statusCode, body }, ttlSeconds).catch((error) =>
        logger.warn(`Failed to cache response for "${key}": ${error.message}`)
      );
    }
    return originalJson(body);
  };

  return next();
};

/** @param {string} namespace - same namespace passed to cacheResponse for this resource */
const invalidateCache = (namespace) => async (req, res, next) => {
  await cacheInvalidatePattern(`${namespace}:*`);
  next();
};

module.exports = { cacheResponse, invalidateCache };
