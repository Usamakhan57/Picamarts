'use strict';

const config = require('../config');
const logger = require('../utils/logger');
const ApiError = require('../utils/ApiError');
const httpStatus = require('../constants/httpStatus');

/**
 * Normalizes known third-party error shapes (Mongoose validation/cast
 * errors, duplicate-key errors, JWT errors) into an ApiError so the rest
 * of this handler only has one shape to deal with.
 */
const normalizeError = (err) => {
  if (err instanceof ApiError) return err;

  // Mongoose validation error
  if (err.name === 'ValidationError') {
    const details = Object.values(err.errors).map((e) => ({ path: e.path, message: e.message }));
    return new ApiError(httpStatus.UNPROCESSABLE_ENTITY, 'Validation failed', { details });
  }

  // Mongoose invalid ObjectId / cast error
  if (err.name === 'CastError') {
    return new ApiError(httpStatus.BAD_REQUEST, `Invalid value for field "${err.path}".`);
  }

  // Mongo duplicate key error
  if (err.code === 11000) {
    const field = Object.keys(err.keyValue || {})[0];
    return new ApiError(httpStatus.CONFLICT, field ? `${field} already exists.` : 'Duplicate value.', {
      details: err.keyValue,
    });
  }

  if (err.name === 'JsonWebTokenError' || err.name === 'TokenExpiredError') {
    return ApiError.unauthorized('Invalid or expired authentication token.');
  }

  // Multer file-size/type errors
  if (err.name === 'MulterError') {
    return ApiError.badRequest(err.message);
  }

  return new ApiError(httpStatus.INTERNAL_SERVER_ERROR, err.message || 'Internal server error', {
    isOperational: false,
    stack: err.stack,
  });
};

/**
 * Express error-handling middleware. Registered last, after all routes
 * and the 404 handler.
 */
// eslint-disable-next-line no-unused-vars
const errorHandler = (err, req, res, next) => {
  const apiError = normalizeError(err);

  if (apiError.isOperational) {
    logger.warn(`${req.method} ${req.originalUrl} → ${apiError.statusCode} ${apiError.message}`);
  } else {
    logger.error(`${req.method} ${req.originalUrl} → ${apiError.statusCode} ${apiError.message}`, {
      stack: apiError.stack,
    });
  }

  const body = {
    success: false,
    statusCode: apiError.statusCode,
    message: apiError.isOperational ? apiError.message : 'Something went wrong. Please try again later.',
  };

  if (apiError.details) body.details = apiError.details;
  if (!config.isProduction && apiError.stack) body.stack = apiError.stack;

  res.status(apiError.statusCode).json(body);
};

module.exports = errorHandler;
