'use strict';

const ApiError = require('../utils/ApiError');

/**
 * Restricts a route to one or more roles. Must run after `protect` so
 * `req.user` is already populated.
 *
 * Usage: router.post('/products', protect, authorize('seller', 'admin'), createProduct)
 */
const authorize = (...allowedRoles) => (req, res, next) => {
  if (!req.user) {
    return next(ApiError.unauthorized('Authentication required.'));
  }

  if (!allowedRoles.includes(req.user.role)) {
    return next(ApiError.forbidden('You do not have permission to perform this action.'));
  }

  return next();
};

module.exports = { authorize };
