'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const { verifyAccessToken } = require('../utils/token');
const userRepository = require('../repositories/user.repository');

/**
 * Pulls a bearer token out of either the `Authorization: Bearer <token>`
 * header or an `accessToken` cookie, preferring the header.
 */
const extractToken = (req) => {
  const header = req.headers.authorization;
  if (header?.startsWith('Bearer ')) return header.slice(7);
  if (req.cookies?.accessToken) return req.cookies.accessToken;
  return null;
};

/**
 * Verifies the JWT, then loads the user record to catch cases a stateless
 * token can't: the account was disabled/deleted after the token was
 * issued, or the password changed since (which invalidates every access
 * token issued before that moment, even ones that haven't expired yet).
 *
 * @returns {Promise<{ payload: object, user: import('mongoose').Document }>}
 * @throws {ApiError} 401 for any failure — invalid/expired token, missing
 *   user, disabled account, or a token issued before a password change.
 */
const authenticate = async (token) => {
  let payload;
  try {
    payload = verifyAccessToken(token);
  } catch (error) {
    throw ApiError.unauthorized(
      error.name === 'TokenExpiredError' ? 'Session expired. Please log in again.' : 'Invalid authentication token.'
    );
  }

  const user = await userRepository.findById(payload.sub, { withPasswordChangedAt: true });

  if (!user || !user.isActive) {
    throw ApiError.unauthorized('Account no longer accessible. Please log in again.');
  }

  if (user.wasPasswordChangedAfter(payload.iat)) {
    throw ApiError.unauthorized('Password was changed recently. Please log in again.');
  }

  return { payload, user };
};

/**
 * Requires a valid access token belonging to an active, up-to-date user.
 * On success, attaches `req.user` (id/role/email/name — no sensitive
 * fields) and the full Mongoose document as `req.userDoc` for handlers
 * that need to mutate it (e.g. profile updates).
 */
const protect = asyncHandler(async (req, res, next) => {
  const token = extractToken(req);

  if (!token) {
    throw ApiError.unauthorized('Authentication token missing.');
  }

  const { user } = await authenticate(token);

  req.user = { id: user._id.toString(), sub: user._id.toString(), role: user.role, email: user.email, name: user.name };
  req.userDoc = user;

  next();
});

/**
 * Same as `protect`, but never throws — attaches `req.user`/`req.userDoc`
 * when a valid token is present and silently continues otherwise. Useful
 * for routes that behave differently for logged-in vs anonymous users
 * without requiring auth.
 */
const attachUserIfPresent = asyncHandler(async (req, res, next) => {
  const token = extractToken(req);
  if (!token) return next();

  try {
    const { user } = await authenticate(token);
    req.user = { id: user._id.toString(), sub: user._id.toString(), role: user.role, email: user.email, name: user.name };
    req.userDoc = user;
  } catch {
    // Ignore invalid/expired tokens or disabled accounts on optional-auth routes.
  }

  next();
});

module.exports = { protect, attachUserIfPresent, extractToken };
