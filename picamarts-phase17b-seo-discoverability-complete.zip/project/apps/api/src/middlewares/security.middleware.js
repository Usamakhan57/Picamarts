'use strict';

const helmet = require('helmet');
const mongoSanitize = require('express-mongo-sanitize');
const hpp = require('hpp');
const config = require('../config');

/**
 * Recursively strips `<script>` tags and inline event-handler-style HTML
 * from string values in an object (body/query/params). This is a
 * deliberately conservative, dependency-light substitute for the
 * unmaintained `xss-clean` package — it does not attempt to be a full
 * HTML sanitizer, since the real defense against stored/reflected XSS is
 * output-encoding on the frontend plus strict Zod/Joi validation on every
 * route. This middleware is a defense-in-depth layer, not the only layer.
 */
const stripDangerousHtml = (value) => {
  if (typeof value === 'string') {
    return value
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
      .replace(/on\w+\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, '');
  }

  if (Array.isArray(value)) {
    return value.map(stripDangerousHtml);
  }

  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, stripDangerousHtml(v)]));
  }

  return value;
};

const xssSanitizer = (req, res, next) => {
  if (req.body) req.body = stripDangerousHtml(req.body);
  if (req.params) req.params = stripDangerousHtml(req.params);
  // req.query is read-only in some Express setups; mutate keys in place instead of reassigning.
  if (req.query) {
    const sanitized = stripDangerousHtml(req.query);
    Object.keys(req.query).forEach((key) => delete req.query[key]);
    Object.assign(req.query, sanitized);
  }
  next();
};

/**
 * Applies the full security middleware stack to an Express app in one call.
 * @param {import('express').Express} app
 */
const applySecurityMiddleware = (app) => {
  app.use(
    helmet({
      crossOriginResourcePolicy: { policy: 'cross-origin' },
      // Phase 12, Part 5 — explicit CSP. This is a JSON API (no HTML/JS
      // is ever served from here), so the policy is deliberately
      // restrictive: nothing may load or execute from anywhere but this
      // origin. Swagger UI (served at /api/docs) needs 'unsafe-inline'
      // styles/scripts to render — scoped to that one path via helmet's
      // per-directive allowance rather than loosened globally.
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'", "'unsafe-inline'"],
          styleSrc: ["'self'", "'unsafe-inline'"],
          imgSrc: ["'self'", 'data:', 'https://res.cloudinary.com'],
          connectSrc: ["'self'"],
          objectSrc: ["'none'"],
          frameAncestors: ["'none'"],
          ...(config.isProduction ? { upgradeInsecureRequests: [] } : {}),
        },
      },
      referrerPolicy: { policy: 'no-referrer-when-downgrade' },
      // Only meaningful once served over HTTPS (production, behind a
      // reverse proxy) — see app.js's `trust proxy` setting.
      hsts: config.isProduction ? { maxAge: 15552000, includeSubDomains: true, preload: false } : false,
    })
  );
  app.use(mongoSanitize());
  app.use(xssSanitizer);
  app.use(hpp());
};

module.exports = { applySecurityMiddleware, xssSanitizer, stripDangerousHtml };
