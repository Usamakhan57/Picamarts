'use strict';

const config = require('../config');
const ApiError = require('../utils/ApiError');
const httpStatus = require('../constants/httpStatus');
const logger = require('../utils/logger');
const { getRedisClient, isRedisReady } = require('../config/redis');

/**
 * Phase 12, Part 5 — brute-force login protection, layered on top of
 * (not a replacement for) `authLimiter`. `authLimiter` caps total
 * requests per IP regardless of outcome; this middleware specifically
 * tracks FAILED login attempts per IP+email pair and blocks further
 * attempts against that pair once a threshold is hit — the standard
 * "credential stuffing" defense that a flat request-rate limit alone
 * doesn't provide (a flat limit can't tell a legitimate user retrying
 * their own password apart from an attacker trying many).
 *
 * Entirely additive: it never touches auth.controller.js or
 * auth.service.js. It reads `res.statusCode` after the request
 * finishes (via the `finish` event) to decide whether the attempt
 * failed, exactly the way a reverse proxy or WAF would from outside
 * the app — no cooperation from the login handler is required.
 *
 * A no-op (calls `next()` immediately, counts nothing) whenever Redis
 * isn't configured/ready — same "degrade, never block" contract as
 * every other Redis-backed piece in this phase.
 */

const keyFor = (req) => {
  const email = (req.body?.email || '').toLowerCase().trim();
  return `${config.redis.cacheKeyPrefix}bruteforce:${req.ip}:${email}`;
};

const bruteForceGuard = async (req, res, next) => {
  if (!isRedisReady()) return next();

  const client = getRedisClient();
  const key = keyFor(req);
  const windowSeconds = config.bruteForce.windowMinutes * 60;

  let attempts;
  try {
    attempts = await client.get(key);
  } catch (error) {
    logger.warn(`Brute-force check failed, allowing request through: ${error.message}`);
    return next();
  }

  if (Number(attempts) >= config.bruteForce.maxAttempts) {
    logger.security(`Login blocked — too many failed attempts for ${req.ip} (${req.body?.email || 'unknown email'}).`);
    return next(
      new ApiError(
        httpStatus.TOO_MANY_REQUESTS,
        `Too many failed login attempts. Please try again in ${config.bruteForce.windowMinutes} minutes.`
      )
    );
  }

  res.on('finish', () => {
    if (res.statusCode === httpStatus.UNAUTHORIZED) {
      client
        .multi()
        .incr(key)
        .expire(key, windowSeconds)
        .exec()
        .catch((error) => logger.warn(`Failed to record failed login attempt: ${error.message}`));
      logger.security(`Failed login attempt for ${req.ip} (${req.body?.email || 'unknown email'}).`);
    } else if (res.statusCode < 300) {
      client.del(key).catch(() => {});
    }
  });

  return next();
};

module.exports = { bruteForceGuard };
