'use strict';

const { ZodError } = require('zod');
const ApiError = require('../utils/ApiError');
const httpStatus = require('../constants/httpStatus');

/**
 * Validates `req.body` / `req.query` / `req.params` against a Zod schema
 * shaped like `{ body?, query?, params? }`. On success, replaces each
 * validated segment with the parsed (and coerced/defaulted) result.
 *
 * Usage:
 *   const schema = z.object({ body: z.object({ email: z.string().email() }) });
 *   router.post('/', validate(schema), controller);
 */
const validate = (schema) => (req, res, next) => {
  try {
    const parsed = schema.parse({
      body: req.body,
      query: req.query,
      params: req.params,
    });

    if (parsed.body) req.body = parsed.body;
    if (parsed.params) req.params = parsed.params;
    if (parsed.query) {
      Object.keys(req.query).forEach((key) => delete req.query[key]);
      Object.assign(req.query, parsed.query);
    }

    next();
  } catch (error) {
    if (error instanceof ZodError) {
      const details = error.errors.map((e) => ({
        path: e.path.join('.'),
        message: e.message,
      }));
      next(new ApiError(httpStatus.UNPROCESSABLE_ENTITY, 'Validation failed', { details }));
      return;
    }

    next(error);
  }
};

module.exports = validate;
