'use strict';

const logger = require('../utils/logger');

/**
 * Phase 12, Part 6 — Performance logs. Separate from morgan's HTTP
 * access log (which records that a request happened) — this records
 * how long each request took, mirrored into performance-%DATE%.log via
 * logger.performance, and additionally warns (mirrored into
 * security-%DATE%.log has nothing to do with this — it stays purely a
 * performance signal) whenever a request exceeds the slow-request
 * threshold, since that's the figure an operator actually wants
 * alerted on rather than buried in per-request noise.
 *
 * @param {number} [slowRequestThresholdMs=1000]
 */
const performanceLogger = (slowRequestThresholdMs = 1000) => (req, res, next) => {
  const start = process.hrtime.bigint();

  res.on('finish', () => {
    const durationMs = Number(process.hrtime.bigint() - start) / 1e6;
    const meta = {
      method: req.method,
      url: req.originalUrl,
      statusCode: res.statusCode,
      durationMs: Math.round(durationMs * 100) / 100,
    };

    if (durationMs >= slowRequestThresholdMs) {
      logger.performance(`Slow request: ${req.method} ${req.originalUrl} took ${meta.durationMs}ms`, meta);
    } else {
      logger.performance(`${req.method} ${req.originalUrl} completed in ${meta.durationMs}ms`, meta);
    }
  });

  next();
};

module.exports = { performanceLogger };
