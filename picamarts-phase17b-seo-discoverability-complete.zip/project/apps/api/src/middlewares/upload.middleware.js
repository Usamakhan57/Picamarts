'use strict';

const multer = require('multer');
const ApiError = require('../utils/ApiError');

const DEFAULT_MAX_FILE_SIZE_MB = 25;

const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/svg+xml'];
const ALLOWED_DOCUMENT_TYPES = ['application/pdf', 'application/zip', 'application/x-zip-compressed'];
// Phase 14.1, Part 2 — Digital Asset Upload. Videos + plain-text/Office
// docs (license files are frequently a .txt or .docx) on top of the
// existing image/pdf/zip set — additive, ALLOWED_DOCUMENT_TYPES above
// is untouched so digitalFileUploader's existing behavior is unchanged.
const ALLOWED_VIDEO_TYPES = ['video/mp4', 'video/webm', 'video/quicktime'];
const ALLOWED_DIGITAL_DOCUMENT_TYPES = [
  ...ALLOWED_DOCUMENT_TYPES,
  'text/plain',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
];

/**
 * Builds a configured multer instance. Files are held in memory (not
 * written to disk) and streamed straight to Cloudinary from the buffer —
 * see utils/cloudinary uploader once business routes are added.
 *
 * @param {object} [options]
 * @param {string[]} [options.allowedMimeTypes] - defaults to images + pdf/zip
 * @param {number} [options.maxFileSizeMB]
 */
const buildUploader = ({
  allowedMimeTypes = [...ALLOWED_IMAGE_TYPES, ...ALLOWED_DOCUMENT_TYPES],
  maxFileSizeMB = DEFAULT_MAX_FILE_SIZE_MB,
} = {}) =>
  multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: maxFileSizeMB * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
      if (!allowedMimeTypes.includes(file.mimetype)) {
        cb(ApiError.badRequest(`Unsupported file type: ${file.mimetype}`));
        return;
      }
      cb(null, true);
    },
  });

const imageUploader = buildUploader({ allowedMimeTypes: ALLOWED_IMAGE_TYPES, maxFileSizeMB: 10 });
const digitalFileUploader = buildUploader({
  allowedMimeTypes: [...ALLOWED_IMAGE_TYPES, ...ALLOWED_DOCUMENT_TYPES],
  maxFileSizeMB: 100,
});
// Phase 14.1, Part 2 — Digital Asset Upload (ZIP/PDF/images/videos/
// documents/license files), 200MB ceiling (videos push past the
// existing 100MB digitalFileUploader default).
const digitalAssetUploader = buildUploader({
  allowedMimeTypes: [...ALLOWED_IMAGE_TYPES, ...ALLOWED_VIDEO_TYPES, ...ALLOWED_DIGITAL_DOCUMENT_TYPES],
  maxFileSizeMB: 200,
});

module.exports = {
  buildUploader,
  imageUploader,
  digitalFileUploader,
  digitalAssetUploader,
  ALLOWED_IMAGE_TYPES,
  ALLOWED_DOCUMENT_TYPES,
  ALLOWED_VIDEO_TYPES,
  ALLOWED_DIGITAL_DOCUMENT_TYPES,
};
