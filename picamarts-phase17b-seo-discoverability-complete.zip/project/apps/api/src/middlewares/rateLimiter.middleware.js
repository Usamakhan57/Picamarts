'use strict';

const rateLimit = require('express-rate-limit');
const config = require('../config');
const ApiError = require('../utils/ApiError');
const httpStatus = require('../constants/httpStatus');
const logger = require('../utils/logger');
const { getRedisClient } = require('../config/redis');

const handler = (req, res, next) => {
  logger.security(`Rate limit exceeded for ${req.ip} on ${req.method} ${req.originalUrl}`);
  next(new ApiError(httpStatus.TOO_MANY_REQUESTS, 'Too many requests. Please try again later.'));
};

/**
 * Phase 12, Part 5/2 — a Redis-backed store makes the rate limit
 * shared across every horizontally-scaled instance (PM2 cluster mode,
 * multiple containers) instead of each process counting in isolation,
 * which would let a client get N times the intended limit. Falls back
 * to express-rate-limit's own in-memory store — correct for a single
 * process, just not shared — whenever Redis isn't configured, so
 * nothing here ever throws for lack of Redis.
 */
const redisStore = () => {
  if (!config.redis.enabled) return undefined;

  try {
    const { RedisStore } = require('rate-limit-redis');
    const client = getRedisClient();
    if (!client) return undefined;

    return new RedisStore({
      sendCommand: (...args) => client.call(...args),
    });
  } catch (error) {
    logger.warn(`Falling back to in-memory rate limiting — Redis store unavailable: ${error.message}`);
    return undefined;
  }
};

/** General-purpose limiter, mounted on the whole API. */
const apiLimiter = rateLimit({
  windowMs: config.rateLimit.windowMs,
  max: config.rateLimit.max,
  standardHeaders: true,
  legacyHeaders: false,
  store: redisStore(),
  handler,
});

/** Stricter limiter for auth routes (login/register/refresh) once they exist. */
const authLimiter = rateLimit({
  windowMs: config.rateLimit.authWindowMs,
  max: config.rateLimit.authMax,
  standardHeaders: true,
  legacyHeaders: false,
  store: redisStore(),
  handler,
});

module.exports = { apiLimiter, authLimiter };
