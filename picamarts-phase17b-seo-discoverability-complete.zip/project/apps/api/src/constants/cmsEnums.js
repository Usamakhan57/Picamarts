'use strict';

/**
 * Phase 10.3 — CMS. Kept separate from every other module's enums —
 * nothing here describes marketplace/order/payment/review lifecycle.
 */

// --------------------------------------------------------------------
// Shared draft/published lifecycle (Pages, Blog posts, Homepage)
// --------------------------------------------------------------------

const CONTENT_STATUSES = Object.freeze({
  DRAFT: 'draft',
  PUBLISHED: 'published',
});
const CONTENT_STATUS_VALUES = Object.values(CONTENT_STATUSES);

// --------------------------------------------------------------------
// Part 1 — CMS Pages
// --------------------------------------------------------------------

/**
 * Fixed set of manageable static pages (Part 1 of the brief). One Page
 * document exists per type at most — enforced by a unique index on
 * `pageType` — so admins edit content for a known slot rather than
 * free-form page creation. `slug` stays independently editable (so
 * "about-us" can be served at a custom URL) while `pageType` is the
 * stable identifier the admin UI/API fetches by.
 */
const PAGE_TYPES = Object.freeze({
  HOMEPAGE: 'homepage',
  ABOUT_US: 'about-us',
  CONTACT_US: 'contact-us',
  PRIVACY_POLICY: 'privacy-policy',
  TERMS_CONDITIONS: 'terms-conditions',
  FAQ: 'faq',
  REFUND_POLICY: 'refund-policy',
  SHIPPING_POLICY: 'shipping-policy',
  COOKIE_POLICY: 'cookie-policy',
});
const PAGE_TYPE_VALUES = Object.values(PAGE_TYPES);

// --------------------------------------------------------------------
// Part 4 — Contact Management
// --------------------------------------------------------------------

const CONTACT_STATUSES = Object.freeze({
  NEW: 'new',
  IN_PROGRESS: 'in_progress',
  RESOLVED: 'resolved',
});
const CONTACT_STATUS_VALUES = Object.values(CONTACT_STATUSES);

// --------------------------------------------------------------------
// Part 5 — Newsletter
// --------------------------------------------------------------------

const NEWSLETTER_STATUSES = Object.freeze({
  SUBSCRIBED: 'subscribed',
  UNSUBSCRIBED: 'unsubscribed',
});
const NEWSLETTER_STATUS_VALUES = Object.values(NEWSLETTER_STATUSES);

module.exports = {
  CONTENT_STATUSES,
  CONTENT_STATUS_VALUES,
  PAGE_TYPES,
  PAGE_TYPE_VALUES,
  CONTACT_STATUSES,
  CONTACT_STATUS_VALUES,
  NEWSLETTER_STATUSES,
  NEWSLETTER_STATUS_VALUES,
};
