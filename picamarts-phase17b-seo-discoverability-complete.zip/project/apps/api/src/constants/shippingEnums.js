'use strict';

/**
 * Phase 14.2 — Physical Shipping & Fulfilment. Kept in its own file,
 * same convention as digitalDeliveryEnums.js/notificationEnums.js —
 * these describe the shipping/shipment envelope, never Product's or
 * Order's own lifecycle (those stay in productEnums.js/orderEnums.js).
 */

/** Part 1 — a profile's default method; the real per-destination cost still comes from its zones/rates (see shippingProfile.service.js#calculateShippingForCart). "calculated" is architecture-ready only — no live carrier-rate integration in this pass, see that same file. */
const SHIPPING_METHODS = Object.freeze({
  FREE: 'free',
  FIXED: 'fixed',
  CALCULATED: 'calculated',
});
const SHIPPING_METHOD_VALUES = Object.values(SHIPPING_METHODS);

/** Part 2 — a zone matches a destination address by one of these. */
const SHIPPING_ZONE_TYPES = Object.freeze({
  WORLDWIDE: 'worldwide',
  COUNTRY: 'country',
  STATE: 'state',
  REGION: 'region',
  POSTAL_CODE: 'postal_code',
});
const SHIPPING_ZONE_TYPE_VALUES = Object.values(SHIPPING_ZONE_TYPES);

/** Part 3 — how a rate's cost is computed. */
const SHIPPING_RATE_TYPES = Object.freeze({
  FLAT: 'flat',
  FREE: 'free',
  WEIGHT_BASED: 'weight_based',
  QUANTITY_BASED: 'quantity_based',
  ORDER_TOTAL_BASED: 'order_total_based',
});
const SHIPPING_RATE_TYPE_VALUES = Object.values(SHIPPING_RATE_TYPES);

/** Part 7 — a shipment's own lifecycle, distinct from (but synced onto) Order.status — see shipment.repository.js#syncOrderStatus. */
const SHIPMENT_STATUSES = Object.freeze({
  PENDING: 'pending',
  SHIPPED: 'shipped',
  IN_TRANSIT: 'in_transit',
  DELIVERED: 'delivered',
  RETURNED: 'returned',
});
const SHIPMENT_STATUS_VALUES = Object.values(SHIPMENT_STATUSES);

/** Maps a shipment status to the Order.status it should sync onto (additive values only — see constants/orderEnums.js). `null` = don't touch the order's status for this shipment transition. */
const SHIPMENT_TO_ORDER_STATUS = Object.freeze({
  [SHIPMENT_STATUSES.PENDING]: null,
  [SHIPMENT_STATUSES.SHIPPED]: 'shipped',
  [SHIPMENT_STATUSES.IN_TRANSIT]: 'shipped',
  [SHIPMENT_STATUSES.DELIVERED]: 'delivered',
  [SHIPMENT_STATUSES.RETURNED]: 'returned',
});

module.exports = {
  SHIPPING_METHODS,
  SHIPPING_METHOD_VALUES,
  SHIPPING_ZONE_TYPES,
  SHIPPING_ZONE_TYPE_VALUES,
  SHIPPING_RATE_TYPES,
  SHIPPING_RATE_TYPE_VALUES,
  SHIPMENT_STATUSES,
  SHIPMENT_STATUS_VALUES,
  SHIPMENT_TO_ORDER_STATUS,
};
