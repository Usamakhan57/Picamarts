'use strict';

/**
 * Phase 16B — Marketplace Wallet & Commission Engine.
 *
 * Kept as its own constants file (mirrors cmsEnums.js / analyticsEnums.js
 * / stripeConnectEnums.js — every phase gets its own enum module rather
 * than growing an unrelated one).
 */

// --------------------------------------------------------------------
// Wallet Ledger (Part 2)
// --------------------------------------------------------------------

/** Every ledger entry is either money coming IN to the seller's wallet, or going OUT. */
const LEDGER_DIRECTIONS = Object.freeze({
  CREDIT: 'credit',
  DEBIT: 'debit',
});
const LEDGER_DIRECTION_VALUES = Object.values(LEDGER_DIRECTIONS);

/**
 * What kind of event produced the entry. A single sale produces TWO
 * entries (SALE credit for the gross amount, COMMISSION_DEDUCTION debit
 * for the platform's cut) rather than one pre-netted credit, so the
 * ledger shows gross → commission → net explicitly (see
 * wallet.service.js#recordSaleForOrder) — this is what makes "every
 * transaction traceable" (Part 2) mean something concrete.
 */
const LEDGER_CATEGORIES = Object.freeze({
  SALE: 'sale',
  COMMISSION_DEDUCTION: 'commission_deduction',
  REFUND_ADJUSTMENT: 'refund_adjustment',
  MANUAL_ADJUSTMENT: 'manual_adjustment',
  OPENING_BALANCE: 'opening_balance',
  CLOSING_BALANCE: 'closing_balance',
  /**
   * Phase 16C — Seller Payouts. WITHDRAWAL_HOLD (debit) fires the
   * instant a withdrawal request is created, moving the requested
   * amount out of `availableBalance` and into `lockedBalance` — this
   * IS the "balance locking" (Part 2), not a separate mechanism.
   * WITHDRAWAL_RELEASE (credit) reverses a hold exactly (cancel/
   * reject/failed). WITHDRAWAL_COMPLETED is a zero-amount audit
   * marker only (money already left at hold time) — same
   * "amount: 0, informational" convention recordClosingBalanceSnapshot
   * already established, so it never double-counts against
   * `pendingBalance`'s live ledger sum.
   */
  WITHDRAWAL_HOLD: 'withdrawal_hold',
  WITHDRAWAL_RELEASE: 'withdrawal_release',
  WITHDRAWAL_COMPLETED: 'withdrawal_completed',
  /**
   * Phase 16D — Refunds, Returns, Disputes & Chargebacks. REFUND_ADJUSTMENT
   * (already defined above, Phase 16B) is reused as-is for a PARTIAL
   * refund's proportional reversal too — see
   * wallet.service.js#reverseEarningsForRefundRequest — so no new
   * category is needed for Parts 1-5. DISPUTE_HOLD (debit) fires the
   * instant a chargeback/dispute is opened, reserving the seller's net
   * earnings on that order pending the outcome — the exact same
   * "balance locking IS the ledger" mechanism Phase 16C's
   * WITHDRAWAL_HOLD established. DISPUTE_RELEASE (credit) reverses it
   * exactly on a WON/CLOSED outcome. DISPUTE_LOST is a zero-amount
   * audit-only marker on a LOST outcome (the held funds simply stay
   * debited — same "amount: 0, informational" convention as
   * WITHDRAWAL_COMPLETED).
   */
  DISPUTE_HOLD: 'dispute_hold',
  DISPUTE_RELEASE: 'dispute_release',
  DISPUTE_LOST: 'dispute_lost',
});
const LEDGER_CATEGORY_VALUES = Object.values(LEDGER_CATEGORIES);

// --------------------------------------------------------------------
// Commission Engine (Part 3)
// --------------------------------------------------------------------

/**
 * Where an item's applied commission rate came from — resolution order
 * is seller override → category rate → global default (see
 * commission.service.js#resolveCommissionRate). `MIXED` is used on a
 * CommissionRecord only, when an order's items for one seller resolved
 * from more than one source (the record stores a single blended
 * effective rate in that case).
 */
const COMMISSION_SOURCES = Object.freeze({
  SELLER_OVERRIDE: 'seller_override',
  CATEGORY: 'category',
  GLOBAL: 'global',
  MIXED: 'mixed',
});
const COMMISSION_SOURCE_VALUES = Object.values(COMMISSION_SOURCES);

module.exports = {
  LEDGER_DIRECTIONS,
  LEDGER_DIRECTION_VALUES,
  LEDGER_CATEGORIES,
  LEDGER_CATEGORY_VALUES,
  COMMISSION_SOURCES,
  COMMISSION_SOURCE_VALUES,
};
