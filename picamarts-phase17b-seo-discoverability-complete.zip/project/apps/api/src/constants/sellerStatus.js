'use strict';

/**
 * Seller application/account status. Defined here (rather than only
 * inside the Mongoose schema) so validators and route middleware can
 * reference the same enum without importing the model — mirrors the
 * pattern used by constants/roles.js and constants/productEnums.js.
 *
 * Lifecycle:
 *   PENDING   — application submitted, awaiting admin review (default)
 *   APPROVED  — admin approved; store is live
 *   REJECTED  — admin rejected the application (see `statusReason`)
 *   SUSPENDED — was approved, temporarily disabled by an admin (see `statusReason`)
 *
 * REJECTED sellers may resubmit (via a new verification document
 * upload), which moves them back to PENDING. SUSPENDED sellers can only
 * be moved back to APPROVED ("reinstate") by an admin.
 */
const SELLER_STATUSES = Object.freeze({
  PENDING: 'pending',
  APPROVED: 'approved',
  REJECTED: 'rejected',
  SUSPENDED: 'suspended',
});

const SELLER_STATUS_VALUES = Object.values(SELLER_STATUSES);

/** Fallback commission rate (%) applied to a seller at application time. */
const DEFAULT_COMMISSION_RATE = 15;

module.exports = { SELLER_STATUSES, SELLER_STATUS_VALUES, DEFAULT_COMMISSION_RATE };
