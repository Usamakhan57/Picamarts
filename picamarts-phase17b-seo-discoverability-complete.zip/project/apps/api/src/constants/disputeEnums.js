'use strict';

/**
 * Phase 16D — Refunds, Returns, Disputes & Chargebacks, Parts 6-7.
 *
 * Design decision (flagged): a bank-initiated Stripe "chargeback"
 * (Part 6) and a marketplace-native buyer-opened "dispute" (Part 7)
 * are modeled as ONE collection (`Dispute`, see models/Dispute.js)
 * distinguished by `origin`, rather than two near-duplicate models —
 * both need the same evidence/messages/status-review shape, and a
 * chargeback IS a dispute from the platform's perspective (money at
 * risk pending a third party's decision). This avoids building two
 * parallel evidence-submission/admin-review pipelines.
 */

/** Where a Dispute document came from. */
const DISPUTE_ORIGINS = Object.freeze({
  STRIPE_CHARGEBACK: 'stripe_chargeback',
  BUYER_OPENED: 'buyer_opened',
});
const DISPUTE_ORIGIN_VALUES = Object.values(DISPUTE_ORIGINS);

/**
 * Unified status vocabulary. For a STRIPE_CHARGEBACK dispute, `open`/
 * `under_review`/`won`/`lost`/`closed` are driven by Stripe's own
 * `charge.dispute.*` webhook events (see dispute.service.js#syncFromStripeEvent) —
 * `evidence_submitted` is additionally set locally the moment a seller
 * submits evidence through our API, ahead of Stripe's own async
 * `needs_response` -> `under_review` transition. For a BUYER_OPENED
 * dispute, an admin drives the same status set directly (Part 7's
 * "Admin: Review, Resolve, Close").
 */
const DISPUTE_STATUSES = Object.freeze({
  OPEN: 'open',
  UNDER_REVIEW: 'under_review',
  EVIDENCE_SUBMITTED: 'evidence_submitted',
  WON: 'won',
  LOST: 'lost',
  CLOSED: 'closed',
});
const DISPUTE_STATUS_VALUES = Object.values(DISPUTE_STATUSES);

/** A dispute no longer needs action / no longer holds funds once here. */
const RESOLVED_DISPUTE_STATUSES = [DISPUTE_STATUSES.WON, DISPUTE_STATUSES.LOST, DISPUTE_STATUSES.CLOSED];

/** Stripe's own charge.dispute reason codes — stored as-is for a STRIPE_CHARGEBACK dispute. */
const STRIPE_DISPUTE_REASONS = Object.freeze({
  DUPLICATE: 'duplicate',
  FRAUDULENT: 'fraudulent',
  SUBSCRIPTION_CANCELED: 'subscription_canceled',
  PRODUCT_UNACCEPTABLE: 'product_unacceptable',
  PRODUCT_NOT_RECEIVED: 'product_not_received',
  UNRECOGNIZED: 'unrecognized',
  CREDIT_NOT_PROCESSED: 'credit_not_processed',
  GENERAL: 'general',
  INCORRECT_ACCOUNT_DETAILS: 'incorrect_account_details',
  INSUFFICIENT_FUNDS: 'insufficient_funds',
  BANK_CANNOT_PROCESS: 'bank_cannot_process',
  DEBIT_NOT_AUTHORIZED: 'debit_not_authorized',
  CUSTOMER_INITIATED: 'customer_initiated',
});
const STRIPE_DISPUTE_REASON_VALUES = Object.values(STRIPE_DISPUTE_REASONS);

/** Reasons a buyer picks from when opening a BUYER_OPENED dispute directly (no bank involved). */
const BUYER_DISPUTE_REASONS = Object.freeze({
  ITEM_NOT_AS_DESCRIBED: 'item_not_as_described',
  ITEM_NOT_RECEIVED: 'item_not_received',
  UNAUTHORIZED_CHARGE: 'unauthorized_charge',
  SELLER_UNRESPONSIVE: 'seller_unresponsive',
  QUALITY_ISSUE: 'quality_issue',
  OTHER: 'other',
});
const BUYER_DISPUTE_REASON_VALUES = Object.values(BUYER_DISPUTE_REASONS);

/** Who submitted a given evidence/message entry — buyer, seller, or admin (Part 7). */
const DISPUTE_PARTICIPANTS = Object.freeze({
  BUYER: 'buyer',
  SELLER: 'seller',
  ADMIN: 'admin',
});
const DISPUTE_PARTICIPANT_VALUES = Object.values(DISPUTE_PARTICIPANTS);

module.exports = {
  DISPUTE_ORIGINS,
  DISPUTE_ORIGIN_VALUES,
  DISPUTE_STATUSES,
  DISPUTE_STATUS_VALUES,
  RESOLVED_DISPUTE_STATUSES,
  STRIPE_DISPUTE_REASONS,
  STRIPE_DISPUTE_REASON_VALUES,
  BUYER_DISPUTE_REASONS,
  BUYER_DISPUTE_REASON_VALUES,
  DISPUTE_PARTICIPANTS,
  DISPUTE_PARTICIPANT_VALUES,
};
