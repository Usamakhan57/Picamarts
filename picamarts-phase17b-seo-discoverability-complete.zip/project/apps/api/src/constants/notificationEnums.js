'use strict';

/**
 * Phase 10.2 — Notification System.
 * Kept separate from orderEnums/paymentEnums/reviewEnums (mirrors how
 * those files keep their own lifecycles independent) — this module
 * only describes the notification envelope itself, never the business
 * rules of the module that triggered it.
 */

// --------------------------------------------------------------------
// Notification types
// --------------------------------------------------------------------

const NOTIFICATION_TYPES = Object.freeze({
  // Orders
  ORDER_CREATED: 'order_created',
  ORDER_CONFIRMED: 'order_confirmed',
  ORDER_PROCESSING: 'order_processing',
  ORDER_PACKED: 'order_packed',
  ORDER_SHIPPED: 'order_shipped',
  ORDER_DELIVERED: 'order_delivered',
  ORDER_CANCELLED: 'order_cancelled',
  // Phase 14.2 — Physical Shipping & Fulfilment
  TRACKING_ADDED: 'tracking_added',

  // Payments
  PAYMENT_SUCCESSFUL: 'payment_successful',
  PAYMENT_FAILED: 'payment_failed',
  REFUND_ISSUED: 'refund_issued',

  // Reviews
  REVIEW_RECEIVED: 'review_received',
  REVIEW_APPROVED: 'review_approved',
  REVIEW_HIDDEN: 'review_hidden',
  REVIEW_REPORTED: 'review_reported',

  // Digital Delivery (Phase 14.1)
  DIGITAL_FILES_READY: 'digital_files_ready',
  LICENSE_ASSIGNED: 'license_assigned',
  DOWNLOAD_EXPIRING: 'download_expiring',

  // Authentication
  EMAIL_VERIFIED: 'email_verified',
  PASSWORD_CHANGED: 'password_changed',
  PASSWORD_RESET: 'password_reset',

  // Admin
  BROADCAST_NOTIFICATION: 'broadcast_notification',
  SYSTEM_ANNOUNCEMENT: 'system_announcement',
  MAINTENANCE_NOTICE: 'maintenance_notice',

  // Phase 16D — Refunds, Returns, Disputes & Chargebacks
  REFUND_REQUESTED: 'refund_requested',
  REFUND_STATUS_CHANGED: 'refund_status_changed',
  RETURN_REQUESTED: 'return_requested',
  RETURN_STATUS_CHANGED: 'return_status_changed',
  DISPUTE_OPENED: 'dispute_opened',
  DISPUTE_STATUS_CHANGED: 'dispute_status_changed',
  CHARGEBACK_OPENED: 'chargeback_opened',
});

const NOTIFICATION_TYPE_VALUES = Object.values(NOTIFICATION_TYPES);

/** Types an admin may use with POST /notifications/broadcast. */
const ADMIN_BROADCAST_TYPES = [
  NOTIFICATION_TYPES.BROADCAST_NOTIFICATION,
  NOTIFICATION_TYPES.SYSTEM_ANNOUNCEMENT,
  NOTIFICATION_TYPES.MAINTENANCE_NOTICE,
];

// --------------------------------------------------------------------
// Priority
// --------------------------------------------------------------------

const NOTIFICATION_PRIORITIES = Object.freeze({
  LOW: 'low',
  NORMAL: 'normal',
  HIGH: 'high',
});

const NOTIFICATION_PRIORITY_VALUES = Object.values(NOTIFICATION_PRIORITIES);

/** Sensible default priority per type — callers may still override it. */
const DEFAULT_PRIORITY_BY_TYPE = Object.freeze({
  [NOTIFICATION_TYPES.ORDER_CREATED]: NOTIFICATION_PRIORITIES.NORMAL,
  [NOTIFICATION_TYPES.ORDER_CONFIRMED]: NOTIFICATION_PRIORITIES.NORMAL,
  [NOTIFICATION_TYPES.ORDER_PROCESSING]: NOTIFICATION_PRIORITIES.NORMAL,
  [NOTIFICATION_TYPES.ORDER_PACKED]: NOTIFICATION_PRIORITIES.NORMAL,
  [NOTIFICATION_TYPES.ORDER_SHIPPED]: NOTIFICATION_PRIORITIES.NORMAL,
  [NOTIFICATION_TYPES.TRACKING_ADDED]: NOTIFICATION_PRIORITIES.NORMAL,
  [NOTIFICATION_TYPES.ORDER_DELIVERED]: NOTIFICATION_PRIORITIES.NORMAL,
  [NOTIFICATION_TYPES.ORDER_CANCELLED]: NOTIFICATION_PRIORITIES.HIGH,
  [NOTIFICATION_TYPES.PAYMENT_SUCCESSFUL]: NOTIFICATION_PRIORITIES.NORMAL,
  [NOTIFICATION_TYPES.PAYMENT_FAILED]: NOTIFICATION_PRIORITIES.HIGH,
  [NOTIFICATION_TYPES.REFUND_ISSUED]: NOTIFICATION_PRIORITIES.HIGH,
  [NOTIFICATION_TYPES.REVIEW_RECEIVED]: NOTIFICATION_PRIORITIES.NORMAL,
  [NOTIFICATION_TYPES.REVIEW_APPROVED]: NOTIFICATION_PRIORITIES.NORMAL,
  [NOTIFICATION_TYPES.REVIEW_HIDDEN]: NOTIFICATION_PRIORITIES.NORMAL,
  [NOTIFICATION_TYPES.REVIEW_REPORTED]: NOTIFICATION_PRIORITIES.NORMAL,
  [NOTIFICATION_TYPES.DIGITAL_FILES_READY]: NOTIFICATION_PRIORITIES.NORMAL,
  [NOTIFICATION_TYPES.LICENSE_ASSIGNED]: NOTIFICATION_PRIORITIES.NORMAL,
  [NOTIFICATION_TYPES.DOWNLOAD_EXPIRING]: NOTIFICATION_PRIORITIES.HIGH,
  [NOTIFICATION_TYPES.EMAIL_VERIFIED]: NOTIFICATION_PRIORITIES.LOW,
  [NOTIFICATION_TYPES.PASSWORD_CHANGED]: NOTIFICATION_PRIORITIES.HIGH,
  [NOTIFICATION_TYPES.PASSWORD_RESET]: NOTIFICATION_PRIORITIES.HIGH,
  [NOTIFICATION_TYPES.BROADCAST_NOTIFICATION]: NOTIFICATION_PRIORITIES.NORMAL,
  [NOTIFICATION_TYPES.SYSTEM_ANNOUNCEMENT]: NOTIFICATION_PRIORITIES.NORMAL,
  [NOTIFICATION_TYPES.MAINTENANCE_NOTICE]: NOTIFICATION_PRIORITIES.HIGH,
  [NOTIFICATION_TYPES.REFUND_REQUESTED]: NOTIFICATION_PRIORITIES.NORMAL,
  [NOTIFICATION_TYPES.REFUND_STATUS_CHANGED]: NOTIFICATION_PRIORITIES.HIGH,
  [NOTIFICATION_TYPES.RETURN_REQUESTED]: NOTIFICATION_PRIORITIES.NORMAL,
  [NOTIFICATION_TYPES.RETURN_STATUS_CHANGED]: NOTIFICATION_PRIORITIES.NORMAL,
  [NOTIFICATION_TYPES.DISPUTE_OPENED]: NOTIFICATION_PRIORITIES.HIGH,
  [NOTIFICATION_TYPES.DISPUTE_STATUS_CHANGED]: NOTIFICATION_PRIORITIES.HIGH,
  [NOTIFICATION_TYPES.CHARGEBACK_OPENED]: NOTIFICATION_PRIORITIES.HIGH,
});

// --------------------------------------------------------------------
// Related entity
// --------------------------------------------------------------------

const RELATED_ENTITY_TYPES = Object.freeze({
  ORDER: 'order',
  PAYMENT: 'payment',
  REVIEW: 'review',
  USER: 'user',
  SYSTEM: 'system',
  DOWNLOAD: 'download',
  SHIPMENT: 'shipment',
  // Phase 16D
  REFUND_REQUEST: 'refund_request',
  RETURN_REQUEST: 'return_request',
  DISPUTE: 'dispute',
});

const RELATED_ENTITY_TYPE_VALUES = Object.values(RELATED_ENTITY_TYPES);

// --------------------------------------------------------------------
// Email eligibility
// --------------------------------------------------------------------

/**
 * Only these types ever attempt an email send (Part 5 of the brief).
 * Every other type is in-app only. This is enforced in
 * notification.service.js — an emailPayload passed for an ineligible
 * type is silently ignored rather than sent.
 */
const EMAIL_ELIGIBLE_TYPES = [
  NOTIFICATION_TYPES.ORDER_CREATED, // "Order Confirmation"
  NOTIFICATION_TYPES.PAYMENT_SUCCESSFUL,
  NOTIFICATION_TYPES.PAYMENT_FAILED,
  NOTIFICATION_TYPES.REFUND_ISSUED,
  NOTIFICATION_TYPES.PASSWORD_RESET,
  NOTIFICATION_TYPES.BROADCAST_NOTIFICATION,
  NOTIFICATION_TYPES.SYSTEM_ANNOUNCEMENT,
  NOTIFICATION_TYPES.MAINTENANCE_NOTICE,
  NOTIFICATION_TYPES.DIGITAL_FILES_READY,
  NOTIFICATION_TYPES.LICENSE_ASSIGNED,
  NOTIFICATION_TYPES.DOWNLOAD_EXPIRING,
  NOTIFICATION_TYPES.ORDER_PROCESSING,
  NOTIFICATION_TYPES.ORDER_SHIPPED,
  NOTIFICATION_TYPES.TRACKING_ADDED,
  NOTIFICATION_TYPES.ORDER_DELIVERED,
];

// --------------------------------------------------------------------
// Sort presets exposed via GET /notifications
// --------------------------------------------------------------------

const NOTIFICATION_SORT_OPTIONS = Object.freeze({
  NEWEST: 'newest',
  OLDEST: 'oldest',
});

const NOTIFICATION_SORT_VALUES = Object.values(NOTIFICATION_SORT_OPTIONS);

module.exports = {
  NOTIFICATION_TYPES,
  NOTIFICATION_TYPE_VALUES,
  ADMIN_BROADCAST_TYPES,
  NOTIFICATION_PRIORITIES,
  NOTIFICATION_PRIORITY_VALUES,
  DEFAULT_PRIORITY_BY_TYPE,
  RELATED_ENTITY_TYPES,
  RELATED_ENTITY_TYPE_VALUES,
  EMAIL_ELIGIBLE_TYPES,
  NOTIFICATION_SORT_OPTIONS,
  NOTIFICATION_SORT_VALUES,
};
