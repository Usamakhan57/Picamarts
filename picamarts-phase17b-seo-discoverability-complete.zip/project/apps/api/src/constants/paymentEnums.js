'use strict';

/**
 * Phase 9 — Payments. Kept separate from orderEnums.js: Order's own
 * `paymentStatus` field (pending/paid/failed/refunded) is a coarse
 * summary the Order module already owns, while these describe the
 * lifecycle of an individual Payment record/attempt against a
 * provider (Stripe). Payment.service.js is the only place that
 * translates between the two.
 */

const PAYMENT_PROVIDERS = Object.freeze({
  STRIPE: 'stripe',
});
const PAYMENT_PROVIDER_VALUES = Object.values(PAYMENT_PROVIDERS);

const PAYMENT_METHODS = Object.freeze({
  CARD: 'card',
});
const PAYMENT_METHOD_VALUES = Object.values(PAYMENT_METHODS);

/**
 * A single payment attempt's own status:
 *   PENDING     - PaymentIntent created, not yet confirmed
 *   PROCESSING  - confirmed, awaiting an async result (e.g. 3DS)
 *   SUCCEEDED   - funds captured
 *   FAILED      - the provider declined/errored the confirmation
 *   CANCELLED   - the PaymentIntent was cancelled before completion
 */
const PAYMENT_STATUSES = Object.freeze({
  PENDING: 'pending',
  PROCESSING: 'processing',
  SUCCEEDED: 'succeeded',
  FAILED: 'failed',
  CANCELLED: 'cancelled',
});
const PAYMENT_STATUS_VALUES = Object.values(PAYMENT_STATUSES);

/** A payment is finished (no further confirm/cancel is valid) once it reaches one of these. */
const TERMINAL_PAYMENT_STATUSES = [
  PAYMENT_STATUSES.SUCCEEDED,
  PAYMENT_STATUSES.FAILED,
  PAYMENT_STATUSES.CANCELLED,
];

const REFUND_STATUSES = Object.freeze({
  NONE: 'none',
  PARTIAL: 'partial',
  FULL: 'full',
});
const REFUND_STATUS_VALUES = Object.values(REFUND_STATUSES);

module.exports = {
  PAYMENT_PROVIDERS,
  PAYMENT_PROVIDER_VALUES,
  PAYMENT_METHODS,
  PAYMENT_METHOD_VALUES,
  PAYMENT_STATUSES,
  PAYMENT_STATUS_VALUES,
  TERMINAL_PAYMENT_STATUSES,
  REFUND_STATUSES,
  REFUND_STATUS_VALUES,
};
