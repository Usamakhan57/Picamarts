'use strict';

/**
 * Phase 6 — Product Media. Kept in its own file rather than added to
 * productEnums.js since these are upload/storage constraints, not
 * product field enums.
 */

/** Accepted image formats for both thumbnail and gallery uploads. */
const PRODUCT_IMAGE_MIME_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/avif'];

/** A single thumbnail per product — the upload endpoint always replaces it, never adds a second. */
const MAX_THUMBNAIL_COUNT = 1;

/** A product's gallery can hold at most this many images. */
const MAX_GALLERY_IMAGES = 20;

/** Per-file upload size ceiling. */
const MAX_IMAGE_SIZE_MB = 10;

/** Phase 14.1, Part 2 — a digital product can carry at most this many downloadable assets (files, license docs, etc. combined). */
const MAX_DOWNLOAD_FILES = 20;

/** Per-file upload size ceiling for digital assets (higher than images — covers video/zip). */
const MAX_DOWNLOAD_FILE_SIZE_MB = 200;

module.exports = {
  PRODUCT_IMAGE_MIME_TYPES,
  MAX_THUMBNAIL_COUNT,
  MAX_GALLERY_IMAGES,
  MAX_IMAGE_SIZE_MB,
  MAX_DOWNLOAD_FILES,
  MAX_DOWNLOAD_FILE_SIZE_MB,
};
