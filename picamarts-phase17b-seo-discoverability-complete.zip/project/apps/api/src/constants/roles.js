'use strict';

/**
 * Marketplace roles. Defined here (rather than only inside a Mongoose
 * schema) so route-level `authorize(...)` middleware and validators can
 * reference the same enum before the User model exists.
 */
const ROLES = Object.freeze({
  BUYER: 'buyer',
  SELLER: 'seller',
  ADMIN: 'admin',
});

const ROLE_VALUES = Object.values(ROLES);

module.exports = { ROLES, ROLE_VALUES };
