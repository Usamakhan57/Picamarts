'use strict';

/**
 * Phase 16C — Seller Payouts & Stripe Transfers.
 *
 * Own constants file, mirrors walletEnums.js/stripeConnectEnums.js/
 * cmsEnums.js's established "every phase gets its own enum module"
 * convention.
 *
 * Lifecycle (see payout.service.js for the actual transitions):
 *
 *   PENDING --(seller cancels)--> CANCELLED
 *   PENDING --(admin rejects)---> REJECTED
 *   PENDING --(admin approves)--> APPROVED --> PROCESSING --> COMPLETED
 *                                                          \-> FAILED --(admin retries)--> PROCESSING --> ...
 *
 * APPROVED/PROCESSING are both "no longer cancellable by the seller"
 * (Part 1's "before processing" only covers PENDING). FAILED can be
 * retried any number of times (Part 5) — `retryCount` on
 * WithdrawalRequest tracks how many attempts have been made.
 */
const PAYOUT_STATUSES = Object.freeze({
  PENDING: 'pending',
  APPROVED: 'approved',
  PROCESSING: 'processing',
  COMPLETED: 'completed',
  REJECTED: 'rejected',
  FAILED: 'failed',
  CANCELLED: 'cancelled',
});
const PAYOUT_STATUS_VALUES = Object.values(PAYOUT_STATUSES);

/** Statuses in which a withdrawal request still holds a balance lock. */
const LOCKED_STATUSES = [
  PAYOUT_STATUSES.PENDING,
  PAYOUT_STATUSES.APPROVED,
  PAYOUT_STATUSES.PROCESSING,
  PAYOUT_STATUSES.FAILED,
];

/** Statuses that block a seller from opening a second concurrent request (Part 1's "prevent duplicate requests"). */
const OPEN_STATUSES = [PAYOUT_STATUSES.PENDING, PAYOUT_STATUSES.APPROVED, PAYOUT_STATUSES.PROCESSING];

module.exports = { PAYOUT_STATUSES, PAYOUT_STATUS_VALUES, LOCKED_STATUSES, OPEN_STATUSES };
