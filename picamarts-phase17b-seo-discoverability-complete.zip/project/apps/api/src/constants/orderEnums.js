'use strict';

/**
 * Phase 8, Part 2 — Orders. Kept separate from productEnums.js since
 * these describe the order lifecycle, not a product field.
 */

const ORDER_STATUSES = Object.freeze({
  PENDING: 'pending',
  CONFIRMED: 'confirmed',
  PROCESSING: 'processing',
  PACKED: 'packed',
  SHIPPED: 'shipped',
  DELIVERED: 'delivered',
  CANCELLED: 'cancelled',
  REFUNDED: 'refunded',
  // Phase 14.2 — Physical Shipping & Fulfilment. Additive only: these
  // three are new selectable values, synced onto Order.status by
  // shipment.repository.js#syncOrderStatus (a direct, narrowly-scoped
  // write into this model, the same convention payment.repository.js
  // and digitalDelivery.repository.js already established) — never
  // via order.service.js/controller.js, which remain untouched.
  COMPLETED: 'completed',
  RETURNED: 'returned',
  REFUND_REQUESTED: 'refund_requested',
});
const ORDER_STATUS_VALUES = Object.values(ORDER_STATUSES);

/** Statuses a seller may set via PATCH /orders/:orderId/status — fulfillment only, never cancel/refund (those are buyer/admin/payment-driven). */
const SELLER_UPDATABLE_ORDER_STATUSES = [
  ORDER_STATUSES.CONFIRMED,
  ORDER_STATUSES.PROCESSING,
  ORDER_STATUSES.PACKED,
  ORDER_STATUSES.SHIPPED,
  ORDER_STATUSES.DELIVERED,
];

/** Terminal statuses — once here, an order can no longer be moved via PATCH /orders/:orderId/status. */
const TERMINAL_ORDER_STATUSES = [ORDER_STATUSES.CANCELLED, ORDER_STATUSES.REFUNDED];

const PAYMENT_STATUSES = Object.freeze({
  PENDING: 'pending',
  PAID: 'paid',
  FAILED: 'failed',
  REFUNDED: 'refunded',
});
const PAYMENT_STATUS_VALUES = Object.values(PAYMENT_STATUSES);

module.exports = {
  ORDER_STATUSES,
  ORDER_STATUS_VALUES,
  SELLER_UPDATABLE_ORDER_STATUSES,
  TERMINAL_ORDER_STATUSES,
  PAYMENT_STATUSES,
  PAYMENT_STATUS_VALUES,
};
