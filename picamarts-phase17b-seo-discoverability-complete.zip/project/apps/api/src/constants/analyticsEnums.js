'use strict';

/**
 * Phase 11 — Analytics & Admin Reports.
 * Defined here (rather than only inside a validator) so the service,
 * repository, and validators can all reference the same enums without
 * importing each other — mirrors the pattern used by orderEnums.js,
 * paymentEnums.js, reviewEnums.js.
 */

/** Sales-series bucket granularity (Part 2). `custom` means "bucket by day within an arbitrary from/to range". */
const SALES_PERIODS = Object.freeze({
  DAILY: 'daily',
  WEEKLY: 'weekly',
  MONTHLY: 'monthly',
  YEARLY: 'yearly',
  CUSTOM: 'custom',
});
const SALES_PERIOD_VALUES = Object.values(SALES_PERIODS);

/** Revenue breakdown dimensions (Part 4). */
const REVENUE_GROUP_BY = Object.freeze({
  TREND: 'trend',
  CATEGORY: 'category',
  SELLER: 'seller',
  PRODUCT: 'product',
  PAYMENT_METHOD: 'payment_method',
});
const REVENUE_GROUP_BY_VALUES = Object.values(REVENUE_GROUP_BY);

/** Product analytics views (Part 5). Phase 17A.2 adds TRENDING (delegates to the same recency+popularity heuristic as /products/trending) and MOST_WISHLISTED. */
const PRODUCT_ANALYTICS_TYPES = Object.freeze({
  BEST_SELLING: 'best_selling',
  MOST_VIEWED: 'most_viewed',
  HIGHEST_RATED: 'highest_rated',
  LOW_STOCK: 'low_stock',
  OUT_OF_STOCK: 'out_of_stock',
  MOST_WISHLISTED: 'most_wishlisted',
});
const PRODUCT_ANALYTICS_TYPE_VALUES = Object.values(PRODUCT_ANALYTICS_TYPES);

/** Report export formats (Part 10). */
const EXPORT_FORMATS = Object.freeze({
  CSV: 'csv',
  XLSX: 'xlsx',
  PDF: 'pdf',
});
const EXPORT_FORMAT_VALUES = Object.values(EXPORT_FORMATS);

/**
 * Reports that can be exported (Part 10/12). `sellers`/`customers`/
 * `payments` are platform-wide and admin-only (see analytics.service.js
 * #assertReportAccess); every other report is available to admins
 * (unscoped) and sellers (auto-scoped to their own store).
 */
const EXPORTABLE_REPORTS = Object.freeze({
  SALES: 'sales',
  ORDERS: 'orders',
  REVENUE: 'revenue',
  PRODUCTS: 'products',
  SELLERS: 'sellers',
  CUSTOMERS: 'customers',
  PAYMENTS: 'payments',
  REVIEWS: 'reviews',
});
const EXPORTABLE_REPORT_VALUES = Object.values(EXPORTABLE_REPORTS);

/** Reports restricted to admins even though the base route allows sellers in. */
const ADMIN_ONLY_REPORTS = [EXPORTABLE_REPORTS.SELLERS, EXPORTABLE_REPORTS.CUSTOMERS, EXPORTABLE_REPORTS.PAYMENTS];

module.exports = {
  SALES_PERIODS,
  SALES_PERIOD_VALUES,
  REVENUE_GROUP_BY,
  REVENUE_GROUP_BY_VALUES,
  PRODUCT_ANALYTICS_TYPES,
  PRODUCT_ANALYTICS_TYPE_VALUES,
  EXPORT_FORMATS,
  EXPORT_FORMAT_VALUES,
  EXPORTABLE_REPORTS,
  EXPORTABLE_REPORT_VALUES,
  ADMIN_ONLY_REPORTS,
};
