'use strict';

/**
 * Marketplace product enums. Defined here (rather than only inside the
 * Mongoose schema) so validators and, later, business logic can
 * reference the same values without importing the model.
 */
const PRODUCT_TYPES = Object.freeze({
  DIGITAL: 'digital',
  PHYSICAL: 'physical',
  BOTH: 'both',
});
const PRODUCT_TYPE_VALUES = Object.values(PRODUCT_TYPES);

const PRODUCT_STATUSES = Object.freeze({
  DRAFT: 'draft',
  PUBLISHED: 'published',
  ARCHIVED: 'archived',
  // Soft-delete marker — never a physical delete. Products in this
  // status are excluded from every public/seller/admin read path
  // except the admin "trash" view (see product.service.js).
  DELETED: 'deleted',
});
const PRODUCT_STATUS_VALUES = Object.values(PRODUCT_STATUSES);

/** Statuses a client may set directly via create/update. `deleted` is only ever reached through the soft-delete endpoint. */
const WRITABLE_PRODUCT_STATUS_VALUES = PRODUCT_STATUS_VALUES.filter((s) => s !== PRODUCT_STATUSES.DELETED);

const WEIGHT_UNITS = Object.freeze({ KG: 'kg', G: 'g', LB: 'lb', OZ: 'oz' });
const WEIGHT_UNIT_VALUES = Object.values(WEIGHT_UNITS);

const DIMENSION_UNITS = Object.freeze({ CM: 'cm', IN: 'in', M: 'm' });
const DIMENSION_UNIT_VALUES = Object.values(DIMENSION_UNITS);

const PRODUCT_CONDITIONS = Object.freeze({
  NEW: 'new',
  USED: 'used',
  REFURBISHED: 'refurbished',
});
const PRODUCT_CONDITION_VALUES = Object.values(PRODUCT_CONDITIONS);

/** Derived stock-status filter values (not stored — computed from stock/lowStockThreshold/allowBackorder). See product.controller.js. */
const STOCK_STATUSES = Object.freeze({
  IN_STOCK: 'in_stock',
  OUT_OF_STOCK: 'out_of_stock',
  LOW_STOCK: 'low_stock',
});
const STOCK_STATUS_VALUES = Object.values(STOCK_STATUSES);

module.exports = {
  PRODUCT_TYPES,
  PRODUCT_TYPE_VALUES,
  PRODUCT_STATUSES,
  PRODUCT_STATUS_VALUES,
  WRITABLE_PRODUCT_STATUS_VALUES,
  WEIGHT_UNITS,
  WEIGHT_UNIT_VALUES,
  DIMENSION_UNITS,
  DIMENSION_UNIT_VALUES,
  PRODUCT_CONDITIONS,
  PRODUCT_CONDITION_VALUES,
  STOCK_STATUSES,
  STOCK_STATUS_VALUES,
};
