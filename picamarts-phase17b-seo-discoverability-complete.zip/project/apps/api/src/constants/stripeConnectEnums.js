'use strict';

/**
 * Phase 16A — Marketplace Finance, Stripe Connect Foundation.
 *
 * `onboardingStatus` is a value WE derive and cache on `Seller.stripeAccount`
 * from the Stripe Account object's own `details_submitted` / `charges_enabled`
 * / `payouts_enabled` / `requirements` fields (see
 * stripeConnect.service.js#deriveOnboardingStatus) — Stripe itself has no
 * single "status" field, just those underlying booleans/requirements, so
 * this exists purely to give the frontend one simple field to branch on.
 */
const ONBOARDING_STATUSES = Object.freeze({
  /** No Connect account has been created for this seller yet. */
  NOT_STARTED: 'not_started',
  /** Account created, but onboarding (details_submitted) is not yet complete. */
  PENDING: 'pending',
  /** Onboarding submitted and Stripe has fully enabled charges + payouts. */
  COMPLETE: 'complete',
  /** Submitted, but Stripe has restricted the account (extra requirements due, or a disabled_reason is set). */
  RESTRICTED: 'restricted',
});
const ONBOARDING_STATUS_VALUES = Object.values(ONBOARDING_STATUSES);

module.exports = { ONBOARDING_STATUSES, ONBOARDING_STATUS_VALUES };
