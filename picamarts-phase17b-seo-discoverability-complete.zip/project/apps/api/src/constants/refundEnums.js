'use strict';

/**
 * Phase 16D — Refunds, Returns, Disputes & Chargebacks, Parts 1-2.
 * Kept as its own constants file (mirrors payoutEnums.js/walletEnums.js
 * — every phase/sub-module gets its own enum module).
 */

// --------------------------------------------------------------------
// Refund Requests (Part 1/3/4)
// --------------------------------------------------------------------

/** A buyer-submitted refund request's lifecycle. Mirrors the exact set the brief's Admin Refund Queue (Part 3) asks for. */
const REFUND_REQUEST_STATUSES = Object.freeze({
  PENDING: 'pending',
  APPROVED: 'approved',
  REJECTED: 'rejected',
  PROCESSING: 'processing',
  COMPLETED: 'completed',
  CANCELLED: 'cancelled',
  /** Part 4 — a Stripe refund attempt errored; retryable (mirrors WithdrawalRequest's FAILED -> retry -> PROCESSING lifecycle). */
  FAILED: 'failed',
});
const REFUND_REQUEST_STATUS_VALUES = Object.values(REFUND_REQUEST_STATUSES);

/** Open = still awaiting a final outcome — used to block a second concurrent request on the same order (mirrors WithdrawalRequest's OPEN_STATUSES). */
const OPEN_REFUND_REQUEST_STATUSES = [
  REFUND_REQUEST_STATUSES.PENDING,
  REFUND_REQUEST_STATUSES.APPROVED,
  REFUND_REQUEST_STATUSES.PROCESSING,
];

const REFUND_REQUEST_TYPES = Object.freeze({
  FULL: 'full',
  PARTIAL: 'partial',
});
const REFUND_REQUEST_TYPE_VALUES = Object.values(REFUND_REQUEST_TYPES);

const REFUND_REASONS = Object.freeze({
  DAMAGED_OR_DEFECTIVE: 'damaged_or_defective',
  NOT_AS_DESCRIBED: 'not_as_described',
  WRONG_ITEM: 'wrong_item',
  NO_LONGER_NEEDED: 'no_longer_needed',
  DUPLICATE_ORDER: 'duplicate_order',
  NOT_RECEIVED: 'not_received',
  OTHER: 'other',
});
const REFUND_REASON_VALUES = Object.values(REFUND_REASONS);

// --------------------------------------------------------------------
// Return Requests (Part 2)
// --------------------------------------------------------------------

const RETURN_REQUEST_STATUSES = Object.freeze({
  REQUESTED: 'requested',
  APPROVED: 'approved',
  REJECTED: 'rejected',
  RETURN_SHIPPED: 'return_shipped',
  RECEIVED: 'received',
  COMPLETED: 'completed',
  CANCELLED: 'cancelled',
});
const RETURN_REQUEST_STATUS_VALUES = Object.values(RETURN_REQUEST_STATUSES);

const OPEN_RETURN_REQUEST_STATUSES = [
  RETURN_REQUEST_STATUSES.REQUESTED,
  RETURN_REQUEST_STATUSES.APPROVED,
  RETURN_REQUEST_STATUSES.RETURN_SHIPPED,
  RETURN_REQUEST_STATUSES.RECEIVED,
];

/** Same reason vocabulary as refunds — a return is just a refund that requires the physical item back first. */
const RETURN_REASONS = REFUND_REASONS;
const RETURN_REASON_VALUES = REFUND_REASON_VALUES;

module.exports = {
  REFUND_REQUEST_STATUSES,
  REFUND_REQUEST_STATUS_VALUES,
  OPEN_REFUND_REQUEST_STATUSES,
  REFUND_REQUEST_TYPES,
  REFUND_REQUEST_TYPE_VALUES,
  REFUND_REASONS,
  REFUND_REASON_VALUES,
  RETURN_REQUEST_STATUSES,
  RETURN_REQUEST_STATUS_VALUES,
  OPEN_RETURN_REQUEST_STATUSES,
  RETURN_REASONS,
  RETURN_REASON_VALUES,
};
