'use strict';

/**
 * Phase 10.1 — Review & Rating constants.
 * Exported from the constants folder (mirrors orderEnums, paymentEnums)
 * so validators and services can import without touching the model file.
 */

const REVIEW_STATUSES = Object.freeze({
  PUBLISHED: 'published',
  HIDDEN: 'hidden',
  DELETED: 'deleted',
});

const REVIEW_STATUS_VALUES = Object.values(REVIEW_STATUSES);

/** Statuses that make a review visible to regular users. */
const VISIBLE_REVIEW_STATUSES = [REVIEW_STATUSES.PUBLISHED];

/** Statuses that are considered "active" for rating aggregation. */
const ACTIVE_REVIEW_STATUSES = [REVIEW_STATUSES.PUBLISHED];

/**
 * Sort presets exposed via the API:
 *   newest    — most recently written
 *   oldest    — first written
 *   helpful   — highest helpfulCount
 *   highest   — rating desc
 *   lowest    — rating asc
 */
const REVIEW_SORT_OPTIONS = Object.freeze({
  NEWEST: 'newest',
  OLDEST: 'oldest',
  HELPFUL: 'helpful',
  HIGHEST: 'highest',
  LOWEST: 'lowest',
});

const REVIEW_SORT_VALUES = Object.values(REVIEW_SORT_OPTIONS);

/** Maximum number of images allowed per review. */
const MAX_REVIEW_IMAGES = 5;

module.exports = {
  REVIEW_STATUSES,
  REVIEW_STATUS_VALUES,
  VISIBLE_REVIEW_STATUSES,
  ACTIVE_REVIEW_STATUSES,
  REVIEW_SORT_OPTIONS,
  REVIEW_SORT_VALUES,
  MAX_REVIEW_IMAGES,
};
