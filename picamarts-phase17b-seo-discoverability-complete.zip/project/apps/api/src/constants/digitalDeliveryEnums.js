'use strict';

/**
 * Phase 14.1 — Digital Product Delivery. Kept in its own file, same
 * convention as productMedia.js/notificationEnums.js — these describe
 * the download/license/delivery-log envelope, never a business module's
 * own lifecycle (Order/Payment keep theirs in orderEnums.js/paymentEnums.js).
 */

const DOWNLOAD_STATUSES = Object.freeze({
  ACTIVE: 'active',
  REVOKED: 'revoked',
});
const DOWNLOAD_STATUS_VALUES = Object.values(DOWNLOAD_STATUSES);

/** How long a generated signed file URL stays valid before Cloudinary itself rejects it (Part 5 — Token Expiration). */
const DOWNLOAD_URL_TTL_MINUTES = 15;

/** Default per-product download policy when the seller hasn't configured one — unlimited downloads, never expires. */
const DEFAULT_DOWNLOAD_LIMIT = null;
const DEFAULT_DOWNLOAD_EXPIRY_DAYS = null;

/** License keys are generated as 4 groups of 4 uppercase alphanumeric characters, e.g. `A1B2-C3D4-E5F6-G7H8`. */
const LICENSE_KEY_GROUP_COUNT = 4;
const LICENSE_KEY_GROUP_LENGTH = 4;

module.exports = {
  DOWNLOAD_STATUSES,
  DOWNLOAD_STATUS_VALUES,
  DOWNLOAD_URL_TTL_MINUTES,
  DEFAULT_DOWNLOAD_LIMIT,
  DEFAULT_DOWNLOAD_EXPIRY_DAYS,
  LICENSE_KEY_GROUP_COUNT,
  LICENSE_KEY_GROUP_LENGTH,
};
