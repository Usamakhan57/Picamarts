'use strict';

const { createQueue } = require('../config/queue');

/**
 * Phase 12, Part 3 — Image Processing queue. Generates an optimized
 * derived variant (via Cloudinary's explicit/eager transformation API)
 * for a just-uploaded image, off the request path. Produced by
 * productMedia.service.js#uploadThumbnail as a single additive,
 * fire-and-forget call — the same integration shape Phase 10.2 used
 * for notification hooks on Order/Payment/Review — so a slow or
 * failed optimization job never affects the upload response.
 */

const QUEUE_NAME = 'image-processing';

let queue;
const getQueue = () => {
  if (queue !== undefined) return queue;
  queue = createQueue(QUEUE_NAME);
  return queue;
};

/**
 * @param {{ publicId: string, url: string }} payload
 * @returns {Promise<import('bullmq').Job|null>}
 */
const addImageOptimizationJob = (payload) => {
  const q = getQueue();
  if (!q) return Promise.resolve(null);
  return q.add('optimize-image', payload);
};

module.exports = { QUEUE_NAME, getQueue, addImageOptimizationJob };
