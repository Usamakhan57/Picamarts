'use strict';

const { createQueue } = require('../config/queue');

/**
 * Phase 12, Part 3 — Email Sending queue. The sole producer is
 * emails/mailer.js#sendMail, which enqueues here transparently and
 * falls back to sending directly when this returns `null` (queues
 * disabled) or the enqueue itself throws — see that file for the
 * fallback logic. No other module should add jobs to this queue
 * directly; go through `sendMail`/`sendAdminMail` instead so every
 * caller keeps the same "await and get a boolean" contract.
 */

const QUEUE_NAME = 'email';

let queue;
const getQueue = () => {
  if (queue !== undefined) return queue;
  queue = createQueue(QUEUE_NAME);
  return queue;
};

/**
 * @param {{ to: string, subject: string, html: string, text?: string }} payload
 * @returns {Promise<import('bullmq').Job|null>} null when the queue is disabled
 */
const addEmailJob = (payload) => {
  const q = getQueue();
  if (!q) return Promise.resolve(null);
  return q.add('send-email', payload);
};

module.exports = { QUEUE_NAME, getQueue, addEmailJob };
