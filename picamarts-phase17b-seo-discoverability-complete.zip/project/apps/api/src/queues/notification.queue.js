'use strict';

const { createQueue } = require('../config/queue');

/**
 * Phase 12, Part 3 — Notifications queue. Fans out per-recipient
 * notification dispatch (in-app + optional email, via
 * notification.service.js#emitNotification) off the request/job that
 * triggered it. Currently produced by workers/background.worker.js's
 * low-stock-scan job; available for any future caller that wants to
 * dispatch a notification asynchronously instead of inline.
 */

const QUEUE_NAME = 'notification';

let queue;
const getQueue = () => {
  if (queue !== undefined) return queue;
  queue = createQueue(QUEUE_NAME);
  return queue;
};

/**
 * @param {object} emitNotificationParams - forwarded verbatim to notification.service.js#emitNotification by the worker.
 *   NOTE: `buildEmail` is a function on emitNotification's normal signature and
 *   cannot survive BullMQ's JSON serialization — jobs on this queue never
 *   include it, so a queued notification is always in-app-only (no email leg).
 *   Anything needing the email leg should call emitNotification (or a
 *   notify* wrapper) in-process instead of going through this queue.
 * @returns {Promise<import('bullmq').Job|null>}
 */
const addNotificationJob = (emitNotificationParams) => {
  const q = getQueue();
  if (!q) return Promise.resolve(null);
  return q.add('dispatch-notification', emitNotificationParams);
};

module.exports = { QUEUE_NAME, getQueue, addNotificationJob };
