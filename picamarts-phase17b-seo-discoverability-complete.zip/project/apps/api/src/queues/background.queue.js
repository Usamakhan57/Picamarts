'use strict';

const { createQueue } = require('../config/queue');

/**
 * Phase 12, Part 3 — Background Jobs queue. General-purpose bucket for
 * scheduled/deferred maintenance work — this is the queue jobs/index.js
 * (the placeholder left since Phase 1) now schedules its repeatable
 * jobs onto: `purge-expired-tokens` and `low-stock-scan` (see
 * jobs/maintenance.job.js and workers/background.worker.js).
 */

const QUEUE_NAME = 'background';

let queue;
const getQueue = () => {
  if (queue !== undefined) return queue;
  queue = createQueue(QUEUE_NAME);
  return queue;
};

/**
 * @param {string} jobName - dispatched on by workers/background.worker.js
 * @param {object} [payload]
 * @param {import('bullmq').JobsOptions} [opts] - e.g. { repeat: { pattern: '0 3 * * *' } }
 */
const addBackgroundJob = (jobName, payload = {}, opts = {}) => {
  const q = getQueue();
  if (!q) return Promise.resolve(null);
  return q.add(jobName, payload, opts);
};

module.exports = { QUEUE_NAME, getQueue, addBackgroundJob };
