'use strict';

const { Server } = require('socket.io');
const config = require('../config');
const logger = require('../utils/logger');
const { verifyAccessToken } = require('../utils/token');

let io;

/**
 * Attaches Socket.IO to the existing HTTP server. Kept minimal in this
 * foundation phase: connection auth + logging only. Business event
 * handlers (e.g. order updates, chat, notifications) get registered
 * inside the `connection` callback once those features exist.
 */
const initSocket = (httpServer) => {
  io = new Server(httpServer, {
    cors: {
      origin: config.corsOrigins,
      credentials: true,
    },
  });

  io.use((socket, next) => {
    const token = socket.handshake.auth?.token;
    if (!token) return next(); // allow anonymous sockets for now

    try {
      socket.user = verifyAccessToken(token);
    } catch {
      // Invalid token — connect as anonymous rather than rejecting outright.
    }
    return next();
  });

  io.on('connection', (socket) => {
    logger.info(`Socket connected: ${socket.id}${socket.user ? ` (user ${socket.user.sub})` : ''}`);

    socket.on('disconnect', (reason) => {
      logger.info(`Socket disconnected: ${socket.id} (${reason})`);
    });
  });

  return io;
};

const getIO = () => {
  if (!io) throw new Error('Socket.IO has not been initialized yet. Call initSocket(server) first.');
  return io;
};

module.exports = { initSocket, getIO };
