'use strict';

const mongoose = require('mongoose');
const config = require('../config');
const logger = require('../utils/logger');

const MAX_RETRIES = 5;
const RETRY_DELAY_MS = 5000;

mongoose.set('strictQuery', true);

/**
 * Connects to MongoDB Atlas, retrying a fixed number of times with a
 * fixed delay before giving up. Called once from server.js before the
 * HTTP server starts listening.
 */
const connectDB = async (attempt = 1) => {
  try {
    await mongoose.connect(config.db.uri, {
      maxPoolSize: 10,
      serverSelectionTimeoutMS: 10000,
    });

    logger.info(`MongoDB connected → host: ${mongoose.connection.host}, db: ${mongoose.connection.name}`);
  } catch (error) {
    logger.error(`MongoDB connection attempt ${attempt}/${MAX_RETRIES} failed: ${error.message}`);

    if (attempt >= MAX_RETRIES) {
      logger.error('Exhausted MongoDB connection retries. Exiting.');
      throw error;
    }

    await new Promise((resolve) => setTimeout(resolve, RETRY_DELAY_MS));
    return connectDB(attempt + 1);
  }

  return mongoose.connection;
};

mongoose.connection.on('disconnected', () => {
  logger.warn('MongoDB disconnected.');
});

mongoose.connection.on('error', (error) => {
  logger.error(`MongoDB connection error: ${error.message}`);
});

/**
 * Closes the MongoDB connection cleanly. Used during graceful shutdown
 * and in test teardown.
 */
const disconnectDB = async () => {
  await mongoose.connection.close();
  logger.info('MongoDB connection closed.');
};

module.exports = { connectDB, disconnectDB, mongoose };
