'use strict';

const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const compression = require('compression');
const morgan = require('morgan');
const swaggerUi = require('swagger-ui-express');

const config = require('./config');
const corsOptions = require('./config/corsOptions');
const logger = require('./utils/logger');
const swaggerSpec = require('./docs/swagger');

const { applySecurityMiddleware } = require('./middlewares/security.middleware');
const { apiLimiter } = require('./middlewares/rateLimiter.middleware');
const { performanceLogger } = require('./middlewares/performanceLogger.middleware');
const notFound = require('./middlewares/notFound.middleware');
const errorHandler = require('./middlewares/errorHandler.middleware');
const paymentController = require('./controllers/payment.controller');

const routes = require('./routes');
const sitemapRoutes = require('./routes/sitemap.routes');

const app = express();

// Behind a reverse proxy (Render, Railway, Nginx, etc.) in production —
// needed for req.ip / rate limiting / secure cookies to work correctly.
app.set('trust proxy', 1);

// ---------------------------------------------------------------------
// Security
// ---------------------------------------------------------------------
applySecurityMiddleware(app);
app.use(cors(corsOptions));

// ---------------------------------------------------------------------
// Stripe webhook (Phase 9, Step 2) — MUST be registered before the
// global express.json() parser below, and uses express.raw() instead,
// because Stripe signature verification needs the exact raw request
// bytes, not a re-serialized parsed object. This is the only route in
// the app that bypasses the standard JSON body parser; every other
// route (including the rest of /payments) is unaffected since this
// exact path is matched and handled here first.
// ---------------------------------------------------------------------
app.post(
  `${config.apiPrefix}/v1/payments/webhooks/stripe`,
  express.raw({ type: 'application/json' }),
  paymentController.handleStripeWebhook
);

// ---------------------------------------------------------------------
// Body & cookie parsing
// ---------------------------------------------------------------------
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(cookieParser());
app.use(compression());

// ---------------------------------------------------------------------
// Logging
// ---------------------------------------------------------------------
app.use(morgan(config.isProduction ? 'combined' : 'dev', { stream: logger.stream }));
// Phase 12, Part 6 — per-request performance logging (separate from
// morgan's access log; see performanceLogger.middleware.js).
app.use(performanceLogger());

// ---------------------------------------------------------------------
// Rate limiting (applied to the whole API surface)
// ---------------------------------------------------------------------
app.use(config.apiPrefix, apiLimiter);

// ---------------------------------------------------------------------
// SEO — sitemap.xml / sitemaps/*.xml / robots.txt (Phase 17B)
// ---------------------------------------------------------------------
// Mounted at the app root (unprefixed, ahead of apiLimiter) because
// these are well-known crawler paths expected at the domain root —
// see routes/sitemap.routes.js for the full rationale.
app.use(sitemapRoutes);

// ---------------------------------------------------------------------
// API docs
// ---------------------------------------------------------------------
if (config.swagger.enabled) {
  app.use('/api/docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));
  app.get('/api/docs.json', (req, res) => res.json(swaggerSpec));
}

// ---------------------------------------------------------------------
// Routes
// ---------------------------------------------------------------------
app.get('/', (req, res) => {
  res.json({
    success: true,
    message: `${config.appName} API is running.`,
    docs: config.swagger.enabled ? '/api/docs' : undefined,
  });
});

app.use(config.apiPrefix, routes);

// ---------------------------------------------------------------------
// 404 + central error handler (must stay last, in this order)
// ---------------------------------------------------------------------
app.use(notFound);
app.use(errorHandler);

module.exports = app;
