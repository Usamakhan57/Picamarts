import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { onSessionChange, getAccessToken } from '../services/apiClient';
import {
  loginRequest,
  logoutRequest,
  registerRequest,
  refreshSessionRequest,
  getCurrentUserRequest,
  updateProfileRequest,
} from '../services/authService';
import { preloadCatalog } from '../services/catalogStore';
import {
  getCart, addCartItem, updateCartItemQuantity, removeCartItem, clearCartRequest,
} from '../services/cartService';
import {
  getWishlist, addWishlistItem, removeWishlistItem, moveWishlistItemToCart,
} from '../services/wishlistService';
import { listOrders } from '../services/orderService';
import { productsApi } from '../services/api';

const StoreContext = createContext(null);

const load = (key, fallback) => {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
};

const ZERO_SUMMARY = { itemCount: 0, subtotal: 0, discount: 0, tax: 0, shipping: 0, grandTotal: 0 };

/** Backend cart item ({id, product:{id,title,thumbnail,...}, quantity, unitPrice, lineTotal, isAvailable}) → the flat shape CartPage/Header/ProductCard already read. */
const mapCartItem = (item) => ({
  id: item.id, // cart line id — use this for updateQty/removeFromCart
  productId: item.product?.id ?? null, // use this for product links/thumbnails
  title: item.product?.title ?? 'Product unavailable',
  img: item.product?.thumbnail?.url || '',
  price: item.unitPrice,
  qty: item.quantity,
  lineTotal: item.lineTotal,
  isAvailable: item.isAvailable !== false,
});

const ORDER_STATUS_LABELS = {
  pending: 'Pending',
  confirmed: 'Processing',
  processing: 'Processing',
  packed: 'Processing',
  shipped: 'Processing',
  delivered: 'Completed',
  cancelled: 'Cancelled',
  refunded: 'Refunded',
};

/** Backend order item ({product, titleSnapshot, thumbnailSnapshot, quantity, lockedPrice, lineTotal}) → the flat item shape account pages already read (item.id is the PRODUCT id, matching the old mock's item.id semantics used for /product/:id links). */
const mapOrderItem = (item) => ({
  id: item.product,
  title: item.titleSnapshot,
  img: item.thumbnailSnapshot?.url || '',
  price: item.lockedPrice,
  qty: item.quantity,
  lineTotal: item.lineTotal,
});

/** Backend order ({id, orderNumber, status, paymentStatus, items, grandTotal, createdAt, ...}) → the flat shape account pages already read. `orderId` carries the real backend id (for cancel/detail calls); `id` stays the human-readable order number, matching how the old mock's random order code was displayed/keyed. */
const mapOrder = (order) => ({
  id: order.orderNumber,
  orderId: order.id,
  date: order.createdAt,
  items: (order.items || []).map(mapOrderItem),
  total: order.grandTotal,
  subtotal: order.subtotal,
  discount: order.discount,
  tax: order.tax,
  shipping: order.shipping,
  status: ORDER_STATUS_LABELS[order.status] || 'Pending',
  rawStatus: order.status,
  paymentStatus: order.paymentStatus,
  billingAddress: order.billingAddress,
  shippingAddress: order.shippingAddress,
  notes: order.notes,
});

/** Thrown by addToCart/toggleWishlist when there's no logged-in buyer — both are buyer-only on the real backend. Callers catch `err.requiresAuth`. */
const requireAuthError = () => {
  const err = new Error('Please log in to continue.');
  err.requiresAuth = true;
  return err;
};

export const StoreProvider = ({ children }) => {
  const [cart, setCart] = useState([]);
  const [cartSummary, setCartSummary] = useState(ZERO_SUMMARY);
  const [wishlist, setWishlist] = useState([]);
  const [user, setUser] = useState(null);
  const [authLoading, setAuthLoading] = useState(true); // true while we check for an existing session on load
  const [compareList, setCompareList] = useState(() => load('pm_compare', []));
  // Orders: fetched from the real backend (see effect below) — no more
  // localStorage. `ordersLoading` covers the initial fetch only, so the
  // account pages that read `orders` can show a loading state instead of
  // briefly flashing an empty-state.
  const [orders, setOrders] = useState([]);
  const [ordersLoading, setOrdersLoading] = useState(false);

  useEffect(() => { localStorage.setItem('pm_compare', JSON.stringify(compareList)); }, [compareList]);

  // On first load: if we have a leftover access token, verify it's still
  // valid via /auth/me. If not (or there's no token at all), silently try
  // the refresh-cookie flow once — this is what keeps a user logged in
  // across a page reload without ever storing the refresh token in JS.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const currentUser = getAccessToken()
          ? await getCurrentUserRequest()
          : await refreshSessionRequest();
        if (!cancelled) setUser(currentUser);
      } catch {
        if (!cancelled) setUser(null);
      } finally {
        if (!cancelled) setAuthLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  // Kicks off once per session; taxonomy (categories/brands/collections/
  // tags) is read synchronously from services/catalogStore.js everywhere
  // else — see that file's header comment for why.
  useEffect(() => { preloadCatalog(); }, []);

  // apiClient emits this when a background token refresh succeeds/fails
  // (e.g. triggered by a 401 on some unrelated request elsewhere in the app).
  useEffect(() => onSessionChange((event) => {
    if (event.type === 'refreshed') setUser(event.user);
    if (event.type === 'expired') setUser(null);
  }), []);

  // Cart/wishlist are buyer-only on the real backend (no guest cart) — load
  // them once we know who's logged in, and clear them straight back out on
  // logout so a shared/public device never shows the previous buyer's data.
  useEffect(() => {
    if (!user) {
      setCart([]);
      setCartSummary(ZERO_SUMMARY);
      setWishlist([]);
      setOrders([]);
      return undefined;
    }
    let cancelled = false;
    (async () => {
      setOrdersLoading(true);
      try {
        const [cartRes, wishlistRes, ordersRes] = await Promise.all([
          getCart(),
          getWishlist(),
          // Capped at 100 most-recent orders — no backend aggregate/streaming
          // list exists yet, same bounded-fetch tradeoff as catalogStore's
          // product cache (flagged there as a scale limit for a later pass).
          listOrders({ limit: 100 }).catch(() => ({ orders: [] })),
        ]);
        if (cancelled) return;
        setCart((cartRes?.items || []).map(mapCartItem));
        setCartSummary(cartRes?.summary || ZERO_SUMMARY);
        setOrders((ordersRes?.orders || []).map(mapOrder));

        // The wishlist endpoint only returns a partial product summary (no
        // category/rating/images) — enrich each entry with the full
        // storefront product shape so WishlistPage's <ProductCard> has
        // everything it needs, same as the main catalog.
        const items = wishlistRes?.items || [];
        const enriched = await Promise.all(
          items.map((item) => (item.product ? productsApi.get(item.product.id).catch(() => null) : Promise.resolve(null)))
        );
        if (!cancelled) setWishlist(enriched.filter(Boolean));
      } catch {
        // non-fatal — cart/wishlist just stay empty until the next mutation succeeds
      } finally {
        if (!cancelled) setOrdersLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [user]);

  /** Re-fetches the buyer's order list from the backend — call after placing an order or retrying a payment so account pages reflect it immediately. */
  const refreshOrders = useCallback(async () => {
    if (!user) return;
    try {
      const { orders: fresh } = await listOrders({ limit: 100 });
      setOrders((fresh || []).map(mapOrder));
    } catch {
      // non-fatal — caller already has the order it just created/paid
    }
  }, [user]);

  const MAX_COMPARE = 4;

  const inCompare = useCallback((id) => compareList.some((p) => p.id === id), [compareList]);

  const toggleCompare = useCallback((product) => {
    setCompareList((prev) => {
      if (prev.some((p) => p.id === product.id)) return prev.filter((p) => p.id !== product.id);
      if (prev.length >= MAX_COMPARE) return prev;
      return [...prev, product];
    });
  }, []);

  const removeFromCompare = useCallback((id) => setCompareList((prev) => prev.filter((p) => p.id !== id)), []);
  const clearCompare = useCallback(() => setCompareList([]), []);

  /** Throws requireAuthError() when logged out — callers catch `err.requiresAuth` and prompt sign-in. */
  const addToCart = useCallback(async (product, qty = 1) => {
    if (!user) throw requireAuthError();
    const backendCart = await addCartItem(product.id, qty);
    setCart((backendCart?.items || []).map(mapCartItem));
    setCartSummary(backendCart?.summary || ZERO_SUMMARY);
  }, [user]);

  /** cartItemId is the cart LINE id (item.id from the mapped cart), not a product id. */
  const updateQty = useCallback(async (cartItemId, qty) => {
    if (qty < 1) return;
    const backendCart = await updateCartItemQuantity(cartItemId, qty);
    setCart((backendCart?.items || []).map(mapCartItem));
    setCartSummary(backendCart?.summary || ZERO_SUMMARY);
  }, []);

  const removeFromCart = useCallback(async (cartItemId) => {
    const backendCart = await removeCartItem(cartItemId);
    setCart((backendCart?.items || []).map(mapCartItem));
    setCartSummary(backendCart?.summary || ZERO_SUMMARY);
  }, []);

  const clearCart = useCallback(async () => {
    await clearCartRequest();
    setCart([]);
    setCartSummary(ZERO_SUMMARY);
  }, []);

  const toggleWishlist = useCallback(async (product) => {
    if (!user) throw requireAuthError();
    if (wishlist.some((p) => p.id === product.id)) {
      await removeWishlistItem(product.id);
      setWishlist((prev) => prev.filter((p) => p.id !== product.id));
    } else {
      await addWishlistItem(product.id);
      setWishlist((prev) => [...prev, product]);
    }
  }, [user, wishlist]);

  const inWishlist = useCallback((id) => wishlist.some((p) => p.id === id), [wishlist]);

  /** Atomic wishlist→cart move (one real request) — productId, not a wishlist line id. */
  const moveWishlistItemToCartById = useCallback(async (productId) => {
    const { wishlist: newWishlist, cart: newCart } = await moveWishlistItemToCart(productId);
    setWishlist((prev) => prev.filter((p) => p.id !== productId));
    setCart((newCart?.items || []).map(mapCartItem));
    setCartSummary(newCart?.summary || ZERO_SUMMARY);
    return newWishlist;
  }, []);

  /** Throws a normalized apiClient error ({ status, message, errors }) on failure — callers catch it. */
  const login = useCallback(async (email, password) => {
    const loggedInUser = await loginRequest({ email, password });
    setUser(loggedInUser);
    return loggedInUser;
  }, []);

  const register = useCallback(async ({ name, email, password, role }) => {
    const { user: newUser } = await registerRequest({ name, email, password, role });
    return newUser;
  }, []);

  const logout = useCallback(async () => {
    try {
      await logoutRequest();
    } finally {
      setUser(null);
    }
  }, []);

  const updateProfile = useCallback(async (payload) => {
    const updatedUser = await updateProfileRequest(payload);
    setUser(updatedUser);
    return updatedUser;
  }, []);

  const cartCount = cartSummary.itemCount;
  const cartSubtotal = cartSummary.subtotal;

  return (
    <StoreContext.Provider value={{
      cart, wishlist, user, authLoading, cartSummary, orders, ordersLoading, refreshOrders,
      addToCart, updateQty, removeFromCart, clearCart,
      toggleWishlist, inWishlist, moveWishlistItemToCart: moveWishlistItemToCartById,
      login, logout, register, updateProfile,
      cartCount, cartSubtotal,
      compareList, inCompare, toggleCompare, removeFromCompare, clearCompare, MAX_COMPARE,
    }}>
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
};
