import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { useStore } from './StoreContext';
import { applyAsSeller as applyAsSellerRequest, getMySellerProfile } from '../services/sellerService';

const SellerAuthContext = createContext(null);

// Non-sensitive bridge: SellerRegisterPage collects the store name up
// front (matches the existing, pre-approved UI), but the real backend
// can't accept a seller "application" (POST /sellers/apply) until the new
// account exists AND its email is verified — so there's no valid session
// to call it with yet. We stash the store name locally, keyed by email,
// and auto-submit the application the first time that seller logs in and
// turns out to have no profile yet. Cleared immediately after use.
const PENDING_KEY = 'pm_seller_pending_application';

const loadPending = () => {
  try {
    return JSON.parse(localStorage.getItem(PENDING_KEY) || '{}');
  } catch {
    return {};
  }
};

const stashPendingApplication = (email, payload) => {
  const all = loadPending();
  all[email.trim().toLowerCase()] = payload;
  localStorage.setItem(PENDING_KEY, JSON.stringify(all));
};

const takePendingApplication = (email) => {
  const all = loadPending();
  const key = email.trim().toLowerCase();
  const payload = all[key];
  if (payload) {
    delete all[key];
    localStorage.setItem(PENDING_KEY, JSON.stringify(all));
  }
  return payload || null;
};

/**
 * Wraps the single, real backend session (StoreContext/useStore) with a
 * seller-specific view: role gating, the seller's own profile/application
 * status (Seller model — separate lifecycle from the User account), and a
 * one-time auto-apply bridge for brand-new seller accounts.
 *
 * Replaces the old mock/localStorage seller "database" entirely.
 */
export const SellerAuthProvider = ({ children }) => {
  const { user, authLoading, login: storeLogin, logout: storeLogout, register: storeRegister } = useStore();
  const [profile, setProfile] = useState(null); // Seller doc, or null if not applied yet
  const [profileStatus, setProfileStatus] = useState('unknown'); // 'unknown' | 'none' | 'loaded'
  const [profileLoading, setProfileLoading] = useState(false);
  const [profileChecked, setProfileChecked] = useState(false); // true once the first fetch attempt (success or 404) has resolved

  const isSellerAccount = !!user && user.role === 'seller';

  const refreshProfile = useCallback(async () => {
    if (!isSellerAccount) {
      setProfile(null);
      setProfileStatus('unknown');
      return null;
    }
    setProfileLoading(true);
    try {
      const seller = await getMySellerProfile();
      setProfile(seller);
      setProfileStatus('loaded');
      return seller;
    } catch (err) {
      if (err?.status === 404) {
        setProfile(null);
        setProfileStatus('none');
        return null;
      }
      // Transient failure (network, 5xx) — leave whatever we had, try again later.
      return profile;
    } finally {
      setProfileLoading(false);
      setProfileChecked(true);
    }
  }, [isSellerAccount]); // eslint-disable-line react-hooks/exhaustive-deps

  // Load (or clear) the seller profile whenever the underlying session
  // settles into "logged in as a seller" vs anything else.
  useEffect(() => {
    if (authLoading) return;
    if (!isSellerAccount) {
      setProfile(null);
      setProfileStatus('unknown');
      setProfileChecked(false);
      return;
    }
    (async () => {
      const existing = await refreshProfile();
      // First login after registration with no profile yet: auto-submit
      // the application using the store name collected at signup, if any.
      if (!existing && user?.email) {
        const pending = takePendingApplication(user.email);
        if (pending) {
          try {
            const seller = await applyAsSellerRequest(pending);
            setProfile(seller);
            setProfileStatus('loaded');
          } catch {
            // If this fails (e.g. duplicate application), the seller can
            // still apply manually from the dashboard gate.
          }
        }
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authLoading, isSellerAccount, user?.id]);

  const login = useCallback(async (email, password) => {
    const loggedInUser = await storeLogin(email, password);
    if (loggedInUser.role !== 'seller') {
      await storeLogout();
      const err = new Error('This account is not a seller account.');
      err.status = 403;
      throw err;
    }
    return loggedInUser;
  }, [storeLogin, storeLogout]);

  const register = useCallback(async ({ storeName, name, email, password }) => {
    const newUser = await storeRegister({ name, email, password, role: 'seller' });
    // Store name (+ anything else collected at signup) waits here until
    // the seller's first successful login (see effect above).
    stashPendingApplication(email, { storeName });
    return newUser;
  }, [storeRegister]);

  const logout = useCallback(async () => {
    await storeLogout();
    setProfile(null);
    setProfileStatus('unknown');
  }, [storeLogout]);

  const applyAsSeller = useCallback(async (payload) => {
    const seller = await applyAsSellerRequest(payload);
    setProfile(seller);
    setProfileStatus('loaded');
    return seller;
  }, []);

  // Backward-compatible `seller` shape for existing dashboard components
  // (SellerDashboard/SellerProfileTab/SellerStoreSettingsTab all read
  // seller.storeName/name/email/joinedAt) — merges the real User account
  // with the real Seller store profile, once loaded.
  const seller = isSellerAccount
    ? {
        name: user.name,
        email: user.email,
        storeName: profile?.storeName || '',
        joinedAt: profile?.createdAt || user.createdAt || null,
        status: profile?.status || (profileStatus === 'none' ? 'not_applied' : profileStatus),
        statusReason: profile?.statusReason || '',
        ...profile,
      }
    : null;

  return (
    <SellerAuthContext.Provider
      value={{
        seller,
        isAuthenticated: isSellerAccount,
        authLoading,
        profileLoading,
        profileChecked,
        hasAppliedProfile: !!profile,
        login,
        logout,
        register,
        applyAsSeller,
        refreshProfile,
      }}
    >
      {children}
    </SellerAuthContext.Provider>
  );
};

export const useSellerAuth = () => {
  const ctx = useContext(SellerAuthContext);
  if (!ctx) throw new Error('useSellerAuth must be used within SellerAuthProvider');
  return ctx;
};
