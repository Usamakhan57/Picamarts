import React from 'react';
import { Field, inputClass, textareaClass } from './FormSheet';
import TagsInput from './TagsInput';
import MediaPickerField from '../../components/media/MediaPickerField';

/**
 * Phase 17B — SEO & Discoverability, Part 6 (Admin SEO). One shared
 * panel reused by ProductForm, CategoriesList, BrandsList, and
 * CollectionsList — those four models all share the same flat
 * seoTitle/seoDescription/canonicalUrl/metaKeywords/ogImage/noIndex
 * shape (see the matching Product/Category/Brand/Collection model
 * changes). Deliberately separate from the CMS Page/BlogPost SEO
 * panel already built into StaticPageForm.jsx/BlogPostForm.jsx, which
 * use a different nested `seo.*` shape (metaTitle vs seoTitle, an
 * embedded ogImage object vs a flat url, etc.) — reusing this one
 * there would require reshaping data on both sides for no benefit.
 *
 *   <AdminSeoFields
 *     value={{ seoTitle, seoDescription, canonicalUrl, metaKeywords, ogImage, noIndex }}
 *     onChange={(patch) => setForm((f) => ({ ...f, ...patch }))}
 *   />
 */
const AdminSeoFields = ({ value = {}, onChange, titlePlaceholder = 'Defaults to the item name if left blank' }) => {
  const set = (key) => (v) => onChange({ [key]: v });

  return (
    <div className="space-y-5">
      <Field label="SEO Title">
        <input
          value={value.seoTitle || ''}
          onChange={(e) => set('seoTitle')(e.target.value)}
          className={inputClass}
          placeholder={titlePlaceholder}
        />
      </Field>

      <Field label="Meta Description">
        <textarea value={value.seoDescription || ''} onChange={(e) => set('seoDescription')(e.target.value)} className={textareaClass} />
      </Field>

      <Field label="Meta Keywords" hint="Press Enter or comma to add a keyword">
        <TagsInput value={value.metaKeywords || []} onChange={set('metaKeywords')} placeholder="Add keyword…" />
      </Field>

      <Field label="Canonical URL" hint="Leave blank unless this item duplicates or mirrors another page">
        <input
          value={value.canonicalUrl || ''}
          onChange={(e) => set('canonicalUrl')(e.target.value)}
          className={inputClass}
          placeholder="https://…"
        />
      </Field>

      <MediaPickerField label="Open Graph Image" value={value.ogImage || ''} onChange={set('ogImage')} modalTitle="Select OG Image" />

      <label className="flex items-center gap-2 text-sm font-medium pt-1 cursor-pointer">
        <input
          type="checkbox"
          checked={!!value.noIndex}
          onChange={(e) => set('noIndex')(e.target.checked)}
          className="rounded border-border"
        />
        Hide from search engines (noindex)
      </label>
    </div>
  );
};

export default AdminSeoFields;
