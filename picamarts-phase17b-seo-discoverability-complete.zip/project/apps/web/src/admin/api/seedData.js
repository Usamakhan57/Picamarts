/**
 * Seed data for the mock admin backend. Shapes here should mirror what
 * the future MongoDB collections will look like (id, timestamps,
 * references by id) so the eventual migration is a data-shape match,
 * not a redesign.
 */

const img = {
  wall: 'https://images.hostinger.com/14c75e77-0a1d-4eff-aeb3-c2f48b8d05b6.png',
  floral: 'https://images.hostinger.com/1aabeebf-b3be-4e50-bda3-c9d079f186bc.png',
  canva: 'https://images.hostinger.com/44bf45d5-8b11-4c36-bc33-ee5b4579d328.png',
  font: 'https://images.hostinger.com/bb373382-441e-48e3-8f24-9bddc6578f8b.png',
  color: 'https://images.hostinger.com/29d71df9-7e01-4110-bdfc-a8a59ac08e88.png',
  icons: 'https://images.hostinger.com/aaa4f72b-3b0f-490f-9733-ba3aad15c3c6.png',
  planner: 'https://images.hostinger.com/b0df72e9-f32f-4fb4-ac50-4e521c8509a3.png',
  vector: 'https://images.hostinger.com/cf257400-b18a-4756-ae1e-d3b8c8e6c2db.png',
};

// Category model fields mirror what a future `categories` MongoDB
// collection would look like: unlimited nesting via `parentId`,
// `displayOrder` scoped to siblings (drives both admin reorder and the
// storefront), soft delete via `deletedAt`, and dedicated SEO fields so
// the frontend never needs hardcoded per-category copy.
// `productCount` is intentionally NOT stored here — it's always computed
// live from actual products (see productRepository.getProductCountByCategoryId),
// so it can never drift out of sync with reality.
const now = '2026-01-01T09:00:00.000Z';

export const seedCategories = [
  // --- Root: parent-only groupings (no products reference these directly) ---
  {
    id: 'cat-digital-products', name: 'Digital Products', slug: 'digital-products',
    description: 'Wall art, cliparts, and PNG bundles — our core digital download categories.',
    image: img.wall, icon: 'Layers', parentId: null, displayOrder: 0, status: 'active',
    featured: false, showInHeader: true, showOnHomepage: false,
    seoTitle: 'Digital Products | PicaMarts', metaDescription: 'Browse wall art, cliparts, and PNG bundles on PicaMarts.', ogImage: img.wall,
    createdAt: now, updatedAt: now, deletedAt: null,
  },
  {
    id: 'cat-planning-printables', name: 'Planning & Printables', slug: 'planning-printables',
    description: 'Planners, posters, cards, and coloring pages you can print or use digitally.',
    image: img.planner, icon: 'CalendarDays', parentId: null, displayOrder: 1, status: 'active',
    featured: false, showInHeader: true, showOnHomepage: false,
    seoTitle: 'Planning & Printables | PicaMarts', metaDescription: 'Browse planners, posters, cards, and coloring pages on PicaMarts.', ogImage: img.planner,
    createdAt: now, updatedAt: now, deletedAt: null,
  },
  {
    id: 'cat-apparel-sports', name: 'Apparel & Sports', slug: 'apparel-sports',
    description: 'Print-on-demand tee graphics and sports badge designs.',
    image: img.icons, icon: 'Dumbbell', parentId: null, displayOrder: 2, status: 'active',
    featured: false, showInHeader: true, showOnHomepage: false,
    seoTitle: 'Apparel & Sports | PicaMarts', metaDescription: 'Browse t-shirt graphics and sports designs on PicaMarts.', ogImage: img.icons,
    createdAt: now, updatedAt: now, deletedAt: null,
  },
  {
    id: 'cat-nature', name: 'Nature', slug: 'nature', image: img.vector,
    description: 'Botanical and nature-inspired illustrations for branding, decor, and stationery.',
    icon: 'Leaf', parentId: null, displayOrder: 3, status: 'active',
    featured: false, showInHeader: true, showOnHomepage: true,
    seoTitle: 'Nature | PicaMarts', metaDescription: 'Botanical and nature-inspired illustrations for branding, decor, and stationery.', ogImage: img.vector,
    createdAt: now, updatedAt: now, deletedAt: null,
  },
  {
    id: 'cat-others', name: 'Others', slug: 'others', image: img.vector,
    description: 'A mix of standout digital assets that don\u2019t fit neatly into one category.',
    icon: 'Grid3x3', parentId: null, displayOrder: 4, status: 'inactive',
    featured: false, showInHeader: false, showOnHomepage: false,
    seoTitle: 'Others | PicaMarts', metaDescription: 'A mix of standout digital assets that don\u2019t fit neatly into one category.', ogImage: img.vector,
    createdAt: now, updatedAt: now, deletedAt: null,
  },

  // --- Children of Digital Products ---
  {
    id: 'cat-wall-arts', name: 'Wall Arts', slug: 'wall-arts', image: img.wall,
    description: 'Printable wall art and gallery sets.', icon: 'Frame',
    parentId: 'cat-digital-products', displayOrder: 0, status: 'active',
    featured: true, showInHeader: true, showOnHomepage: true,
    seoTitle: 'Wall Arts | PicaMarts', metaDescription: 'Printable wall art and gallery sets.', ogImage: img.wall,
    createdAt: now, updatedAt: now, deletedAt: null,
  },
  {
    id: 'cat-cliparts', name: 'Cliparts', slug: 'cliparts', image: img.floral,
    description: 'Clipart bundles and elements.', icon: 'Image',
    parentId: 'cat-digital-products', displayOrder: 1, status: 'active',
    featured: true, showInHeader: true, showOnHomepage: true,
    seoTitle: 'Cliparts | PicaMarts', metaDescription: 'Clipart bundles and elements.', ogImage: img.floral,
    createdAt: now, updatedAt: now, deletedAt: null,
  },
  {
    id: 'cat-png-bundles', name: 'PNG Bundles', slug: 'png-bundles', image: img.icons,
    description: 'Transparent PNG graphic bundles.', icon: 'Boxes',
    parentId: 'cat-digital-products', displayOrder: 2, status: 'active',
    featured: false, showInHeader: true, showOnHomepage: true,
    seoTitle: 'PNG Bundles | PicaMarts', metaDescription: 'Transparent PNG graphic bundles.', ogImage: img.icons,
    createdAt: now, updatedAt: now, deletedAt: null,
  },

  // --- Grandchild demo: nesting goes deeper than 2 levels with zero code changes ---
  {
    id: 'cat-watercolor-cliparts', name: 'Watercolor Cliparts', slug: 'watercolor-cliparts', image: img.floral,
    description: 'Hand-painted watercolor clipart sets.', icon: 'Palette',
    parentId: 'cat-cliparts', displayOrder: 0, status: 'active',
    featured: false, showInHeader: false, showOnHomepage: false,
    seoTitle: 'Watercolor Cliparts | PicaMarts', metaDescription: 'Hand-painted watercolor clipart sets.', ogImage: img.floral,
    createdAt: now, updatedAt: now, deletedAt: null,
  },

  // --- Children of Planning & Printables ---
  {
    id: 'cat-planner', name: 'Planner', slug: 'planner', image: img.planner,
    description: 'Digital and printable planners.', icon: 'NotebookPen',
    parentId: 'cat-planning-printables', displayOrder: 0, status: 'active',
    featured: true, showInHeader: true, showOnHomepage: true,
    seoTitle: 'Planner | PicaMarts', metaDescription: 'Digital and printable planners.', ogImage: img.planner,
    createdAt: now, updatedAt: now, deletedAt: null,
  },
  {
    id: 'cat-posters', name: 'Posters', slug: 'posters', image: img.canva,
    description: 'Printable poster designs.', icon: 'Printer',
    parentId: 'cat-planning-printables', displayOrder: 1, status: 'active',
    featured: false, showInHeader: true, showOnHomepage: true,
    seoTitle: 'Posters | PicaMarts', metaDescription: 'Printable poster designs.', ogImage: img.canva,
    createdAt: now, updatedAt: now, deletedAt: null,
  },
  {
    id: 'cat-cards', name: 'Cards', slug: 'cards', image: img.font,
    description: 'Greeting and invitation card sets.', icon: 'Mail',
    parentId: 'cat-planning-printables', displayOrder: 2, status: 'active',
    featured: false, showInHeader: true, showOnHomepage: true,
    seoTitle: 'Cards | PicaMarts', metaDescription: 'Greeting and invitation card sets.', ogImage: img.font,
    createdAt: now, updatedAt: now, deletedAt: null,
  },
  {
    id: 'cat-coloring', name: 'Coloring Pages', slug: 'coloring-pages', image: img.color,
    description: 'Printable coloring pages.', icon: 'PencilRuler',
    parentId: 'cat-planning-printables', displayOrder: 3, status: 'active',
    featured: false, showInHeader: true, showOnHomepage: false,
    seoTitle: 'Coloring Pages | PicaMarts', metaDescription: 'Printable coloring pages.', ogImage: img.color,
    createdAt: now, updatedAt: now, deletedAt: null,
  },

  // --- Children of Apparel & Sports ---
  {
    id: 'cat-tshirt', name: 'T-Shirt Design', slug: 't-shirt-design', image: img.icons,
    description: 'Print-on-demand tee graphics.', icon: 'Shirt',
    parentId: 'cat-apparel-sports', displayOrder: 0, status: 'active',
    featured: false, showInHeader: true, showOnHomepage: false,
    seoTitle: 'T-Shirt Design | PicaMarts', metaDescription: 'Print-on-demand tee graphics.', ogImage: img.icons,
    createdAt: now, updatedAt: now, deletedAt: null,
  },
  {
    id: 'cat-sports', name: 'Sports', slug: 'sports', image: img.vector,
    description: 'Sports badges and graphics.', icon: 'Trophy',
    parentId: 'cat-apparel-sports', displayOrder: 1, status: 'active',
    featured: false, showInHeader: true, showOnHomepage: false,
    seoTitle: 'Sports | PicaMarts', metaDescription: 'Sports badges and graphics.', ogImage: img.vector,
    createdAt: now, updatedAt: now, deletedAt: null,
  },
];

export const seedBrands = [
  { id: 'brand-studio-lume', name: 'Studio Lume', logo: img.wall, website: 'https://studiolume.example.com', description: 'Wall art and print specialists.', status: 'active', productCount: 2 },
  { id: 'brand-petal-ink', name: 'Petal & Ink', logo: img.floral, website: 'https://petalandink.example.com', description: 'Hand-painted botanical designs.', status: 'active', productCount: 1 },
  { id: 'brand-nova-grid', name: 'Nova Grid', logo: img.canva, website: '', description: 'Minimal typography and posters.', status: 'active', productCount: 1 },
  { id: 'brand-pixel-craft', name: 'Pixel Craft', logo: img.icons, website: 'https://pixelcraft.example.com', description: 'High-volume PNG bundles.', status: 'active', productCount: 1 },
  { id: 'brand-bold-press', name: 'Bold Press', logo: img.icons, website: '', description: 'Retro sports and tee graphics.', status: 'inactive', productCount: 1 },
];

// Curated collections — distinct from Categories. A collection groups
// products across categories around a theme (e.g. a seasonal promo or
// a "starter bundle"), and admins manage it with Create/Edit/Delete.
export const seedCollections = [
  { id: 'coll-editors-picks', name: "Editors' Picks", slug: 'editors-picks', image: img.wall, description: 'Hand-picked bestsellers our team loves.', status: 'active', productIds: ['prod-1', 'prod-2', 'prod-6'] },
  { id: 'coll-summer-refresh', name: 'Summer Refresh', slug: 'summer-refresh', image: img.vector, description: 'Bright, warm-weather designs for the season.', status: 'active', productIds: ['prod-8', 'prod-10'] },
  { id: 'coll-starter-bundle', name: 'Starter Bundle', slug: 'starter-bundle', image: img.planner, description: 'Everything a new shop owner needs to get going.', status: 'active', productIds: ['prod-3', 'prod-5', 'prod-7'] },
  { id: 'coll-holiday-2026', name: 'Holiday 2026', slug: 'holiday-2026', image: img.font, description: 'Seasonal cards, posters, and gift-ready sets.', status: 'draft', productIds: ['prod-4'] },
];

export const seedProducts = [
  { id: 'prod-1', title: 'Boho Arch Wall Art Set', slug: 'boho-arch-wall-art-set', sku: 'PM-WA-001', categoryId: 'cat-wall-arts', collectionIds: ['coll-editors-picks'], brandId: 'brand-studio-lume', tags: ['wall-art', 'boho', 'printable'], price: 18, salePrice: 12, cost: 3, stock: 999, lowStockThreshold: 20, status: 'active', featured: true, thumbnail: img.wall, gallery: [img.wall, img.floral], previewImages: [img.wall], previewVideos: [], zipFile: { name: 'boho-arch-wall-art-set.zip', size: 18_400_000 }, description: 'A set of 8 minimalist boho arch wall art prints.', metaTitle: 'Boho Arch Wall Art Set | PicaMarts', metaDescription: 'Download a set of 8 minimalist boho arch wall art prints, ready to print at home.', rating: 4.9, reviewCount: 128, downloads: 3120, createdAt: '2025-11-02T10:00:00.000Z' },
  { id: 'prod-2', title: 'Watercolor Floral Clipart', slug: 'watercolor-floral-clipart', sku: 'PM-CL-002', categoryId: 'cat-cliparts', collectionIds: ['coll-editors-picks'], brandId: 'brand-petal-ink', tags: ['clipart', 'floral', 'watercolor'], price: 9, salePrice: null, cost: 2, stock: 999, lowStockThreshold: 20, status: 'active', featured: true, thumbnail: img.floral, gallery: [img.floral, img.wall], previewImages: [img.floral], previewVideos: [], zipFile: { name: 'watercolor-floral-clipart.zip', size: 9_800_000 }, description: 'Hand-painted watercolor floral clipart bundle — 24 elements.', metaTitle: 'Watercolor Floral Clipart Bundle | PicaMarts', metaDescription: 'A 24-element hand-painted watercolor floral clipart bundle for commercial and personal use.', rating: 4.8, reviewCount: 312, downloads: 5240, createdAt: '2025-11-10T10:00:00.000Z' },
  { id: 'prod-3', title: 'Minimal Motivation Poster', slug: 'minimal-motivation-poster', sku: 'PM-PO-003', categoryId: 'cat-posters', collectionIds: ['coll-starter-bundle'], brandId: 'brand-nova-grid', tags: ['poster', 'typography', 'minimal'], price: 14, salePrice: 8, cost: 2, stock: 999, lowStockThreshold: 20, status: 'active', featured: false, thumbnail: img.canva, gallery: [img.canva], previewImages: [img.canva], previewVideos: [], zipFile: { name: 'minimal-motivation-poster.zip', size: 6_200_000 }, description: 'A set of 6 minimal typography motivation posters.', metaTitle: 'Minimal Motivation Poster Set | PicaMarts', metaDescription: '6 minimal typography motivation posters, print-ready in multiple sizes.', rating: 5.0, reviewCount: 64, downloads: 1890, createdAt: '2025-12-01T10:00:00.000Z' },
  { id: 'prod-4', title: 'Elegant Wedding Card Suite', slug: 'elegant-wedding-card-suite', sku: 'PM-CA-004', categoryId: 'cat-cards', collectionIds: ['coll-holiday-2026'], brandId: 'brand-studio-lume', tags: ['cards', 'wedding', 'stationery'], price: 15, salePrice: null, cost: 4, stock: 999, lowStockThreshold: 10, status: 'draft', featured: false, thumbnail: img.font, gallery: [img.font], previewImages: [img.font], previewVideos: [], zipFile: null, description: 'A complete editable wedding stationery suite.', metaTitle: 'Elegant Wedding Card Suite | PicaMarts', metaDescription: 'A complete, fully editable wedding stationery suite for invitations and save-the-dates.', rating: 4.9, reviewCount: 201, downloads: 980, createdAt: '2025-12-05T10:00:00.000Z' },
  { id: 'prod-5', title: 'Dino Kids Coloring Pages', slug: 'dino-kids-coloring-pages', sku: 'PM-CP-005', categoryId: 'cat-coloring', collectionIds: ['coll-starter-bundle'], brandId: 'brand-petal-ink', tags: ['coloring', 'kids', 'dinosaurs'], price: 10, salePrice: 6, cost: 1.5, stock: 999, lowStockThreshold: 20, status: 'active', featured: false, thumbnail: img.color, gallery: [img.color], previewImages: [img.color], previewVideos: [], zipFile: { name: 'dino-kids-coloring-pages.zip', size: 12_100_000 }, description: '20 dinosaur-themed coloring pages for kids.', metaTitle: 'Dino Kids Coloring Pages | PicaMarts', metaDescription: '20 printable dinosaur-themed coloring pages, perfect for classrooms and rainy days.', rating: 4.7, reviewCount: 87, downloads: 4110, createdAt: '2025-12-10T10:00:00.000Z' },
  { id: 'prod-6', title: 'Mega PNG Bundle Vol.3', slug: 'mega-png-bundle-vol-3', sku: 'PM-PB-006', categoryId: 'cat-png-bundles', collectionIds: ['coll-editors-picks'], brandId: 'brand-pixel-craft', tags: ['png', 'bundle', 'graphics'], price: 14, salePrice: null, cost: 3.5, stock: 8, lowStockThreshold: 10, status: 'active', featured: true, thumbnail: img.icons, gallery: [img.icons, img.vector], previewImages: [img.icons], previewVideos: [{ name: 'mega-png-bundle-vol3-preview.mp4', size: 24_500_000 }], zipFile: { name: 'mega-png-bundle-vol3.zip', size: 41_000_000 }, description: '150+ transparent PNG graphics.', metaTitle: 'Mega PNG Bundle Vol. 3 | PicaMarts', metaDescription: '150+ transparent PNG graphics covering icons, shapes, and design elements.', rating: 4.9, reviewCount: 445, downloads: 2760, createdAt: '2026-01-04T10:00:00.000Z' },
  { id: 'prod-9', title: 'Vintage Sports Tee Graphics', slug: 'vintage-sports-tee-graphics', sku: 'PM-TS-009', categoryId: 'cat-tshirt', collectionIds: [], brandId: 'brand-bold-press', tags: ['t-shirt', 'sports', 'retro'], price: 20, salePrice: 13, cost: 3, stock: 5, lowStockThreshold: 10, status: 'active', featured: false, thumbnail: img.icons, gallery: [img.icons, img.vector], previewImages: [img.icons], previewVideos: [], zipFile: { name: 'vintage-sports-tee-graphics.zip', size: 15_700_000 }, description: 'A retro-style sports graphics bundle.', metaTitle: 'Vintage Sports Tee Graphics | PicaMarts', metaDescription: 'A retro-style sports graphics bundle built for print-on-demand tees.', rating: 4.8, reviewCount: 178, downloads: 1720, createdAt: '2026-01-15T10:00:00.000Z' },
  { id: 'prod-10', title: 'Championship Sports Badges', slug: 'championship-sports-badges', sku: 'PM-SP-010', categoryId: 'cat-sports', collectionIds: ['coll-summer-refresh'], brandId: 'brand-bold-press', tags: ['sports', 'badges', 'vector'], price: 10, salePrice: null, cost: 2.5, stock: 0, lowStockThreshold: 10, status: 'active', featured: false, thumbnail: img.vector, gallery: [img.vector], previewImages: [img.vector], previewVideos: [], zipFile: { name: 'championship-sports-badges.zip', size: 8_900_000 }, description: 'A set of 15 championship badge graphics.', metaTitle: 'Championship Sports Badges | PicaMarts', metaDescription: 'A set of 15 championship-style badge graphics for sports branding.', rating: 4.7, reviewCount: 51, downloads: 1330, createdAt: '2026-02-01T10:00:00.000Z' },
  { id: 'prod-8', title: 'Botanical Nature Prints', slug: 'botanical-nature-prints', sku: 'PM-NA-008', categoryId: 'cat-nature', collectionIds: ['coll-summer-refresh'], brandId: 'brand-studio-lume', tags: ['nature', 'botanical', 'vector'], price: 11, salePrice: null, cost: 3, stock: 999, lowStockThreshold: 20, status: 'active', featured: false, thumbnail: img.vector, gallery: [img.vector, img.wall], previewImages: [img.vector], previewVideos: [], zipFile: { name: 'botanical-nature-prints.zip', size: 11_300_000 }, description: 'A vector botanical print collection.', metaTitle: 'Botanical Nature Prints | PicaMarts', metaDescription: 'A vector botanical print collection featuring 10 hand-drawn leaf and branch illustrations.', rating: 4.6, reviewCount: 93, downloads: 2230, createdAt: '2026-02-10T10:00:00.000Z' },
  { id: 'prod-7', title: 'Aesthetic Digital Planner', slug: 'aesthetic-digital-planner', sku: 'PM-PL-007', categoryId: 'cat-planner', collectionIds: ['coll-starter-bundle'], brandId: 'brand-nova-grid', tags: ['planner', 'digital', 'productivity'], price: 22, salePrice: 16, cost: 4, stock: 999, lowStockThreshold: 15, status: 'archived', featured: false, thumbnail: img.planner, gallery: [img.planner], previewImages: [img.planner], previewVideos: [{ name: 'aesthetic-digital-planner-walkthrough.mp4', size: 31_200_000 }], zipFile: { name: 'aesthetic-digital-planner.zip', size: 22_600_000 }, description: 'A fully hyperlinked digital planner.', metaTitle: 'Aesthetic Digital Planner | PicaMarts', metaDescription: 'A fully hyperlinked digital planner for GoodNotes, Notability, and iPad note-taking apps.', rating: 4.8, reviewCount: 156, downloads: 1540, createdAt: '2026-02-20T10:00:00.000Z' },
];

export const seedCustomers = [
  { id: 'cust-1', name: 'Amelia Carter', email: 'amelia@example.com', phone: '+1 555-0101', status: 'active', totalOrders: 6, totalSpent: 142.5, joinedAt: '2025-09-14T10:00:00.000Z' },
  { id: 'cust-2', name: 'Marcus Bailey', email: 'marcus@example.com', phone: '+1 555-0102', status: 'active', totalOrders: 3, totalSpent: 67.0, joinedAt: '2025-10-02T10:00:00.000Z' },
  { id: 'cust-3', name: 'Priya Nair', email: 'priya@example.com', phone: '+1 555-0103', status: 'active', totalOrders: 9, totalSpent: 284.2, joinedAt: '2025-08-21T10:00:00.000Z' },
  { id: 'cust-4', name: 'Jordan King', email: 'jordan@example.com', phone: '+1 555-0104', status: 'suspended', totalOrders: 1, totalSpent: 9.0, joinedAt: '2025-12-01T10:00:00.000Z' },
  { id: 'cust-5', name: 'Sam Rivera', email: 'sam@example.com', phone: '+1 555-0105', status: 'active', totalOrders: 4, totalSpent: 98.4, joinedAt: '2026-01-05T10:00:00.000Z' },
  { id: 'cust-6', name: 'Taylor Moss', email: 'taylor@example.com', phone: '+1 555-0106', status: 'active', totalOrders: 2, totalSpent: 41.0, joinedAt: '2026-01-18T10:00:00.000Z' },
];

const oi = (productId, title, price, qty, licenseName) => ({ productId, title, price, qty, licenseName });

export const seedOrders = [
  { id: 'ord-1001', customerId: 'cust-1', customerName: 'Amelia Carter', email: 'amelia@example.com', items: [oi('prod-1', 'Boho Arch Wall Art Set', 12, 1, 'Personal Use'), oi('prod-2', 'Watercolor Floral Clipart', 9, 1, 'Commercial Use')], total: 21, status: 'completed', paymentStatus: 'paid', paymentMethod: 'Card', createdAt: '2026-06-01T09:12:00.000Z' },
  { id: 'ord-1002', customerId: 'cust-2', customerName: 'Marcus Bailey', email: 'marcus@example.com', items: [oi('prod-3', 'Minimal Motivation Poster', 8, 1, 'Personal Use')], total: 8, status: 'completed', paymentStatus: 'paid', paymentMethod: 'PayPal', createdAt: '2026-06-03T14:40:00.000Z' },
  { id: 'ord-1003', customerId: 'cust-3', customerName: 'Priya Nair', email: 'priya@example.com', items: [oi('prod-6', 'Mega PNG Bundle Vol.3', 25.2, 1, 'Commercial Use')], total: 25.2, status: 'processing', paymentStatus: 'paid', paymentMethod: 'Card', createdAt: '2026-06-10T08:05:00.000Z' },
  { id: 'ord-1004', customerId: 'cust-5', customerName: 'Sam Rivera', email: 'sam@example.com', items: [oi('prod-5', 'Dino Kids Coloring Pages', 6, 1, 'Personal Use'), oi('prod-9', 'Vintage Sports Tee Graphics', 23.4, 1, 'Commercial Use')], total: 29.4, status: 'pending', paymentStatus: 'unpaid', paymentMethod: 'Bank Transfer', createdAt: '2026-06-14T17:22:00.000Z' },
  { id: 'ord-1005', customerId: 'cust-4', customerName: 'Jordan King', email: 'jordan@example.com', items: [oi('prod-10', 'Championship Sports Badges', 10, 1, 'Personal Use')], total: 10, status: 'cancelled', paymentStatus: 'refunded', paymentMethod: 'Card', createdAt: '2026-06-16T11:00:00.000Z' },
  { id: 'ord-1006', customerId: 'cust-1', customerName: 'Amelia Carter', email: 'amelia@example.com', items: [oi('prod-8', 'Botanical Nature Prints', 11, 2, 'Personal Use')], total: 22, status: 'completed', paymentStatus: 'paid', paymentMethod: 'Card', createdAt: '2026-06-20T13:10:00.000Z' },
  { id: 'ord-1007', customerId: 'cust-6', customerName: 'Taylor Moss', email: 'taylor@example.com', items: [oi('prod-2', 'Watercolor Floral Clipart', 9, 1, 'Personal Use')], total: 9, status: 'shipped', paymentStatus: 'paid', paymentMethod: 'PayPal', createdAt: '2026-06-25T09:47:00.000Z' },
  { id: 'ord-1008', customerId: 'cust-3', customerName: 'Priya Nair', email: 'priya@example.com', items: [oi('prod-1', 'Boho Arch Wall Art Set', 21.6, 1, 'Commercial Use')], total: 21.6, status: 'completed', paymentStatus: 'paid', paymentMethod: 'Card', createdAt: '2026-07-01T10:30:00.000Z' },
  { id: 'ord-1009', customerId: 'cust-2', customerName: 'Marcus Bailey', email: 'marcus@example.com', items: [oi('prod-3', 'Minimal Motivation Poster', 8, 1, 'Personal Use')], total: 8, status: 'pending', paymentStatus: 'unpaid', paymentMethod: 'Bank Transfer', createdAt: '2026-07-08T16:15:00.000Z' },
  { id: 'ord-1010', customerId: 'cust-5', customerName: 'Sam Rivera', email: 'sam@example.com', items: [oi('prod-6', 'Mega PNG Bundle Vol.3', 14, 1, 'Personal Use')], total: 14, status: 'processing', paymentStatus: 'paid', paymentMethod: 'Card', createdAt: '2026-07-12T12:00:00.000Z' },
];

export const seedCoupons = [
  { id: 'cpn-1', code: 'WELCOME10', type: 'percent', value: 10, minSpend: 0, usageLimit: 500, usedCount: 213, status: 'active', expiresAt: '2026-12-31T00:00:00.000Z' },
  { id: 'cpn-2', code: 'SUMMER25', type: 'percent', value: 25, minSpend: 20, usageLimit: 200, usedCount: 88, status: 'active', expiresAt: '2026-08-31T00:00:00.000Z' },
  { id: 'cpn-3', code: 'FLAT5', type: 'fixed', value: 5, minSpend: 15, usageLimit: 1000, usedCount: 401, status: 'active', expiresAt: '2027-01-01T00:00:00.000Z' },
  { id: 'cpn-4', code: 'VIP50', type: 'percent', value: 50, minSpend: 50, usageLimit: 50, usedCount: 50, status: 'expired', expiresAt: '2026-05-01T00:00:00.000Z' },
  { id: 'cpn-5', code: 'HOLIDAY15', type: 'percent', value: 15, minSpend: 0, usageLimit: 300, usedCount: 0, status: 'scheduled', expiresAt: '2026-12-26T00:00:00.000Z' },
];

export const seedReviews = [
  { id: 'rev-1', productId: 'prod-2', productTitle: 'Watercolor Floral Clipart', customerName: 'Jordan K.', rating: 5, comment: 'Exactly what I needed for my shop mockups.', status: 'approved', createdAt: '2026-06-05T10:00:00.000Z' },
  { id: 'rev-2', productId: 'prod-1', productTitle: 'Boho Arch Wall Art Set', customerName: 'Sam R.', rating: 4, comment: 'Great quality, wish there were more color variations.', status: 'approved', createdAt: '2026-06-08T10:00:00.000Z' },
  { id: 'rev-3', productId: 'prod-6', productTitle: 'Mega PNG Bundle Vol.3', customerName: 'Taylor M.', rating: 5, comment: 'Instant download worked perfectly.', status: 'approved', createdAt: '2026-06-11T10:00:00.000Z' },
  { id: 'rev-4', productId: 'prod-9', productTitle: 'Vintage Sports Tee Graphics', customerName: 'Casey B.', rating: 2, comment: 'Files were fine but the license PDF took a while to arrive.', status: 'pending', createdAt: '2026-07-01T10:00:00.000Z' },
  { id: 'rev-5', productId: 'prod-3', productTitle: 'Minimal Motivation Poster', customerName: 'Riley P.', rating: 5, comment: 'Clean, modern, printed beautifully.', status: 'pending', createdAt: '2026-07-05T10:00:00.000Z' },
  { id: 'rev-6', productId: 'prod-10', productTitle: 'Championship Sports Badges', customerName: 'Drew A.', rating: 1, comment: 'This looked nothing like the preview image, disappointed.', status: 'rejected', createdAt: '2026-07-06T10:00:00.000Z' },
];

export const seedMedia = [
  { id: 'med-1', filename: 'boho-arch-wall-art-1.png', url: img.wall, type: 'image/png', size: 2_400_000, uploadedAt: '2025-11-02T10:00:00.000Z' },
  { id: 'med-2', filename: 'watercolor-floral-clipart.png', url: img.floral, type: 'image/png', size: 1_800_000, uploadedAt: '2025-11-10T10:00:00.000Z' },
  { id: 'med-3', filename: 'minimal-motivation-poster.png', url: img.canva, type: 'image/png', size: 1_200_000, uploadedAt: '2025-12-01T10:00:00.000Z' },
  { id: 'med-4', filename: 'wedding-card-suite.png', url: img.font, type: 'image/png', size: 980_000, uploadedAt: '2025-12-05T10:00:00.000Z' },
  { id: 'med-5', filename: 'dino-coloring-pages.png', url: img.color, type: 'image/png', size: 1_500_000, uploadedAt: '2025-12-10T10:00:00.000Z' },
  { id: 'med-6', filename: 'mega-png-bundle-vol3.png', url: img.icons, type: 'image/png', size: 3_100_000, uploadedAt: '2026-01-04T10:00:00.000Z' },
  { id: 'med-7', filename: 'digital-planner-cover.png', url: img.planner, type: 'image/png', size: 2_050_000, uploadedAt: '2026-01-15T10:00:00.000Z' },
  { id: 'med-8', filename: 'botanical-nature-vector.png', url: img.vector, type: 'image/png', size: 1_650_000, uploadedAt: '2026-02-01T10:00:00.000Z' },
];

export const seedBanners = [
  { id: 'ban-1', title: 'Summer Sale — Up to 40% Off', image: img.wall, mobileImage: '', link: '/shop?search=sale', buttonText: 'Shop the Sale', position: 'homepage', status: 'active', startAt: '2026-06-01T00:00:00.000Z', endAt: '2026-08-31T00:00:00.000Z' },
  { id: 'ban-2', title: 'New Arrivals: Botanical Collection', image: img.vector, mobileImage: '', link: '/shop?search=Nature', buttonText: 'Explore Collection', position: 'collection', status: 'active', startAt: '2026-06-15T00:00:00.000Z', endAt: '2026-12-31T00:00:00.000Z' },
  { id: 'ban-3', title: 'Back to School Planners', image: img.planner, mobileImage: '', link: '/shop?search=Planner', buttonText: 'Shop Planners', position: 'category', status: 'scheduled', startAt: '2026-08-01T00:00:00.000Z', endAt: '2026-09-15T00:00:00.000Z' },
  { id: 'ban-4', title: 'Holiday Card Suite Launch', image: img.font, mobileImage: '', link: '/shop?search=Cards', buttonText: 'Shop Now', position: 'sale', status: 'draft', startAt: '2026-11-01T00:00:00.000Z', endAt: '2026-12-25T00:00:00.000Z' },
];

export const seedUsers = [
  { id: 'usr-1', name: 'Ava Thompson', email: 'ava@picamarts.com', role: 'Admin', status: 'active', lastLoginAt: '2026-07-15T09:00:00.000Z' },
  { id: 'usr-2', name: 'Liam Chen', email: 'liam@picamarts.com', role: 'Editor', status: 'active', lastLoginAt: '2026-07-14T15:20:00.000Z' },
  { id: 'usr-3', name: 'Noor Hassan', email: 'noor@picamarts.com', role: 'Support', status: 'active', lastLoginAt: '2026-07-10T11:45:00.000Z' },
  { id: 'usr-4', name: 'Diego Alvarez', email: 'diego@picamarts.com', role: 'Editor', status: 'invited', lastLoginAt: null },
  { id: 'usr-5', name: 'Mei Lin', email: 'mei@picamarts.com', role: 'Support', status: 'suspended', lastLoginAt: '2026-05-02T08:00:00.000Z' },
];

// Marketplace vendors (distinct from admin Users above, which are internal
// staff accounts). Sellers go through Approve/Reject/Suspend workflows.
export const seedSellers = [
  { id: 'sell-1', storeName: 'Studio Lume', ownerName: 'Hana Kobayashi', email: 'hana@studiolume.example.com', phone: '+1 555-0201', status: 'approved', productsCount: 2, totalSales: 412.6, commissionRate: 15, joinedAt: '2025-10-01T10:00:00.000Z' },
  { id: 'sell-2', storeName: 'Petal & Ink', ownerName: 'Elena Petrova', email: 'elena@petalandink.example.com', phone: '+1 555-0202', status: 'approved', productsCount: 1, totalSales: 208.0, commissionRate: 15, joinedAt: '2025-10-20T10:00:00.000Z' },
  { id: 'sell-3', storeName: 'Nova Grid', ownerName: 'Theo Marsh', email: 'theo@novagrid.example.com', phone: '+1 555-0203', status: 'approved', productsCount: 1, totalSales: 96.0, commissionRate: 12, joinedAt: '2025-11-05T10:00:00.000Z' },
  { id: 'sell-4', storeName: 'Pixel Craft', ownerName: 'Ravi Menon', email: 'ravi@pixelcraft.example.com', phone: '+1 555-0204', status: 'pending', productsCount: 0, totalSales: 0, commissionRate: 15, joinedAt: '2026-06-28T10:00:00.000Z' },
  { id: 'sell-5', storeName: 'Bold Press', ownerName: 'Casey Grant', email: 'casey@boldpress.example.com', phone: '+1 555-0205', status: 'suspended', productsCount: 1, totalSales: 143.5, commissionRate: 15, joinedAt: '2025-12-12T10:00:00.000Z' },
  { id: 'sell-6', storeName: 'Driftwood Designs', ownerName: 'Ines Oliveira', email: 'ines@driftwooddesigns.example.com', phone: '+1 555-0206', status: 'pending', productsCount: 0, totalSales: 0, commissionRate: 15, joinedAt: '2026-07-10T10:00:00.000Z' },
  { id: 'sell-7', storeName: 'Quiet Forms Studio', ownerName: 'Malik Freeman', email: 'malik@quietforms.example.com', phone: '+1 555-0207', status: 'rejected', productsCount: 0, totalSales: 0, commissionRate: 15, joinedAt: '2026-05-18T10:00:00.000Z' },
];

export const seedStockLog = [];

export const seedSettings = {
  storeName: 'PicaMarts',
  storeEmail: 'hello@picamarts.com',
  storePhone: '+1 555-010-0000',
  address: '123 Market Street, Suite 400, San Francisco, CA',
  currency: 'USD',
  timezone: 'America/Los_Angeles',
  logo: '',
  taxRatePercent: 0,
  flatShippingFee: 0,
  emailNewOrder: true,
  emailLowStock: true,
  emailNewReview: false,
  maintenanceMode: false,
  // Shipping & fees — future-ready for physical products; digital-only today.
  shippingZones: [
    { id: 'zone-1', name: 'Domestic (US)', countries: 'United States', rate: 0 },
    { id: 'zone-2', name: 'International', countries: 'Rest of World', rate: 0 },
  ],
  shippingMethods: [
    { id: 'method-1', name: 'Instant Digital Delivery', cost: 0, estimatedDays: 'Instant' },
  ],
  taxRules: [
    { id: 'tax-1', region: 'United States', rate: 0, taxClass: 'Digital Goods' },
  ],
  platformFeePercent: 2,
  commissionRules: [
    { id: 'comm-1', scope: 'All Categories', rate: 15 },
  ],
};

// ---------------------------------------------------------------------
// BLOG CMS — authors, posts, categories, tags, comments (future-ready),
// revisions (future-ready), settings. Shapes mirror what future
// `blog_authors` / `posts` / `blog_categories` / `blog_tags` /
// `blog_comments` / `blog_post_revisions` / `blog_settings` collections
// would look like so wiring a real backend later is a data-shape match,
// not a redesign.
// ---------------------------------------------------------------------

export const seedBlogAuthors = [
  {
    id: 'author-picamarts-team', name: 'PicaMarts Team', avatar: img.font,
    bio: 'The team behind PicaMarts, writing about digital products, licensing, and everything else that helps sellers succeed.',
    socialLinks: [{ platform: 'website', url: 'https://picamarts.example.com' }, { platform: 'twitter', url: 'https://twitter.com/picamarts' }],
  },
  {
    id: 'author-petal-ink', name: 'Petal & Ink', avatar: img.floral,
    bio: 'Hand-painted watercolor florals and behind-the-scenes process notes from the Petal & Ink studio.',
    socialLinks: [{ platform: 'instagram', url: 'https://instagram.com/petalandink' }],
  },
  {
    id: 'author-pixel-craft', name: 'Pixel Craft', avatar: img.icons,
    bio: 'High-volume PNG bundles and practical business advice for print-on-demand sellers.',
    socialLinks: [{ platform: 'website', url: 'https://pixelcraft.example.com' }],
  },
  {
    id: 'author-daily-flow', name: 'Daily Flow', avatar: img.planner,
    bio: 'Digital planner design trends and productivity-first spreads.',
    socialLinks: [{ platform: 'twitter', url: 'https://twitter.com/dailyflow' }],
  },
];

export const seedBlogCategories = [
  { id: 'bcat-guides', name: 'Guides', slug: 'guides', description: 'Practical how-tos for using and selling digital downloads.', icon: 'BookOpen', image: img.font, status: 'active', order: 0, postCount: 1 },
  { id: 'bcat-inspiration', name: 'Inspiration', slug: 'inspiration', description: 'Creative ways to use PicaMarts assets.', icon: 'Sparkles', image: img.floral, status: 'active', order: 1, postCount: 1 },
  { id: 'bcat-business', name: 'Business', slug: 'business', description: 'Running and growing a digital shop.', icon: 'Briefcase', image: img.icons, status: 'active', order: 2, postCount: 1 },
  { id: 'bcat-trends', name: 'Trends', slug: 'trends', description: 'What is shaping design and digital products this year.', icon: 'TrendingUp', image: img.planner, status: 'active', order: 3, postCount: 1 },
  { id: 'bcat-behind-the-scenes', name: 'Behind the Scenes', slug: 'behind-the-scenes', description: 'How our sellers make what they make.', icon: 'Camera', image: img.color, status: 'active', order: 4, postCount: 1 },
];

export const seedBlogTags = [
  { id: 'btag-license', name: 'Licensing', slug: 'licensing', postCount: 1 },
  { id: 'btag-clipart', name: 'Clipart', slug: 'clipart', postCount: 2 },
  { id: 'btag-pod', name: 'Print on Demand', slug: 'print-on-demand', postCount: 1 },
  { id: 'btag-planner', name: 'Planners', slug: 'planners', postCount: 2 },
  { id: 'btag-watercolor', name: 'Watercolor', slug: 'watercolor', postCount: 1 },
  { id: 'btag-tutorial', name: 'Tutorial', slug: 'tutorial', postCount: 0 },
];

// `deletedAt` is null for a live post; setting it moves a post to Trash
// (soft delete) without removing its row, so Restore is just clearing
// the field back to null. `version` / `lastModified` (= updatedAt) /
// `modifiedBy` back the Revisions UI; the SEO fields cover canonical,
// robots, Open Graph, and Twitter Card independently of the base fields.
export const seedBlogPosts = [
  {
    id: 'post-1', title: 'Choosing the Right License for Your Project', slug: 'choosing-the-right-license',
    excerpt: 'Personal, Commercial, or Extended — here is how to pick the license that actually matches how you plan to use your download.',
    content: 'Every product on PicaMarts ships with at least one license tier, and picking the right one is less about the price and more about what you plan to do with the file after checkout.\n\nA Personal license covers gifts, home projects, and anything that never touches a sale. A Commercial license opens the door to client work and limited-run resale, while Extended Commercial removes the sales cap entirely for agencies and high-volume shops.\n\nWhen in doubt, start with the smallest license that covers your current project — you can always come back and upgrade later if your use case grows.',
    categoryId: 'bcat-guides', tags: ['btag-license', 'btag-tutorial'], authorId: 'author-picamarts-team',
    featuredImage: img.font, gallery: [img.font], status: 'published', featured: true, trending: false, editorsPick: true,
    readingTime: '5 min read',
    seoTitle: 'Choosing the Right License for Your Project | PicaMarts', metaDescription: 'How to pick the license tier that matches how you plan to use your download.', focusKeyword: 'digital product license',
    canonicalUrl: '', robotsIndex: true, robotsFollow: true,
    ogTitle: '', ogDescription: '', ogImage: img.font,
    twitterCard: 'summary_large_image', twitterTitle: '', twitterDescription: '', twitterImage: '',
    createdAt: '2026-06-10T09:00:00.000Z', updatedAt: '2026-06-18T09:00:00.000Z', publishedAt: '2026-06-18T09:00:00.000Z', views: 4210,
    version: 3, modifiedBy: 'Admin', deletedAt: null,
  },
  {
    id: 'post-2', title: '5 Ways to Use Clipart Beyond the Obvious', slug: 'five-ways-to-use-clipart',
    excerpt: 'Clipart is not just for scrapbooking — see how sellers are using it in packaging, social templates, and more.',
    content: 'Clipart libraries are often thought of as a scrapbooking tool, but the most creative shop owners are using them everywhere from product packaging to social media templates.\n\nTry layering clipart elements behind your logo for packaging inserts, or use single elements as accent graphics in a slide deck or newsletter header.\n\nThe key is treating each element as a flexible building block rather than a finished graphic — resize, recolor, and recombine to get something that feels custom.',
    categoryId: 'bcat-inspiration', tags: ['btag-clipart'], authorId: 'author-petal-ink',
    featuredImage: img.floral, gallery: [img.floral], status: 'published', featured: true, trending: true, editorsPick: false,
    readingTime: '4 min read',
    seoTitle: '5 Ways to Use Clipart Beyond the Obvious | PicaMarts', metaDescription: 'Creative, non-obvious ways sellers are using clipart bundles.', focusKeyword: 'clipart ideas',
    canonicalUrl: '', robotsIndex: true, robotsFollow: true,
    ogTitle: '', ogDescription: '', ogImage: img.floral,
    twitterCard: 'summary_large_image', twitterTitle: '', twitterDescription: '', twitterImage: '',
    createdAt: '2026-05-28T09:00:00.000Z', updatedAt: '2026-06-05T09:00:00.000Z', publishedAt: '2026-06-05T09:00:00.000Z', views: 3110,
    version: 2, modifiedBy: 'Admin', deletedAt: null,
  },
  {
    id: 'post-3', title: 'Setting Up Your Print-on-Demand Shop in a Weekend', slug: 'setting-up-your-print-on-demand-shop',
    excerpt: 'A practical, no-fluff walkthrough for turning a folder of downloads into a live storefront.',
    content: 'You do not need months of planning to launch a print-on-demand shop — with the right assets, a weekend is plenty of time.\n\nStart by picking one tight niche and 10-15 designs with a commercial license, then mock them up on your chosen products using a free mockup generator.\n\nList your first batch, set realistic shipping expectations, and treat your first two weeks as a feedback loop rather than a finish line.',
    categoryId: 'bcat-business', tags: ['btag-pod'], authorId: 'author-pixel-craft',
    featuredImage: img.icons, gallery: [img.icons], status: 'published', featured: false, trending: true, editorsPick: false,
    readingTime: '7 min read',
    seoTitle: 'Setting Up Your Print-on-Demand Shop in a Weekend | PicaMarts', metaDescription: 'A no-fluff walkthrough for launching a print-on-demand shop fast.', focusKeyword: 'print on demand shop',
    canonicalUrl: '', robotsIndex: true, robotsFollow: true,
    ogTitle: '', ogDescription: '', ogImage: img.icons,
    twitterCard: 'summary_large_image', twitterTitle: '', twitterDescription: '', twitterImage: '',
    createdAt: '2026-05-15T09:00:00.000Z', updatedAt: '2026-05-22T09:00:00.000Z', publishedAt: '2026-05-22T09:00:00.000Z', views: 2870,
    version: 1, modifiedBy: 'Admin', deletedAt: null,
  },
  {
    id: 'post-4', title: '2026 Trends in Digital Planning', slug: 'trends-in-digital-planning',
    excerpt: 'From hyperlinked spreads to minimalist widgets, here is what is shaping digital planner design this year.',
    content: 'Digital planning has moved well past simple PDF grids — this year most popular spreads lean on deep hyperlinking so every tap feels instant.\n\nMinimalist, low-contrast palettes are trending over busy stickers, giving planners a calmer, more focused feel on-screen.\n\nExpect to see more modular spreads too, where users mix and match widgets like habit trackers and mood logs instead of one fixed layout.',
    categoryId: 'bcat-trends', tags: ['btag-planner'], authorId: 'author-daily-flow',
    featuredImage: img.planner, gallery: [img.planner], status: 'published', featured: false, trending: false, editorsPick: true,
    readingTime: '4 min read',
    seoTitle: '2026 Trends in Digital Planning | PicaMarts', metaDescription: 'What is shaping digital planner design in 2026.', focusKeyword: 'digital planner trends',
    canonicalUrl: '', robotsIndex: true, robotsFollow: true,
    ogTitle: '', ogDescription: '', ogImage: img.planner,
    twitterCard: 'summary_large_image', twitterTitle: '', twitterDescription: '', twitterImage: '',
    createdAt: '2026-04-22T09:00:00.000Z', updatedAt: '2026-04-30T09:00:00.000Z', publishedAt: '2026-04-30T09:00:00.000Z', views: 1980,
    version: 1, modifiedBy: 'Admin', deletedAt: null,
  },
  {
    id: 'post-5', title: 'Behind the Scenes: Our Watercolor Technique', slug: 'watercolor-technique-breakdown',
    excerpt: 'A peek into how our best-selling floral clipart sets go from real paint to layered PNG files.',
    content: 'Every floral element starts as a real watercolor painting on cold-press paper, scanned at high resolution to preserve the texture of the pigment.\n\nFrom there, each piece is hand-cut in layers so shadows and highlights stay separate, which is what lets you recolor elements without losing the painted texture.\n\nThe final export pass checks every file at multiple sizes to make sure the details still hold up whether it is printed at 3 inches or 30.',
    categoryId: 'bcat-behind-the-scenes', tags: ['btag-watercolor', 'btag-clipart'], authorId: 'author-petal-ink',
    featuredImage: img.color, gallery: [img.color, img.floral], status: 'published', featured: false, trending: false, editorsPick: false,
    readingTime: '6 min read',
    seoTitle: 'Behind the Scenes: Our Watercolor Technique | PicaMarts', metaDescription: 'How our floral clipart sets go from real paint to layered PNG files.', focusKeyword: 'watercolor clipart process',
    canonicalUrl: '', robotsIndex: true, robotsFollow: true,
    ogTitle: '', ogDescription: '', ogImage: img.color,
    twitterCard: 'summary_large_image', twitterTitle: '', twitterDescription: '', twitterImage: '',
    createdAt: '2026-04-02T09:00:00.000Z', updatedAt: '2026-04-11T09:00:00.000Z', publishedAt: '2026-04-11T09:00:00.000Z', views: 1540,
    version: 1, modifiedBy: 'Admin', deletedAt: null,
  },
  {
    id: 'post-6', title: 'A First Look at Our Q3 Roadmap', slug: 'q3-roadmap-preview',
    excerpt: 'A short preview of what the team is shipping next quarter — still being finalized.',
    content: 'We are heads-down on a handful of seller-requested features for next quarter.\n\nThis post is still a work in progress and will be expanded closer to launch.',
    categoryId: 'bcat-business', tags: [], authorId: 'author-picamarts-team',
    featuredImage: img.vector, gallery: [], status: 'draft', featured: false, trending: false, editorsPick: false,
    readingTime: '2 min read',
    seoTitle: '', metaDescription: '', focusKeyword: '',
    canonicalUrl: '', robotsIndex: true, robotsFollow: true,
    ogTitle: '', ogDescription: '', ogImage: '',
    twitterCard: 'summary_large_image', twitterTitle: '', twitterDescription: '', twitterImage: '',
    createdAt: '2026-07-01T09:00:00.000Z', updatedAt: '2026-07-10T09:00:00.000Z', publishedAt: null, views: 0,
    version: 1, modifiedBy: 'Admin', deletedAt: null,
  },
  {
    id: 'post-7', title: 'Fall Refresh: New Seasonal Collections', slug: 'fall-refresh-seasonal-collections',
    excerpt: 'A scheduled announcement for the upcoming seasonal collection drop.',
    content: 'Our fall collection drops soon with new planner spreads, clipart sets, and printable decor.\n\nCheck back for the full lineup on release day.',
    categoryId: 'bcat-trends', tags: ['btag-planner'], authorId: 'author-daily-flow',
    featuredImage: img.planner, gallery: [], status: 'scheduled', featured: false, trending: false, editorsPick: false,
    readingTime: '3 min read',
    seoTitle: 'Fall Refresh: New Seasonal Collections | PicaMarts', metaDescription: 'A first look at our upcoming fall seasonal collection.', focusKeyword: 'fall seasonal collection',
    canonicalUrl: '', robotsIndex: true, robotsFollow: true,
    ogTitle: '', ogDescription: '', ogImage: img.planner,
    twitterCard: 'summary_large_image', twitterTitle: '', twitterDescription: '', twitterImage: '',
    createdAt: '2026-07-05T09:00:00.000Z', updatedAt: '2026-07-12T09:00:00.000Z', publishedAt: '2026-08-01T09:00:00.000Z', views: 0,
    version: 1, modifiedBy: 'Admin', deletedAt: null,
  },
  {
    id: 'post-8', title: 'Why We Retired Our Old Sticker Pack', slug: 'retired-old-sticker-pack',
    excerpt: 'An older post kept only for reference — moved to Trash as a soft-delete example.',
    content: 'This post has been retired and moved to Trash.\n\nIt is kept here only to demonstrate the Trash / Restore / Permanently Delete workflow.',
    categoryId: 'bcat-inspiration', tags: [], authorId: 'author-petal-ink',
    featuredImage: img.floral, gallery: [], status: 'draft', featured: false, trending: false, editorsPick: false,
    readingTime: '2 min read',
    seoTitle: '', metaDescription: '', focusKeyword: '',
    canonicalUrl: '', robotsIndex: false, robotsFollow: true,
    ogTitle: '', ogDescription: '', ogImage: '',
    twitterCard: 'summary_large_image', twitterTitle: '', twitterDescription: '', twitterImage: '',
    createdAt: '2026-02-01T09:00:00.000Z', updatedAt: '2026-02-15T09:00:00.000Z', publishedAt: null, views: 12,
    version: 2, modifiedBy: 'Admin', deletedAt: '2026-07-15T09:00:00.000Z',
  },
];

// Comments are future-ready: modeled and wired into the Admin nav/API now
// so the page and data shape already exist, even though nothing on the
// live frontend posts comments yet.
export const seedBlogComments = [];

// Revisions are future-ready: the resource, service functions, and a
// read-only "Version History" panel in the post editor all exist now.
// Only a couple of posts have seeded history, purely to demonstrate the
// UI — real snapshotting arrives with the backend.
export const seedBlogRevisions = [
  { id: 'rev-1', postId: 'post-1', version: 1, modifiedBy: 'Admin', createdAt: '2026-06-10T09:00:00.000Z', summary: 'Initial draft created' },
  { id: 'rev-2', postId: 'post-1', version: 2, modifiedBy: 'Admin', createdAt: '2026-06-15T10:00:00.000Z', summary: 'Expanded licensing examples' },
  { id: 'rev-3', postId: 'post-1', version: 3, modifiedBy: 'Admin', createdAt: '2026-06-18T09:00:00.000Z', summary: 'Published' },
  { id: 'rev-4', postId: 'post-2', version: 1, modifiedBy: 'Admin', createdAt: '2026-05-28T09:00:00.000Z', summary: 'Initial draft created' },
  { id: 'rev-5', postId: 'post-2', version: 2, modifiedBy: 'Admin', createdAt: '2026-06-05T09:00:00.000Z', summary: 'Published' },
];

export const seedBlogSettings = {
  pageTitle: 'The PicaMarts Blog',
  heroHeading: 'The PicaMarts Blog',
  heroDescription: 'Guides, inspiration, and behind-the-scenes stories from our team and top artists.',
  featuredCategoryIds: ['bcat-guides', 'bcat-inspiration', 'bcat-business', 'bcat-trends'],
  postsPerPage: 9,
  enableSearch: true,
  enableCategories: true,
  enableRelatedPosts: true,
  enableNewsletter: true,
  defaultAuthorId: 'author-picamarts-team',
  defaultOgImage: img.font,
  defaultSeoTitle: 'Blog — Guides & Inspiration | PicaMarts',
  defaultMetaDescription: 'Guides, inspiration, and behind-the-scenes stories from the PicaMarts team and top digital artists.',
  // Dynamic copy — every user-facing label on the Blog page is
  // configurable here so nothing is hardcoded in frontend components.
  searchPlaceholder: 'Search articles…',
  allCategoriesLabel: 'All',
  featuredSectionHeading: 'Featured',
  noResultsTitle: 'No posts found',
  noResultsDescription: 'Try a different category or search term.',
  loadMoreButtonLabel: 'Load more articles',
  newsletterHeading: 'Get new articles in your inbox',
  newsletterDescription: 'Guides and inspiration, once or twice a month. No spam.',
  newsletterPlaceholder: 'you@email.com',
  newsletterButtonLabel: 'Subscribe',
};

// Homepage CMS — every section a shopper sees on the storefront home
// page, in the order they render. Admins can enable/disable, rename,
// reorder, cap product counts, and set imagery/CTAs per section without
// touching code. `type` drives which fields the admin UI shows for a
// given section, and later which storefront component/query it maps to.
export const seedHomepageCms = {
  sections: [
    {
      key: 'hero', type: 'hero', label: 'Hero Section', enabled: true, sortOrder: 1,
      title: 'Digital assets for creators who ship', subtitle: 'Handpicked templates, mockups & fonts',
      description: '', maxProducts: null, backgroundImage: img.wall, buttonText: 'Explore the Shop', buttonUrl: '/shop',
    },
    {
      key: 'featured_categories', type: 'categories', label: 'Featured Categories', enabled: true, sortOrder: 2,
      title: 'Shop by Category', subtitle: 'Find exactly what your project needs',
      description: '', maxProducts: 8, backgroundImage: '', buttonText: 'View All Categories', buttonUrl: '/categories',
    },
    {
      key: 'featured_collections', type: 'collections', label: 'Featured Collections', enabled: true, sortOrder: 3,
      title: 'Curated Collections', subtitle: 'Themed bundles picked by our team',
      description: '', maxProducts: 6, backgroundImage: '', buttonText: 'View All Collections', buttonUrl: '/collections',
    },
    {
      key: 'featured_products', type: 'products', label: 'Featured Products', enabled: true, sortOrder: 4,
      title: 'Featured', subtitle: 'Editor\u2019s picks this week',
      description: '', maxProducts: 12, backgroundImage: '', buttonText: 'Shop Featured', buttonUrl: '/shop?featured=true',
    },
    {
      key: 'trending_products', type: 'products', label: 'Trending Products', enabled: true, sortOrder: 5,
      title: 'Trending Now', subtitle: 'What everyone\u2019s downloading this week',
      description: '', maxProducts: 12, backgroundImage: '', buttonText: 'See What\u2019s Trending', buttonUrl: '/shop?sort=trending',
    },
    {
      key: 'new_arrivals', type: 'products', label: 'New Arrivals', enabled: true, sortOrder: 6,
      title: 'New Arrivals', subtitle: 'Fresh from our sellers',
      description: '', maxProducts: 12, backgroundImage: '', buttonText: 'Shop New Arrivals', buttonUrl: '/shop?sort=newest',
    },
    {
      key: 'best_sellers', type: 'products', label: 'Best Sellers', enabled: true, sortOrder: 7,
      title: 'Best Sellers', subtitle: 'Most loved by our customers',
      description: '', maxProducts: 12, backgroundImage: '', buttonText: 'Shop Best Sellers', buttonUrl: '/shop?sort=best-selling',
    },
    {
      key: 'recommended_products', type: 'products', label: 'Recommended Products', enabled: false, sortOrder: 8,
      title: 'Recommended For You', subtitle: 'Based on what you\u2019ve viewed',
      description: '', maxProducts: 12, backgroundImage: '', buttonText: 'See More', buttonUrl: '/shop',
    },
    {
      key: 'popular_sellers', type: 'sellers', label: 'Popular Sellers', enabled: true, sortOrder: 9,
      title: 'Popular Sellers', subtitle: 'Top-rated shops on PicaMarts',
      description: '', maxProducts: 8, backgroundImage: '', buttonText: 'Browse All Sellers', buttonUrl: '/sellers',
    },
    {
      key: 'testimonials', type: 'testimonials', label: 'Customer Testimonials', enabled: true, sortOrder: 10,
      title: 'Loved by Creators', subtitle: 'Real feedback from real customers',
      description: '', maxProducts: null, backgroundImage: '', buttonText: '', buttonUrl: '',
    },
    {
      key: 'newsletter', type: 'newsletter', label: 'Newsletter Block', enabled: true, sortOrder: 11,
      title: 'Never Miss a Drop', subtitle: 'New templates, freebies & deals in your inbox',
      description: '', maxProducts: null, backgroundImage: '', buttonText: 'Subscribe', buttonUrl: '',
    },
    {
      key: 'promotion_blocks', type: 'promotion', label: 'Promotion Blocks', enabled: false, sortOrder: 12,
      title: 'Limited-Time Offer', subtitle: 'Save on select bundles this month',
      description: '', maxProducts: null, backgroundImage: img.font, buttonText: 'Shop the Sale', buttonUrl: '/shop?search=sale',
    },
  ],
};

// Header CMS — top-of-site chrome the storefront Header component will
// eventually read from: bars above the nav, the nav behavior itself, and
// the buttons on the right side of the bar.
export const seedHeaderCms = {
  logo: '',
  stickyHeader: true,
  megaMenuEnabled: true,
  searchPlaceholder: 'Search for anything…',
  topBar: {
    enabled: false,
    text: 'Free instant delivery on every digital order',
    linkText: '',
    linkUrl: '',
  },
  announcementBar: {
    enabled: false,
    text: '🎉 Summer Sale — up to 40% off select bundles',
    linkText: 'Shop Now',
    linkUrl: '/shop?search=sale',
    backgroundColor: '#7C3AED',
  },
  becomeSellerButton: {
    enabled: true,
    text: 'Become a Seller',
    url: '/become-a-seller',
  },
  headerButtons: [
    { id: 'hb-1', label: 'Help Center', url: '/contact', openInNewTab: false },
  ],
};

// Footer CMS — the parts of the Footer component that are copy/branding
// rather than link structure. Link columns themselves (Marketplace,
// Company, Support, Legal) are managed as Navigation Menus and referenced
// here by menu key, so the same menu builder powers header and footer.
export const seedFooterCms = {
  logo: '',
  description: 'A premium marketplace for digital art. Instant downloads, clear licensing, and hand-picked quality from talented creators worldwide.',
  tagline: 'Secure payments · Instant delivery · 30-day guarantee',
  copyrightText: '© {year} PicaMarts. All rights reserved.',
  socialLinks: [
    { id: 'soc-1', platform: 'Instagram', url: '#' },
    { id: 'soc-2', platform: 'Twitter', url: '#' },
    { id: 'soc-3', platform: 'Github', url: '#' },
    { id: 'soc-4', platform: 'Youtube', url: '#' },
  ],
  paymentIcons: [
    { id: 'pay-1', name: 'Visa', enabled: true },
    { id: 'pay-2', name: 'Mastercard', enabled: true },
    { id: 'pay-3', name: 'PayPal', enabled: true },
    { id: 'pay-4', name: 'Stripe', enabled: false },
    { id: 'pay-5', name: 'Apple Pay', enabled: false },
  ],
  newsletter: {
    enabled: true,
    title: 'Newsletter',
    description: 'New drops, deals, and creator spotlights — no spam.',
    placeholder: 'Your email',
    buttonLabel: 'Subscribe',
  },
  columnMenuKeys: {
    marketplace: 'footer-marketplace',
    company: 'footer-company',
    support: 'footer-support',
    legal: 'footer-legal',
  },
};

// Navigation Menus — the Menu Builder's data. Each menu is a flat list of
// items with `parentId` for one level of nesting (dropdown/sub-menu) and
// `sortOrder` for manual ordering within a parent. `location` is a hint
// for where a menu is intended to be used (Header / Footer / Custom);
// `key` is the stable identifier other CMS modules (e.g. Footer CMS
// columnMenuKeys) reference so swapping a menu's items never breaks the
// reference.
export const seedNavMenus = [
  {
    id: 'menu-header-nav', key: 'header-navigation', name: 'Header Navigation', location: 'Header',
    items: [
      { id: 'hn-1', label: 'Shop', url: '/shop', icon: '', openInNewTab: false, parentId: null, sortOrder: 1 },
      { id: 'hn-2', label: 'Categories', url: '/categories', icon: '', openInNewTab: false, parentId: null, sortOrder: 2 },
      { id: 'hn-3', label: 'Collections', url: '/collections', icon: '', openInNewTab: false, parentId: null, sortOrder: 3 },
      { id: 'hn-4', label: 'Blog', url: '/blog', icon: '', openInNewTab: false, parentId: null, sortOrder: 4 },
    ],
  },
  {
    id: 'menu-footer-marketplace', key: 'footer-marketplace', name: 'Footer — Marketplace', location: 'Footer',
    items: [
      { id: 'fm-1', label: 'Shop All', url: '/shop', icon: '', openInNewTab: false, parentId: null, sortOrder: 1 },
      { id: 'fm-2', label: 'Categories', url: '/categories', icon: '', openInNewTab: false, parentId: null, sortOrder: 2 },
      { id: 'fm-3', label: 'Collections', url: '/collections', icon: '', openInNewTab: false, parentId: null, sortOrder: 3 },
      { id: 'fm-4', label: 'Best Sellers', url: '/shop?sort=top-rated', icon: '', openInNewTab: false, parentId: null, sortOrder: 4 },
      { id: 'fm-5', label: 'Become a Seller', url: '/become-a-seller', icon: '', openInNewTab: false, parentId: null, sortOrder: 5 },
    ],
  },
  {
    id: 'menu-footer-company', key: 'footer-company', name: 'Footer — Company', location: 'Footer',
    items: [
      { id: 'fc-1', label: 'About', url: '/about', icon: '', openInNewTab: false, parentId: null, sortOrder: 1 },
      { id: 'fc-2', label: 'Blog', url: '/blog', icon: '', openInNewTab: false, parentId: null, sortOrder: 2 },
      { id: 'fc-3', label: 'Contact', url: '/contact', icon: '', openInNewTab: false, parentId: null, sortOrder: 3 },
      { id: 'fc-4', label: 'Careers', url: '/contact', icon: '', openInNewTab: false, parentId: null, sortOrder: 4 },
      { id: 'fc-5', label: 'Affiliates', url: '/contact', icon: '', openInNewTab: false, parentId: null, sortOrder: 5 },
    ],
  },
  {
    id: 'menu-footer-support', key: 'footer-support', name: 'Footer — Support', location: 'Footer',
    items: [
      { id: 'fs-1', label: 'FAQ', url: '/faq', icon: '', openInNewTab: false, parentId: null, sortOrder: 1 },
      { id: 'fs-2', label: 'Licensing', url: '/terms', icon: '', openInNewTab: false, parentId: null, sortOrder: 2 },
      { id: 'fs-3', label: 'Wishlist', url: '/wishlist', icon: '', openInNewTab: false, parentId: null, sortOrder: 3 },
      { id: 'fs-4', label: 'Cart', url: '/cart', icon: '', openInNewTab: false, parentId: null, sortOrder: 4 },
      { id: 'fs-5', label: 'Help Center', url: '/contact', icon: '', openInNewTab: false, parentId: null, sortOrder: 5 },
    ],
  },
  {
    id: 'menu-footer-legal', key: 'footer-legal', name: 'Footer — Legal', location: 'Footer',
    items: [
      { id: 'fl-1', label: 'Privacy Policy', url: '/privacy', icon: '', openInNewTab: false, parentId: null, sortOrder: 1 },
      { id: 'fl-2', label: 'Terms & Conditions', url: '/terms', icon: '', openInNewTab: false, parentId: null, sortOrder: 2 },
      { id: 'fl-3', label: 'Refund Policy', url: '/refund-policy', icon: '', openInNewTab: false, parentId: null, sortOrder: 3 },
      { id: 'fl-4', label: 'Cookies', url: '/privacy', icon: '', openInNewTab: false, parentId: null, sortOrder: 4 },
      { id: 'fl-5', label: 'DMCA', url: '/terms', icon: '', openInNewTab: false, parentId: null, sortOrder: 5 },
    ],
  },
];

// Hero Slider — homepage hero carousel slides. Distinct from the
// Homepage CMS's single "hero" section entry: when the hero section is
// enabled, it rotates through these slides.
export const seedHeroSlides = [
  {
    id: 'slide-1', title: 'Digital assets for creators who ship', subtitle: 'Handpicked templates, mockups & fonts',
    description: 'Instant downloads from vetted independent creators worldwide.',
    backgroundImage: img.wall, buttonText: 'Explore the Shop', buttonUrl: '/shop', status: 'active', sortOrder: 1,
  },
  {
    id: 'slide-2', title: 'New: Botanical Illustration Collection', subtitle: 'Fresh from our top-rated sellers',
    description: 'Nature-inspired vectors, patterns, and prints.',
    backgroundImage: img.vector, buttonText: 'Shop the Collection', buttonUrl: '/shop?search=Nature', status: 'active', sortOrder: 2,
  },
  {
    id: 'slide-3', title: 'Summer Sale — Up to 40% Off', subtitle: 'Limited time on select bundles',
    description: '',
    backgroundImage: img.font, buttonText: 'Shop the Sale', buttonUrl: '/shop?search=sale', status: 'draft', sortOrder: 3,
  },
];

// Static Pages — the fixed legal/informational pages every marketplace
// needs. Content is plain text today (RichTextEditorPlaceholder — same
// component the Blog CMS uses), swapped for a real editor later with no
// change to this shape.
export const seedStaticPages = [
  { id: 'page-about', title: 'About Us', slug: 'about', content: 'PicaMarts connects independent digital artists with creators who need quality assets fast.', featuredImage: '', seoTitle: 'About Us | PicaMarts', metaDescription: 'Learn about PicaMarts, a marketplace for digital art and templates.', ogImage: '', status: 'published' },
  { id: 'page-contact', title: 'Contact', slug: 'contact', content: 'Reach out to our support team any time — we typically reply within one business day.', featuredImage: '', seoTitle: 'Contact Us | PicaMarts', metaDescription: 'Get in touch with the PicaMarts team.', ogImage: '', status: 'published' },
  { id: 'page-privacy', title: 'Privacy Policy', slug: 'privacy', content: 'This policy explains what information we collect and how we use it.', featuredImage: '', seoTitle: 'Privacy Policy | PicaMarts', metaDescription: 'Read the PicaMarts privacy policy.', ogImage: '', status: 'published' },
  { id: 'page-terms', title: 'Terms & Conditions', slug: 'terms', content: 'These terms govern your use of PicaMarts and the licenses attached to purchased products.', featuredImage: '', seoTitle: 'Terms & Conditions | PicaMarts', metaDescription: 'Read the PicaMarts terms and conditions.', ogImage: '', status: 'published' },
  { id: 'page-refund', title: 'Refund Policy', slug: 'refund-policy', content: 'Digital products are non-refundable once downloaded, with exceptions outlined below.', featuredImage: '', seoTitle: 'Refund Policy | PicaMarts', metaDescription: 'Read the PicaMarts refund policy for digital products.', ogImage: '', status: 'published' },
  { id: 'page-cookies', title: 'Cookie Policy', slug: 'cookie-policy', content: 'We use cookies to keep you signed in and to understand how the site is used.', featuredImage: '', seoTitle: 'Cookie Policy | PicaMarts', metaDescription: 'Learn how PicaMarts uses cookies.', ogImage: '', status: 'draft' },
  { id: 'page-license', title: 'License Policy', slug: 'license-policy', content: 'Every product on PicaMarts is sold under a Personal, Commercial, or Extended license — see what each allows.', featuredImage: '', seoTitle: 'License Policy | PicaMarts', metaDescription: 'Understand PicaMarts product licensing terms.', ogImage: '', status: 'published' },
  { id: 'page-shipping', title: 'Shipping Policy', slug: 'shipping-policy', content: 'Digital products deliver instantly. For the rare physical item, see delivery estimates below.', featuredImage: '', seoTitle: 'Shipping Policy | PicaMarts', metaDescription: 'Delivery details for digital and physical orders on PicaMarts.', ogImage: '', status: 'draft' },
];

// FAQ — grouped questions shown on the /faq storefront page.
export const seedFaqCategories = [
  { id: 'faqcat-orders', name: 'Orders & Downloads', slug: 'orders-downloads', sortOrder: 1 },
  { id: 'faqcat-licensing', name: 'Licensing', slug: 'licensing', sortOrder: 2 },
  { id: 'faqcat-sellers', name: 'Selling on PicaMarts', slug: 'selling', sortOrder: 3 },
  { id: 'faqcat-account', name: 'Account & Billing', slug: 'account-billing', sortOrder: 4 },
];

export const seedFaqs = [
  { id: 'faq-1', categoryId: 'faqcat-orders', question: 'When do I get access to my download?', answer: 'Immediately after payment confirms — from your Orders page or the confirmation email.', sortOrder: 1, status: 'published' },
  { id: 'faq-2', categoryId: 'faqcat-orders', question: 'Can I re-download a purchase later?', answer: 'Yes, every past purchase stays available from your account\u2019s Downloads tab.', sortOrder: 2, status: 'published' },
  { id: 'faq-3', categoryId: 'faqcat-licensing', question: 'What\u2019s the difference between Personal and Commercial licenses?', answer: 'Personal covers non-commercial personal use; Commercial allows use in client and for-profit work. See each product\u2019s license tab for specifics.', sortOrder: 1, status: 'published' },
  { id: 'faq-4', categoryId: 'faqcat-licensing', question: 'Can I resell a product I purchased?', answer: 'No — reselling or redistributing the source files themselves is not permitted under any license tier.', sortOrder: 2, status: 'published' },
  { id: 'faq-5', categoryId: 'faqcat-sellers', question: 'How do I become a seller?', answer: 'Apply from the Become a Seller page — approval typically takes 1-2 business days.', sortOrder: 1, status: 'published' },
  { id: 'faq-6', categoryId: 'faqcat-account', question: 'How do I update my billing details?', answer: 'Go to Account → Payment Methods to add or remove a card.', sortOrder: 1, status: 'draft' },
];

// Testimonials — customer quotes shown in the homepage testimonials
// section (and anywhere else it's reused).
export const seedTestimonials = [
  { id: 'test-1', customerName: 'Ava Thompson', photo: '', rating: 5, review: 'The license terms were crystal clear and the files were perfectly organized. Exactly what I needed for a client project.', status: 'published' },
  { id: 'test-2', customerName: 'Marco Ruiz', photo: '', rating: 5, review: 'Found a font pairing I now use across my whole brand. Instant download, no fuss.', status: 'published' },
  { id: 'test-3', customerName: 'Priya Nair', photo: '', rating: 4, review: 'Great selection of mockups — wish there were a few more color variants, but overall very happy.', status: 'published' },
  { id: 'test-4', customerName: 'Jonas Weber', photo: '', rating: 5, review: 'Support answered a licensing question within the hour. Will buy again.', status: 'draft' },
];

// Newsletter CMS — global appearance settings for the newsletter capture
// block wherever it's shown (homepage section, footer, popup). Homepage
// CMS and Footer CMS each control whether their own instance is enabled;
// this singleton owns the shared look-and-feel and the confirmation copy.
export const seedNewsletterCms = {
  backgroundImage: '',
  successMessage: "You're subscribed — thanks for joining!",
  disclaimerText: 'No spam. Unsubscribe any time.',
};

// Popup Manager — site-wide popups. Fixed set of 4 popup types (one per
// spec), each independently enabled/scheduled/delayed.
export const seedPopups = [
  {
    id: 'popup-newsletter', type: 'newsletter', label: 'Newsletter Popup', enabled: true,
    image: '', headline: 'Get 10% off your first order', content: 'Join our list for new drops, deals, and creator spotlights.',
    buttonText: 'Subscribe', buttonUrl: '', delaySeconds: 8, scheduleStart: '', scheduleEnd: '',
  },
  {
    id: 'popup-discount', type: 'discount', label: 'Discount Popup', enabled: false,
    image: '', headline: 'Flash Sale — 20% Off', content: 'Use code FLASH20 at checkout. Ends soon.',
    buttonText: 'Shop the Sale', buttonUrl: '/shop?search=sale', delaySeconds: 5, scheduleStart: '2026-08-01T00:00:00.000Z', scheduleEnd: '2026-08-07T00:00:00.000Z',
  },
  {
    id: 'popup-announcement', type: 'announcement', label: 'Announcement Popup', enabled: false,
    image: '', headline: "We've launched Collections!", content: 'Browse curated bundles picked by our team.',
    buttonText: 'Explore Collections', buttonUrl: '/collections', delaySeconds: 3, scheduleStart: '', scheduleEnd: '',
  },
  {
    id: 'popup-age', type: 'age_verification', label: 'Age Verification Popup', enabled: false,
    image: '', headline: 'Please confirm your age', content: 'Some content on PicaMarts may not be suitable for all ages.',
    buttonText: 'I am 18 or older', buttonUrl: '', delaySeconds: 0, scheduleStart: '', scheduleEnd: '',
  },
];

// SEO Manager — centralized SEO for page *types* that don't already have
// their own dedicated SEO fields elsewhere. Blog has its own defaults
// (see seedBlogSettings) and Static Pages each carry their own SEO block
// (see seedStaticPages), so those aren't duplicated here.
export const seedSeoEntries = [
  {
    id: 'seo-homepage', pageType: 'Homepage', metaTitle: 'PicaMarts — Digital Assets for Creators', metaDescription: 'Templates, mockups, fonts, and more from independent digital artists. Instant download, clear licensing.',
    keywords: 'digital assets, templates, mockups, fonts, marketplace', canonicalUrl: '/', ogTitle: '', ogDescription: '', ogImage: '', twitterCard: 'summary_large_image', twitterTitle: '', twitterDescription: '', twitterImage: '', schemaType: 'WebSite',
  },
  {
    id: 'seo-shop', pageType: 'Products (Shop)', metaTitle: 'Shop All Digital Products | PicaMarts', metaDescription: 'Browse the full PicaMarts catalog of digital templates, mockups, fonts, and design assets.',
    keywords: 'shop, digital products, templates', canonicalUrl: '/shop', ogTitle: '', ogDescription: '', ogImage: '', twitterCard: 'summary_large_image', twitterTitle: '', twitterDescription: '', twitterImage: '', schemaType: 'CollectionPage',
  },
  {
    id: 'seo-categories', pageType: 'Categories', metaTitle: 'Shop by Category | PicaMarts', metaDescription: 'Explore digital products organized by category.',
    keywords: 'categories, digital products', canonicalUrl: '/categories', ogTitle: '', ogDescription: '', ogImage: '', twitterCard: 'summary_large_image', twitterTitle: '', twitterDescription: '', twitterImage: '', schemaType: 'CollectionPage',
  },
  {
    id: 'seo-collections', pageType: 'Collections', metaTitle: 'Curated Collections | PicaMarts', metaDescription: 'Themed bundles of digital products, hand-picked by our team.',
    keywords: 'collections, bundles', canonicalUrl: '/collections', ogTitle: '', ogDescription: '', ogImage: '', twitterCard: 'summary_large_image', twitterTitle: '', twitterDescription: '', twitterImage: '', schemaType: 'CollectionPage',
  },
  {
    id: 'seo-seller-store', pageType: 'Seller Store', metaTitle: '{sellerName} — Seller on PicaMarts', metaDescription: "Shop {sellerName}'s digital products on PicaMarts.",
    keywords: 'seller, shop, digital products', canonicalUrl: '', ogTitle: '', ogDescription: '', ogImage: '', twitterCard: 'summary_large_image', twitterTitle: '', twitterDescription: '', twitterImage: '', schemaType: 'ProfilePage',
  },
];

// Email Templates — transactional/marketing emails. `body` is plain text
// today (same RichTextEditorPlaceholder pattern used elsewhere); `{tokens}`
// mark merge fields the future backend will substitute.
export const seedEmailTemplates = [
  { id: 'email-welcome', key: 'welcome', name: 'Welcome Email', subject: 'Welcome to PicaMarts, {customerName}!', body: "Hi {customerName},\n\nWelcome to PicaMarts — we're glad you're here. Start exploring templates, mockups, and fonts from independent creators.\n\nHappy shopping!", enabled: true },
  { id: 'email-order', key: 'order', name: 'Order Confirmation Email', subject: 'Your PicaMarts order {orderNumber} is confirmed', body: 'Hi {customerName},\n\nThanks for your order! Your download is ready in your account under Orders.\n\nOrder: {orderNumber}\nTotal: {orderTotal}', enabled: true },
  { id: 'email-refund', key: 'refund', name: 'Refund Email', subject: 'Your refund for order {orderNumber} has been processed', body: 'Hi {customerName},\n\nYour refund for order {orderNumber} has been processed and should appear in your account within 5-10 business days.', enabled: true },
  { id: 'email-seller-approval', key: 'seller_approval', name: 'Seller Approval Email', subject: "You're approved to sell on PicaMarts!", body: 'Hi {sellerName},\n\nCongratulations — your seller application has been approved. You can now list your first product from your Seller Dashboard.', enabled: true },
  { id: 'email-password-reset', key: 'password_reset', name: 'Password Reset Email', subject: 'Reset your PicaMarts password', body: 'Hi {customerName},\n\nClick the link below to reset your password. This link expires in 1 hour.\n\n{resetLink}', enabled: true },
  { id: 'email-newsletter', key: 'newsletter', name: 'Newsletter Email', subject: '{newsletterSubject}', body: 'Hi {customerName},\n\n{newsletterContent}', enabled: false },
];

// Global Settings — brand-level appearance and locale defaults. Distinct
// from the store-operational fields on the System → Settings page
// (store email/phone/address/tax), which stay as-is; this owns the
// visual identity fields the CMS spec calls for.
export const seedGlobalSettings = {
  siteName: 'PicaMarts',
  tagline: 'Digital assets for creators who ship',
  logo: '',
  favicon: '',
  primaryColor: '#7C3AED',
  secondaryColor: '#F97316',
  headingFont: 'Inter',
  bodyFont: 'Inter',
  timezone: 'America/Los_Angeles',
  language: 'en',
  currency: 'USD',
  measurementUnit: 'in',
};

// Social Settings — the storefront's own social profile links (distinct
// from Footer CMS's socialLinks, which are the icons rendered inline in
// the footer; this is the canonical per-platform URL list other
// components — e.g. a future "follow us" block or schema markup — read
// from, so a platform is entered once).
export const seedSocialSettings = {
  facebook: '', instagram: 'https://instagram.com/picamarts', youtube: '', tiktok: '', pinterest: '', linkedin: '', x: 'https://x.com/picamarts',
};

// Contact Settings — company/contact info shown on the Contact page and
// used for schema.org LocalBusiness/Organization markup later.
export const seedContactSettings = {
  companyName: 'PicaMarts Inc.',
  address: '123 Market Street, Suite 400, San Francisco, CA',
  phone: '+1 555-010-0000',
  email: 'hello@picamarts.com',
  whatsapp: '',
  googleMapsUrl: '',
  businessHours: [
    { id: 'bh-1', day: 'Monday – Friday', hours: '9:00 AM – 6:00 PM' },
    { id: 'bh-2', day: 'Saturday', hours: '10:00 AM – 4:00 PM' },
    { id: 'bh-3', day: 'Sunday', hours: 'Closed' },
  ],
};
