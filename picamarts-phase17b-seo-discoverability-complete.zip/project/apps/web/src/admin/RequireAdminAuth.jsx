import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAdminAuth } from './AdminAuthContext';
import { Spinner } from '../components/ui/spinner';

// Wraps the /admin routes — normal storefront users are bounced to
// /admin/login and sent back to where they were headed once they sign in.
// While the real session is still being restored (page reload /
// cookie-refresh check), this shows a brief loading state instead of
// prematurely redirecting a still-logged-in admin to the login page.
const RequireAdminAuth = ({ children }) => {
  const { isAuthenticated, authLoading } = useAdminAuth();
  const location = useLocation();

  if (authLoading) {
    return (
      <div className="min-h-screen grid place-items-center">
        <Spinner />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/admin/login" replace state={{ from: location }} />;
  }
  return children;
};

export default RequireAdminAuth;
