import {
  LayoutDashboard, Package, FolderTree, Layers, Tag, Boxes, ShoppingCart,
  Store, TicketPercent, Star, Image as ImageIcon,
  Settings as SettingsIcon, ShieldCheck, BarChart3, Newspaper, FileText,
  FilePlus2, FolderOpen, Tags, LayoutTemplate, FileStack,
  Mail, Bell, Truck, Download, MessageCircle, Wallet, Percent, Send,
  Undo2, RotateCcw, Gavel,
} from 'lucide-react';

export const adminNavSections = [
  {
    items: [
      { label: 'Dashboard', to: '/admin', icon: LayoutDashboard, end: true },
      { label: 'Analytics', to: '/admin/analytics', icon: BarChart3 },
    ],
  },
  {
    label: 'Catalog',
    items: [
      { label: 'Products', to: '/admin/products', icon: Package },
      { label: 'Categories', to: '/admin/categories', icon: FolderTree },
      { label: 'Collections', to: '/admin/collections', icon: Layers },
      { label: 'Brands', to: '/admin/brands', icon: Tag },
      { label: 'Inventory', to: '/admin/inventory', icon: Boxes },
    ],
  },
  {
    label: 'Sales',
    items: [
      { label: 'Orders', to: '/admin/orders', icon: ShoppingCart },
      { label: 'Shipping', to: '/admin/shipping', icon: Truck },
      { label: 'Digital Delivery', to: '/admin/digital-delivery', icon: Download },
      { label: 'Sellers', to: '/admin/sellers', icon: Store },
      { label: 'Coupons', to: '/admin/coupons', icon: TicketPercent },
    ],
  },
  {
    label: 'Finance',
    items: [
      { label: 'Finance Dashboard', to: '/admin/finance', icon: Wallet },
      { label: 'Payout Queue', to: '/admin/finance/payouts', icon: Send },
      { label: 'Refund Queue', to: '/admin/finance/refunds', icon: Undo2 },
      { label: 'Return Queue', to: '/admin/finance/returns', icon: RotateCcw },
      { label: 'Dispute Queue', to: '/admin/finance/disputes', icon: Gavel },
      { label: 'Commission Settings', to: '/admin/finance/commission', icon: Percent },
    ],
  },
  {
    label: 'Content',
    items: [
      { label: 'Reviews', to: '/admin/reviews', icon: Star },
      { label: 'Media Library', to: '/admin/media', icon: ImageIcon },
      {
        label: 'Blog', icon: Newspaper, to: '/admin/blog',
        children: [
          { label: 'All Posts', to: '/admin/blog', icon: FileText, end: true },
          { label: 'Add New Post', to: '/admin/blog/new', icon: FilePlus2 },
          { label: 'Categories', to: '/admin/blog/categories', icon: FolderOpen },
          { label: 'Tags', to: '/admin/blog/tags', icon: Tags },
        ],
      },
    ],
  },
  {
    label: 'CMS',
    items: [
      // Homepage's editor covers hero banner, featured categories/
      // products, promotional banners, testimonials, FAQ, footer
      // (incl. social links + contact info), and homepage SEO — all
      // one real HomepageConfig singleton document, see HomepageCms.jsx.
      { label: 'Homepage', to: '/admin/cms/homepage', icon: LayoutTemplate },
      { label: 'Static Pages', to: '/admin/cms/pages', icon: FileStack },
      { label: 'Contact Messages', to: '/admin/cms/contact-messages', icon: MessageCircle },
      { label: 'Newsletter', to: '/admin/cms/newsletter', icon: Mail },
    ],
  },
  {
    label: 'System',
    items: [
      { label: 'Settings', to: '/admin/settings', icon: SettingsIcon },
      { label: 'User Management', to: '/admin/users', icon: ShieldCheck },
      { label: 'Notifications', to: '/admin/notifications', icon: Bell },
    ],
  },
];
