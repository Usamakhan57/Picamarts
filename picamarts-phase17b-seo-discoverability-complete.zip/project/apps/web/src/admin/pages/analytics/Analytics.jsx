import React, { useEffect, useMemo, useState } from 'react';
import {
  ResponsiveContainer, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, CartesianGrid, Legend, LineChart, Line,
} from 'recharts';
import {
  DollarSign, ShoppingCart, Users, Store, Package, Star, Download, CreditCard, RefreshCcw, Tag, Award, Search as SearchIcon,
} from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import StatCard from '../../components/StatCard';
import EmptyState from '../../components/EmptyState';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../../../components/ui/select';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../../../components/ui/tabs';
import {
  getDashboard, getSales, getOrderAnalytics, getRevenue, getProductAnalytics,
  getSellerAnalytics, getCustomerAnalytics, getPaymentAnalytics, getReviewAnalytics, exportReport,
  getCategoryAnalytics, getBrandAnalytics, getSearchAnalytics,
} from '../../../services/analyticsService';
import { getErrorMessage } from '../../../lib/errorMessage';
import { useToast } from '../../../hooks/use-toast';

/**
 * Phase 15C, Part 10 — Reports & Analytics. Fully real: every widget below
 * is backed by the actual Phase 11 `/analytics/*` endpoints (see
 * apps/api/src/{routes,controllers,services,repositories}/analytics.*) —
 * nothing here reads from apps/web/src/admin/api/{orders,products,
 * categories,customers}.js, which is why those mock modules can now be
 * deleted (see Part 13 cleanup notes in the delivery summary).
 *
 * Layout: one stat-card overview up top (real /analytics/dashboard,
 * platform-wide since this page always runs as an admin), then a tab per
 * report family, matching the nine JSON endpoints the backend actually
 * exposes. Every tab that has a matching `report=` value on
 * /analytics/export gets its own Export button (CSV/XLSX/PDF) via the new
 * `exportReport()` wrapper in services/analyticsService.js.
 */

const COLORS = ['#6C3BFF', '#FF7A59', '#22C55E', '#F59E0B', '#3B82F6', '#EC4899', '#14B8A6', '#A855F7'];
const STATUS_COLORS = {
  pending: '#F59E0B', confirmed: '#3B82F6', processing: '#6366F1', packed: '#8B5CF6',
  shipped: '#06B6D4', delivered: '#10B981', completed: '#10B981', cancelled: '#EF4444',
  refunded: '#F97316', returned: '#F97316', refund_requested: '#F97316',
};

const fmtMoney = (n) => `$${Number(n || 0).toFixed(2)}`;
const fmtDate = (iso) => (iso ? new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) : '—');
const titleCase = (s = '') => s.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());

const PERIODS = ['daily', 'weekly', 'monthly', 'yearly'];

/** Small shared control row: period selector + CSV/XLSX/PDF export for the given report. */
const ReportToolbar = ({ period, onPeriodChange, report, filters, showPeriod = true }) => {
  const { toast } = useToast();
  const [exporting, setExporting] = useState('');

  const handleExport = async (format) => {
    setExporting(format);
    try {
      await exportReport({ report, format, ...filters });
    } catch (err) {
      toast({ title: 'Export failed', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setExporting('');
    }
  };

  return (
    <div className="flex flex-wrap items-center gap-2 mb-4">
      {showPeriod && (
        <Select value={period} onValueChange={onPeriodChange}>
          <SelectTrigger className="w-[140px] rounded-full text-sm"><SelectValue /></SelectTrigger>
          <SelectContent>
            {PERIODS.map((p) => <SelectItem key={p} value={p}>{titleCase(p)}</SelectItem>)}
          </SelectContent>
        </Select>
      )}
      <div className="flex-1" />
      {['csv', 'xlsx', 'pdf'].map((format) => (
        <button
          key={format}
          type="button"
          onClick={() => handleExport(format)}
          disabled={exporting !== ''}
          className="inline-flex items-center gap-1.5 text-xs font-semibold border border-border rounded-full px-3 py-1.5 bg-white hover:bg-secondary disabled:opacity-50"
        >
          <Download className="w-3.5 h-3.5" />
          {exporting === format ? 'Exporting…' : format.toUpperCase()}
        </button>
      ))}
    </div>
  );
};

const ChartCard = ({ title, height = 260, children }) => (
  <div className="bg-white rounded-2xl border border-border p-5 soft-shadow">
    <h2 className="font-semibold mb-4">{title}</h2>
    <div style={{ height }}>{children}</div>
  </div>
);

// ------------------------------------------------------------------
// Overview tab — /analytics/dashboard
// ------------------------------------------------------------------
const OverviewTab = () => {
  const [data, setData] = useState(null);
  const [salesSeries, setSalesSeries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    setError('');
    Promise.all([getDashboard(), getSales({ period: 'monthly' })])
      .then(([dash, sales]) => { setData(dash); setSalesSeries(sales.series || []); })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p className="text-sm text-muted-foreground py-12 text-center">Loading overview…</p>;
  if (error) return <EmptyState icon={RefreshCcw} title="Couldn't load the dashboard" description={error} />;

  return (
    <div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Total Revenue" value={fmtMoney(data?.revenue?.total)} icon={DollarSign} />
        <StatCard label="Revenue (30d)" value={fmtMoney(data?.revenue?.month)} icon={DollarSign} />
        <StatCard label="Total Orders" value={data?.orders?.total ?? 0} icon={ShoppingCart} />
        <StatCard label="Active Products" value={data?.products?.active ?? 0} icon={Package} />
        {data?.customers && <StatCard label="Customers" value={data.customers.total} icon={Users} />}
        {data?.sellers && <StatCard label="Sellers" value={data.sellers.total} icon={Store} />}
        {data?.sellers && <StatCard label="Pending Sellers" value={data.sellers.pending} icon={Store} />}
        <StatCard label="Out of Stock" value={data?.products?.outOfStock ?? 0} icon={Package} />
      </div>
      <ChartCard title="Revenue Trend (monthly)">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={salesSeries} margin={{ left: -20 }}>
            <defs>
              <linearGradient id="overviewRevFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#6C3BFF" stopOpacity={0.35} />
                <stop offset="100%" stopColor="#6C3BFF" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#EEE" />
            <XAxis dataKey="label" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
            <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
            <Tooltip formatter={(v, name) => [name === 'revenue' ? fmtMoney(v) : v, titleCase(name)]} />
            <Area type="monotone" dataKey="revenue" stroke="#6C3BFF" strokeWidth={2} fill="url(#overviewRevFill)" />
          </AreaChart>
        </ResponsiveContainer>
      </ChartCard>
    </div>
  );
};

// ------------------------------------------------------------------
// Sales tab — /analytics/sales
// ------------------------------------------------------------------
const SalesTab = () => {
  const [period, setPeriod] = useState('monthly');
  const [series, setSeries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    setError('');
    getSales({ period }).then((res) => setSeries(res.series || []))
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, [period]);

  return (
    <div>
      <ReportToolbar period={period} onPeriodChange={setPeriod} report="sales" filters={{ period }} />
      {loading ? <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p> : error ? (
        <EmptyState icon={RefreshCcw} title="Couldn't load sales" description={error} />
      ) : (
        <ChartCard title="Revenue &amp; Orders" height={320}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={series}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#EEE" />
              <XAxis dataKey="label" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
              <YAxis yAxisId="left" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
              <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
              <Tooltip formatter={(v, name) => [name === 'revenue' ? fmtMoney(v) : v, titleCase(name)]} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar yAxisId="left" dataKey="revenue" fill="#6C3BFF" radius={[6, 6, 0, 0]} />
              <Bar yAxisId="right" dataKey="orders" fill="#10B981" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      )}
    </div>
  );
};

// ------------------------------------------------------------------
// Orders tab — /analytics/orders
// ------------------------------------------------------------------
const OrdersTab = () => {
  const [period, setPeriod] = useState('monthly');
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    setError('');
    getOrderAnalytics({ period }).then(setData)
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, [period]);

  const byStatus = useMemo(() => {
    if (!data) return [];
    const { byStatus: counts } = data;
    return Object.entries(counts || {}).filter(([k]) => k !== 'total').map(([status, count]) => ({ status, count }));
  }, [data]);

  if (loading) return <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>;

  return (
    <div>
      <ReportToolbar period={period} onPeriodChange={setPeriod} report="orders" filters={{ period }} />
      {error ? <EmptyState icon={RefreshCcw} title="Couldn't load orders" description={error} /> : (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
            <StatCard label="Avg. Order Value" value={fmtMoney(data.averageOrderValue)} icon={DollarSign} />
            <StatCard label="Cancelled Orders" value={data.cancelledOrders ?? 0} icon={ShoppingCart} />
            <StatCard label="Refund Rate" value={`${data.refundRate ?? 0}%`} icon={RefreshCcw} />
          </div>
          <div className="grid lg:grid-cols-2 gap-4">
            <ChartCard title="Orders Over Time">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={data.byDate || []}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#EEE" />
                  <XAxis dataKey="label" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                  <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                  <Tooltip />
                  <Line type="monotone" dataKey="count" stroke="#6C3BFF" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </ChartCard>
            <ChartCard title="Orders by Status">
              {byStatus.every((s) => s.count === 0) ? (
                <p className="text-sm text-muted-foreground">No orders yet.</p>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={byStatus} dataKey="count" nameKey="status" cx="50%" cy="50%" innerRadius={45} outerRadius={75} paddingAngle={2}>
                      {byStatus.map((entry) => <Cell key={entry.status} fill={STATUS_COLORS[entry.status] || '#94A3B8'} />)}
                    </Pie>
                    <Tooltip formatter={(v, n) => [v, titleCase(n)]} />
                    <Legend wrapperStyle={{ fontSize: 10 }} formatter={(v) => titleCase(v)} />
                  </PieChart>
                </ResponsiveContainer>
              )}
            </ChartCard>
          </div>
        </>
      )}
    </div>
  );
};

// ------------------------------------------------------------------
// Revenue tab — /analytics/revenue (groupBy: trend|category|seller|product|payment_method)
// ------------------------------------------------------------------
const REVENUE_GROUPINGS = [
  { value: 'trend', label: 'Trend' },
  { value: 'category', label: 'By Category' },
  { value: 'product', label: 'By Product' },
  { value: 'seller', label: 'By Seller' },
  { value: 'payment_method', label: 'By Payment Method' },
];

const RevenueTab = () => {
  const [groupBy, setGroupBy] = useState('trend');
  const [period, setPeriod] = useState('monthly');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    setError('');
    getRevenue({ groupBy, period }).then(setResult)
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, [groupBy, period]);

  const breakdown = result?.breakdown || [];
  const nameKey = groupBy === 'category' ? 'category' : groupBy === 'seller' ? 'sellerName' : groupBy === 'product' ? 'title' : 'paymentMethod';

  return (
    <div>
      <div className="flex flex-wrap items-center gap-2 mb-4">
        <Select value={groupBy} onValueChange={setGroupBy}>
          <SelectTrigger className="w-[190px] rounded-full text-sm"><SelectValue /></SelectTrigger>
          <SelectContent>
            {REVENUE_GROUPINGS.map((g) => <SelectItem key={g.value} value={g.value}>{g.label}</SelectItem>)}
          </SelectContent>
        </Select>
        <ReportToolbar
          period={period}
          onPeriodChange={setPeriod}
          report="revenue"
          filters={{ groupBy, period }}
          showPeriod={groupBy === 'trend'}
        />
      </div>
      {loading ? <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p> : error ? (
        <EmptyState icon={RefreshCcw} title="Couldn't load revenue" description={error} />
      ) : groupBy === 'trend' ? (
        <ChartCard title="Revenue Trend" height={320}>
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={result?.series || []} margin={{ left: -20 }}>
              <defs>
                <linearGradient id="revTrendFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#6C3BFF" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="#6C3BFF" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#EEE" />
              <XAxis dataKey="label" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
              <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
              <Tooltip formatter={(v) => [fmtMoney(v), 'Revenue']} />
              <Area type="monotone" dataKey="revenue" stroke="#6C3BFF" strokeWidth={2} fill="url(#revTrendFill)" />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>
      ) : breakdown.length === 0 ? (
        <EmptyState icon={DollarSign} title="No revenue data yet" description="Once paid orders exist for this grouping, they'll show up here." />
      ) : (
        <ChartCard title={`Revenue ${REVENUE_GROUPINGS.find((g) => g.value === groupBy)?.label}`} height={Math.max(280, breakdown.length * 34)}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={breakdown} layout="vertical" margin={{ left: 40 }}>
              <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#EEE" />
              <XAxis type="number" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
              <YAxis type="category" dataKey={nameKey} tick={{ fontSize: 11 }} tickLine={false} axisLine={false} width={140} />
              <Tooltip formatter={(v) => [fmtMoney(v), 'Revenue']} />
              <Bar dataKey="revenue" fill="#6C3BFF" radius={[0, 6, 6, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      )}
    </div>
  );
};

// ------------------------------------------------------------------
// Products tab — /analytics/products (type: best_selling|most_viewed|highest_rated|low_stock|out_of_stock)
// ------------------------------------------------------------------
const PRODUCT_TYPES = [
  { value: 'best_selling', label: 'Best Selling' },
  { value: 'most_viewed', label: 'Most Viewed' },
  { value: 'highest_rated', label: 'Highest Rated' },
  { value: 'low_stock', label: 'Low Stock' },
  { value: 'out_of_stock', label: 'Out of Stock' },
  // Phase 17A.2 — most-wishlisted, across every buyer's every wishlist.
  { value: 'most_wishlisted', label: 'Most Wishlisted' },
];

const ProductsTab = () => {
  const [type, setType] = useState('best_selling');
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    setError('');
    getProductAnalytics({ type, limit: 15 }).then((res) => setItems(res.items || []))
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, [type]);

  const metricKey = { best_selling: 'salesCount', most_viewed: 'views', highest_rated: 'ratingAverage', low_stock: 'stock', out_of_stock: 'stock', most_wishlisted: 'wishlistCount' }[type];
  const metricLabel = { best_selling: 'Sold', most_viewed: 'Views', highest_rated: 'Rating', low_stock: 'In Stock', out_of_stock: 'In Stock', most_wishlisted: 'Wishlisted' }[type];

  return (
    <div>
      <div className="flex flex-wrap items-center gap-2 mb-4">
        <Select value={type} onValueChange={setType}>
          <SelectTrigger className="w-[170px] rounded-full text-sm"><SelectValue /></SelectTrigger>
          <SelectContent>
            {PRODUCT_TYPES.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
          </SelectContent>
        </Select>
        <ReportToolbar report="products" filters={{ type }} showPeriod={false} />
      </div>
      {loading ? <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p> : error ? (
        <EmptyState icon={RefreshCcw} title="Couldn't load products" description={error} />
      ) : items.length === 0 ? (
        <EmptyState icon={Package} title="No products in this view" description="Try a different report type." />
      ) : (
        <div className="bg-white rounded-2xl border border-border soft-shadow divide-y divide-border">
          {items.map((p) => (
            <div key={p.productId} className="flex items-center gap-3 px-5 py-3">
              <span className="w-9 h-9 rounded-lg bg-secondary grid place-items-center text-muted-foreground shrink-0"><Package className="w-4 h-4" /></span>
              <p className="flex-1 min-w-0 text-sm font-medium truncate">{p.title}</p>
              <span className="text-xs font-semibold text-muted-foreground shrink-0">
                {type === 'highest_rated' ? `${Number(p[metricKey] || 0).toFixed(1)} ★ (${p.ratingCount})` : `${(p[metricKey] ?? 0).toLocaleString()} ${metricLabel}`}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// ------------------------------------------------------------------
// Sellers tab (admin only) — /analytics/sellers
// ------------------------------------------------------------------
const SellersTab = () => {
  const [period, setPeriod] = useState('monthly');
  const [sellers, setSellers] = useState([]);
  const [growth, setGrowth] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    setError('');
    getSellerAnalytics({ period, limit: 15 }).then((res) => { setSellers(res.sellers || []); setGrowth(res.growth || []); })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, [period]);

  if (loading) return <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>;
  if (error) return <EmptyState icon={RefreshCcw} title="Couldn't load sellers" description={error} />;

  return (
    <div>
      <ReportToolbar period={period} onPeriodChange={setPeriod} report="sellers" filters={{ period }} />
      <ChartCard title="New Approved Sellers" height={220}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={growth}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#EEE" />
            <XAxis dataKey="label" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
            <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} allowDecimals={false} />
            <Tooltip />
            <Bar dataKey="count" fill="#6C3BFF" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>
      <div className="bg-white rounded-2xl border border-border soft-shadow mt-4 overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-muted-foreground border-b border-border">
              <th className="px-5 py-3 font-medium">Store</th>
              <th className="px-5 py-3 font-medium">Status</th>
              <th className="px-5 py-3 font-medium">Revenue</th>
              <th className="px-5 py-3 font-medium">Orders</th>
              <th className="px-5 py-3 font-medium">Units Sold</th>
              <th className="px-5 py-3 font-medium">Products</th>
              <th className="px-5 py-3 font-medium">Rating</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {sellers.length === 0 ? (
              <tr><td colSpan={7} className="px-5 py-8 text-center text-muted-foreground">No sellers yet.</td></tr>
            ) : sellers.map((s) => (
              <tr key={s.sellerId}>
                <td className="px-5 py-3 font-medium">{s.storeName}</td>
                <td className="px-5 py-3 text-muted-foreground">{titleCase(s.status)}</td>
                <td className="px-5 py-3">{fmtMoney(s.revenue)}</td>
                <td className="px-5 py-3">{s.orderCount}</td>
                <td className="px-5 py-3">{s.unitsSold}</td>
                <td className="px-5 py-3">{s.productCount}</td>
                <td className="px-5 py-3">{s.averageRating ? `${s.averageRating} ★` : '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ------------------------------------------------------------------
// Customers tab (admin only) — /analytics/customers
// ------------------------------------------------------------------
const CustomersTab = () => {
  const [period, setPeriod] = useState('monthly');
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    setError('');
    getCustomerAnalytics({ period, limit: 15 }).then(setData)
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, [period]);

  if (loading) return <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>;
  if (error) return <EmptyState icon={RefreshCcw} title="Couldn't load customers" description={error} />;

  const split = [
    { name: 'Returning', value: data.returningCustomers || 0 },
    { name: 'One-time', value: data.oneTimeCustomers || 0 },
  ];

  return (
    <div>
      <ReportToolbar period={period} onPeriodChange={setPeriod} report="customers" filters={{ period }} />
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        <StatCard label="Returning Customers" value={data.returningCustomers ?? 0} icon={Users} />
        <StatCard label="One-time Customers" value={data.oneTimeCustomers ?? 0} icon={Users} />
        <StatCard label="Avg. Purchase Frequency" value={data.averagePurchaseFrequency ?? 0} icon={RefreshCcw} />
      </div>
      <div className="grid lg:grid-cols-3 gap-4">
        <ChartCard title="New Customers">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data.newCustomers || []}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#EEE" />
              <XAxis dataKey="label" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
              <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} allowDecimals={false} />
              <Tooltip />
              <Line type="monotone" dataKey="count" stroke="#6C3BFF" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>
        <ChartCard title="Returning vs One-time">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={split} dataKey="value" nameKey="name" innerRadius={45} outerRadius={75} paddingAngle={2}>
                {split.map((_, i) => <Cell key={i} fill={COLORS[i]} />)}
              </Pie>
              <Tooltip />
              <Legend wrapperStyle={{ fontSize: 11 }} />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>
        <div className="bg-white rounded-2xl border border-border p-5 soft-shadow lg:col-span-1">
          <h2 className="font-semibold mb-3">Top Buyers</h2>
          <ul className="divide-y divide-border max-h-64 overflow-y-auto">
            {(data.topBuyers || []).length === 0 ? (
              <p className="text-sm text-muted-foreground">No buyers yet.</p>
            ) : data.topBuyers.map((b) => (
              <li key={b.buyerId} className="py-2 flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate">{b.name}</p>
                  <p className="text-xs text-muted-foreground truncate">{b.email}</p>
                </div>
                <span className="text-xs font-semibold shrink-0">{fmtMoney(b.lifetimeValue)}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

// ------------------------------------------------------------------
// Payments tab (admin only) — /analytics/payments
// ------------------------------------------------------------------
const PaymentsTab = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    setError('');
    getPaymentAnalytics().then(setData)
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>;
  if (error) return <EmptyState icon={RefreshCcw} title="Couldn't load payments" description={error} />;

  const pieData = [
    { name: 'Successful', value: data.successfulPayments || 0 },
    { name: 'Failed', value: data.failedPayments || 0 },
    { name: 'Pending', value: data.pendingPayments || 0 },
  ];

  return (
    <div>
      <ReportToolbar report="payments" filters={{}} showPeriod={false} />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Successful Payments" value={data.successfulPayments ?? 0} icon={CreditCard} />
        <StatCard label="Failed Payments" value={data.failedPayments ?? 0} icon={CreditCard} />
        <StatCard label="Refund Amount" value={fmtMoney(data.refundAmount)} icon={RefreshCcw} trendLabel={`${data.refundCount ?? 0} refunds`} />
        <StatCard label="Stripe Revenue" value={fmtMoney(data.stripeRevenue)} icon={DollarSign} />
      </div>
      <ChartCard title="Payment Outcomes" height={240}>
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie data={pieData} dataKey="value" nameKey="name" innerRadius={45} outerRadius={75} paddingAngle={2}>
              {pieData.map((_, i) => <Cell key={i} fill={COLORS[i]} />)}
            </Pie>
            <Tooltip />
            <Legend wrapperStyle={{ fontSize: 11 }} />
          </PieChart>
        </ResponsiveContainer>
      </ChartCard>
    </div>
  );
};

// ------------------------------------------------------------------
// Reviews tab — /analytics/reviews
// ------------------------------------------------------------------
const ReviewsTab = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    setError('');
    getReviewAnalytics().then(setData)
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>;
  if (error) return <EmptyState icon={RefreshCcw} title="Couldn't load reviews" description={error} />;

  const distribution = [5, 4, 3, 2, 1].map((star) => ({ star: `${star} ★`, count: data.distribution?.[star] ?? 0 }));

  return (
    <div>
      <ReportToolbar report="reviews" filters={{}} showPeriod={false} />
      <div className="grid grid-cols-2 gap-4 mb-6">
        <StatCard label="Average Rating" value={`${data.averageRating ?? 0} ★`} icon={Star} />
        <StatCard label="Total Reviews" value={data.totalReviews ?? 0} icon={Star} />
      </div>
      <div className="grid lg:grid-cols-2 gap-4">
        <ChartCard title="Rating Distribution">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={distribution} layout="vertical" margin={{ left: 10 }}>
              <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#EEE" />
              <XAxis type="number" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} allowDecimals={false} />
              <YAxis type="category" dataKey="star" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} width={40} />
              <Tooltip />
              <Bar dataKey="count" fill="#F59E0B" radius={[0, 6, 6, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
        <div className="bg-white rounded-2xl border border-border p-5 soft-shadow">
          <h2 className="font-semibold mb-3">Most Reviewed Products</h2>
          <ul className="divide-y divide-border max-h-64 overflow-y-auto">
            {(data.mostReviewedProducts || []).length === 0 ? (
              <p className="text-sm text-muted-foreground">No reviews yet.</p>
            ) : data.mostReviewedProducts.map((p) => (
              <li key={p.productId} className="py-2 flex items-center justify-between gap-2">
                <p className="text-sm font-medium truncate min-w-0">{p.title}</p>
                <span className="text-xs font-semibold text-muted-foreground shrink-0">{p.reviewCount} reviews · {p.averageRating} ★</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

const WINDOW_OPTIONS = [
  { value: '7', label: 'Last 7 days' },
  { value: '30', label: 'Last 30 days' },
  { value: '90', label: 'Last 90 days' },
];

// ------------------------------------------------------------------
// Categories tab — /analytics/categories (Phase 17A.2)
// ------------------------------------------------------------------
const CategoriesTab = () => {
  const [windowDays, setWindowDays] = useState('30');
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    setError('');
    getCategoryAnalytics({ windowDays: Number(windowDays), limit: 10 }).then(setData)
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, [windowDays]);

  if (loading) return <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>;
  if (error) return <EmptyState icon={RefreshCcw} title="Couldn't load category analytics" description={error} />;

  const categories = data?.categories || [];

  return (
    <div>
      <div className="flex flex-wrap items-center gap-2 mb-4">
        <Select value={windowDays} onValueChange={setWindowDays}>
          <SelectTrigger className="w-[160px] rounded-full text-sm"><SelectValue /></SelectTrigger>
          <SelectContent>
            {WINDOW_OPTIONS.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      {categories.length === 0 ? (
        <EmptyState icon={Tag} title="No trending categories yet" description="Category activity will appear here as products get views and sales." />
      ) : (
        <div className="grid lg:grid-cols-2 gap-4">
          <ChartCard title="Views by Category">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={categories} layout="vertical" margin={{ left: 10 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#EEE" />
                <XAxis type="number" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} allowDecimals={false} />
                <YAxis type="category" dataKey="category" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} width={100} />
                <Tooltip />
                <Bar dataKey="views" fill="#6C3BFF" radius={[0, 6, 6, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
          <div className="bg-white rounded-2xl border border-border soft-shadow divide-y divide-border">
            {categories.map((c) => (
              <div key={c.categoryId || c.category} className="flex items-center gap-3 px-5 py-3">
                <span className="w-9 h-9 rounded-lg bg-secondary grid place-items-center text-muted-foreground shrink-0"><Tag className="w-4 h-4" /></span>
                <p className="flex-1 min-w-0 text-sm font-medium truncate">{c.category}</p>
                <span className="text-xs font-semibold text-muted-foreground shrink-0">{c.productCount} products · {c.salesCount} sold</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

// ------------------------------------------------------------------
// Brands tab — /analytics/brands (Phase 17A.2)
// ------------------------------------------------------------------
const BrandsTab = () => {
  const [windowDays, setWindowDays] = useState('30');
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    setError('');
    getBrandAnalytics({ windowDays: Number(windowDays), limit: 10 }).then(setData)
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, [windowDays]);

  if (loading) return <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>;
  if (error) return <EmptyState icon={RefreshCcw} title="Couldn't load brand analytics" description={error} />;

  const brands = data?.brands || [];

  return (
    <div>
      <div className="flex flex-wrap items-center gap-2 mb-4">
        <Select value={windowDays} onValueChange={setWindowDays}>
          <SelectTrigger className="w-[160px] rounded-full text-sm"><SelectValue /></SelectTrigger>
          <SelectContent>
            {WINDOW_OPTIONS.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      {brands.length === 0 ? (
        <EmptyState icon={Award} title="No trending brands yet" description="Brand activity will appear here as products get views and sales." />
      ) : (
        <div className="grid lg:grid-cols-2 gap-4">
          <ChartCard title="Views by Brand">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={brands} layout="vertical" margin={{ left: 10 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#EEE" />
                <XAxis type="number" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} allowDecimals={false} />
                <YAxis type="category" dataKey="brand" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} width={100} />
                <Tooltip />
                <Bar dataKey="views" fill="#FF7A59" radius={[0, 6, 6, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
          <div className="bg-white rounded-2xl border border-border soft-shadow divide-y divide-border">
            {brands.map((b) => (
              <div key={b.brandId || b.brand} className="flex items-center gap-3 px-5 py-3">
                <span className="w-9 h-9 rounded-lg bg-secondary grid place-items-center text-muted-foreground shrink-0"><Award className="w-4 h-4" /></span>
                <p className="flex-1 min-w-0 text-sm font-medium truncate">{b.brand}</p>
                <span className="text-xs font-semibold text-muted-foreground shrink-0">{b.productCount} products · {b.salesCount} sold</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

// ------------------------------------------------------------------
// Search tab (admin only) — /analytics/search (Phase 17A.2)
// ------------------------------------------------------------------
const SearchTab = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    setError('');
    getSearchAnalytics({ limit: 20 }).then(setData)
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>;
  if (error) return <EmptyState icon={RefreshCcw} title="Couldn't load search analytics" description={error} />;

  const terms = data?.terms || [];

  return terms.length === 0 ? (
    <EmptyState icon={SearchIcon} title="No searches recorded yet" description="Buyers' search terms will show up here once they start searching." />
  ) : (
    <div className="bg-white rounded-2xl border border-border soft-shadow divide-y divide-border">
      {terms.map((t) => (
        <div key={t.term} className="flex items-center gap-3 px-5 py-3">
          <span className="w-9 h-9 rounded-lg bg-secondary grid place-items-center text-muted-foreground shrink-0"><SearchIcon className="w-4 h-4" /></span>
          <p className="flex-1 min-w-0 text-sm font-medium truncate">{t.term}</p>
          <span className="text-xs font-semibold text-muted-foreground shrink-0">{t.searchCount} searches · last {fmtDate(t.lastSearchedAt)}</span>
        </div>
      ))}
    </div>
  );
};

const Analytics = () => (
  <div>
    <PageHeader title="Reports &amp; Analytics" description="Real-time store performance across sales, products, sellers, customers, payments, and reviews." />
    <OverviewTab />
    <div className="mt-6">
      <Tabs defaultValue="sales">
        <TabsList className="flex-wrap h-auto">
          <TabsTrigger value="sales">Sales</TabsTrigger>
          <TabsTrigger value="orders">Orders</TabsTrigger>
          <TabsTrigger value="revenue">Revenue</TabsTrigger>
          <TabsTrigger value="products">Products</TabsTrigger>
          <TabsTrigger value="categories">Categories</TabsTrigger>
          <TabsTrigger value="brands">Brands</TabsTrigger>
          <TabsTrigger value="sellers">Sellers</TabsTrigger>
          <TabsTrigger value="customers">Customers</TabsTrigger>
          <TabsTrigger value="payments">Payments</TabsTrigger>
          <TabsTrigger value="reviews">Reviews</TabsTrigger>
          <TabsTrigger value="search">Search</TabsTrigger>
        </TabsList>
        <TabsContent value="sales"><SalesTab /></TabsContent>
        <TabsContent value="orders"><OrdersTab /></TabsContent>
        <TabsContent value="revenue"><RevenueTab /></TabsContent>
        <TabsContent value="products"><ProductsTab /></TabsContent>
        <TabsContent value="categories"><CategoriesTab /></TabsContent>
        <TabsContent value="brands"><BrandsTab /></TabsContent>
        <TabsContent value="sellers"><SellersTab /></TabsContent>
        <TabsContent value="customers"><CustomersTab /></TabsContent>
        <TabsContent value="payments"><PaymentsTab /></TabsContent>
        <TabsContent value="reviews"><ReviewsTab /></TabsContent>
        <TabsContent value="search"><SearchTab /></TabsContent>
      </Tabs>
    </div>
  </div>
);

export default Analytics;
