import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  DollarSign, ShoppingCart, Users, Package, Store, Truck, Download, Star, Clock,
} from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import PageHeader from '../../components/PageHeader';
import StatCard from '../../components/StatCard';
import StatusBadge from '../../components/StatusBadge';
import { getDashboard, getReviewAnalytics } from '../../../services/analyticsService';
import { getShippingOverview } from '../../../services/shippingService';
import { getDeliveryStats } from '../../../services/sellerDownloadService';
import { listOrders, mapOrderSummary } from '../../../services/orderService';
import { getErrorMessage } from '../../../lib/errorMessage';

const fmtMoney = (n) => `$${Number(n || 0).toFixed(2)}`;
const fmtDate = (iso) => new Date(iso).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });

/**
 * Phase 15C, Part 2 — Admin Dashboard Overview. Every number here comes
 * from a real, already-existing backend endpoint — none of this needed
 * a single backend change:
 *  - revenue/orders/products/customers/sellers/pending applications:
 *    /analytics/dashboard (Phase 11)
 *  - shipments: /shipments/overview (Phase 14.2)
 *  - digital deliveries: /downloads/stats (Phase 14.1), summed client-side
 *    since that endpoint returns a per-product breakdown, not one total
 *  - reviews: /analytics/reviews (Phase 11)
 *  - recent orders: /orders (Phase 8, admin sees every order server-side);
 *    the "customer" column reads shippingAddress.fullName — a snapshot
 *    already stored on every order — rather than needing Order.buyer
 *    populated (Order module is off-limits to modify this phase)
 */
const Dashboard = () => {
  const [data, setData] = useState(null);
  const [shipping, setShipping] = useState(null);
  const [deliveryTotal, setDeliveryTotal] = useState(null);
  const [reviews, setReviews] = useState(null);
  const [recentOrders, setRecentOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    setError('');
    Promise.all([
      getDashboard(),
      getShippingOverview(),
      getDeliveryStats(),
      getReviewAnalytics(),
      listOrders({ page: 1, limit: 6, sort: '-createdAt' }),
    ])
      .then(([dashboard, shipOverview, deliveryStats, reviewStats, { orders }]) => {
        setData(dashboard);
        setShipping(shipOverview);
        setDeliveryTotal((deliveryStats || []).reduce((sum, s) => sum + (s.totalDownloads || 0), 0));
        setReviews(reviewStats);
        setRecentOrders(orders.map(mapOrderSummary));
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, []);

  const chartData = recentOrders
    .slice()
    .reverse()
    .map((o) => ({ day: fmtDate(o.date), total: Math.round(Number(o.total) * 100) / 100 }));

  if (error) {
    return (
      <div>
        <PageHeader title="Dashboard" description="Overview of the marketplace's performance." />
        <div className="bg-white rounded-2xl border border-border p-8 text-center">
          <p className="text-sm text-destructive mb-3">{error}</p>
          <button onClick={() => window.location.reload()} className="text-sm font-semibold text-primary hover:underline">Try again</button>
        </div>
      </div>
    );
  }

  return (
    <div>
      <PageHeader title="Dashboard" description="Overview of the marketplace's performance." />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
        <StatCard label="Total Revenue" value={loading ? '—' : fmtMoney(data?.revenue?.total)} icon={DollarSign} />
        <StatCard label="Total Orders" value={loading ? '—' : (data?.orders?.total ?? 0)} icon={ShoppingCart} />
        <StatCard label="Customers" value={loading ? '—' : (data?.customers?.total ?? 0)} icon={Users} />
        <StatCard label="Products" value={loading ? '—' : (data?.products?.total ?? 0)} icon={Package} />
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Sellers" value={loading ? '—' : (data?.sellers?.total ?? 0)} icon={Store} />
        <StatCard label="Pending Applications" value={loading ? '—' : (data?.sellers?.pending ?? 0)} icon={Clock} />
        <StatCard label="Shipments" value={loading ? '—' : (shipping?.total ?? 0)} icon={Truck} />
        <StatCard label="Digital Deliveries" value={loading ? '—' : (deliveryTotal ?? 0)} icon={Download} />
      </div>

      <div className="grid lg:grid-cols-3 gap-4 mb-6">
        <div className="lg:col-span-2 bg-white rounded-2xl border border-border p-5 soft-shadow">
          <h2 className="font-semibold mb-4">Recent Order Value</h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ left: -20 }}>
                <defs>
                  <linearGradient id="revFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#6C3BFF" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="#6C3BFF" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#EEE" />
                <XAxis dataKey="day" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                <Tooltip formatter={(v) => [`$${v}`, 'Order total']} />
                <Area type="monotone" dataKey="total" stroke="#6C3BFF" strokeWidth={2} fill="url(#revFill)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            Based on the 6 most recent orders — a full trend chart lives in Reports &amp; Analytics.
          </p>
        </div>

        <div className="bg-white rounded-2xl border border-border p-5 soft-shadow">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold">Reviews</h2>
            <Star className="w-4 h-4 text-amber-500" />
          </div>
          {loading ? (
            <p className="text-sm text-muted-foreground">Loading…</p>
          ) : (
            <>
              <p className="text-3xl font-bold tracking-tight">{reviews?.averageRating ?? 0}<span className="text-sm font-medium text-muted-foreground"> / 5</span></p>
              <p className="text-xs text-muted-foreground mt-1 mb-4">{reviews?.totalReviews ?? 0} published reviews</p>
              <div className="space-y-1.5">
                {[5, 4, 3, 2, 1].map((star) => {
                  const count = reviews?.distribution?.[`dist${star}`] ?? 0;
                  const pct = reviews?.totalReviews ? Math.round((count / reviews.totalReviews) * 100) : 0;
                  return (
                    <div key={star} className="flex items-center gap-2 text-xs">
                      <span className="w-3 text-muted-foreground">{star}</span>
                      <div className="flex-1 h-1.5 rounded-full bg-secondary overflow-hidden">
                        <div className="h-full bg-amber-400" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="w-8 text-right text-muted-foreground">{count}</span>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-border overflow-hidden">
        <div className="flex items-center justify-between p-5 pb-0">
          <h2 className="font-semibold">Recent Orders</h2>
          <Link to="/admin/orders" className="text-xs font-semibold text-primary">View all</Link>
        </div>
        <div className="overflow-x-auto mt-3">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs text-muted-foreground border-b border-border">
                <th className="font-medium px-5 py-3">Order</th>
                <th className="font-medium px-5 py-3">Customer</th>
                <th className="font-medium px-5 py-3">Date</th>
                <th className="font-medium px-5 py-3">Status</th>
                <th className="font-medium px-5 py-3 text-right">Total</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={5} className="px-5 py-8 text-center text-muted-foreground">Loading…</td></tr>
              ) : recentOrders.length === 0 ? (
                <tr><td colSpan={5} className="px-5 py-8 text-center text-muted-foreground">No orders yet.</td></tr>
              ) : (
                recentOrders.map((o) => (
                  <tr key={o.orderId} className="border-b border-border last:border-0 hover:bg-secondary/30">
                    <td className="px-5 py-3">
                      <span className="font-medium text-primary">{o.id}</span>
                    </td>
                    <td className="px-5 py-3">{o.customerName || '—'}</td>
                    <td className="px-5 py-3 text-muted-foreground">{fmtDate(o.date)}</td>
                    <td className="px-5 py-3"><StatusBadge status={o.rawStatus} /></td>
                    <td className="px-5 py-3 text-right font-medium">{fmtMoney(o.total)}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
