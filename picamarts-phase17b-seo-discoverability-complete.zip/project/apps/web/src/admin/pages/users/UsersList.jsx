import React, { useEffect, useState } from 'react';
import { Users as UsersIcon, ShieldOff, ShieldCheck, Trash2, Search } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import StatusBadge from '../../components/StatusBadge';
import EmptyState from '../../components/EmptyState';
import ConfirmDeleteDialog from '../../components/ConfirmDeleteDialog';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../../../components/ui/select';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '../../../components/ui/dropdown-menu';
import Pagination from '../../../pages/seller/components/Pagination';
import { listUsers, suspendUser, activateUser, deleteUser } from '../../../services/adminUserService';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

const PAGE_SIZE = 20;
const fmtDate = (iso) => (iso ? new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) : 'Never');
const initials = (name = '') => name.split(' ').map((w) => w[0]).filter(Boolean).slice(0, 2).join('').toUpperCase() || '?';

/**
 * Phase 15C, Part 3 — Admin User Management. Wired to the real backend's
 * /users endpoints (new this phase — see apps/api/src/routes/v1/user.routes.js).
 *
 * The old mock version of this page invented a fictional "invite staff
 * member with a custom Editor/Support role" flow — the real User model
 * only has buyer/seller/admin, and there's no invite system, so that UI
 * is dropped rather than kept as a non-functional relic. This page is
 * now a real account-oversight tool: search/filter by role & status,
 * view, suspend (locks the account out immediately), activate, delete.
 * Admin accounts and your own account are protected from suspend/delete
 * by the backend itself (see user.service.js).
 */
const UsersList = () => {
  const { toast } = useToast();
  const [users, setUsers] = useState([]);
  const [meta, setMeta] = useState({ totalPages: 1, totalItems: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [role, setRole] = useState('all');
  const [status, setStatus] = useState('all');
  const [page, setPage] = useState(1);
  const [busyId, setBusyId] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => { setDebouncedQuery(query); setPage(1); }, 350);
    return () => clearTimeout(t);
  }, [query]);

  useEffect(() => { setPage(1); }, [role, status]);

  const load = () => {
    setLoading(true);
    setError('');
    const params = { page, limit: PAGE_SIZE };
    if (debouncedQuery.trim()) params.q = debouncedQuery.trim();
    if (role !== 'all') params.role = role;
    if (status !== 'all') params.status = status;

    listUsers(params)
      .then(({ users: rows, meta: m }) => {
        setUsers(rows);
        setMeta(m || { totalPages: 1, totalItems: rows.length });
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };

  useEffect(load, [page, debouncedQuery, role, status]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleSuspend = async (user) => {
    setBusyId(user.id);
    try {
      await suspendUser(user.id);
      toast({ title: 'User suspended', description: user.name });
      load();
    } catch (err) {
      toast({ title: 'Could not suspend user', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setBusyId(null);
    }
  };

  const handleActivate = async (user) => {
    setBusyId(user.id);
    try {
      await activateUser(user.id);
      toast({ title: 'User reactivated', description: user.name });
      load();
    } catch (err) {
      toast({ title: 'Could not reactivate user', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setBusyId(null);
    }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await deleteUser(deleteTarget.id);
      toast({ title: 'User deleted', description: deleteTarget.name });
      setDeleteTarget(null);
      load();
    } catch (err) {
      toast({ title: 'Could not delete user', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div>
      <PageHeader title="User Management" description={`${meta.totalItems ?? users.length} accounts`} />

      <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-4">
        <div className="flex items-center gap-2 bg-secondary/60 rounded-full px-3.5 py-2 flex-1 max-w-sm">
          <Search className="w-4 h-4 text-muted-foreground shrink-0" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search name or email…"
            className="bg-transparent outline-none text-sm w-full placeholder:text-muted-foreground"
          />
        </div>
        <Select value={role} onValueChange={setRole}>
          <SelectTrigger className="w-[150px] rounded-full text-sm"><SelectValue placeholder="Role" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Roles</SelectItem>
            <SelectItem value="buyer">Buyer</SelectItem>
            <SelectItem value="seller">Seller</SelectItem>
            <SelectItem value="admin">Admin</SelectItem>
          </SelectContent>
        </Select>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-[150px] rounded-full text-sm"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="suspended">Suspended</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="bg-white rounded-2xl border border-border overflow-hidden">
        {loading ? (
          <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>
        ) : error ? (
          <div className="p-8 text-center">
            <p className="text-sm text-destructive mb-3">{error}</p>
            <button onClick={load} className="text-sm font-semibold text-primary hover:underline">Try again</button>
          </div>
        ) : users.length === 0 ? (
          <EmptyState icon={UsersIcon} title="No users found" description="Try adjusting your search or filters." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-muted-foreground border-b border-border">
                  <th className="font-medium px-5 py-3">User</th>
                  <th className="font-medium px-5 py-3">Role</th>
                  <th className="font-medium px-5 py-3">Joined</th>
                  <th className="font-medium px-5 py-3">Last Login</th>
                  <th className="font-medium px-5 py-3">Status</th>
                  <th className="font-medium px-5 py-3 w-10"><span className="sr-only">Actions</span></th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id} className="border-b border-border last:border-0 hover:bg-secondary/30">
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-3">
                        <span className="w-9 h-9 rounded-full brand-gradient text-white grid place-items-center text-xs font-bold shrink-0">
                          {initials(u.name)}
                        </span>
                        <div className="min-w-0">
                          <p className="font-medium truncate">{u.name}</p>
                          <p className="text-xs text-muted-foreground truncate">{u.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-3 capitalize">{u.role}</td>
                    <td className="px-5 py-3 text-muted-foreground">{fmtDate(u.createdAt)}</td>
                    <td className="px-5 py-3 text-muted-foreground">{fmtDate(u.lastLoginAt)}</td>
                    <td className="px-5 py-3"><StatusBadge status={u.isActive ? 'active' : 'suspended'} /></td>
                    <td className="px-5 py-3">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <button
                            disabled={busyId === u.id}
                            className="p-1.5 rounded-lg hover:bg-secondary transition-colors disabled:opacity-50"
                            aria-label="Row actions"
                          >
                            <ShieldCheck className="w-4 h-4" />
                          </button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          {u.role === 'admin' ? (
                            <DropdownMenuItem disabled>Admin accounts are protected</DropdownMenuItem>
                          ) : u.isActive ? (
                            <DropdownMenuItem onClick={() => handleSuspend(u)}>
                              <ShieldOff className="w-4 h-4 mr-2" /> Suspend
                            </DropdownMenuItem>
                          ) : (
                            <DropdownMenuItem onClick={() => handleActivate(u)}>
                              <ShieldCheck className="w-4 h-4 mr-2" /> Reactivate
                            </DropdownMenuItem>
                          )}
                          {u.role !== 'admin' && (
                            <DropdownMenuItem className="text-red-600 focus:text-red-600" onClick={() => setDeleteTarget(u)}>
                              <Trash2 className="w-4 h-4 mr-2" /> Delete
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Pagination page={page} totalPages={meta.totalPages || 1} onPageChange={setPage} />

      <ConfirmDeleteDialog
        open={!!deleteTarget}
        onOpenChange={(v) => !v && setDeleteTarget(null)}
        title="Delete this user?"
        description={deleteTarget ? `"${deleteTarget.name}"'s account will be permanently removed. This cannot be undone.` : ''}
        onConfirm={handleDelete}
        busy={deleting}
      />
    </div>
  );
};

export default UsersList;
