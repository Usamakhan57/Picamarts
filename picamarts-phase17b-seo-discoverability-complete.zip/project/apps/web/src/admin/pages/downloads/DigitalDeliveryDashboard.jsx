import React, { useEffect, useState } from 'react';
import { Download as DownloadIcon, KeyRound, History, Ban } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import EmptyState from '../../components/EmptyState';
import StatusBadge from '../../components/StatusBadge';
import ConfirmDeleteDialog from '../../components/ConfirmDeleteDialog';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../../../components/ui/select';
import Pagination from '../../../pages/seller/components/Pagination';
import { getDeliveryStats, listDeliveries, listDownloadLogs, revokeDownload } from '../../../services/sellerDownloadService';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

const PAGE_SIZE = 20;
const fmtDate = (iso) => (iso ? new Date(iso).toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—');

const TABS = [
  { key: 'deliveries', label: 'Deliveries', icon: KeyRound },
  { key: 'logs', label: 'Download Logs', icon: History },
];

/**
 * Phase 15C, Part 8 — Admin Digital Delivery Management. This page
 * didn't exist before (not even a mock) — the backend has fully
 * supported an admin view since Phase 14.1, it was just never wired to
 * a page. Every service call here is role-scoped server-side (admin
 * sees every seller's deliveries/logs on the exact same endpoints a
 * seller uses for their own), see sellerDownloadService.js.
 */
const DigitalDeliveryDashboard = () => {
  const { toast } = useToast();
  const [stats, setStats] = useState([]);
  const [statsLoading, setStatsLoading] = useState(true);

  const [tab, setTab] = useState('deliveries');

  const [deliveries, setDeliveries] = useState([]);
  const [deliveriesMeta, setDeliveriesMeta] = useState({ totalPages: 1, totalItems: 0 });
  const [deliveriesPage, setDeliveriesPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState('all');
  const [deliveriesLoading, setDeliveriesLoading] = useState(true);
  const [deliveriesError, setDeliveriesError] = useState('');
  const [revokeTarget, setRevokeTarget] = useState(null);
  const [revoking, setRevoking] = useState(false);

  const [logs, setLogs] = useState([]);
  const [logsMeta, setLogsMeta] = useState({ totalPages: 1, totalItems: 0 });
  const [logsPage, setLogsPage] = useState(1);
  const [logsLoading, setLogsLoading] = useState(true);
  const [logsError, setLogsError] = useState('');

  useEffect(() => {
    setStatsLoading(true);
    getDeliveryStats()
      .then(setStats)
      .catch(() => setStats([]))
      .finally(() => setStatsLoading(false));
  }, []);

  useEffect(() => { setDeliveriesPage(1); }, [statusFilter]);

  const loadDeliveries = () => {
    setDeliveriesLoading(true);
    setDeliveriesError('');
    const params = { page: deliveriesPage, limit: PAGE_SIZE };
    if (statusFilter !== 'all') params.status = statusFilter;
    listDeliveries(params)
      .then(({ deliveries: rows, meta }) => {
        setDeliveries(rows);
        setDeliveriesMeta(meta || { totalPages: 1, totalItems: rows.length });
      })
      .catch((err) => setDeliveriesError(getErrorMessage(err)))
      .finally(() => setDeliveriesLoading(false));
  };
  useEffect(loadDeliveries, [deliveriesPage, statusFilter]); // eslint-disable-line react-hooks/exhaustive-deps

  const loadLogs = () => {
    setLogsLoading(true);
    setLogsError('');
    listDownloadLogs({ page: logsPage, limit: PAGE_SIZE })
      .then(({ logs: rows, meta }) => {
        setLogs(rows);
        setLogsMeta(meta || { totalPages: 1, totalItems: rows.length });
      })
      .catch((err) => setLogsError(getErrorMessage(err)))
      .finally(() => setLogsLoading(false));
  };
  useEffect(() => { if (tab === 'logs') loadLogs(); }, [tab, logsPage]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleRevoke = async () => {
    setRevoking(true);
    try {
      await revokeDownload(revokeTarget.id, 'Revoked by admin.');
      toast({ title: 'Download access revoked' });
      setRevokeTarget(null);
      loadDeliveries();
    } catch (err) {
      toast({ title: 'Could not revoke access', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setRevoking(false);
    }
  };

  const totalDownloads = stats.reduce((s, r) => s + (r.totalDownloads || 0), 0);
  const totalPurchases = stats.reduce((s, r) => s + (r.totalPurchases || 0), 0);
  const totalRevoked = stats.reduce((s, r) => s + (r.revoked || 0), 0);

  return (
    <div>
      <PageHeader title="Digital Delivery" description="Downloads, license keys, and delivery logs across every seller." />

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-6">
        <div className="bg-white rounded-2xl border border-border p-4">
          <p className="text-xs text-muted-foreground">Total Purchases</p>
          <p className="text-2xl font-bold mt-1">{statsLoading ? '—' : totalPurchases}</p>
        </div>
        <div className="bg-white rounded-2xl border border-border p-4">
          <p className="text-xs text-muted-foreground">Total Downloads</p>
          <p className="text-2xl font-bold mt-1">{statsLoading ? '—' : totalDownloads}</p>
        </div>
        <div className="bg-white rounded-2xl border border-border p-4">
          <p className="text-xs text-muted-foreground">Revoked</p>
          <p className="text-2xl font-bold mt-1">{statsLoading ? '—' : totalRevoked}</p>
        </div>
      </div>

      {!statsLoading && stats.length > 0 && (
        <div className="bg-white rounded-2xl border border-border overflow-hidden mb-6">
          <div className="p-5 border-b border-border">
            <h3 className="font-semibold text-sm">Per-Product Breakdown</h3>
          </div>
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs text-muted-foreground">
                <th className="font-medium px-5 py-3">Product</th>
                <th className="font-medium px-5 py-3 text-right">Purchases</th>
                <th className="font-medium px-5 py-3 text-right">Downloads</th>
                <th className="font-medium px-5 py-3 text-right">Revoked</th>
              </tr>
            </thead>
            <tbody>
              {stats.map((row, i) => (
                <tr key={i} className="border-t border-border">
                  <td className="px-5 py-3 font-medium">{typeof row.product === 'object' ? row.product.title : row.product}</td>
                  <td className="px-5 py-3 text-right">{row.totalPurchases}</td>
                  <td className="px-5 py-3 text-right">{row.totalDownloads}</td>
                  <td className="px-5 py-3 text-right">{row.revoked}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div className="flex gap-1.5 overflow-x-auto pb-1 mb-4 border-b border-border">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`inline-flex items-center gap-1.5 px-4 py-2.5 text-sm font-semibold whitespace-nowrap border-b-2 -mb-px transition-colors ${tab === t.key ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'}`}
          >
            <t.icon className="w-4 h-4" /> {t.label}
          </button>
        ))}
      </div>

      {tab === 'deliveries' && (
        <>
          <div className="flex justify-end mb-4">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[150px] rounded-full text-sm"><SelectValue placeholder="Status" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="revoked">Revoked</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="bg-white rounded-2xl border border-border overflow-hidden">
            {deliveriesLoading ? (
              <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>
            ) : deliveriesError ? (
              <div className="p-8 text-center">
                <p className="text-sm text-destructive mb-3">{deliveriesError}</p>
                <button onClick={loadDeliveries} className="text-sm font-semibold text-primary hover:underline">Try again</button>
              </div>
            ) : deliveries.length === 0 ? (
              <EmptyState icon={DownloadIcon} title="No deliveries found" description="Try adjusting the status filter." />
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-left text-xs text-muted-foreground border-b border-border">
                      <th className="font-medium px-5 py-3">Product</th>
                      <th className="font-medium px-5 py-3">License Key</th>
                      <th className="font-medium px-5 py-3">Downloads</th>
                      <th className="font-medium px-5 py-3">Purchased</th>
                      <th className="font-medium px-5 py-3">Status</th>
                      <th className="font-medium px-5 py-3 w-10"><span className="sr-only">Actions</span></th>
                    </tr>
                  </thead>
                  <tbody>
                    {deliveries.map((d) => (
                      <tr key={d.id} className="border-b border-border last:border-0 hover:bg-secondary/30">
                        <td className="px-5 py-3 font-medium">{typeof d.product === 'object' ? d.product.title : d.product}</td>
                        <td className="px-5 py-3 font-mono text-xs text-muted-foreground">{d.licenseKey || '—'}</td>
                        <td className="px-5 py-3">{d.downloadCount} / {d.maxDownloads}</td>
                        <td className="px-5 py-3 text-muted-foreground">{fmtDate(d.purchasedAt)}</td>
                        <td className="px-5 py-3"><StatusBadge status={d.status} /></td>
                        <td className="px-5 py-3">
                          {d.status !== 'revoked' && (
                            <button
                              onClick={() => setRevokeTarget(d)}
                              className="p-1.5 rounded-lg hover:bg-secondary transition-colors text-red-600"
                              aria-label="Revoke access"
                              title="Revoke access"
                            >
                              <Ban className="w-4 h-4" />
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
          <Pagination page={deliveriesPage} totalPages={deliveriesMeta.totalPages || 1} onPageChange={setDeliveriesPage} />
        </>
      )}

      {tab === 'logs' && (
        <>
          <div className="bg-white rounded-2xl border border-border overflow-hidden">
            {logsLoading ? (
              <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>
            ) : logsError ? (
              <div className="p-8 text-center">
                <p className="text-sm text-destructive mb-3">{logsError}</p>
                <button onClick={loadLogs} className="text-sm font-semibold text-primary hover:underline">Try again</button>
              </div>
            ) : logs.length === 0 ? (
              <EmptyState icon={History} title="No download activity yet" />
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-left text-xs text-muted-foreground border-b border-border">
                      <th className="font-medium px-5 py-3">Downloaded At</th>
                      <th className="font-medium px-5 py-3">User</th>
                      <th className="font-medium px-5 py-3">Product</th>
                      <th className="font-medium px-5 py-3">IP Address</th>
                    </tr>
                  </thead>
                  <tbody>
                    {logs.map((log) => (
                      <tr key={log.id} className="border-b border-border last:border-0 hover:bg-secondary/30">
                        <td className="px-5 py-3 text-muted-foreground">{fmtDate(log.downloadedAt)}</td>
                        <td className="px-5 py-3 font-mono text-xs">{log.user}</td>
                        <td className="px-5 py-3 font-mono text-xs">{log.product}</td>
                        <td className="px-5 py-3 text-muted-foreground">{log.ipAddress || '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
          <Pagination page={logsPage} totalPages={logsMeta.totalPages || 1} onPageChange={setLogsPage} />
        </>
      )}

      <ConfirmDeleteDialog
        open={!!revokeTarget}
        onOpenChange={(v) => !v && setRevokeTarget(null)}
        title="Revoke download access?"
        description="The buyer will no longer be able to redeem this download."
        onConfirm={handleRevoke}
        busy={revoking}
        confirmLabel="Revoke"
        busyLabel="Revoking…"
      />
    </div>
  );
};

export default DigitalDeliveryDashboard;
