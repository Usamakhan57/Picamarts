import React from 'react';
import PageHeader from '../../components/PageHeader';
import SellerNotificationsTab from '../../../pages/seller/components/SellerNotificationsTab';

/**
 * Phase 15C, Part 12 — Admin Notifications. This page didn't exist
 * before (not even a mock). The real /notifications endpoints are
 * role-agnostic — a buyer, seller, and admin all read/write their own
 * notifications through the exact same API (Phase 10.2) — and the
 * list/filter/mark-read/mark-all-read/delete UI built for the Seller
 * Dashboard (Phase 15B) has zero seller-specific logic in it, so this
 * reuses that component directly rather than duplicating it, per this
 * phase's "avoid duplicating business logic" instruction.
 */
const NotificationsList = () => (
  <div>
    <PageHeader title="Notifications" description="Your admin account's notifications." />
    <SellerNotificationsTab />
  </div>
);

export default NotificationsList;
