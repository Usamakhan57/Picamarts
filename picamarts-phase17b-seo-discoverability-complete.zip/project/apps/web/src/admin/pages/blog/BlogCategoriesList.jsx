import React, { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import ConfirmDeleteDialog from '../../components/ConfirmDeleteDialog';
import FormSheet, { Field, inputClass, textareaClass } from '../../components/FormSheet';
import { listCategories, createCategory, updateCategory, deleteCategory } from '../../../services/adminBlogService';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

/**
 * Phase 15C, Part 11 — real `/blog/categories` CRUD. The old mock had
 * `icon`/`order`/drag-to-reorder fields the real BlogCategory model
 * doesn't have (just name/slug/description/active) — dropped rather
 * than faked, same "drop what the backend doesn't model" convention
 * used throughout Phase 15C.
 */
const EMPTY = { name: '', slug: '', description: '', active: true };

const BlogCategoriesList = () => {
  const { toast } = useToast();
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [sheetOpen, setSheetOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const load = () => {
    setLoading(true);
    setError('');
    listCategories({ limit: 100 })
      .then((res) => setCategories(res.categories || []))
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };
  useEffect(load, []);

  const openAdd = () => { setEditing(null); setForm(EMPTY); setSheetOpen(true); };
  const openEdit = (row) => { setEditing(row); setForm({ name: row.name, slug: row.slug, description: row.description || '', active: row.active !== false }); setSheetOpen(true); };

  const handleSubmit = async () => {
    if (!form.name.trim()) { toast({ title: 'Name is required', variant: 'destructive' }); return; }
    setSaving(true);
    try {
      if (editing) await updateCategory(editing.id, form);
      else await createCategory(form);
      toast({ title: editing ? 'Category updated' : 'Category created', description: form.name });
      setSheetOpen(false);
      load();
    } catch (err) {
      toast({ title: 'Save failed', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await deleteCategory(deleteTarget.id);
      toast({ title: 'Category deleted', description: deleteTarget.name });
      setDeleteTarget(null);
      load();
    } catch (err) {
      toast({ title: 'Delete failed', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setDeleting(false);
    }
  };

  const columns = [
    { key: 'name', label: 'Name', render: (row) => <span className="font-medium">{row.name}</span> },
    { key: 'slug', label: 'Slug', render: (row) => <span className="text-muted-foreground">{row.slug}</span> },
    { key: 'postCount', label: 'Posts', render: (row) => row.postCount ?? 0 },
    { key: 'active', label: 'Status', render: (row) => <StatusBadge status={row.active !== false ? 'active' : 'inactive'} /> },
    {
      key: 'actions', label: '', render: (row) => (
        <div className="flex items-center gap-1 justify-end">
          <button onClick={() => openEdit(row)} className="p-2 rounded-lg hover:bg-secondary"><Pencil className="w-4 h-4" /></button>
          <button onClick={() => setDeleteTarget(row)} className="p-2 rounded-lg hover:bg-secondary text-destructive"><Trash2 className="w-4 h-4" /></button>
        </div>
      ),
    },
  ];

  return (
    <div>
      <PageHeader
        title="Blog Categories"
        description="Organize blog posts into categories."
        actions={<button onClick={openAdd} className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-full text-sm font-semibold brand-gradient text-white"><Plus className="w-4 h-4" /> Add Category</button>}
      />
      {error ? (
        <p className="text-sm text-destructive py-8 text-center">{error}</p>
      ) : (
        <DataTable columns={columns} data={categories} isLoading={loading} emptyState={{ title: 'No blog categories yet.' }} />
      )}

      <FormSheet open={sheetOpen} onOpenChange={setSheetOpen} title={editing ? 'Edit Category' : 'Add Category'} onSubmit={handleSubmit} submitting={saving}>
        <Field label="Name">
          <input className={inputClass} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        </Field>
        <Field label="Slug" hint="Leave blank to auto-generate from name.">
          <input className={inputClass} value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} />
        </Field>
        <Field label="Description">
          <textarea className={textareaClass} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
        </Field>
        <label className="flex items-center gap-2 text-sm font-medium">
          <input type="checkbox" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} />
          Active
        </label>
      </FormSheet>

      <ConfirmDeleteDialog
        open={!!deleteTarget}
        onOpenChange={(v) => !v && setDeleteTarget(null)}
        onConfirm={handleDelete}
        busy={deleting}
        title="Delete category?"
        description={`"${deleteTarget?.name}" will be permanently deleted. Posts in this category will keep their assignment removed.`}
      />
    </div>
  );
};

export default BlogCategoriesList;
