import React, { useEffect, useState } from 'react';
import { Tags as TagsIcon } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import EmptyState from '../../components/EmptyState';
import { listTags } from '../../../services/adminBlogService';
import { getErrorMessage } from '../../../lib/errorMessage';

/**
 * Phase 15C, Part 11 — real `GET /blog/tags`. `tags` on BlogPost is a
 * plain embedded string array, not its own collection (see
 * adminBlogService.js) — so unlike Categories there is no rename/
 * merge/delete here, just the real distinct-tag list (with post
 * counts, published posts only) for browsing which tags are in use.
 */
const BlogTagsList = () => {
  const [tags, setTags] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    listTags()
      .then(setTags)
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <PageHeader title="Blog Tags" description="Tags currently in use across published posts. Add or edit tags directly on a post." />
      {loading ? (
        <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>
      ) : error ? (
        <p className="text-sm text-destructive py-8 text-center">{error}</p>
      ) : tags.length === 0 ? (
        <EmptyState icon={TagsIcon} title="No tags yet" description="Tags will appear here once a published post uses them." />
      ) : (
        <div className="bg-white rounded-2xl border border-border soft-shadow p-5 flex flex-wrap gap-2">
          {tags.map((t) => (
            <span key={t.tag} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium bg-secondary">
              {t.tag}
              <span className="text-xs text-muted-foreground">{t.count}</span>
            </span>
          ))}
        </div>
      )}
    </div>
  );
};

export default BlogTagsList;
