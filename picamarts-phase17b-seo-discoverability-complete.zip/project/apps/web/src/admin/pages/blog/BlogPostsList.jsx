import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import ConfirmDeleteDialog from '../../components/ConfirmDeleteDialog';
import { listPosts, deletePost } from '../../../services/adminBlogService';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

const formatDate = (d) => (d ? new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '—');

/**
 * Phase 15C, Part 11 — real `/blog` CRUD. The old mock's duplicate/
 * bulk-publish/bulk-trash actions and a separate Authors lookup have
 * no backend equivalent (BlogPost has no soft-delete, no duplicate
 * endpoint, and `author` is just whichever admin created the post —
 * there's no Author entity to look a name up in) — dropped rather
 * than faked. Category name comes pre-populated on every post from
 * the real API, no separate lookup needed.
 */
const BlogPostsList = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [posts, setPosts] = useState([]);
  const [meta, setMeta] = useState({ totalPages: 1 });
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const load = () => {
    setLoading(true);
    setError('');
    listPosts({ page, limit: 20, sort: '-createdAt' })
      .then((res) => { setPosts(res.posts || []); setMeta(res.meta || { totalPages: 1 }); })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };
  useEffect(load, [page]);

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await deletePost(deleteTarget.id);
      toast({ title: 'Post deleted', description: deleteTarget.title });
      setDeleteTarget(null);
      load();
    } catch (err) {
      toast({ title: 'Delete failed', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setDeleting(false);
    }
  };

  const columns = [
    { key: 'title', label: 'Title', render: (row) => <span className="font-medium">{row.title}</span> },
    { key: 'category', label: 'Category', render: (row) => row.category?.name || '—' },
    { key: 'status', label: 'Status', render: (row) => <StatusBadge status={row.status} /> },
    { key: 'publishedAt', label: 'Published', render: (row) => formatDate(row.publishedAt) },
    { key: 'updatedAt', label: 'Updated', render: (row) => formatDate(row.updatedAt) },
    {
      key: 'actions', label: '', render: (row) => (
        <div className="flex items-center gap-1 justify-end">
          <button onClick={() => navigate(`/admin/blog/edit/${row.id}`)} className="p-2 rounded-lg hover:bg-secondary"><Pencil className="w-4 h-4" /></button>
          <button onClick={() => setDeleteTarget(row)} className="p-2 rounded-lg hover:bg-secondary text-destructive"><Trash2 className="w-4 h-4" /></button>
        </div>
      ),
    },
  ];

  return (
    <div>
      <PageHeader
        title="All Posts"
        description="Manage blog articles."
        actions={<Link to="/admin/blog/new" className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-full text-sm font-semibold brand-gradient text-white"><Plus className="w-4 h-4" /> Add New Post</Link>}
      />
      {error ? (
        <p className="text-sm text-destructive py-8 text-center">{error}</p>
      ) : (
        <>
          <DataTable columns={columns} data={posts} isLoading={loading} emptyState={{ title: 'No posts yet.' }} />
          {meta.totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 mt-4 text-sm">
              <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className="px-3 py-1.5 rounded-full border border-border disabled:opacity-40">Prev</button>
              <span className="text-muted-foreground">Page {page} of {meta.totalPages}</span>
              <button disabled={page >= meta.totalPages} onClick={() => setPage((p) => p + 1)} className="px-3 py-1.5 rounded-full border border-border disabled:opacity-40">Next</button>
            </div>
          )}
        </>
      )}

      <ConfirmDeleteDialog
        open={!!deleteTarget}
        onOpenChange={(v) => !v && setDeleteTarget(null)}
        onConfirm={handleDelete}
        busy={deleting}
        title="Delete post?"
        description={`"${deleteTarget?.title}" will be permanently deleted.`}
      />
    </div>
  );
};

export default BlogPostsList;
