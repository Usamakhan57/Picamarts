import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import PageHeader from '../../components/PageHeader';
import MediaPickerField from '../../../components/media/MediaPickerField';
import { Field, inputClass, textareaClass } from '../../components/FormSheet';
import RichTextEditorPlaceholder from '../../../components/blog/RichTextEditorPlaceholder';
import TagsInput from '../../components/TagsInput';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../../../components/ui/select';
import { getPost, createPost, updatePost, listCategories } from '../../../services/adminBlogService';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

/**
 * Phase 15C, Part 11 — real `/blog` create/update. Rebuilt against the
 * real BlogPost schema (title/slug/excerpt/content/featuredImage/
 * category/tags/seo/status) — dropped every field the old mock invented
 * with no backend equivalent: featured/trending/editors-pick flags, a
 * separate author picker (author is always the acting admin, set
 * server-side), reading time, a gallery, robots meta, Open Graph
 * title/description, and the whole Twitter Card block. SEO here is
 * just the real embedded `seo` shape (metaTitle/metaDescription/
 * metaKeywords/canonicalUrl/ogImage) shared with Pages and Homepage.
 */
const EMPTY = {
  title: '', slug: '', excerpt: '', content: '', category: '', tags: [],
  featuredImage: '', status: 'draft',
  metaTitle: '', metaDescription: '', metaKeywords: [], canonicalUrl: '', ogImage: '',
};

const slugify = (s) => s.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

const BlogPostForm = () => {
  const { id } = useParams();
  const isEdit = !!id;
  const navigate = useNavigate();
  const { toast } = useToast();
  const [form, setForm] = useState(EMPTY);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(isEdit);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    listCategories({ limit: 100 }).then((res) => setCategories(res.categories || [])).catch(() => {});
  }, []);

  useEffect(() => {
    if (!isEdit) return;
    setLoading(true);
    getPost(id)
      .then((post) => setForm({
        title: post.title, slug: post.slug, excerpt: post.excerpt || '', content: post.content || '',
        category: post.category?.id || '', tags: post.tags || [],
        featuredImage: post.featuredImage?.url || '', status: post.status,
        metaTitle: post.seo?.metaTitle || '', metaDescription: post.seo?.metaDescription || '',
        metaKeywords: post.seo?.metaKeywords || [], canonicalUrl: post.seo?.canonicalUrl || '',
        ogImage: post.seo?.ogImage?.url || '',
      }))
      .catch((err) => toast({ title: 'Could not load post', description: getErrorMessage(err), variant: 'destructive' }))
      .finally(() => setLoading(false));
  }, [id, isEdit]);

  const buildPayload = () => ({
    title: form.title,
    slug: form.slug || slugify(form.title),
    excerpt: form.excerpt,
    content: form.content,
    category: form.category || null,
    tags: form.tags,
    featuredImage: form.featuredImage ? { url: form.featuredImage } : undefined,
    status: form.status,
    seo: {
      metaTitle: form.metaTitle,
      metaDescription: form.metaDescription,
      metaKeywords: form.metaKeywords,
      canonicalUrl: form.canonicalUrl,
      ogImage: form.ogImage ? { url: form.ogImage } : undefined,
    },
  });

  const handleSubmit = async (status) => {
    if (!form.title.trim()) { toast({ title: 'Title is required', variant: 'destructive' }); return; }
    if (!form.content.trim()) { toast({ title: 'Content is required', variant: 'destructive' }); return; }
    setSaving(true);
    try {
      const payload = { ...buildPayload(), status: status || form.status };
      if (isEdit) await updatePost(id, payload);
      else await createPost(payload);
      toast({ title: isEdit ? 'Post updated' : 'Post created', description: form.title });
      navigate('/admin/blog');
    } catch (err) {
      toast({ title: 'Save failed', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>;

  return (
    <div>
      <PageHeader
        title={isEdit ? 'Edit Post' : 'Add New Post'}
        backTo="/admin/blog"
        backLabel="All Posts"
        actions={(
          <>
            <button onClick={() => handleSubmit('draft')} disabled={saving} className="px-4 py-2.5 rounded-full text-sm font-semibold border border-border hover:bg-secondary disabled:opacity-60">Save Draft</button>
            <button onClick={() => handleSubmit('published')} disabled={saving} className="px-4 py-2.5 rounded-full text-sm font-semibold brand-gradient text-white disabled:opacity-60">{saving ? 'Saving…' : 'Publish'}</button>
          </>
        )}
      />

      <div className="grid lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 space-y-5">
          <div className="bg-white rounded-2xl border border-border p-5 soft-shadow space-y-4">
            <Field label="Title">
              <input className={inputClass} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
            </Field>
            <Field label="Slug" hint="Leave blank to auto-generate from title.">
              <input className={inputClass} value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} />
            </Field>
            <Field label="Excerpt">
              <textarea className={textareaClass} value={form.excerpt} onChange={(e) => setForm({ ...form, excerpt: e.target.value })} />
            </Field>
            <Field label="Content">
              <RichTextEditorPlaceholder value={form.content} onChange={(v) => setForm({ ...form, content: v })} placeholder="Write your post…" />
            </Field>
          </div>

          <div className="bg-white rounded-2xl border border-border p-5 soft-shadow space-y-4">
            <h2 className="font-semibold">SEO</h2>
            <Field label="Meta Title">
              <input className={inputClass} value={form.metaTitle} onChange={(e) => setForm({ ...form, metaTitle: e.target.value })} />
            </Field>
            <Field label="Meta Description">
              <textarea className={textareaClass} value={form.metaDescription} onChange={(e) => setForm({ ...form, metaDescription: e.target.value })} />
            </Field>
            <Field label="Meta Keywords">
              <TagsInput value={form.metaKeywords} onChange={(v) => setForm({ ...form, metaKeywords: v })} placeholder="Add keyword…" />
            </Field>
            <Field label="Canonical URL">
              <input className={inputClass} value={form.canonicalUrl} onChange={(e) => setForm({ ...form, canonicalUrl: e.target.value })} />
            </Field>
            <MediaPickerField label="Open Graph Image" value={form.ogImage} onChange={(v) => setForm({ ...form, ogImage: v })} modalTitle="Select OG Image" />
          </div>
        </div>

        <div className="space-y-5">
          <div className="bg-white rounded-2xl border border-border p-5 soft-shadow space-y-4">
            <Field label="Status">
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="published">Published</SelectItem>
                </SelectContent>
              </Select>
            </Field>
            <Field label="Category">
              <Select value={form.category || 'none'} onValueChange={(v) => setForm({ ...form, category: v === 'none' ? '' : v })}>
                <SelectTrigger className="rounded-xl"><SelectValue placeholder="None" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {categories.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Tags">
              <TagsInput value={form.tags} onChange={(v) => setForm({ ...form, tags: v })} placeholder="Add tag…" />
            </Field>
          </div>
          <div className="bg-white rounded-2xl border border-border p-5 soft-shadow">
            <MediaPickerField label="Featured Image" value={form.featuredImage} onChange={(v) => setForm({ ...form, featuredImage: v })} modalTitle="Select Featured Image" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default BlogPostForm;
