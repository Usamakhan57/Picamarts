import React, { useEffect, useState } from 'react';
import { Truck, PackagePlus, AlertTriangle, ChevronDown, ChevronUp } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import EmptyState from '../../components/EmptyState';
import StatusBadge from '../../components/StatusBadge';
import ShipmentTimeline from '../../../components/shipping/ShipmentTimeline';
import TrackingInfo from '../../../components/shipping/TrackingInfo';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';
import { getShippingOverview, listShipments, updateShipmentStatus, addShipmentTracking } from '../../../services/shippingService';

const STATUS_OPTIONS = ['pending', 'shipped', 'in_transit', 'delivered', 'returned'];
const fmtDate = (iso) => (iso ? new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) : '—');

/**
 * Phase 14.2, Part 10 — Admin Shipping Dashboard. Wired to the real
 * GET /shipments/overview and GET /shipments (admin sees every
 * shipment across every seller) — see shipment.controller.js. Note:
 * the rest of this Admin Panel runs on a local mock DB (admin/api/db.js)
 * with a mock/local admin session; this page is additive real-backend
 * integration, same pattern already established for Phase 14.1's
 * digital delivery work, so it will need a real admin JWT session to
 * actually authenticate once that's wired up.
 */
const ShippingDashboard = () => {
  const { toast } = useToast();
  const [overview, setOverview] = useState(null);
  const [overviewLoading, setOverviewLoading] = useState(true);
  const [shipments, setShipments] = useState([]);
  const [meta, setMeta] = useState(null);
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [expandedId, setExpandedId] = useState(null);
  const [trackingDraft, setTrackingDraft] = useState({});

  useEffect(() => {
    setOverviewLoading(true);
    getShippingOverview()
      .then(setOverview)
      .catch(() => setOverview(null))
      .finally(() => setOverviewLoading(false));
  }, []);

  const load = () => {
    setLoading(true);
    setError(null);
    listShipments({ page, limit: 15, ...(statusFilter ? { status: statusFilter } : {}) })
      .then((res) => { setShipments(res.shipments || []); setMeta(res.meta); })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };
  useEffect(load, [page, statusFilter]); // eslint-disable-line react-hooks/exhaustive-deps

  const changeStatus = async (shipment, status) => {
    try {
      await updateShipmentStatus(shipment.id, status);
      toast({ title: 'Shipment status updated', description: `${shipment.orderNumber} → ${status.replace('_', ' ')}` });
      load();
    } catch (err) {
      toast({ title: "Couldn't update status", description: getErrorMessage(err), variant: 'destructive' });
    }
  };

  const saveTracking = async (shipment) => {
    const draft = trackingDraft[shipment.id];
    if (!draft?.trackingNumber) return;
    try {
      await addShipmentTracking(shipment.id, draft);
      toast({ title: 'Tracking added' });
      load();
    } catch (err) {
      toast({ title: "Couldn't add tracking", description: getErrorMessage(err), variant: 'destructive' });
    }
  };

  return (
    <div>
      <PageHeader title="Shipping" description="Shipment status, tracking, and delivery performance across every seller." />

      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-6">
        {overviewLoading ? (
          [1, 2, 3, 4, 5].map((i) => <div key={i} className="h-20 rounded-2xl bg-secondary/60 animate-pulse" />)
        ) : (
          <>
            {STATUS_OPTIONS.map((s) => (
              <div key={s} className="bg-white rounded-2xl border border-border p-4">
                <p className="text-xs text-muted-foreground capitalize">{s.replace('_', ' ')}</p>
                <p className="text-xl font-bold mt-1">{overview?.counts?.[s] ?? 0}</p>
              </div>
            ))}
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 col-span-2 sm:col-span-1">
              <p className="text-xs text-amber-700 flex items-center gap-1"><AlertTriangle className="w-3 h-3" /> Delayed</p>
              <p className="text-xl font-bold mt-1 text-amber-800">{overview?.delayed ?? 0}</p>
            </div>
          </>
        )}
      </div>

      <div className="flex items-center gap-2 mb-4 overflow-x-auto pb-1">
        <button onClick={() => { setStatusFilter(''); setPage(1); }} className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap ${!statusFilter ? 'bg-primary text-white' : 'bg-secondary text-muted-foreground'}`}>All</button>
        {STATUS_OPTIONS.map((s) => (
          <button key={s} onClick={() => { setStatusFilter(s); setPage(1); }} className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap capitalize ${statusFilter === s ? 'bg-primary text-white' : 'bg-secondary text-muted-foreground'}`}>
            {s.replace('_', ' ')}
          </button>
        ))}
      </div>

      {error ? (
        <div className="bg-white rounded-3xl border border-border">
          <EmptyState icon={Truck} title="Couldn't load shipments" description={error} />
        </div>
      ) : loading ? (
        <div className="space-y-3">{[1, 2, 3].map((i) => <div key={i} className="h-20 rounded-2xl bg-secondary/60 animate-pulse" />)}</div>
      ) : shipments.length === 0 ? (
        <div className="bg-white rounded-3xl border border-border">
          <EmptyState icon={PackagePlus} title="No shipments" description="Shipments matching this filter will show up here." />
        </div>
      ) : (
        <div className="bg-white rounded-3xl border border-border soft-shadow divide-y divide-border">
          {shipments.map((s) => {
            const expanded = expandedId === s.id;
            return (
              <div key={s.id} className="p-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="text-sm font-semibold">{s.orderNumber} <span className="text-muted-foreground font-normal">· {s.items.map((i) => i.title).join(', ')}</span></p>
                    <p className="text-xs text-muted-foreground mt-1">{s.estimatedDelivery ? `Est. delivery ${fmtDate(s.estimatedDelivery)}` : `Created ${fmtDate(s.createdAt)}`}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <StatusBadge status={s.status} />
                    <select value={s.status} onChange={(e) => changeStatus(s, e.target.value)} className="text-xs font-semibold border border-border rounded-full px-2.5 py-1 bg-white">
                      {STATUS_OPTIONS.map((opt) => <option key={opt} value={opt}>{opt.replace('_', ' ')}</option>)}
                    </select>
                  </div>
                </div>

                <TrackingInfo carrier={s.carrier} trackingNumber={s.trackingNumber} trackingUrl={s.trackingUrl} className="mt-3" />

                {!s.trackingNumber && (
                  <div className="mt-3 grid sm:grid-cols-3 gap-2">
                    <input placeholder="Carrier" value={trackingDraft[s.id]?.carrier || ''} onChange={(e) => setTrackingDraft((d) => ({ ...d, [s.id]: { ...d[s.id], carrier: e.target.value } }))} className="bg-secondary/60 rounded-lg px-3 py-1.5 text-xs outline-none border border-transparent focus:border-primary" />
                    <input placeholder="Tracking number" value={trackingDraft[s.id]?.trackingNumber || ''} onChange={(e) => setTrackingDraft((d) => ({ ...d, [s.id]: { ...d[s.id], trackingNumber: e.target.value } }))} className="bg-secondary/60 rounded-lg px-3 py-1.5 text-xs outline-none border border-transparent focus:border-primary" />
                    <button onClick={() => saveTracking(s)} className="px-3 py-1.5 rounded-full border border-border text-xs font-semibold hover:bg-secondary">Add Tracking</button>
                  </div>
                )}

                <button onClick={() => setExpandedId(expanded ? null : s.id)} className="mt-3 inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline">
                  {expanded ? 'Hide timeline' : 'View timeline'} {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                </button>
                {expanded && <div className="mt-3 pt-3 border-t border-border"><ShipmentTimeline timeline={s.timeline} /></div>}
              </div>
            );
          })}
        </div>
      )}

      {meta && meta.totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 mt-6">
          <button disabled={page === 1} onClick={() => setPage((p) => p - 1)} className="w-8 h-8 grid place-items-center rounded-full border border-border disabled:opacity-40">‹</button>
          <span className="text-xs font-medium text-muted-foreground">Page {page} of {meta.totalPages}</span>
          <button disabled={page === meta.totalPages} onClick={() => setPage((p) => p + 1)} className="w-8 h-8 grid place-items-center rounded-full border border-border disabled:opacity-40">›</button>
        </div>
      )}
    </div>
  );
};

export default ShippingDashboard;
