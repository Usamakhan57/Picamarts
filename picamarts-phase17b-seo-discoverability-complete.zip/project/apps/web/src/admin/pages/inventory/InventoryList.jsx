import React, { useEffect, useState } from 'react';
import { Boxes, Plus, Minus, Search } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import EmptyState from '../../components/EmptyState';
import StatusBadge from '../../components/StatusBadge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../../../components/ui/dialog';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../../../components/ui/select';
import { inputClass } from '../../components/FormSheet';
import Pagination from '../../../pages/seller/components/Pagination';
import { listInventory, adjustStock } from '../../../services/adminInventoryService';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

const PAGE_SIZE = 20;

/**
 * Phase 15C, Part 5 — Admin Inventory. Wired to the real backend's
 * /products/admin listing, filtered server-side by the real
 * `stockStatus` param (Phase 5). Stock adjustments write through the
 * real PATCH /products/:id endpoint.
 *
 * Known, disclosed gap: the old mock kept an audit trail of every
 * adjustment (`stock_log`, with a reason). The real backend has no
 * stock-history collection — only the resulting number is ever stored
 * — so no log is written or shown here; the "reason" field is kept for
 * the admin's own reference while typing but is not persisted anywhere.
 */
const InventoryList = () => {
  const { toast } = useToast();
  const [items, setItems] = useState([]);
  const [meta, setMeta] = useState({ totalPages: 1, totalItems: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [stockStatus, setStockStatus] = useState('all');
  const [page, setPage] = useState(1);

  const [adjustTarget, setAdjustTarget] = useState(null);
  const [delta, setDelta] = useState('');
  const [reason, setReason] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => { setDebouncedQuery(query); setPage(1); }, 350);
    return () => clearTimeout(t);
  }, [query]);

  useEffect(() => { setPage(1); }, [stockStatus]);

  const load = () => {
    setLoading(true);
    setError('');
    const params = { page, limit: PAGE_SIZE, sort: 'newest' };
    if (debouncedQuery.trim()) params.q = debouncedQuery.trim();
    if (stockStatus !== 'all') params.stockStatus = stockStatus;

    listInventory(params)
      .then(({ items: rows, pagination }) => {
        setItems(rows);
        setMeta(pagination || { totalPages: 1, totalItems: rows.length });
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };

  useEffect(load, [page, debouncedQuery, stockStatus]); // eslint-disable-line react-hooks/exhaustive-deps

  const openAdjust = (row) => { setAdjustTarget(row); setDelta(''); setReason(''); };

  const applyAdjust = async (sign) => {
    const amount = Number(delta);
    if (!amount || amount <= 0) { toast({ title: 'Enter a quantity', variant: 'destructive' }); return; }
    setSaving(true);
    try {
      await adjustStock(adjustTarget.id, sign * amount, reason);
      toast({ title: 'Stock updated', description: `${adjustTarget.title}: ${sign > 0 ? '+' : '-'}${amount}` });
      setAdjustTarget(null);
      load();
    } catch (err) {
      toast({ title: 'Could not update stock', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <PageHeader title="Inventory" description={`${meta.totalItems ?? items.length} tracked products`} />

      <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-4">
        <div className="flex items-center gap-2 bg-secondary/60 rounded-full px-3.5 py-2 flex-1 max-w-sm">
          <Search className="w-4 h-4 text-muted-foreground shrink-0" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search title or SKU…"
            className="bg-transparent outline-none text-sm w-full placeholder:text-muted-foreground"
          />
        </div>
        <Select value={stockStatus} onValueChange={setStockStatus}>
          <SelectTrigger className="w-[160px] rounded-full text-sm"><SelectValue placeholder="Stock" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Stock</SelectItem>
            <SelectItem value="in_stock">In Stock</SelectItem>
            <SelectItem value="low_stock">Low Stock</SelectItem>
            <SelectItem value="out_of_stock">Out of Stock</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="bg-white rounded-2xl border border-border overflow-hidden">
        {loading ? (
          <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>
        ) : error ? (
          <div className="p-8 text-center">
            <p className="text-sm text-destructive mb-3">{error}</p>
            <button onClick={load} className="text-sm font-semibold text-primary hover:underline">Try again</button>
          </div>
        ) : items.length === 0 ? (
          <EmptyState icon={Boxes} title="No inventory records" description="Try adjusting your search or filters." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-muted-foreground border-b border-border">
                  <th className="font-medium px-5 py-3">Product</th>
                  <th className="font-medium px-5 py-3">Stock</th>
                  <th className="font-medium px-5 py-3">Reorder Point</th>
                  <th className="font-medium px-5 py-3">Status</th>
                  <th className="font-medium px-5 py-3 w-10"><span className="sr-only">Actions</span></th>
                </tr>
              </thead>
              <tbody>
                {items.map((row) => (
                  <tr key={row.id} className="border-b border-border last:border-0 hover:bg-secondary/30">
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-3">
                        {row.image ? <img src={row.image} alt="" className="w-10 h-10 rounded-lg object-cover" /> : <span className="w-10 h-10 rounded-lg bg-secondary grid place-items-center shrink-0"><Boxes className="w-4 h-4 text-muted-foreground" /></span>}
                        <div>
                          <p className="font-medium">{row.title}</p>
                          <p className="text-xs text-muted-foreground">{row.sku}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-3 font-semibold">{row.stock}</td>
                    <td className="px-5 py-3">{row.lowStockThreshold}</td>
                    <td className="px-5 py-3"><StatusBadge status={row.status} /></td>
                    <td className="px-5 py-3">
                      <button
                        onClick={() => openAdjust(row)}
                        className="text-xs font-semibold text-primary px-3 py-1.5 rounded-full hover:bg-secondary transition-colors"
                      >
                        Adjust Stock
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Pagination page={page} totalPages={meta.totalPages || 1} onPageChange={setPage} />

      <Dialog open={!!adjustTarget} onOpenChange={(v) => !v && setAdjustTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Adjust Stock — {adjustTarget?.title}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">Current stock: <span className="font-semibold text-foreground">{adjustTarget?.stock}</span></p>
            <div>
              <label className="block text-sm font-medium mb-1.5">Quantity</label>
              <input type="number" min="1" value={delta} onChange={(e) => setDelta(e.target.value)} className={inputClass} placeholder="e.g. 50" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5">Reason (optional, not stored)</label>
              <input value={reason} onChange={(e) => setReason(e.target.value)} className={inputClass} placeholder="e.g. Restock, correction…" />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <button disabled={saving} onClick={() => applyAdjust(-1)} className="flex-1 inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-full border border-border text-sm font-semibold hover:bg-secondary disabled:opacity-60">
              <Minus className="w-4 h-4" /> Remove
            </button>
            <button disabled={saving} onClick={() => applyAdjust(1)} className="flex-1 inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-full brand-gradient text-white text-sm font-semibold disabled:opacity-60">
              <Plus className="w-4 h-4" /> Add
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default InventoryList;
