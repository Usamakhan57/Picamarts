import React, { useEffect, useState } from 'react';
import { Eye, EyeOff, Trash2, Star, Search, ShieldAlert } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import StatusBadge from '../../components/StatusBadge';
import EmptyState from '../../components/EmptyState';
import ConfirmDeleteDialog from '../../components/ConfirmDeleteDialog';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../../../components/ui/select';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '../../../components/ui/dropdown-menu';
import Pagination from '../../../pages/seller/components/Pagination';
import { listAllReviews, moderateReview, deleteReview } from '../../../services/reviewService';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

const PAGE_SIZE = 20;
const fmtDate = (iso) => new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });

const Stars = ({ rating }) => (
  <div className="flex gap-0.5">
    {[1, 2, 3, 4, 5].map((n) => <Star key={n} className={`w-3.5 h-3.5 ${n <= rating ? 'fill-amber-400 text-amber-400' : 'text-border'}`} />)}
  </div>
);

/**
 * Phase 15C, Part 9 — Admin Review Management. Wired to the real
 * backend's /reviews endpoints — the cross-product admin listing
 * (GET /reviews) is new this phase (see apps/api/src/routes/v1/review.routes.js);
 * moderate/delete reuse the pre-existing PATCH/DELETE /reviews/:id.
 *
 * The real Review model only has two moderation states (published/
 * hidden) — no "pending/approved/rejected" workflow like the old mock
 * invented (every review is live the moment a verified buyer submits
 * it; admin's job is to hide or delete, not approve). Filters and
 * actions below match that.
 */
const ReviewsList = () => {
  const { toast } = useToast();
  const [reviews, setReviews] = useState([]);
  const [meta, setMeta] = useState({ totalPages: 1, totalItems: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [status, setStatus] = useState('all');
  const [rating, setRating] = useState('all');
  const [page, setPage] = useState(1);
  const [busyId, setBusyId] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => { setDebouncedQuery(query); setPage(1); }, 350);
    return () => clearTimeout(t);
  }, [query]);

  useEffect(() => { setPage(1); }, [status, rating]);

  const load = () => {
    setLoading(true);
    setError('');
    const params = { page, limit: PAGE_SIZE, sort: '-createdAt' };
    if (status !== 'all') params.status = status;
    if (rating !== 'all') params.rating = rating;

    listAllReviews(params)
      .then(({ reviews: rows, meta: m }) => {
        setReviews(rows);
        setMeta(m || { totalPages: 1, totalItems: rows.length });
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };

  useEffect(load, [page, debouncedQuery, status, rating]); // eslint-disable-line react-hooks/exhaustive-deps

  // Client-side filter for the free-text search box — product title /
  // reviewer name / review body aren't filterable server-side (the
  // admin endpoint only takes status/rating), so this narrows within
  // the current page rather than across the whole result set.
  const visibleReviews = debouncedQuery.trim()
    ? reviews.filter((r) => {
        const q = debouncedQuery.trim().toLowerCase();
        return (
          (typeof r.product === 'object' ? r.product?.title : '')?.toLowerCase().includes(q) ||
          (typeof r.reviewer === 'object' ? r.reviewer?.name : '')?.toLowerCase().includes(q) ||
          r.title?.toLowerCase().includes(q) ||
          r.body?.toLowerCase().includes(q)
        );
      })
    : reviews;

  const handleModerate = async (row, nextStatus) => {
    setBusyId(row.id);
    try {
      await moderateReview(row.id, { status: nextStatus });
      toast({ title: nextStatus === 'hidden' ? 'Review hidden' : 'Review published' });
      load();
    } catch (err) {
      toast({ title: 'Could not update review', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setBusyId(null);
    }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await deleteReview(deleteTarget.id);
      toast({ title: 'Review deleted' });
      setDeleteTarget(null);
      load();
    } catch (err) {
      toast({ title: 'Could not delete review', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div>
      <PageHeader title="Reviews" description={`${meta.totalItems ?? reviews.length} reviews`} />

      <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-4">
        <div className="flex items-center gap-2 bg-secondary/60 rounded-full px-3.5 py-2 flex-1 max-w-sm">
          <Search className="w-4 h-4 text-muted-foreground shrink-0" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search this page…"
            className="bg-transparent outline-none text-sm w-full placeholder:text-muted-foreground"
          />
        </div>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-[150px] rounded-full text-sm"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="published">Published</SelectItem>
            <SelectItem value="hidden">Hidden</SelectItem>
          </SelectContent>
        </Select>
        <Select value={rating} onValueChange={setRating}>
          <SelectTrigger className="w-[130px] rounded-full text-sm"><SelectValue placeholder="Rating" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Ratings</SelectItem>
            {[5, 4, 3, 2, 1].map((n) => <SelectItem key={n} value={String(n)}>{n} Star{n > 1 ? 's' : ''}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="bg-white rounded-2xl border border-border overflow-hidden">
        {loading ? (
          <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>
        ) : error ? (
          <div className="p-8 text-center">
            <p className="text-sm text-destructive mb-3">{error}</p>
            <button onClick={load} className="text-sm font-semibold text-primary hover:underline">Try again</button>
          </div>
        ) : visibleReviews.length === 0 ? (
          <EmptyState icon={Star} title="No reviews found" description="Try adjusting your search or filters." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-muted-foreground border-b border-border">
                  <th className="font-medium px-5 py-3">Product</th>
                  <th className="font-medium px-5 py-3">Reviewer</th>
                  <th className="font-medium px-5 py-3">Rating</th>
                  <th className="font-medium px-5 py-3">Review</th>
                  <th className="font-medium px-5 py-3">Date</th>
                  <th className="font-medium px-5 py-3">Status</th>
                  <th className="font-medium px-5 py-3 w-10"><span className="sr-only">Actions</span></th>
                </tr>
              </thead>
              <tbody>
                {visibleReviews.map((row) => (
                  <tr key={row.id} className="border-b border-border last:border-0 hover:bg-secondary/30">
                    <td className="px-5 py-3 font-medium max-w-[160px] truncate">
                      {typeof row.product === 'object' ? row.product.title : row.product}
                    </td>
                    <td className="px-5 py-3">
                      <p>{typeof row.reviewer === 'object' ? row.reviewer.name : row.reviewer}</p>
                      {typeof row.reviewer === 'object' && row.reviewer.email && (
                        <p className="text-xs text-muted-foreground">{row.reviewer.email}</p>
                      )}
                    </td>
                    <td className="px-5 py-3"><Stars rating={row.rating} /></td>
                    <td className="px-5 py-3 max-w-xs">
                      {row.title && <p className="font-medium truncate">{row.title}</p>}
                      <p className="text-muted-foreground line-clamp-1">{row.body}</p>
                      {row.reportCount > 0 && (
                        <p className="text-xs text-red-600 flex items-center gap-1 mt-0.5">
                          <ShieldAlert className="w-3 h-3" /> Reported {row.reportCount}×
                        </p>
                      )}
                    </td>
                    <td className="px-5 py-3 text-muted-foreground">{fmtDate(row.createdAt)}</td>
                    <td className="px-5 py-3"><StatusBadge status={row.status} /></td>
                    <td className="px-5 py-3">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <button disabled={busyId === row.id} className="p-1.5 rounded-lg hover:bg-secondary transition-colors disabled:opacity-50" aria-label="Row actions">
                            {row.status === 'hidden' ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          {row.status === 'published' ? (
                            <DropdownMenuItem onClick={() => handleModerate(row, 'hidden')}><EyeOff className="w-4 h-4 mr-2" /> Hide</DropdownMenuItem>
                          ) : (
                            <DropdownMenuItem onClick={() => handleModerate(row, 'published')}><Eye className="w-4 h-4 mr-2" /> Publish</DropdownMenuItem>
                          )}
                          <DropdownMenuItem className="text-red-600 focus:text-red-600" onClick={() => setDeleteTarget(row)}>
                            <Trash2 className="w-4 h-4 mr-2" /> Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Pagination page={page} totalPages={meta.totalPages || 1} onPageChange={setPage} />

      <ConfirmDeleteDialog
        open={!!deleteTarget}
        onOpenChange={(v) => !v && setDeleteTarget(null)}
        title="Delete this review?"
        description="This review will be permanently removed and the product's rating recalculated."
        onConfirm={handleDelete}
        busy={deleting}
      />
    </div>
  );
};

export default ReviewsList;
