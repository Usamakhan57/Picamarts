import React, { useEffect, useMemo, useState } from 'react';
import {
  Plus, Pencil, Trash2, Power, PowerOff, ChevronRight, ChevronDown,
  Star, Search as SearchIcon, FolderPlus,
} from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import EmptyState from '../../components/EmptyState';
import ConfirmDeleteDialog from '../../components/ConfirmDeleteDialog';
import MediaPickerField from '../../../components/media/MediaPickerField';
import FormSheet, { inputClass, textareaClass } from '../../components/FormSheet';
import AdminSeoFields from '../../components/AdminSeoFields';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '../../../components/ui/dropdown-menu';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../../../components/ui/select';
import { Switch } from '../../../components/ui/switch';
import {
  listAllCategories, createCategory, updateCategory, deleteCategory,
  toggleCategoryActive, getProductCountByCategoryId,
} from '../../../services/adminCategoryService';
import {
  getCategoryTree, flattenCategories, isSelfOrDescendant, getRolledUpCount, getDescendants,
} from '../../../services/categoryTree';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

const ICON_CHOICES = [
  'Frame', 'Image', 'Boxes', 'Palette', 'CalendarDays', 'NotebookPen',
  'Printer', 'Mail', 'PencilRuler', 'Shirt', 'Trophy', 'Leaf', 'Grid3x3',
  'Layers', 'Dumbbell', 'Sparkles',
];

const ROOT_VALUE = '__root__';

const EMPTY = {
  name: '', slug: '', description: '', image: '', icon: 'Sparkles', parentId: null,
  status: 'active', featured: false, showInHeader: true, showOnHomepage: false,
  seoTitle: '', seoDescription: '', displayOrder: 0,
  canonicalUrl: '', metaKeywords: [], ogImage: '', noIndex: false,
};

const slugify = (s) => s.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

const ToggleRow = ({ label, description, checked, onChange }) => (
  <div className="flex items-center justify-between py-2.5 border-b border-border last:border-0">
    <div>
      <p className="text-sm font-medium">{label}</p>
      {description && <p className="text-xs text-muted-foreground mt-0.5">{description}</p>}
    </div>
    <Switch checked={checked} onCheckedChange={onChange} />
  </div>
);

/**
 * Phase 15C, Part 5 — Admin Categories. Wired to the real backend's
 * /categories endpoints (Phase 4) — the tree structure, unlimited
 * nesting, and cycle protection are all enforced server-side by the
 * Category model itself (parentCategory/level/path).
 *
 * Known, disclosed gap: the old mock had a soft-delete Trash (move to
 * trash / restore / permanently delete). The real Category model has
 * no `deletedAt` — DELETE /categories/:id is the only delete
 * operation, is permanent, and the backend refuses it (409) while
 * subcategories still exist — so Trash/Restore is dropped rather than
 * kept as a non-functional relic; the delete dialog explains the real
 * behavior instead. Drag-to-reorder is also dropped (no drag library
 * wired to a real sortOrder-swap here) — reordering is done from the
 * Edit sheet's "Display Order" field instead.
 */
const CategoriesList = () => {
  const { toast } = useToast();
  const [categories, setCategories] = useState([]);
  const [productCounts, setProductCounts] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');
  const [expanded, setExpanded] = useState(() => new Set());

  const [sheetOpen, setSheetOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY);
  const [saving, setSaving] = useState(false);

  const [deleteTarget, setDeleteTarget] = useState(null);
  const [busy, setBusy] = useState(false);

  const load = () => {
    setLoading(true);
    setError('');
    listAllCategories()
      .then((cats) => {
        setCategories(cats);
        setExpanded((prev) => (prev.size ? prev : new Set(cats.map((c) => c.id))));
        getProductCountByCategoryId(cats).then(setProductCounts).catch(() => setProductCounts({}));
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };
  useEffect(load, []);

  const tree = useMemo(() => getCategoryTree(categories), [categories]);
  const flatOptions = useMemo(() => flattenCategories(tree), [tree]);

  const filteredTree = useMemo(() => {
    if (!query.trim()) return tree;
    const needle = query.trim().toLowerCase();
    const matches = categories.filter((c) => c.name.toLowerCase().includes(needle));
    const matchIds = new Set(matches.map((c) => c.id));
    return matches.map((c) => ({ ...c, children: [] })).map((c) => (matchIds.has(c.parentId) ? c : { ...c, parentId: null }));
  }, [query, categories, tree]);

  const toggleExpand = (id) => setExpanded((prev) => {
    const next = new Set(prev);
    if (next.has(id)) next.delete(id); else next.add(id);
    return next;
  });

  const openAdd = (parent = null) => {
    setEditing(null);
    const siblingCount = categories.filter((c) => (c.parentId || null) === (parent?.id || null)).length;
    setForm({ ...EMPTY, parentId: parent?.id || null, displayOrder: siblingCount });
    setSheetOpen(true);
  };
  const openEdit = (row) => { setEditing(row); setForm({ ...EMPTY, ...row }); setSheetOpen(true); };

  const parentOptions = useMemo(() => {
    if (!editing) return flatOptions;
    return flatOptions.filter((c) => !isSelfOrDescendant(categories, editing.id, c.id));
  }, [flatOptions, editing, categories]);

  const handleSubmit = async () => {
    if (!form.name.trim()) { toast({ title: 'Name is required', variant: 'destructive' }); return; }
    setSaving(true);
    try {
      const payload = { ...form, slug: form.slug || slugify(form.name) };
      if (editing) await updateCategory(editing.id, payload);
      else await createCategory(payload);
      toast({ title: editing ? 'Category updated' : 'Category created', description: payload.name });
      setSheetOpen(false);
      load();
    } catch (err) {
      toast({ title: 'Could not save category', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const toggleEnabled = async (row) => {
    try {
      await toggleCategoryActive(row.id);
      toast({ title: row.status === 'active' ? 'Category disabled' : 'Category enabled', description: row.name });
      load();
    } catch (err) {
      toast({ title: 'Could not update category', description: getErrorMessage(err), variant: 'destructive' });
    }
  };

  const requestDelete = (row) => {
    const childCount = getDescendants(categories, row.id).length;
    const productCount = productCounts[row.id] || 0;
    if (childCount > 0) {
      toast({ title: 'Can\u2019t delete this category', description: `It has ${childCount} subcategor${childCount === 1 ? 'y' : 'ies'}. Delete or move them first.`, variant: 'destructive' });
      return;
    }
    if (productCount > 0) {
      toast({ title: 'Can\u2019t delete this category', description: `It has ${productCount} product${productCount === 1 ? '' : 's'} assigned. Reassign them first.`, variant: 'destructive' });
      return;
    }
    setDeleteTarget(row);
  };

  const handleDelete = async () => {
    setBusy(true);
    try {
      await deleteCategory(deleteTarget.id);
      toast({ title: 'Category deleted', description: deleteTarget.name });
      setDeleteTarget(null);
      load();
    } catch (err) {
      toast({ title: 'Could not delete category', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  const totalCount = categories.length;

  const CategoryRow = ({ node, depth }) => {
    const hasChildren = node.children.length > 0;
    const isExpanded = expanded.has(node.id);
    const count = getRolledUpCount(node, productCounts);

    return (
      <div>
        <div
          className="flex items-center gap-2 px-3 py-2.5 rounded-xl hover:bg-secondary/50 transition-colors"
          style={{ marginLeft: depth * 28 }}
        >
          <button
            type="button"
            onClick={() => hasChildren && toggleExpand(node.id)}
            className="w-5 h-5 grid place-items-center shrink-0 text-muted-foreground"
            aria-label={hasChildren ? (isExpanded ? 'Collapse' : 'Expand') : undefined}
          >
            {hasChildren && (isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />)}
          </button>

          {node.image ? (
            <img src={node.image} alt="" className="w-9 h-9 rounded-lg object-cover shrink-0" />
          ) : (
            <span className="w-9 h-9 rounded-lg bg-secondary grid place-items-center shrink-0 text-muted-foreground text-xs font-bold">
              {node.name.charAt(0)}
            </span>
          )}

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <p className="font-medium text-sm truncate">{node.name}</p>
              {node.featured && <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400 shrink-0" />}
            </div>
            <p className="text-xs text-muted-foreground">/{node.slug}</p>
          </div>

          <span className="text-xs text-muted-foreground w-20 text-right shrink-0">{count.toLocaleString()} items</span>

          <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full shrink-0 ${node.status === 'active' ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-600'}`}>
            {node.status === 'active' ? 'Enabled' : 'Disabled'}
          </span>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="p-1.5 rounded-lg hover:bg-secondary transition-colors shrink-0" aria-label={`Actions for ${node.name}`}>
                <ChevronDown className="w-4 h-4" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => openEdit(node)}><Pencil className="w-4 h-4 mr-2" /> Edit</DropdownMenuItem>
              <DropdownMenuItem onClick={() => openAdd(node)}><FolderPlus className="w-4 h-4 mr-2" /> Add Subcategory</DropdownMenuItem>
              <DropdownMenuItem onClick={() => toggleEnabled(node)}>
                {node.status === 'active' ? <PowerOff className="w-4 h-4 mr-2" /> : <Power className="w-4 h-4 mr-2" />}
                {node.status === 'active' ? 'Disable' : 'Enable'}
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => requestDelete(node)} className="text-red-600 focus:text-red-600">
                <Trash2 className="w-4 h-4 mr-2" /> Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {hasChildren && isExpanded && (
          <div>
            {node.children.map((child) => <CategoryRow key={child.id} node={child} depth={depth + 1} />)}
          </div>
        )}
      </div>
    );
  };

  return (
    <div>
      <PageHeader
        title="Categories"
        description={`${totalCount} categories`}
        actions={
          <button onClick={() => openAdd(null)} className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-full brand-gradient text-white text-sm font-semibold soft-shadow">
            <Plus className="w-4 h-4" /> Add Category
          </button>
        }
      />

      <div className="bg-white rounded-2xl border border-border">
        <div className="flex items-center gap-2 bg-secondary/60 rounded-full px-3.5 py-2 m-4 max-w-sm">
          <SearchIcon className="w-4 h-4 text-muted-foreground shrink-0" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search categories…"
            className="bg-transparent outline-none text-sm w-full placeholder:text-muted-foreground"
          />
        </div>

        {loading ? (
          <p className="text-sm text-muted-foreground p-6">Loading…</p>
        ) : error ? (
          <div className="p-8 text-center">
            <p className="text-sm text-destructive mb-3">{error}</p>
            <button onClick={load} className="text-sm font-semibold text-primary hover:underline">Try again</button>
          </div>
        ) : filteredTree.length === 0 ? (
          <EmptyState title="No categories found" description="Try a different search, or add your first category." />
        ) : (
          <div className="px-2 pb-4 space-y-0.5">
            {filteredTree.map((node) => <CategoryRow key={node.id} node={node} depth={0} />)}
          </div>
        )}
      </div>

      <FormSheet
        open={sheetOpen}
        onOpenChange={setSheetOpen}
        title={editing ? 'Edit Category' : 'Add Category'}
        onSubmit={handleSubmit}
        submitting={saving}
      >
        <MediaPickerField label="Image (optional)" value={form.image} onChange={(v) => setForm((f) => ({ ...f, image: v }))} modalTitle="Select Category Image" />
        <div>
          <label className="block text-sm font-medium mb-1.5">Category Name</label>
          <input value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} className={inputClass} placeholder="e.g. Wall Arts" />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1.5">Slug</label>
          <input value={form.slug} onChange={(e) => setForm((f) => ({ ...f, slug: e.target.value }))} className={inputClass} placeholder="auto-generated if left blank" />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1.5">Parent Category</label>
          <Select
            value={form.parentId || ROOT_VALUE}
            onValueChange={(v) => setForm((f) => ({ ...f, parentId: v === ROOT_VALUE ? null : v }))}
          >
            <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value={ROOT_VALUE}>— None (Top Level) —</SelectItem>
              {parentOptions.map((c) => (
                <SelectItem key={c.id} value={c.id}>{'\u2014 '.repeat(c.depth)}{c.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1.5">Display Order</label>
          <input type="number" value={form.displayOrder} onChange={(e) => setForm((f) => ({ ...f, displayOrder: Number(e.target.value) || 0 }))} className={inputClass} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1.5">Description</label>
          <textarea value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} className={textareaClass} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1.5">Icon</label>
          <Select value={form.icon} onValueChange={(v) => setForm((f) => ({ ...f, icon: v }))}>
            <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
            <SelectContent>
              {ICON_CHOICES.map((i) => <SelectItem key={i} value={i}>{i}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1.5">Status</label>
          <Select value={form.status} onValueChange={(v) => setForm((f) => ({ ...f, status: v }))}>
            <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="active">Enabled</SelectItem>
              <SelectItem value="inactive">Disabled</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="border-t border-border pt-2">
          <ToggleRow label="Featured" description="Highlight this category across the storefront." checked={form.featured} onChange={(v) => setForm((f) => ({ ...f, featured: v }))} />
          <ToggleRow label="Show in Header" description="Include in the header mega menu and mobile menu." checked={form.showInHeader} onChange={(v) => setForm((f) => ({ ...f, showInHeader: v }))} />
        </div>

        <div className="border-t border-border pt-4 space-y-4">
          <p className="text-sm font-semibold">SEO</p>
          <AdminSeoFields
            value={form}
            onChange={(patch) => setForm((f) => ({ ...f, ...patch }))}
            titlePlaceholder="Defaults to the category name if left blank"
          />
        </div>
      </FormSheet>

      <ConfirmDeleteDialog
        open={!!deleteTarget}
        onOpenChange={(v) => !v && setDeleteTarget(null)}
        title="Delete this category?"
        description={deleteTarget ? `"${deleteTarget.name}" will be permanently removed. This cannot be undone.` : ''}
        onConfirm={handleDelete}
        busy={busy}
      />
    </div>
  );
};

export default CategoriesList;
