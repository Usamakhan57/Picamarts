import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Plus, Pencil, Trash2, Eye, Star, UploadCloud, EyeOff, Package, Search,
} from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import EmptyState from '../../components/EmptyState';
import StatusBadge from '../../components/StatusBadge';
import ConfirmDeleteDialog from '../../components/ConfirmDeleteDialog';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../../../components/ui/select';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '../../../components/ui/dropdown-menu';
import { Checkbox } from '../../../components/ui/checkbox';
import Pagination from '../../../pages/seller/components/Pagination';
import {
  listAdminProducts, deleteAdminProduct, changeAdminProductStatus,
  bulkDeleteAdminProducts, bulkChangeAdminProductStatus,
} from '../../../services/adminProductService';
import { listAllCategories } from '../../../services/adminCategoryService';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

const PAGE_SIZE = 20;

/**
 * Phase 15C, Part 5 — Admin Product Management. Wired to the real
 * backend's /products/admin listing (Phase 5) — search/filter/sort/
 * pagination are all server-side (this list can hold thousands of
 * products, unlike Categories/Brands/Collections, so it does NOT reuse
 * the client-side DataTable component; same "reusable server-paginated
 * table" convention as UsersList.jsx / SellersList.jsx from Part 3/4).
 *
 * No bulk-action endpoint exists on the backend — the bulk Delete /
 * Publish / Unpublish actions below are sequential loops over the real
 * single-item endpoints (see adminProductService.js), not a fabricated
 * backend feature.
 */
const ProductsList = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [meta, setMeta] = useState({ totalPages: 1, totalItems: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [query, setQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [status, setStatus] = useState('all');
  const [category, setCategory] = useState('all');
  const [stockStatus, setStockStatus] = useState('all');
  const [page, setPage] = useState(1);

  const [selected, setSelected] = useState([]);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [busy, setBusy] = useState(false);
  const [bulkBusy, setBulkBusy] = useState(false);

  useEffect(() => { listAllCategories().then(setCategories).catch(() => setCategories([])); }, []);

  useEffect(() => {
    const t = setTimeout(() => { setDebouncedQuery(query); setPage(1); }, 350);
    return () => clearTimeout(t);
  }, [query]);

  useEffect(() => { setPage(1); }, [status, category, stockStatus]);

  const load = () => {
    setLoading(true);
    setError('');
    const params = { page, limit: PAGE_SIZE, sort: 'newest' };
    if (debouncedQuery.trim()) params.q = debouncedQuery.trim();
    if (status !== 'all') params.status = status;
    if (category !== 'all') params.category = category;
    if (stockStatus !== 'all') params.stockStatus = stockStatus;

    listAdminProducts(params)
      .then(({ products: rows, pagination }) => {
        setProducts(rows);
        setMeta(pagination || { totalPages: 1, totalItems: rows.length });
        setSelected([]);
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };

  useEffect(load, [page, debouncedQuery, status, category, stockStatus]); // eslint-disable-line react-hooks/exhaustive-deps

  const categoryName = (row) => row.categoryName || categories.find((c) => c.id === row.categoryId)?.name || '—';

  const togglePublish = async (row) => {
    const next = row.status === 'published' ? 'draft' : 'published';
    try {
      await changeAdminProductStatus(row.id, next);
      toast({ title: next === 'published' ? 'Product published' : 'Product unpublished', description: row.title });
      load();
    } catch (err) {
      toast({ title: 'Could not update status', description: getErrorMessage(err), variant: 'destructive' });
    }
  };

  const toggleFeatured = async (row) => {
    try {
      const { updateAdminProduct } = await import('../../../services/adminProductService');
      await updateAdminProduct(row.id, { featured: !row.featured });
      toast({ title: !row.featured ? 'Product featured' : 'Product unfeatured', description: row.title });
      load();
    } catch (err) {
      toast({ title: 'Could not update product', description: getErrorMessage(err), variant: 'destructive' });
    }
  };

  const handleDelete = async () => {
    setBusy(true);
    try {
      await deleteAdminProduct(deleteTarget.id);
      toast({ title: 'Product deleted', description: deleteTarget.title });
      setDeleteTarget(null);
      load();
    } catch (err) {
      toast({ title: 'Could not delete product', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  const runBulk = async (action, label) => {
    setBulkBusy(true);
    try {
      await action(selected);
      toast({ title: `${selected.length} product${selected.length === 1 ? '' : 's'} ${label}` });
      setSelected([]);
      load();
    } catch (err) {
      toast({ title: 'Bulk action failed partway through', description: getErrorMessage(err), variant: 'destructive' });
      load();
    } finally {
      setBulkBusy(false);
    }
  };

  const allOnPageSelected = products.length > 0 && products.every((p) => selected.includes(p.id));
  const toggleAll = () => setSelected(allOnPageSelected ? [] : products.map((p) => p.id));
  const toggleOne = (id) => setSelected((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));

  return (
    <div>
      <PageHeader
        title="Products"
        description={`${meta.totalItems ?? products.length} products across the marketplace`}
        actions={
          <button
            onClick={() => navigate('/admin/products/new')}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-full brand-gradient text-white text-sm font-semibold soft-shadow"
          >
            <Plus className="w-4 h-4" /> Add Product
          </button>
        }
      />

      <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-4">
        <div className="flex items-center gap-2 bg-secondary/60 rounded-full px-3.5 py-2 flex-1 max-w-sm">
          <Search className="w-4 h-4 text-muted-foreground shrink-0" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search title or SKU…"
            className="bg-transparent outline-none text-sm w-full placeholder:text-muted-foreground"
          />
        </div>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-[160px] rounded-full text-sm"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="published">Published</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="archived">Archived</SelectItem>
            <SelectItem value="deleted">Trash</SelectItem>
          </SelectContent>
        </Select>
        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger className="w-[170px] rounded-full text-sm"><SelectValue placeholder="Category" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {categories.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={stockStatus} onValueChange={setStockStatus}>
          <SelectTrigger className="w-[150px] rounded-full text-sm"><SelectValue placeholder="Stock" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Stock</SelectItem>
            <SelectItem value="in_stock">In Stock</SelectItem>
            <SelectItem value="low_stock">Low Stock</SelectItem>
            <SelectItem value="out_of_stock">Out of Stock</SelectItem>
          </SelectContent>
        </Select>

        {selected.length > 0 && (
          <div className="flex items-center gap-2 sm:ml-auto">
            <span className="text-xs text-muted-foreground font-medium">{selected.length} selected</span>
            <button
              disabled={bulkBusy}
              onClick={() => runBulk((ids) => bulkChangeAdminProductStatus(ids, 'published'), 'published')}
              className="text-xs font-semibold px-3 py-1.5 rounded-full hover:bg-secondary transition-colors disabled:opacity-50"
            >
              Publish
            </button>
            <button
              disabled={bulkBusy}
              onClick={() => runBulk((ids) => bulkChangeAdminProductStatus(ids, 'draft'), 'unpublished')}
              className="text-xs font-semibold px-3 py-1.5 rounded-full hover:bg-secondary transition-colors disabled:opacity-50"
            >
              Unpublish
            </button>
            <button
              disabled={bulkBusy}
              onClick={() => runBulk(bulkDeleteAdminProducts, 'deleted')}
              className="text-xs font-semibold px-3 py-1.5 rounded-full text-red-600 hover:bg-red-50 transition-colors disabled:opacity-50"
            >
              Delete
            </button>
          </div>
        )}
      </div>

      <div className="bg-white rounded-2xl border border-border overflow-hidden">
        {loading ? (
          <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>
        ) : error ? (
          <div className="p-8 text-center">
            <p className="text-sm text-destructive mb-3">{error}</p>
            <button onClick={load} className="text-sm font-semibold text-primary hover:underline">Try again</button>
          </div>
        ) : products.length === 0 ? (
          <EmptyState icon={Package} title="No products found" description="Try adjusting your search or filters, or add your first product." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-muted-foreground border-b border-border">
                  <th className="w-10 px-4 py-3"><Checkbox checked={allOnPageSelected} onCheckedChange={toggleAll} aria-label="Select all" /></th>
                  <th className="font-medium px-3 py-3">Product</th>
                  <th className="font-medium px-3 py-3">Category</th>
                  <th className="font-medium px-3 py-3">Price</th>
                  <th className="font-medium px-3 py-3">Stock</th>
                  <th className="font-medium px-3 py-3">Status</th>
                  <th className="font-medium px-3 py-3 w-10"><span className="sr-only">Actions</span></th>
                </tr>
              </thead>
              <tbody>
                {products.map((row) => (
                  <tr key={row.id} className="border-b border-border last:border-0 hover:bg-secondary/30">
                    <td className="px-4 py-3" data-no-row-click>
                      <Checkbox checked={selected.includes(row.id)} onCheckedChange={() => toggleOne(row.id)} aria-label="Select row" />
                    </td>
                    <td className="px-3 py-3 cursor-pointer" onClick={() => navigate(`/admin/products/${row.id}/edit`)}>
                      <div className="flex items-center gap-3 min-w-[220px]">
                        {row.thumbnailUrl ? (
                          <img src={row.thumbnailUrl} alt="" className="w-10 h-10 rounded-lg object-cover shrink-0" />
                        ) : (
                          <span className="w-10 h-10 rounded-lg bg-secondary grid place-items-center shrink-0 text-muted-foreground"><Package className="w-4 h-4" /></span>
                        )}
                        <div className="min-w-0">
                          <p className="font-medium truncate flex items-center gap-1.5">
                            {row.title}
                            {row.featured && <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400 shrink-0" />}
                          </p>
                          <p className="text-xs text-muted-foreground">{row.sku || '—'}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-3 py-3 text-muted-foreground">{categoryName(row)}</td>
                    <td className="px-3 py-3">
                      {row.salePrice
                        ? (<span><span className="line-through text-muted-foreground mr-1">${row.price.toFixed(2)}</span><span className="font-medium text-emerald-700">${row.salePrice.toFixed(2)}</span></span>)
                        : `$${(row.price || 0).toFixed(2)}`}
                    </td>
                    <td className="px-3 py-3">
                      <span className={row.stock === 0 ? 'text-red-600 font-medium' : row.stock <= row.lowStockThreshold ? 'text-amber-600 font-medium' : ''}>
                        {row.stock}
                      </span>
                    </td>
                    <td className="px-3 py-3"><StatusBadge status={row.status} /></td>
                    <td className="px-3 py-3" data-no-row-click>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <button className="p-1.5 rounded-lg hover:bg-secondary transition-colors" aria-label="Row actions">⋯</button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => navigate(`/admin/products/${row.id}/edit`)}><Pencil className="w-4 h-4 mr-2" /> Edit</DropdownMenuItem>
                          {row.slug && <DropdownMenuItem onClick={() => window.open(`/product/${row.slug}`, '_blank')}><Eye className="w-4 h-4 mr-2" /> View on Store</DropdownMenuItem>}
                          {row.status !== 'deleted' && (
                            <>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onClick={() => togglePublish(row)}>
                                {row.status === 'published' ? <EyeOff className="w-4 h-4 mr-2" /> : <UploadCloud className="w-4 h-4 mr-2" />}
                                {row.status === 'published' ? 'Unpublish' : 'Publish'}
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => toggleFeatured(row)}><Star className="w-4 h-4 mr-2" /> {row.featured ? 'Unfeature' : 'Feature'}</DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onClick={() => setDeleteTarget(row)} className="text-red-600 focus:text-red-600"><Trash2 className="w-4 h-4 mr-2" /> Delete</DropdownMenuItem>
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Pagination page={page} totalPages={meta.totalPages || 1} onPageChange={setPage} />

      <ConfirmDeleteDialog
        open={!!deleteTarget}
        onOpenChange={(v) => !v && setDeleteTarget(null)}
        title="Delete this product?"
        description={deleteTarget ? `"${deleteTarget.title}" will be moved to Trash (soft-deleted) — this cannot be undone from the admin panel.` : ''}
        onConfirm={handleDelete}
        busy={busy}
      />
    </div>
  );
};

export default ProductsList;
