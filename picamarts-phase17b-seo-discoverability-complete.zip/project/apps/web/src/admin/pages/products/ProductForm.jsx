import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Star, UploadCloud, X } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import ImageUploadInput from '../../components/ImageUploadInput';
import TagsInput from '../../components/TagsInput';
import AdminSeoFields from '../../components/AdminSeoFields';
import { inputClass, textareaClass } from '../../components/FormSheet';
import FormTabs from '../../components/product-editor/FormTabs';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../../../components/ui/select';
import { Checkbox } from '../../../components/ui/checkbox';
import {
  getAdminProduct, createAdminProduct, updateAdminProduct,
  uploadProductThumbnail, uploadProductGalleryImages, removeProductGalleryImage,
} from '../../../services/adminProductService';
import { listAllCategories } from '../../../services/adminCategoryService';
import { listAllBrands } from '../../../services/adminBrandService';
import { listAllCollections } from '../../../services/adminCollectionService';
import { resolveTagsToIds } from '../../../services/adminTagService';
import { flattenCategories, getCategoryTree } from '../../../services/categoryTree';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

/**
 * Phase 15C, Part 5 — Admin Product Form. Rewritten against the real
 * backend's Product schema (apps/api/src/models/Product.js /
 * validators/product.validator.js) — the old mock form modeled dozens
 * of fields the backend has no concept of (multi-currency, tax class,
 * cost/margin, discount percent, barcode, unlimited-stock toggle,
 * licensing editor, product variations/options, live demo URL,
 * changelog, extra digital-file slots, OG image, canonical URL,
 * sub-categories, trending/best-seller/new-arrival flags, a
 * multi-collection membership picker). None of those are sent here —
 * this form is now a straightforward editor for what the real Product
 * document actually stores, matching the same "drop fields the backend
 * doesn't model" decision already made for
 * pages/seller/api/sellerProducts.js.
 *
 * Known, disclosed gap: thumbnail/gallery uploads need a real product
 * id (Phase 6's /products/:id/thumbnail, /products/:id/images), so
 * real Cloudinary upload only happens once a product exists (Edit
 * mode). Create mode keeps a local-preview-only image picker (same
 * gap flagged in services/sellerProductService.js) — save the product
 * first, then add images from the Edit page.
 */
const TABS = ['Basic Info', 'Pricing & Inventory', 'Shipping', 'Media', 'SEO'];

const EMPTY = {
  title: '', slug: '', shortDescription: '', description: '',
  category: '', brand: '', collection: '', tags: [],
  type: 'digital', condition: 'new',
  basePrice: '', salePrice: '', currency: 'USD',
  sku: '', stock: '', reservedStock: 0, lowStockThreshold: '5', allowBackorder: false,
  version: '', fileSize: '', compatibleWith: [], downloadLimit: '', downloadExpiryDays: '',
  weightValue: '', weightUnit: 'kg',
  dimLength: '', dimWidth: '', dimHeight: '', dimUnit: 'cm',
  shippingClass: '',
  seoTitle: '', seoDescription: '',
  canonicalUrl: '', metaKeywords: [], ogImage: '', noIndex: false,
  status: 'draft', featured: false,
};

const slugify = (s) => s.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
const NONE = '__none__';

const ProductForm = () => {
  const { id } = useParams();
  const isEdit = Boolean(id);
  const navigate = useNavigate();
  const { toast } = useToast();

  const [form, setForm] = useState(EMPTY);
  const [tab, setTab] = useState(TABS[0]);
  const [categories, setCategories] = useState([]);
  const [brands, setBrands] = useState([]);
  const [collections, setCollections] = useState([]);
  const [thumbnailUrl, setThumbnailUrl] = useState('');
  const [gallery, setGallery] = useState([]);
  const [pendingThumbnail, setPendingThumbnail] = useState('');
  const [loading, setLoading] = useState(isEdit);
  const [saving, setSaving] = useState(false);
  const [uploadingThumb, setUploadingThumb] = useState(false);
  const [uploadingGallery, setUploadingGallery] = useState(false);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    listAllCategories().then(setCategories).catch(() => setCategories([]));
    listAllBrands().then(setBrands).catch(() => setBrands([]));
    listAllCollections().then(setCollections).catch(() => setCollections([]));
  }, []);

  const categoryOptions = useMemo(() => flattenCategories(getCategoryTree(categories)), [categories]);

  useEffect(() => {
    if (!isEdit) return;
    getAdminProduct(id).then((p) => {
      setForm({
        ...EMPTY,
        title: p.title || '',
        slug: p.slug || '',
        shortDescription: p.shortDescription || '',
        description: p.description || '',
        category: p.categoryId || '',
        brand: p.brandId || '',
        collection: p.collectionId || '',
        tags: p.tagNames || [],
        type: p.type || 'digital',
        condition: p.condition || 'new',
        basePrice: String(p.basePrice ?? ''),
        salePrice: p.salePrice != null ? String(p.salePrice) : '',
        currency: p.currency || 'USD',
        sku: p.sku || '',
        stock: String(p.stock ?? 0),
        reservedStock: p.reservedStock || 0,
        lowStockThreshold: String(p.lowStockThreshold ?? 5),
        allowBackorder: !!p.allowBackorder,
        version: p.version || '',
        fileSize: p.fileSize ? String(p.fileSize) : '',
        compatibleWith: p.compatibleWith || [],
        downloadLimit: p.downloadLimit != null ? String(p.downloadLimit) : '',
        downloadExpiryDays: p.downloadExpiryDays != null ? String(p.downloadExpiryDays) : '',
        weightValue: p.weight?.value ? String(p.weight.value) : '',
        weightUnit: p.weight?.unit || 'kg',
        dimLength: p.dimensions?.length ? String(p.dimensions.length) : '',
        dimWidth: p.dimensions?.width ? String(p.dimensions.width) : '',
        dimHeight: p.dimensions?.height ? String(p.dimensions.height) : '',
        dimUnit: p.dimensions?.unit || 'cm',
        shippingClass: p.shippingClass || '',
        seoTitle: p.seoTitle || '',
        seoDescription: p.seoDescription || '',
        canonicalUrl: p.canonicalUrl || '',
        metaKeywords: p.metaKeywords || [],
        ogImage: p.ogImage || '',
        noIndex: !!p.noIndex,
        status: p.status || 'draft',
        featured: !!p.featured,
      });
      setThumbnailUrl(p.thumbnailUrl || '');
      setGallery(p.galleryUrls || []);
      setLoading(false);
    }).catch((err) => {
      toast({ title: 'Could not load product', description: getErrorMessage(err), variant: 'destructive' });
      setLoading(false);
    });
  }, [id, isEdit]); // eslint-disable-line react-hooks/exhaustive-deps

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e?.target ? e.target.value : e }));

  const validate = () => {
    const errs = {};
    if (!form.title.trim()) errs.title = 'Title is required';
    if (!form.category) errs.category = 'Select a category';
    if (!form.basePrice || Number(form.basePrice) <= 0) errs.basePrice = 'Enter a valid price';
    if (form.salePrice && Number(form.salePrice) >= Number(form.basePrice)) errs.salePrice = 'Sale price must be lower than base price';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const buildPayload = (overrides = {}) => {
    const payload = {
      title: form.title,
      slug: form.slug || slugify(form.title),
      shortDescription: form.shortDescription || undefined,
      description: form.description || undefined,
      category: form.category,
      brand: form.brand || null,
      collection: form.collection || null,
      type: form.type,
      condition: form.condition,
      basePrice: Number(form.basePrice),
      salePrice: form.salePrice ? Number(form.salePrice) : null,
      currency: form.currency || 'USD',
      sku: form.sku || undefined,
      stock: Number(form.stock || 0),
      lowStockThreshold: Number(form.lowStockThreshold || 5),
      allowBackorder: !!form.allowBackorder,
      version: form.version || undefined,
      fileSize: form.fileSize ? Number(form.fileSize) : undefined,
      compatibleWith: form.compatibleWith,
      downloadLimit: form.downloadLimit !== '' ? Number(form.downloadLimit) : null,
      downloadExpiryDays: form.downloadExpiryDays !== '' ? Number(form.downloadExpiryDays) : null,
      weight: { value: Number(form.weightValue || 0), unit: form.weightUnit },
      dimensions: {
        length: Number(form.dimLength || 0), width: Number(form.dimWidth || 0),
        height: Number(form.dimHeight || 0), unit: form.dimUnit,
      },
      shippingClass: form.shippingClass || undefined,
      seoTitle: form.seoTitle || undefined,
      seoDescription: form.seoDescription || undefined,
      canonicalUrl: form.canonicalUrl || undefined,
      metaKeywords: form.metaKeywords?.length ? form.metaKeywords : undefined,
      ogImage: form.ogImage || undefined,
      noIndex: form.noIndex,
      status: form.status,
      featured: form.featured,
      ...overrides,
    };
    Object.keys(payload).forEach((key) => payload[key] === undefined && delete payload[key]);
    return payload;
  };

  const persist = async (overrides, successMsg) => {
    setSaving(true);
    try {
      const tagIds = await resolveTagsToIds(form.tags);
      const payload = buildPayload({ ...overrides, tags: tagIds });
      if (isEdit) {
        await updateAdminProduct(id, payload);
        toast({ title: successMsg, description: form.title });
      } else {
        const created = await createAdminProduct(payload);
        toast({ title: successMsg, description: form.title });
        navigate(`/admin/products/${created.id}/edit`);
        return;
      }
      navigate('/admin/products');
    } catch (err) {
      toast({ title: 'Something went wrong', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    await persist({}, isEdit ? 'Product updated' : 'Product created');
  };

  const handlePublishToggle = async () => {
    if (!validate()) return;
    const nextStatus = form.status === 'published' ? 'draft' : 'published';
    setForm((f) => ({ ...f, status: nextStatus }));
    await persist({ status: nextStatus }, nextStatus === 'published' ? 'Product published' : 'Product unpublished');
  };

  const handleFeatureToggle = async () => {
    const next = !form.featured;
    setForm((f) => ({ ...f, featured: next }));
    if (!isEdit) return;
    try {
      await updateAdminProduct(id, { featured: next });
      toast({ title: next ? 'Product featured' : 'Product unfeatured', description: form.title });
    } catch (err) {
      toast({ title: 'Could not update product', description: getErrorMessage(err), variant: 'destructive' });
    }
  };

  const handleThumbnailUpload = async (file) => {
    if (!file) return;
    setUploadingThumb(true);
    try {
      const updated = await uploadProductThumbnail(id, file);
      setThumbnailUrl(updated.thumbnailUrl);
      toast({ title: 'Thumbnail updated' });
    } catch (err) {
      toast({ title: 'Upload failed', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setUploadingThumb(false);
    }
  };

  const handleGalleryUpload = async (files) => {
    if (!files || !files.length) return;
    setUploadingGallery(true);
    try {
      const updated = await uploadProductGalleryImages(id, files);
      setGallery(updated.galleryUrls);
      toast({ title: 'Gallery updated' });
    } catch (err) {
      toast({ title: 'Upload failed', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setUploadingGallery(false);
    }
  };

  const handleRemoveGalleryImage = async (imageId) => {
    try {
      const updated = await removeProductGalleryImage(id, imageId);
      setGallery(updated.galleryUrls);
    } catch (err) {
      toast({ title: 'Could not remove image', description: getErrorMessage(err), variant: 'destructive' });
    }
  };

  if (loading) return <p className="text-sm text-muted-foreground">Loading…</p>;

  return (
    <div>
      <PageHeader
        title={isEdit ? 'Edit Product' : 'Add Product'}
        backTo="/admin/products"
        backLabel="Products"
        actions={
          isEdit && (
            <>
              <button
                type="button"
                onClick={handleFeatureToggle}
                className={`inline-flex items-center gap-1.5 px-4 py-2.5 rounded-full border text-sm font-semibold transition-colors ${form.featured ? 'border-amber-300 bg-amber-50 text-amber-700' : 'border-border hover:bg-secondary'}`}
              >
                <Star className={`w-4 h-4 ${form.featured ? 'fill-amber-400 text-amber-400' : ''}`} /> {form.featured ? 'Featured' : 'Feature'}
              </button>
              <button
                type="button"
                onClick={handlePublishToggle}
                disabled={saving}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-full border border-border text-sm font-semibold hover:bg-secondary transition-colors disabled:opacity-60"
              >
                {form.status === 'published' ? 'Unpublish' : 'Publish'}
              </button>
            </>
          )
        }
      />

      <form onSubmit={handleSubmit} className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="bg-white rounded-2xl border border-border p-5">
            <FormTabs tabs={TABS} active={tab} onChange={setTab} />

            {tab === 'Basic Info' && (
              <div className="space-y-5">
                <div>
                  <label className="block text-sm font-medium mb-1.5">Product Title</label>
                  <input value={form.title} onChange={set('title')} className={inputClass} placeholder="e.g. Boho Arch Wall Art Set" />
                  {errors.title && <p className="text-xs text-red-600 mt-1">{errors.title}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5">Slug</label>
                  <input value={form.slug} onChange={set('slug')} className={inputClass} placeholder="auto-generated from title if left blank" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5">Short Description</label>
                  <textarea value={form.shortDescription} onChange={set('shortDescription')} className={`${textareaClass} min-h-[60px]`} placeholder="One or two sentences shown in listings and search…" maxLength={300} />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5">Full Description</label>
                  <textarea value={form.description} onChange={set('description')} className={textareaClass} placeholder="Describe this product…" />
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Category</label>
                    <Select value={form.category} onValueChange={(v) => setForm((f) => ({ ...f, category: v }))}>
                      <SelectTrigger className="rounded-xl"><SelectValue placeholder="Select category" /></SelectTrigger>
                      <SelectContent>
                        {categoryOptions.map((c) => (
                          <SelectItem key={c.id} value={c.id}>{'\u2014 '.repeat(c.depth)}{c.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.category && <p className="text-xs text-red-600 mt-1">{errors.category}</p>}
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Brand</label>
                    <Select value={form.brand || NONE} onValueChange={(v) => setForm((f) => ({ ...f, brand: v === NONE ? '' : v }))}>
                      <SelectTrigger className="rounded-xl"><SelectValue placeholder="Select brand" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value={NONE}>— None —</SelectItem>
                        {brands.map((b) => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5">Collection</label>
                  <Select value={form.collection || NONE} onValueChange={(v) => setForm((f) => ({ ...f, collection: v === NONE ? '' : v }))}>
                    <SelectTrigger className="rounded-xl"><SelectValue placeholder="Select collection" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value={NONE}>— None —</SelectItem>
                      {collections.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground mt-1">A product belongs to at most one collection.</p>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5">Tags</label>
                  <TagsInput value={form.tags} onChange={(v) => setForm((f) => ({ ...f, tags: v }))} placeholder="e.g. printable, wall-art…" />
                  <p className="text-xs text-muted-foreground mt-1">New tag names are created automatically on save.</p>
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Type</label>
                    <Select value={form.type} onValueChange={(v) => setForm((f) => ({ ...f, type: v }))}>
                      <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="digital">Digital</SelectItem>
                        <SelectItem value="physical">Physical</SelectItem>
                        <SelectItem value="both">Both</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Condition</label>
                    <Select value={form.condition} onValueChange={(v) => setForm((f) => ({ ...f, condition: v }))}>
                      <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="new">New</SelectItem>
                        <SelectItem value="used">Used</SelectItem>
                        <SelectItem value="refurbished">Refurbished</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5">Product Status</label>
                  <Select value={form.status} onValueChange={(v) => setForm((f) => ({ ...f, status: v }))}>
                    <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="published">Published</SelectItem>
                      <SelectItem value="draft">Draft (Unpublished)</SelectItem>
                      <SelectItem value="archived">Archived</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <Checkbox checked={form.featured} onCheckedChange={(v) => setForm((f) => ({ ...f, featured: !!v }))} /> Featured Product
                </label>
              </div>
            )}

            {tab === 'Pricing & Inventory' && (
              <div className="space-y-5">
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Base Price</label>
                    <input type="number" step="0.01" min="0" value={form.basePrice} onChange={set('basePrice')} className={inputClass} />
                    {errors.basePrice && <p className="text-xs text-red-600 mt-1">{errors.basePrice}</p>}
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Sale Price</label>
                    <input type="number" step="0.01" min="0" value={form.salePrice} onChange={set('salePrice')} className={inputClass} placeholder="Optional" />
                    {errors.salePrice && <p className="text-xs text-red-600 mt-1">{errors.salePrice}</p>}
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Currency</label>
                    <input value={form.currency} onChange={(e) => setForm((f) => ({ ...f, currency: e.target.value.toUpperCase().slice(0, 3) }))} className={inputClass} placeholder="USD" />
                  </div>
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1.5">SKU</label>
                    <input value={form.sku} onChange={set('sku')} className={inputClass} placeholder="e.g. PM-WA-001" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Stock Quantity</label>
                    <input type="number" min="0" value={form.stock} onChange={set('stock')} className={inputClass} />
                  </div>
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Low Stock Alert At</label>
                    <input type="number" min="0" value={form.lowStockThreshold} onChange={set('lowStockThreshold')} className={inputClass} />
                  </div>
                  <label className="flex items-center gap-2.5 cursor-pointer mt-6">
                    <Checkbox checked={form.allowBackorder} onCheckedChange={(v) => setForm((f) => ({ ...f, allowBackorder: !!v }))} />
                    <span className="text-sm font-semibold">Allow Backorder</span>
                  </label>
                </div>
                <div className="border-t border-border pt-4">
                  <h4 className="text-sm font-semibold mb-3">Digital File Details</h4>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1.5">Version</label>
                      <input value={form.version} onChange={set('version')} className={inputClass} placeholder="1.0.0" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1.5">File Size (bytes)</label>
                      <input type="number" min="0" value={form.fileSize} onChange={set('fileSize')} className={inputClass} />
                    </div>
                  </div>
                  <div className="grid sm:grid-cols-2 gap-4 mt-4">
                    <div>
                      <label className="block text-sm font-medium mb-1.5">Download Limit</label>
                      <input type="number" min="0" value={form.downloadLimit} onChange={set('downloadLimit')} className={inputClass} placeholder="Unlimited if blank" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1.5">Download Expiry (days)</label>
                      <input type="number" min="0" value={form.downloadExpiryDays} onChange={set('downloadExpiryDays')} className={inputClass} placeholder="Never expires if blank" />
                    </div>
                  </div>
                  <div className="mt-4">
                    <label className="block text-sm font-medium mb-1.5">Compatible With</label>
                    <TagsInput value={form.compatibleWith} onChange={(v) => setForm((f) => ({ ...f, compatibleWith: v }))} placeholder="e.g. photoshop, canva…" />
                  </div>
                </div>
              </div>
            )}

            {tab === 'Shipping' && (
              <div className="space-y-5">
                <p className="text-xs text-muted-foreground">Only used when Type (Basic Info tab) is Physical or Both — digital-only products ship instantly and ignore these fields.</p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Weight</label>
                    <input type="number" min="0" step="0.01" value={form.weightValue} onChange={set('weightValue')} className={inputClass} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Unit</label>
                    <Select value={form.weightUnit} onValueChange={(v) => setForm((f) => ({ ...f, weightUnit: v }))}>
                      <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="kg">kg</SelectItem>
                        <SelectItem value="g">g</SelectItem>
                        <SelectItem value="lb">lb</SelectItem>
                        <SelectItem value="oz">oz</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Length</label>
                    <input type="number" min="0" step="0.01" value={form.dimLength} onChange={set('dimLength')} className={inputClass} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Width</label>
                    <input type="number" min="0" step="0.01" value={form.dimWidth} onChange={set('dimWidth')} className={inputClass} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Height</label>
                    <input type="number" min="0" step="0.01" value={form.dimHeight} onChange={set('dimHeight')} className={inputClass} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Unit</label>
                    <Select value={form.dimUnit} onValueChange={(v) => setForm((f) => ({ ...f, dimUnit: v }))}>
                      <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cm">cm</SelectItem>
                        <SelectItem value="in">in</SelectItem>
                        <SelectItem value="m">m</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5">Shipping Class</label>
                  <input value={form.shippingClass} onChange={set('shippingClass')} className={inputClass} placeholder="Optional" />
                </div>
              </div>
            )}

            {tab === 'Media' && (
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium mb-1.5">Thumbnail</label>
                  {isEdit ? (
                    <div className="flex items-center gap-4">
                      {thumbnailUrl ? (
                        <img src={thumbnailUrl} alt="" className="w-24 h-24 rounded-xl object-cover border border-border" />
                      ) : (
                        <div className="w-24 h-24 rounded-xl border-2 border-dashed border-border grid place-items-center text-muted-foreground text-xs">None</div>
                      )}
                      <label className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full border border-border text-sm font-semibold hover:bg-secondary cursor-pointer">
                        <UploadCloud className="w-4 h-4" /> {uploadingThumb ? 'Uploading…' : 'Upload'}
                        <input type="file" accept="image/*" className="hidden" disabled={uploadingThumb} onChange={(e) => handleThumbnailUpload(e.target.files?.[0])} />
                      </label>
                    </div>
                  ) : (
                    <>
                      <ImageUploadInput value={pendingThumbnail} onChange={setPendingThumbnail} />
                      <p className="text-xs text-muted-foreground mt-1.5">Preview only — save the product first, then upload the real thumbnail from this Edit page.</p>
                    </>
                  )}
                </div>

                {isEdit && (
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Gallery Images</label>
                    <div className="flex flex-wrap gap-3 mb-3">
                      {gallery.map((img) => (
                        <div key={img.id} className="relative w-20 h-20 rounded-xl overflow-hidden border border-border group">
                          <img src={img.url} alt="" className="w-full h-full object-cover" />
                          <button type="button" onClick={() => handleRemoveGalleryImage(img.id)} className="absolute top-1 right-1 w-5 h-5 rounded-full bg-black/60 text-white grid place-items-center opacity-0 group-hover:opacity-100 transition-opacity">
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                    <label className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full border border-border text-sm font-semibold hover:bg-secondary cursor-pointer">
                      <UploadCloud className="w-4 h-4" /> {uploadingGallery ? 'Uploading…' : 'Add Images'}
                      <input type="file" accept="image/*" multiple className="hidden" disabled={uploadingGallery} onChange={(e) => handleGalleryUpload(e.target.files)} />
                    </label>
                  </div>
                )}
              </div>
            )}

            {tab === 'SEO' && (
              <AdminSeoFields
                value={form}
                onChange={(patch) => setForm((f) => ({ ...f, ...patch }))}
                titlePlaceholder="Defaults to product title if left blank"
              />
            )}
          </div>
        </div>

        <div className="space-y-6">
          <div className="flex flex-col gap-2">
            <button type="submit" disabled={saving} className="w-full px-5 py-3 rounded-full brand-gradient text-white text-sm font-semibold soft-shadow disabled:opacity-60">
              {saving ? 'Saving…' : isEdit ? 'Save Changes' : 'Create Product'}
            </button>
            <button type="button" onClick={() => navigate('/admin/products')} className="w-full px-5 py-3 rounded-full border border-border text-sm font-semibold hover:bg-secondary transition-colors">
              Cancel
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default ProductForm;
