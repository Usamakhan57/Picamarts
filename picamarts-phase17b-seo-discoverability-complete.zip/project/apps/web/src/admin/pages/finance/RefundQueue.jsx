import React, { useEffect, useState } from 'react';
import { Undo2, CheckCircle2, XCircle, RotateCcw, Clock, AlertTriangle, Ban } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import StatCard from '../../components/StatCard';
import EmptyState from '../../components/EmptyState';
import StatusBadge from '../../components/StatusBadge';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '../../../components/ui/dialog';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../../../components/ui/select';
import Pagination from '../../../pages/seller/components/Pagination';
import { getRefundOverview, getRefundQueue, approveRefund, rejectRefund, retryRefund } from '../../../services/adminFinanceService';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

const PAGE_SIZE = 20;
const fmtMoney = (n) => `$${Number(n || 0).toFixed(2)}`;
const fmtDate = (iso) => (iso ? new Date(iso).toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—');

const STATUS_OPTIONS = [
  { value: 'all', label: 'All Statuses' },
  { value: 'pending', label: 'Pending' },
  { value: 'approved', label: 'Approved' },
  { value: 'processing', label: 'Processing' },
  { value: 'completed', label: 'Completed' },
  { value: 'failed', label: 'Failed' },
  { value: 'rejected', label: 'Rejected' },
  { value: 'cancelled', label: 'Cancelled' },
];

/**
 * Phase 16D, Part 3 — Admin Refund Queue. Approving immediately
 * attempts the real Stripe refund server-side (refund.service.js#
 * processApprovedRequest, reusing payment.service.js's Stripe call
 * unmodified) — this page just shows whichever status comes back
 * (COMPLETED or FAILED), same "approve = process, no polling" shape
 * PayoutQueue.jsx already established for withdrawals.
 */
const RefundQueue = () => {
  const { toast } = useToast();
  const [overview, setOverview] = useState(null);
  const [overviewLoading, setOverviewLoading] = useState(true);

  const [requests, setRequests] = useState([]);
  const [meta, setMeta] = useState({ totalPages: 1 });
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState('pending');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [actioningId, setActioningId] = useState(null);
  const [rejectTarget, setRejectTarget] = useState(null);
  const [rejectReason, setRejectReason] = useState('');
  const [rejecting, setRejecting] = useState(false);

  const loadOverview = () => {
    setOverviewLoading(true);
    getRefundOverview()
      .then(setOverview)
      .catch(() => setOverview(null))
      .finally(() => setOverviewLoading(false));
  };
  useEffect(loadOverview, []);

  useEffect(() => { setPage(1); }, [statusFilter]);

  const loadQueue = () => {
    setLoading(true);
    setError('');
    const params = { page, limit: PAGE_SIZE };
    if (statusFilter !== 'all') params.status = statusFilter;
    getRefundQueue(params)
      .then(({ requests: rows, meta: m }) => {
        setRequests(rows || []);
        setMeta(m || { totalPages: 1 });
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };
  useEffect(loadQueue, [page, statusFilter]); // eslint-disable-line react-hooks/exhaustive-deps

  const refreshAll = () => { loadQueue(); loadOverview(); };

  const handleApprove = async (requestId) => {
    setActioningId(requestId);
    try {
      const updated = await approveRefund(requestId);
      if (updated.status === 'completed') {
        toast({ title: 'Refund completed', description: `Stripe refund ${updated.stripeRefundId} succeeded.` });
      } else if (updated.status === 'failed') {
        toast({ title: 'Refund failed', description: updated.failureReason || 'The Stripe refund could not be completed.', variant: 'destructive' });
      } else {
        toast({ title: 'Request approved' });
      }
      refreshAll();
    } catch (err) {
      toast({ title: 'Could not approve request', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setActioningId(null);
    }
  };

  const handleRetry = async (requestId) => {
    setActioningId(requestId);
    try {
      const updated = await retryRefund(requestId);
      if (updated.status === 'completed') {
        toast({ title: 'Retry succeeded', description: `Stripe refund ${updated.stripeRefundId} completed.` });
      } else {
        toast({ title: 'Retry failed again', description: updated.failureReason || 'The Stripe refund failed.', variant: 'destructive' });
      }
      refreshAll();
    } catch (err) {
      toast({ title: 'Could not retry request', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setActioningId(null);
    }
  };

  const handleReject = async () => {
    setRejecting(true);
    try {
      await rejectRefund(rejectTarget.id, rejectReason || undefined);
      toast({ title: 'Refund request rejected' });
      setRejectTarget(null);
      setRejectReason('');
      refreshAll();
    } catch (err) {
      toast({ title: 'Could not reject request', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setRejecting(false);
    }
  };

  return (
    <div>
      <PageHeader title="Refund Queue" description="Buyer refund requests — approve, reject, and retry Stripe refunds." />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard label="Pending" value={overviewLoading ? '—' : (overview?.byStatus?.pending?.count ?? 0)} icon={Clock} />
        <StatCard label="Processing" value={overviewLoading ? '—' : (overview?.byStatus?.processing?.count ?? 0)} icon={Undo2} />
        <StatCard label="Failed" value={overviewLoading ? '—' : (overview?.byStatus?.failed?.count ?? 0)} icon={AlertTriangle} />
        <StatCard label="Completed ($)" value={overviewLoading ? '—' : fmtMoney(overview?.byStatus?.completed?.total)} icon={CheckCircle2} />
      </div>

      <div className="flex justify-end mb-4">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[170px] rounded-full text-sm"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            {STATUS_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="bg-white rounded-2xl border border-border overflow-hidden">
        {loading ? (
          <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>
        ) : error ? (
          <div className="p-8 text-center">
            <p className="text-sm text-destructive mb-3">{error}</p>
            <button onClick={loadQueue} className="text-sm font-semibold text-primary hover:underline">Try again</button>
          </div>
        ) : requests.length === 0 ? (
          <EmptyState icon={Undo2} title="No refund requests found" description="Try adjusting the status filter." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-muted-foreground border-b border-border">
                  <th className="font-medium px-5 py-3">Order</th>
                  <th className="font-medium px-5 py-3">Type / Reason</th>
                  <th className="font-medium px-5 py-3">Amount</th>
                  <th className="font-medium px-5 py-3">Requested</th>
                  <th className="font-medium px-5 py-3">Status</th>
                  <th className="font-medium px-5 py-3 w-32"><span className="sr-only">Actions</span></th>
                </tr>
              </thead>
              <tbody>
                {requests.map((r) => (
                  <tr key={r.id} className="border-b border-border last:border-0 hover:bg-secondary/30">
                    <td className="px-5 py-3 font-mono text-xs text-muted-foreground">{r.order}</td>
                    <td className="px-5 py-3 text-xs">
                      <span className="capitalize">{r.type}</span> · {(r.reason || '').replace(/_/g, ' ')}
                    </td>
                    <td className="px-5 py-3 font-semibold">{fmtMoney(r.requestedAmount)}</td>
                    <td className="px-5 py-3 text-muted-foreground">{fmtDate(r.createdAt)}</td>
                    <td className="px-5 py-3"><StatusBadge status={r.status} /></td>
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-1.5">
                        {r.status === 'pending' && (
                          <>
                            <button
                              onClick={() => handleApprove(r.id)}
                              disabled={actioningId === r.id}
                              className="p-1.5 rounded-lg hover:bg-secondary transition-colors text-emerald-600 disabled:opacity-50"
                              aria-label="Approve"
                              title="Approve & process"
                            >
                              <CheckCircle2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => setRejectTarget(r)}
                              disabled={actioningId === r.id}
                              className="p-1.5 rounded-lg hover:bg-secondary transition-colors text-red-600 disabled:opacity-50"
                              aria-label="Reject"
                              title="Reject"
                            >
                              <XCircle className="w-4 h-4" />
                            </button>
                          </>
                        )}
                        {r.status === 'failed' && (
                          <button
                            onClick={() => handleRetry(r.id)}
                            disabled={actioningId === r.id}
                            className="p-1.5 rounded-lg hover:bg-secondary transition-colors text-blue-600 disabled:opacity-50"
                            aria-label="Retry"
                            title="Retry refund"
                          >
                            <RotateCcw className="w-4 h-4" />
                          </button>
                        )}
                        {!['pending', 'failed'].includes(r.status) && (
                          <span className="text-muted-foreground text-xs inline-flex items-center gap-1">
                            <Ban className="w-3.5 h-3.5" /> —
                          </span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      <Pagination page={page} totalPages={meta.totalPages || 1} onPageChange={setPage} />

      <Dialog open={!!rejectTarget} onOpenChange={(v) => { if (!v) { setRejectTarget(null); setRejectReason(''); } }}>
        <DialogContent className="max-w-md rounded-3xl">
          <DialogTitle>Reject refund request?</DialogTitle>
          <DialogDescription>The buyer will be notified. This cannot be undone.</DialogDescription>
          <form onSubmit={(e) => { e.preventDefault(); handleReject(); }} className="space-y-4 mt-2">
            <div>
              <label className="text-sm font-medium block mb-1.5">Reason (optional)</label>
              <input
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                placeholder="Let the buyer know why"
                className="w-full bg-secondary/60 rounded-xl px-4 py-2.5 text-sm outline-none border border-transparent focus:border-primary"
              />
            </div>
            <div className="flex gap-2 justify-end">
              <button type="button" onClick={() => { setRejectTarget(null); setRejectReason(''); }} disabled={rejecting} className="px-5 py-2.5 rounded-full text-sm font-semibold border border-border hover:bg-secondary transition-colors disabled:opacity-50">
                Cancel
              </button>
              <button type="submit" disabled={rejecting} className="px-5 py-2.5 rounded-full text-sm font-semibold bg-red-600 text-white hover:bg-red-700 transition-colors disabled:opacity-60">
                {rejecting ? 'Rejecting…' : 'Reject'}
              </button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Bulk approve/reject (backend supports /refunds/admin/bulk) is intentionally left to a future
          iteration — every row's individual action above already covers the core queue workflow. */}
    </div>
  );
};

export default RefundQueue;
