import React, { useEffect, useState } from 'react';
import { RotateCcw, CheckCircle2, XCircle, PackageOpen, PackageCheck, Clock, Ban } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import StatCard from '../../components/StatCard';
import EmptyState from '../../components/EmptyState';
import StatusBadge from '../../components/StatusBadge';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../../../components/ui/select';
import Pagination from '../../../pages/seller/components/Pagination';
import { getReturnOverview, getReturnQueue } from '../../../services/adminFinanceService';
import { approveReturnRequest, rejectReturnRequest, markReturnReceived, completeReturnRequest } from '../../../services/returnService';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

const PAGE_SIZE = 20;
const fmtDate = (iso) => (iso ? new Date(iso).toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—');

const STATUS_OPTIONS = [
  { value: 'all', label: 'All Statuses' },
  { value: 'requested', label: 'Requested' },
  { value: 'approved', label: 'Approved' },
  { value: 'return_shipped', label: 'Return Shipped' },
  { value: 'received', label: 'Received' },
  { value: 'completed', label: 'Completed' },
  { value: 'rejected', label: 'Rejected' },
  { value: 'cancelled', label: 'Cancelled' },
];

/**
 * Phase 16D, Part 2 — Admin Return Queue. Listing comes from the
 * read-only `/returns/admin*` overview/queue (marketplace-wide, any
 * seller); the row actions below reuse the exact same `/returns/seller/
 * :requestId/*` endpoints the Seller Cases tab uses — admin is
 * explicitly allowed on those routes too (see return.routes.js), so
 * this page never duplicates the approve/reject/receive/complete
 * logic, it just lets an admin act on ANY seller's return instead of
 * only their own.
 */
const ReturnQueue = () => {
  const { toast } = useToast();
  const [overview, setOverview] = useState(null);
  const [overviewLoading, setOverviewLoading] = useState(true);

  const [requests, setRequests] = useState([]);
  const [meta, setMeta] = useState({ totalPages: 1 });
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState('requested');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [actioningId, setActioningId] = useState(null);

  const loadOverview = () => {
    setOverviewLoading(true);
    getReturnOverview()
      .then(setOverview)
      .catch(() => setOverview(null))
      .finally(() => setOverviewLoading(false));
  };
  useEffect(loadOverview, []);

  useEffect(() => { setPage(1); }, [statusFilter]);

  const loadQueue = () => {
    setLoading(true);
    setError('');
    const params = { page, limit: PAGE_SIZE };
    if (statusFilter !== 'all') params.status = statusFilter;
    getReturnQueue(params)
      .then(({ requests: rows, meta: m }) => {
        setRequests(rows || []);
        setMeta(m || { totalPages: 1 });
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };
  useEffect(loadQueue, [page, statusFilter]); // eslint-disable-line react-hooks/exhaustive-deps

  const refreshAll = () => { loadQueue(); loadOverview(); };

  const runAction = async (action, requestId, ...args) => {
    setActioningId(requestId);
    try {
      const updated = await action(requestId, ...args);
      toast({ title: `Return ${updated.status.replace('_', ' ')}` });
      refreshAll();
    } catch (err) {
      toast({ title: 'Could not update return', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setActioningId(null);
    }
  };

  return (
    <div>
      <PageHeader title="Return Queue" description="Physical return requests across every seller — review, receive, and complete." />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard label="Requested" value={overviewLoading ? '—' : (overview?.byStatus?.requested?.count ?? 0)} icon={Clock} />
        <StatCard label="Return Shipped" value={overviewLoading ? '—' : (overview?.byStatus?.return_shipped?.count ?? 0)} icon={RotateCcw} />
        <StatCard label="Received" value={overviewLoading ? '—' : (overview?.byStatus?.received?.count ?? 0)} icon={PackageOpen} />
        <StatCard label="Completed" value={overviewLoading ? '—' : (overview?.byStatus?.completed?.count ?? 0)} icon={PackageCheck} />
      </div>

      <div className="flex justify-end mb-4">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[180px] rounded-full text-sm"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            {STATUS_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="bg-white rounded-2xl border border-border overflow-hidden">
        {loading ? (
          <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>
        ) : error ? (
          <div className="p-8 text-center">
            <p className="text-sm text-destructive mb-3">{error}</p>
            <button onClick={loadQueue} className="text-sm font-semibold text-primary hover:underline">Try again</button>
          </div>
        ) : requests.length === 0 ? (
          <EmptyState icon={RotateCcw} title="No return requests found" description="Try adjusting the status filter." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-muted-foreground border-b border-border">
                  <th className="font-medium px-5 py-3">Order</th>
                  <th className="font-medium px-5 py-3">Seller</th>
                  <th className="font-medium px-5 py-3">Reason</th>
                  <th className="font-medium px-5 py-3">Requested</th>
                  <th className="font-medium px-5 py-3">Status</th>
                  <th className="font-medium px-5 py-3 w-36"><span className="sr-only">Actions</span></th>
                </tr>
              </thead>
              <tbody>
                {requests.map((r) => (
                  <tr key={r.id} className="border-b border-border last:border-0 hover:bg-secondary/30">
                    <td className="px-5 py-3 font-mono text-xs text-muted-foreground">{r.order}</td>
                    <td className="px-5 py-3 font-mono text-xs text-muted-foreground">{r.seller}</td>
                    <td className="px-5 py-3 text-xs capitalize">{(r.reason || '').replace(/_/g, ' ')}</td>
                    <td className="px-5 py-3 text-muted-foreground">{fmtDate(r.createdAt)}</td>
                    <td className="px-5 py-3"><StatusBadge status={r.status} /></td>
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-1.5">
                        {r.status === 'requested' && (
                          <>
                            <button onClick={() => runAction(approveReturnRequest, r.id)} disabled={actioningId === r.id} className="p-1.5 rounded-lg hover:bg-secondary transition-colors text-emerald-600 disabled:opacity-50" aria-label="Approve" title="Approve">
                              <CheckCircle2 className="w-4 h-4" />
                            </button>
                            <button onClick={() => runAction(rejectReturnRequest, r.id)} disabled={actioningId === r.id} className="p-1.5 rounded-lg hover:bg-secondary transition-colors text-red-600 disabled:opacity-50" aria-label="Reject" title="Reject">
                              <XCircle className="w-4 h-4" />
                            </button>
                          </>
                        )}
                        {r.status === 'return_shipped' && (
                          <button onClick={() => runAction(markReturnReceived, r.id)} disabled={actioningId === r.id} className="p-1.5 rounded-lg hover:bg-secondary transition-colors text-blue-600 disabled:opacity-50" aria-label="Mark received" title="Mark received">
                            <PackageOpen className="w-4 h-4" />
                          </button>
                        )}
                        {r.status === 'received' && (
                          <button onClick={() => runAction(completeReturnRequest, r.id)} disabled={actioningId === r.id} className="p-1.5 rounded-lg hover:bg-secondary transition-colors text-emerald-600 disabled:opacity-50" aria-label="Complete" title="Complete (opens the refund)">
                            <PackageCheck className="w-4 h-4" />
                          </button>
                        )}
                        {!['requested', 'return_shipped', 'received'].includes(r.status) && (
                          <span className="text-muted-foreground text-xs inline-flex items-center gap-1"><Ban className="w-3.5 h-3.5" /> —</span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      <Pagination page={page} totalPages={meta.totalPages || 1} onPageChange={setPage} />
    </div>
  );
};

export default ReturnQueue;
