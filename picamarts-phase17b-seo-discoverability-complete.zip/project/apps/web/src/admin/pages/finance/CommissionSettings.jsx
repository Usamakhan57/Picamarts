import React, { useEffect, useState } from 'react';
import { Search } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import { Field, inputClass } from '../../components/FormSheet';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';
import {
  getGlobalCommission, updateGlobalCommission, updateCategoryCommission, updateSellerCommission,
} from '../../../services/adminFinanceService';
import { listAllCategories } from '../../../services/adminCategoryService';
import { listSellers } from '../../../services/sellerService';

/**
 * Phase 16B, Part 5 — Admin Commission Settings. Brand-new page (no
 * mock/placeholder existed before this). Manages the three levels of
 * the real commission resolution chain: Global (PlatformSettings),
 * Category (Category.commissionRate — reuses the real, already-listed
 * categories), and Seller override (Seller.commissionRate — reuses the
 * existing seller search, same field the old Admin Seller Management
 * "commissionRate" field already edited, just exposed here too for a
 * commission-focused workflow). Nothing here duplicates that Seller
 * Management edit path — it's the same backend field either way.
 */
const CommissionSettings = () => {
  const { toast } = useToast();
  const [globalRate, setGlobalRate] = useState('');
  const [savingGlobal, setSavingGlobal] = useState(false);
  const [loading, setLoading] = useState(true);

  const [categories, setCategories] = useState([]);
  const [categoryDrafts, setCategoryDrafts] = useState({});
  const [savingCategory, setSavingCategory] = useState(null);

  const [sellerQuery, setSellerQuery] = useState('');
  const [sellerResults, setSellerResults] = useState([]);
  const [selectedSeller, setSelectedSeller] = useState(null);
  const [sellerRateDraft, setSellerRateDraft] = useState('');
  const [savingSeller, setSavingSeller] = useState(false);

  useEffect(() => {
    Promise.all([getGlobalCommission(), listAllCategories()])
      .then(([settings, cats]) => {
        setGlobalRate(String(settings.defaultCommissionRate));
        setCategories(cats);
        setCategoryDrafts(Object.fromEntries(cats.map((c) => [c.id, c.commissionRate ?? ''])));
      })
      .catch((err) => toast({ title: 'Could not load commission settings', description: getErrorMessage(err), variant: 'destructive' }))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!sellerQuery.trim()) { setSellerResults([]); return; }
    const t = setTimeout(() => {
      listSellers({ q: sellerQuery, limit: 8 }).then((res) => setSellerResults(res.sellers || res.items || [])).catch(() => {});
    }, 300);
    return () => clearTimeout(t);
  }, [sellerQuery]);

  const handleSaveGlobal = async () => {
    const rate = Number(globalRate);
    if (Number.isNaN(rate) || rate < 0 || rate > 100) { toast({ title: 'Enter a rate between 0 and 100', variant: 'destructive' }); return; }
    setSavingGlobal(true);
    try {
      await updateGlobalCommission(rate);
      toast({ title: 'Global commission rate updated', description: `${rate}%` });
    } catch (err) {
      toast({ title: 'Save failed', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setSavingGlobal(false);
    }
  };

  const handleSaveCategory = async (categoryId) => {
    const draft = categoryDrafts[categoryId];
    const rate = draft === '' ? null : Number(draft);
    if (rate !== null && (Number.isNaN(rate) || rate < 0 || rate > 100)) {
      toast({ title: 'Enter a rate between 0 and 100, or leave blank to clear', variant: 'destructive' });
      return;
    }
    setSavingCategory(categoryId);
    try {
      await updateCategoryCommission(categoryId, rate);
      toast({ title: 'Category commission updated', description: rate === null ? 'Cleared — uses global rate' : `${rate}%` });
    } catch (err) {
      toast({ title: 'Save failed', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setSavingCategory(null);
    }
  };

  const selectSeller = (seller) => {
    setSelectedSeller(seller);
    setSellerRateDraft(seller.commissionRate ?? '');
    setSellerQuery('');
    setSellerResults([]);
  };

  const handleSaveSeller = async () => {
    const rate = sellerRateDraft === '' ? null : Number(sellerRateDraft);
    if (rate !== null && (Number.isNaN(rate) || rate < 0 || rate > 100)) {
      toast({ title: 'Enter a rate between 0 and 100, or leave blank to clear', variant: 'destructive' });
      return;
    }
    setSavingSeller(true);
    try {
      await updateSellerCommission(selectedSeller.id, rate);
      toast({ title: 'Seller commission override updated', description: rate === null ? 'Cleared — uses category/global rate' : `${rate}%` });
    } catch (err) {
      toast({ title: 'Save failed', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setSavingSeller(false);
    }
  };

  if (loading) return <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>;

  return (
    <div>
      <PageHeader
        title="Commission Settings"
        description="Resolution order: seller override → category rate → global default."
      />

      <div className="space-y-5">
        <section className="bg-white rounded-2xl border border-border p-5 soft-shadow">
          <h2 className="font-semibold mb-3">Global Commission Rate</h2>
          <div className="flex items-end gap-3 max-w-xs">
            <Field label="Default rate (%)">
              <input type="number" min={0} max={100} className={inputClass} value={globalRate} onChange={(e) => setGlobalRate(e.target.value)} />
            </Field>
            <button onClick={handleSaveGlobal} disabled={savingGlobal} className="px-4 py-2.5 rounded-full text-sm font-semibold brand-gradient text-white disabled:opacity-60 shrink-0">
              {savingGlobal ? 'Saving…' : 'Save'}
            </button>
          </div>
        </section>

        <section className="bg-white rounded-2xl border border-border soft-shadow">
          <div className="p-5 border-b border-border">
            <h2 className="font-semibold">Category Commission Overrides</h2>
            <p className="text-xs text-muted-foreground mt-1">Leave blank to use the global rate for that category.</p>
          </div>
          <div className="divide-y divide-border">
            {categories.map((c) => (
              <div key={c.id} className="flex items-center gap-3 px-5 py-3">
                <span className="flex-1 text-sm font-medium">{c.name}</span>
                <input
                  type="number" min={0} max={100} placeholder="Global"
                  className={`${inputClass} w-28`}
                  value={categoryDrafts[c.id] ?? ''}
                  onChange={(e) => setCategoryDrafts({ ...categoryDrafts, [c.id]: e.target.value })}
                />
                <button
                  onClick={() => handleSaveCategory(c.id)}
                  disabled={savingCategory === c.id}
                  className="px-3 py-2 rounded-full text-xs font-semibold border border-border hover:bg-secondary disabled:opacity-60 shrink-0"
                >
                  {savingCategory === c.id ? 'Saving…' : 'Save'}
                </button>
              </div>
            ))}
          </div>
        </section>

        <section className="bg-white rounded-2xl border border-border p-5 soft-shadow">
          <h2 className="font-semibold mb-3">Seller Commission Override</h2>
          <div className="relative max-w-md">
            <Search className="w-4 h-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              className="w-full rounded-xl border border-border pl-9 pr-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
              placeholder="Search sellers by store name…"
              value={sellerQuery}
              onChange={(e) => setSellerQuery(e.target.value)}
            />
            {sellerResults.length > 0 && (
              <div className="absolute z-10 mt-1 w-full bg-white border border-border rounded-xl soft-shadow max-h-56 overflow-y-auto">
                {sellerResults.map((s) => (
                  <button key={s.id} type="button" onClick={() => selectSeller(s)} className="w-full text-left px-3 py-2 text-sm hover:bg-secondary">
                    {s.storeName}
                  </button>
                ))}
              </div>
            )}
          </div>

          {selectedSeller && (
            <div className="mt-4 flex items-end gap-3 max-w-sm">
              <Field label={`${selectedSeller.storeName} — override (%)`}>
                <input
                  type="number" min={0} max={100} placeholder="No override"
                  className={inputClass}
                  value={sellerRateDraft}
                  onChange={(e) => setSellerRateDraft(e.target.value)}
                />
              </Field>
              <button onClick={handleSaveSeller} disabled={savingSeller} className="px-4 py-2.5 rounded-full text-sm font-semibold brand-gradient text-white disabled:opacity-60 shrink-0">
                {savingSeller ? 'Saving…' : 'Save'}
              </button>
            </div>
          )}
        </section>
      </div>
    </div>
  );
};

export default CommissionSettings;
