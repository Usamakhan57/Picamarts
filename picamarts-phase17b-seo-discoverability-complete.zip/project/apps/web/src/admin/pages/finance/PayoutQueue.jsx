import React, { useEffect, useState } from 'react';
import { Send, CheckCircle2, XCircle, RotateCcw, DollarSign, Clock, Ban, AlertTriangle } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import StatCard from '../../components/StatCard';
import EmptyState from '../../components/EmptyState';
import StatusBadge from '../../components/StatusBadge';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '../../../components/ui/dialog';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../../../components/ui/select';
import Pagination from '../../../pages/seller/components/Pagination';
import { getPayoutOverview, getPayoutQueue, approvePayout, rejectPayout, retryPayout } from '../../../services/adminFinanceService';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

const PAGE_SIZE = 20;
const fmtMoney = (n) => `$${Number(n || 0).toFixed(2)}`;
const fmtDate = (iso) => (iso ? new Date(iso).toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—');

const STATUS_OPTIONS = [
  { value: 'all', label: 'All Statuses' },
  { value: 'pending', label: 'Pending' },
  { value: 'approved', label: 'Approved' },
  { value: 'processing', label: 'Processing' },
  { value: 'completed', label: 'Completed' },
  { value: 'failed', label: 'Failed' },
  { value: 'rejected', label: 'Rejected' },
  { value: 'cancelled', label: 'Cancelled' },
];

/**
 * Phase 16C, Parts 4/5/7 — Admin Payout Queue. Brand-new page (no
 * mock/placeholder existed before this) against the real
 * `/payouts/admin*` endpoints. Approve immediately attempts the
 * Stripe transfer server-side (payout.service.js#processPayout) —
 * this page shows whichever status comes back (COMPLETED or FAILED),
 * it doesn't poll or simulate a queue itself. Reject only applies to
 * a still-PENDING request; Retry only applies to a FAILED one — the
 * row's own action buttons are gated on `status` to match exactly
 * what the backend will actually accept (see payout.service.js's
 * transitionStatus guards).
 */
const PayoutQueue = () => {
  const { toast } = useToast();
  const [overview, setOverview] = useState(null);
  const [overviewLoading, setOverviewLoading] = useState(true);

  const [requests, setRequests] = useState([]);
  const [meta, setMeta] = useState({ totalPages: 1, totalItems: 0 });
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState('pending');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [actioningId, setActioningId] = useState(null);
  const [rejectTarget, setRejectTarget] = useState(null);
  const [rejectReason, setRejectReason] = useState('');
  const [rejecting, setRejecting] = useState(false);

  const loadOverview = () => {
    setOverviewLoading(true);
    getPayoutOverview()
      .then(setOverview)
      .catch(() => setOverview(null))
      .finally(() => setOverviewLoading(false));
  };
  useEffect(loadOverview, []);

  useEffect(() => { setPage(1); }, [statusFilter]);

  const loadQueue = () => {
    setLoading(true);
    setError('');
    const params = { page, limit: PAGE_SIZE };
    if (statusFilter !== 'all') params.status = statusFilter;
    getPayoutQueue(params)
      .then(({ requests: rows, meta: m }) => {
        setRequests(rows || []);
        setMeta(m || { totalPages: 1, totalItems: (rows || []).length });
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };
  useEffect(loadQueue, [page, statusFilter]); // eslint-disable-line react-hooks/exhaustive-deps

  const refreshAll = () => { loadQueue(); loadOverview(); };

  const handleApprove = async (requestId) => {
    setActioningId(requestId);
    try {
      const updated = await approvePayout(requestId);
      if (updated.status === 'completed') {
        toast({ title: 'Payout completed', description: `Stripe transfer ${updated.stripeTransferId} succeeded.` });
      } else if (updated.status === 'failed') {
        toast({ title: 'Transfer failed', description: updated.failureReason || 'The Stripe transfer could not be completed.', variant: 'destructive' });
      } else {
        toast({ title: 'Request approved' });
      }
      refreshAll();
    } catch (err) {
      toast({ title: 'Could not approve request', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setActioningId(null);
    }
  };

  const handleRetry = async (requestId) => {
    setActioningId(requestId);
    try {
      const updated = await retryPayout(requestId);
      if (updated.status === 'completed') {
        toast({ title: 'Retry succeeded', description: `Stripe transfer ${updated.stripeTransferId} completed.` });
      } else {
        toast({ title: 'Retry failed again', description: updated.failureReason || 'The Stripe transfer failed.', variant: 'destructive' });
      }
      refreshAll();
    } catch (err) {
      toast({ title: 'Could not retry request', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setActioningId(null);
    }
  };

  const handleReject = async () => {
    setRejecting(true);
    try {
      await rejectPayout(rejectTarget.id, rejectReason || undefined);
      toast({ title: 'Withdrawal request rejected', description: 'The held balance has been released back to the seller.' });
      setRejectTarget(null);
      setRejectReason('');
      refreshAll();
    } catch (err) {
      toast({ title: 'Could not reject request', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setRejecting(false);
    }
  };

  return (
    <div>
      <PageHeader title="Payout Queue" description="Seller withdrawal requests — approve, reject, and retry Stripe transfers." />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Pending" value={overviewLoading ? '—' : (overview?.pending?.count ?? 0)} icon={Clock} />
        <StatCard label="Processing" value={overviewLoading ? '—' : (overview?.processing?.count ?? 0)} icon={Send} />
        <StatCard label="Failed" value={overviewLoading ? '—' : (overview?.failed?.count ?? 0)} icon={AlertTriangle} />
        <StatCard label="Completed" value={overviewLoading ? '—' : (overview?.completed?.count ?? 0)} icon={CheckCircle2} />
      </div>
      <div className="grid grid-cols-2 gap-4 mb-8">
        <StatCard label="Total Paid" value={overviewLoading ? '—' : fmtMoney(overview?.totalPaid)} icon={DollarSign} />
        <StatCard label="Total Pending" value={overviewLoading ? '—' : fmtMoney(overview?.totalPending)} icon={Clock} />
      </div>

      <div className="flex justify-end mb-4">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[170px] rounded-full text-sm"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            {STATUS_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="bg-white rounded-2xl border border-border overflow-hidden">
        {loading ? (
          <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>
        ) : error ? (
          <div className="p-8 text-center">
            <p className="text-sm text-destructive mb-3">{error}</p>
            <button onClick={loadQueue} className="text-sm font-semibold text-primary hover:underline">Try again</button>
          </div>
        ) : requests.length === 0 ? (
          <EmptyState icon={Send} title="No withdrawal requests found" description="Try adjusting the status filter." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-muted-foreground border-b border-border">
                  <th className="font-medium px-5 py-3">Seller</th>
                  <th className="font-medium px-5 py-3">Amount</th>
                  <th className="font-medium px-5 py-3">Requested</th>
                  <th className="font-medium px-5 py-3">Status</th>
                  <th className="font-medium px-5 py-3">Transfer / Failure</th>
                  <th className="font-medium px-5 py-3 w-32"><span className="sr-only">Actions</span></th>
                </tr>
              </thead>
              <tbody>
                {requests.map((r) => (
                  <tr key={r.id} className="border-b border-border last:border-0 hover:bg-secondary/30">
                    <td className="px-5 py-3 font-mono text-xs text-muted-foreground">{r.seller}</td>
                    <td className="px-5 py-3 font-semibold">{fmtMoney(r.amount)}</td>
                    <td className="px-5 py-3 text-muted-foreground">{fmtDate(r.requestedAt)}</td>
                    <td className="px-5 py-3"><StatusBadge status={r.status} /></td>
                    <td className="px-5 py-3 text-xs text-muted-foreground">
                      {r.stripeTransferId || r.failureReason || '—'}
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-1.5">
                        {r.status === 'pending' && (
                          <>
                            <button
                              onClick={() => handleApprove(r.id)}
                              disabled={actioningId === r.id}
                              className="p-1.5 rounded-lg hover:bg-secondary transition-colors text-emerald-600 disabled:opacity-50"
                              aria-label="Approve"
                              title="Approve & process"
                            >
                              <CheckCircle2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => setRejectTarget(r)}
                              disabled={actioningId === r.id}
                              className="p-1.5 rounded-lg hover:bg-secondary transition-colors text-red-600 disabled:opacity-50"
                              aria-label="Reject"
                              title="Reject"
                            >
                              <XCircle className="w-4 h-4" />
                            </button>
                          </>
                        )}
                        {r.status === 'failed' && (
                          <button
                            onClick={() => handleRetry(r.id)}
                            disabled={actioningId === r.id}
                            className="p-1.5 rounded-lg hover:bg-secondary transition-colors text-blue-600 disabled:opacity-50"
                            aria-label="Retry"
                            title="Retry transfer"
                          >
                            <RotateCcw className="w-4 h-4" />
                          </button>
                        )}
                        {!['pending', 'failed'].includes(r.status) && (
                          <span className="text-muted-foreground text-xs inline-flex items-center gap-1">
                            <Ban className="w-3.5 h-3.5" /> —
                          </span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      <Pagination page={page} totalPages={meta.totalPages || 1} onPageChange={setPage} />

      <Dialog open={!!rejectTarget} onOpenChange={(v) => { if (!v) { setRejectTarget(null); setRejectReason(''); } }}>
        <DialogContent className="max-w-md rounded-3xl">
          <DialogTitle>Reject withdrawal request?</DialogTitle>
          <DialogDescription>The held balance will be released back to the seller.</DialogDescription>
          <form
            onSubmit={(e) => { e.preventDefault(); handleReject(); }}
            className="space-y-4 mt-2"
          >
            <div>
              <label className="text-sm font-medium block mb-1.5">Reason (optional)</label>
              <input
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                placeholder="Let the seller know why"
                className="w-full bg-secondary/60 rounded-xl px-4 py-2.5 text-sm outline-none border border-transparent focus:border-primary"
              />
            </div>
            <div className="flex gap-2 justify-end">
              <button
                type="button"
                onClick={() => { setRejectTarget(null); setRejectReason(''); }}
                disabled={rejecting}
                className="px-5 py-2.5 rounded-full text-sm font-semibold border border-border hover:bg-secondary transition-colors disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={rejecting}
                className="px-5 py-2.5 rounded-full text-sm font-semibold bg-red-600 text-white hover:bg-red-700 transition-colors disabled:opacity-60"
              >
                {rejecting ? 'Rejecting…' : 'Reject'}
              </button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PayoutQueue;
