import React, { useEffect, useState } from 'react';
import { Gavel, ShieldAlert, Clock, Lock, TrendingDown, CheckCircle2, XCircle, Ban } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import StatCard from '../../components/StatCard';
import EmptyState from '../../components/EmptyState';
import StatusBadge from '../../components/StatusBadge';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '../../../components/ui/dialog';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../../../components/ui/select';
import Pagination from '../../../pages/seller/components/Pagination';
import { getDisputeOverview, getDisputeQueue, markDisputeUnderReview, resolveDispute, closeDispute } from '../../../services/adminFinanceService';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

const PAGE_SIZE = 20;
const fmtMoney = (n) => `$${Number(n || 0).toFixed(2)}`;
const fmtDate = (iso) => (iso ? new Date(iso).toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—');

const STATUS_OPTIONS = [
  { value: 'all', label: 'All Statuses' },
  { value: 'open', label: 'Open' },
  { value: 'under_review', label: 'Under Review' },
  { value: 'evidence_submitted', label: 'Evidence Submitted' },
  { value: 'won', label: 'Won' },
  { value: 'lost', label: 'Lost' },
  { value: 'closed', label: 'Closed' },
];

/**
 * Phase 16D, Part 7 — Admin Dispute Queue, covering Disputes,
 * Chargebacks, and the "Financial Impact" of funds currently held.
 * `origin` distinguishes a Stripe chargeback (synced automatically —
 * see dispute.service.js#syncFromStripeEvent, resolved outcome always
 * comes from Stripe itself) from a buyer-opened, marketplace-native
 * dispute (admin-driven via Resolve below). Financial Impact reads
 * `open + under_review + evidence_submitted` totals as "currently
 * held" — the same held-until-resolved amounts wallet.service.js#
 * holdForDispute actually debits from sellers.
 */
const DisputeQueue = () => {
  const { toast } = useToast();
  const [overview, setOverview] = useState(null);
  const [overviewLoading, setOverviewLoading] = useState(true);

  const [disputes, setDisputes] = useState([]);
  const [meta, setMeta] = useState({ totalPages: 1 });
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState('open');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [actioningId, setActioningId] = useState(null);
  const [resolveTarget, setResolveTarget] = useState(null);
  const [resolveNote, setResolveNote] = useState('');
  const [resolving, setResolving] = useState(false);

  const loadOverview = () => {
    setOverviewLoading(true);
    getDisputeOverview()
      .then(setOverview)
      .catch(() => setOverview(null))
      .finally(() => setOverviewLoading(false));
  };
  useEffect(loadOverview, []);

  useEffect(() => { setPage(1); }, [statusFilter]);

  const loadQueue = () => {
    setLoading(true);
    setError('');
    const params = { page, limit: PAGE_SIZE };
    if (statusFilter !== 'all') params.status = statusFilter;
    getDisputeQueue(params)
      .then(({ disputes: rows, meta: m }) => {
        setDisputes(rows || []);
        setMeta(m || { totalPages: 1 });
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };
  useEffect(loadQueue, [page, statusFilter]); // eslint-disable-line react-hooks/exhaustive-deps

  const refreshAll = () => { loadQueue(); loadOverview(); };

  const held = ['open', 'under_review', 'evidence_submitted'].reduce(
    (sum, key) => sum + (overview?.byStatus?.[key]?.total || 0),
    0
  );
  const heldCount = ['open', 'under_review', 'evidence_submitted'].reduce(
    (sum, key) => sum + (overview?.byStatus?.[key]?.count || 0),
    0
  );
  const lost = overview?.byStatus?.lost?.total || 0;
  const won = overview?.byStatus?.won?.total || 0;

  const handleMarkUnderReview = async (disputeId) => {
    setActioningId(disputeId);
    try {
      await markDisputeUnderReview(disputeId);
      toast({ title: 'Marked under review' });
      refreshAll();
    } catch (err) {
      toast({ title: 'Could not update dispute', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setActioningId(null);
    }
  };

  const handleClose = async (disputeId) => {
    setActioningId(disputeId);
    try {
      await closeDispute(disputeId);
      toast({ title: 'Dispute closed', description: 'Held earnings released back to the seller.' });
      refreshAll();
    } catch (err) {
      toast({ title: 'Could not close dispute', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setActioningId(null);
    }
  };

  const handleResolve = async () => {
    setResolving(true);
    try {
      const updated = await resolveDispute(resolveTarget.id, resolveTarget.outcome, resolveNote || undefined);
      toast({
        title: `Dispute resolved: ${updated.status}`,
        description: updated.status === 'won' ? 'Held earnings released back to the seller.' : 'Held earnings forfeited.',
      });
      setResolveTarget(null);
      setResolveNote('');
      refreshAll();
    } catch (err) {
      toast({ title: 'Could not resolve dispute', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setResolving(false);
    }
  };

  return (
    <div>
      <PageHeader title="Dispute Queue" description="Buyer-opened disputes and Stripe chargebacks — review, resolve, and track financial impact." />

      <div className="mb-2">
        <h2 className="font-semibold text-sm text-muted-foreground">Financial Impact</h2>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        <StatCard label={`Currently Held (${overviewLoading ? '—' : heldCount})`} value={overviewLoading ? '—' : fmtMoney(held)} icon={Lock} />
        <StatCard label="Lost (Forfeited)" value={overviewLoading ? '—' : fmtMoney(lost)} icon={TrendingDown} />
        <StatCard label="Won (Released)" value={overviewLoading ? '—' : fmtMoney(won)} icon={CheckCircle2} />
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard label="Open" value={overviewLoading ? '—' : (overview?.byStatus?.open?.count ?? 0)} icon={Clock} />
        <StatCard label="Under Review" value={overviewLoading ? '—' : (overview?.byStatus?.under_review?.count ?? 0)} icon={Gavel} />
        <StatCard label="Evidence Submitted" value={overviewLoading ? '—' : (overview?.byStatus?.evidence_submitted?.count ?? 0)} icon={ShieldAlert} />
        <StatCard label="Closed" value={overviewLoading ? '—' : (overview?.byStatus?.closed?.count ?? 0)} icon={Ban} />
      </div>

      <div className="flex justify-end mb-4">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[190px] rounded-full text-sm"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            {STATUS_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="bg-white rounded-2xl border border-border overflow-hidden">
        {loading ? (
          <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>
        ) : error ? (
          <div className="p-8 text-center">
            <p className="text-sm text-destructive mb-3">{error}</p>
            <button onClick={loadQueue} className="text-sm font-semibold text-primary hover:underline">Try again</button>
          </div>
        ) : disputes.length === 0 ? (
          <EmptyState icon={Gavel} title="No disputes found" description="Try adjusting the status filter." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-muted-foreground border-b border-border">
                  <th className="font-medium px-5 py-3">Order</th>
                  <th className="font-medium px-5 py-3">Seller</th>
                  <th className="font-medium px-5 py-3">Origin</th>
                  <th className="font-medium px-5 py-3">Amount</th>
                  <th className="font-medium px-5 py-3">Opened</th>
                  <th className="font-medium px-5 py-3">Status</th>
                  <th className="font-medium px-5 py-3 w-36"><span className="sr-only">Actions</span></th>
                </tr>
              </thead>
              <tbody>
                {disputes.map((d) => {
                  const isChargeback = d.origin === 'stripe_chargeback';
                  const actionable = ['open', 'under_review', 'evidence_submitted'].includes(d.status);
                  return (
                    <tr key={d.id} className="border-b border-border last:border-0 hover:bg-secondary/30">
                      <td className="px-5 py-3 font-mono text-xs text-muted-foreground">{d.order}</td>
                      <td className="px-5 py-3 font-mono text-xs text-muted-foreground">{d.seller}</td>
                      <td className="px-5 py-3 text-xs">
                        <span className={`inline-flex items-center gap-1 ${isChargeback ? 'text-amber-700' : 'text-blue-700'}`}>
                          {isChargeback ? <ShieldAlert className="w-3.5 h-3.5" /> : <Gavel className="w-3.5 h-3.5" />}
                          {isChargeback ? 'Chargeback' : 'Buyer Dispute'}
                        </span>
                      </td>
                      <td className="px-5 py-3 font-semibold">{fmtMoney(d.amount)}</td>
                      <td className="px-5 py-3 text-muted-foreground">{fmtDate(d.createdAt)}</td>
                      <td className="px-5 py-3"><StatusBadge status={d.status} /></td>
                      <td className="px-5 py-3">
                        <div className="flex items-center gap-1.5">
                          {!actionable ? (
                            <span className="text-muted-foreground text-xs inline-flex items-center gap-1"><Ban className="w-3.5 h-3.5" /> —</span>
                          ) : isChargeback ? (
                            // A Stripe chargeback's outcome always comes from Stripe itself
                            // (dispute.service.js#syncFromStripeEvent) — admin can only mark
                            // it under review locally as a triage step, never force-resolve it.
                            <button
                              onClick={() => handleMarkUnderReview(d.id)}
                              disabled={actioningId === d.id || d.status === 'under_review'}
                              className="px-3 py-1.5 rounded-lg text-xs font-semibold border border-border hover:bg-secondary transition-colors disabled:opacity-50"
                            >
                              Mark Reviewing
                            </button>
                          ) : (
                            <>
                              <button
                                onClick={() => setResolveTarget({ id: d.id, outcome: 'won' })}
                                disabled={actioningId === d.id}
                                className="p-1.5 rounded-lg hover:bg-secondary transition-colors text-emerald-600 disabled:opacity-50"
                                aria-label="Resolve — seller wins"
                                title="Resolve: seller wins (release hold)"
                              >
                                <CheckCircle2 className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => setResolveTarget({ id: d.id, outcome: 'lost' })}
                                disabled={actioningId === d.id}
                                className="p-1.5 rounded-lg hover:bg-secondary transition-colors text-red-600 disabled:opacity-50"
                                aria-label="Resolve — buyer wins"
                                title="Resolve: buyer wins (forfeit hold)"
                              >
                                <XCircle className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleClose(d.id)}
                                disabled={actioningId === d.id}
                                className="p-1.5 rounded-lg hover:bg-secondary transition-colors text-muted-foreground disabled:opacity-50"
                                aria-label="Close without a winner/loser"
                                title="Close (release hold, no fault)"
                              >
                                <Ban className="w-4 h-4" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
      <Pagination page={page} totalPages={meta.totalPages || 1} onPageChange={setPage} />

      <Dialog open={!!resolveTarget} onOpenChange={(v) => { if (!v) { setResolveTarget(null); setResolveNote(''); } }}>
        <DialogContent className="max-w-md rounded-3xl">
          <DialogTitle>{resolveTarget?.outcome === 'won' ? 'Resolve — seller wins?' : 'Resolve — buyer wins?'}</DialogTitle>
          <DialogDescription>
            {resolveTarget?.outcome === 'won'
              ? "The seller's held earnings will be released back to their available balance."
              : "The seller's held earnings will be forfeited — this cannot be undone."}
          </DialogDescription>
          <form onSubmit={(e) => { e.preventDefault(); handleResolve(); }} className="space-y-4 mt-2">
            <textarea
              value={resolveNote}
              onChange={(e) => setResolveNote(e.target.value)}
              placeholder="Resolution note (optional)"
              rows={3}
              className="w-full bg-secondary/60 rounded-xl px-4 py-2.5 text-sm outline-none border border-transparent focus:border-primary resize-none"
            />
            <div className="flex gap-2 justify-end">
              <button type="button" onClick={() => { setResolveTarget(null); setResolveNote(''); }} disabled={resolving} className="px-5 py-2.5 rounded-full text-sm font-semibold border border-border hover:bg-secondary transition-colors disabled:opacity-50">
                Cancel
              </button>
              <button
                type="submit"
                disabled={resolving}
                className={`px-5 py-2.5 rounded-full text-sm font-semibold text-white transition-colors disabled:opacity-60 ${resolveTarget?.outcome === 'won' ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-red-600 hover:bg-red-700'}`}
              >
                {resolving ? 'Resolving…' : `Confirm — ${resolveTarget?.outcome === 'won' ? 'Seller Wins' : 'Buyer Wins'}`}
              </button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default DisputeQueue;
