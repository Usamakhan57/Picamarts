import React, { useEffect, useState } from 'react';
import { DollarSign, Percent, Wallet, Clock, Banknote, Search, CheckCircle2, AlertTriangle } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import StatCard from '../../components/StatCard';
import EmptyState from '../../components/EmptyState';
import { getFinanceOverview, getSellerWallet, getPayoutOverview } from '../../../services/adminFinanceService';
import { listSellers } from '../../../services/sellerService';
import { getErrorMessage } from '../../../lib/errorMessage';

const fmtMoney = (n) => `$${Number(n || 0).toFixed(2)}`;

/**
 * Phase 16B, Part 7 — Admin Finance Dashboard. Brand-new page (no
 * mock/placeholder existed before this) against the real
 * /wallet/admin/overview endpoint — marketplace-wide revenue,
 * commission, seller earnings, and wallet totals, all computed from
 * real CommissionRecord/Wallet data (see wallet.service.js). Phase
 * 16C adds the Payouts row (/payouts/admin/overview) — pending/
 * completed/failed counts and total paid/pending, still on this same
 * page since Part 7 explicitly asks for payout totals here; the
 * queue itself (approve/reject/retry actions) lives on its own
 * Payout Queue page.
 *
 * The seller drill-down search below is a lightweight lookup (reuses
 * the existing admin seller list + GET /wallet/admin/:sellerId) rather
 * than a full per-seller table — Part 7 asks for aggregate figures,
 * not a paginated seller-by-seller ledger view.
 */
const FinanceDashboard = () => {
  const [overview, setOverview] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [payoutOverview, setPayoutOverview] = useState(null);
  const [payoutLoading, setPayoutLoading] = useState(true);

  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [selected, setSelected] = useState(null);
  const [selectedWallet, setSelectedWallet] = useState(null);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    getFinanceOverview()
      .then(setOverview)
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    getPayoutOverview()
      .then(setPayoutOverview)
      .catch(() => setPayoutOverview(null))
      .finally(() => setPayoutLoading(false));
  }, []);

  useEffect(() => {
    if (!query.trim()) { setResults([]); return; }
    const t = setTimeout(() => {
      listSellers({ q: query, limit: 8 }).then((res) => setResults(res.sellers || res.items || [])).catch(() => {});
    }, 300);
    return () => clearTimeout(t);
  }, [query]);

  const selectSeller = async (seller) => {
    setSelected(seller);
    setSearching(true);
    setQuery('');
    setResults([]);
    try {
      const detail = await getSellerWallet(seller.id);
      setSelectedWallet(detail);
    } catch {
      setSelectedWallet(null);
    } finally {
      setSearching(false);
    }
  };

  if (loading) return <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>;
  if (error) return <EmptyState title="Couldn't load finance overview" description={error} />;

  return (
    <div>
      <PageHeader title="Finance Dashboard" description="Marketplace-wide revenue, commission, and wallet totals — computed from real sales." />

      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        <StatCard label="Marketplace Revenue" value={fmtMoney(overview?.marketplaceRevenue)} icon={DollarSign} />
        <StatCard label="Total Commission" value={fmtMoney(overview?.totalCommission)} icon={Percent} />
        <StatCard label="Seller Earnings" value={fmtMoney(overview?.sellerEarnings)} icon={Wallet} />
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard label="Total Available" value={fmtMoney(overview?.walletTotals?.totalAvailable)} icon={Wallet} />
        <StatCard label="Total Pending" value={fmtMoney(overview?.walletTotals?.totalPending)} icon={Clock} />
        <StatCard label="Lifetime Earnings" value={fmtMoney(overview?.walletTotals?.totalEarnings)} icon={DollarSign} />
        <StatCard label="Total Withdrawn" value={fmtMoney(overview?.walletTotals?.totalWithdrawn)} icon={Banknote} />
      </div>

      <div className="mb-2">
        <h2 className="font-semibold text-sm text-muted-foreground">Payouts</h2>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard label="Total Paid" value={payoutLoading ? '—' : fmtMoney(payoutOverview?.totalPaid)} icon={CheckCircle2} />
        <StatCard label="Total Pending Payout" value={payoutLoading ? '—' : fmtMoney(payoutOverview?.totalPending)} icon={Clock} />
        <StatCard label="Processing" value={payoutLoading ? '—' : (payoutOverview?.processing?.count ?? 0)} icon={Wallet} />
        <StatCard label="Failed" value={payoutLoading ? '—' : (payoutOverview?.failed?.count ?? 0)} icon={AlertTriangle} />
      </div>

      <div className="bg-white rounded-2xl border border-border p-5 soft-shadow">
        <h2 className="font-semibold mb-3">Look up a seller's wallet</h2>
        <div className="relative max-w-md">
          <Search className="w-4 h-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            className="w-full rounded-xl border border-border pl-9 pr-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
            placeholder="Search sellers by store name…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          {results.length > 0 && (
            <div className="absolute z-10 mt-1 w-full bg-white border border-border rounded-xl soft-shadow max-h-56 overflow-y-auto">
              {results.map((s) => (
                <button key={s.id} type="button" onClick={() => selectSeller(s)} className="w-full text-left px-3 py-2 text-sm hover:bg-secondary">
                  {s.storeName}
                </button>
              ))}
            </div>
          )}
        </div>

        {selected && (
          <div className="mt-5 border-t border-border pt-5">
            <h3 className="font-semibold mb-3">{selected.storeName}</h3>
            {searching ? (
              <p className="text-sm text-muted-foreground">Loading wallet…</p>
            ) : !selectedWallet ? (
              <p className="text-sm text-destructive">Couldn't load this seller's wallet.</p>
            ) : (
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <StatCard label="Available" value={fmtMoney(selectedWallet.summary?.availableBalance)} icon={Wallet} />
                <StatCard label="Pending" value={fmtMoney(selectedWallet.summary?.pendingBalance)} icon={Clock} />
                <StatCard label="Total Earnings" value={fmtMoney(selectedWallet.summary?.totalEarnings)} icon={DollarSign} />
                <StatCard label="Commission Paid" value={fmtMoney(selectedWallet.commissionTotals?.commissionAmount)} icon={Percent} />
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default FinanceDashboard;
