import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Pencil, FileStack } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import StatusBadge from '../../components/StatusBadge';
import { listPages, STATIC_PAGE_TYPES } from '../../../services/adminPageService';
import { getErrorMessage } from '../../../lib/errorMessage';

const TYPE_LABELS = {
  'about-us': 'About Us',
  'contact-us': 'Contact Us',
  'privacy-policy': 'Privacy Policy',
  'terms-conditions': 'Terms & Conditions',
  faq: 'FAQ',
  'refund-policy': 'Refund Policy',
  'shipping-policy': 'Shipping Policy',
  'cookie-policy': 'Cookie Policy',
};

/**
 * Phase 15C, Part 11 — real `/pages` list. One Page document exists
 * per fixed `pageType` at most (the backend enforces this with a
 * unique index) — so this always shows all 8 manageable static page
 * slots, whether or not an admin has created content for them yet.
 * (Homepage's own pageType has a dedicated richer editor — see
 * HomepageCms.jsx — so it's excluded from this list.)
 */
const StaticPagesList = () => {
  const [pagesByType, setPagesByType] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    listPages({ limit: 50 })
      .then((pages) => {
        const map = {};
        (pages || []).forEach((p) => { map[p.pageType] = p; });
        setPagesByType(map);
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <PageHeader title="Static Pages" description="Edit content for the site's fixed policy and info pages." />
      {loading ? (
        <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>
      ) : error ? (
        <p className="text-sm text-destructive py-8 text-center">{error}</p>
      ) : (
        <div className="bg-white rounded-2xl border border-border soft-shadow divide-y divide-border">
          {STATIC_PAGE_TYPES.map((type) => {
            const page = pagesByType[type];
            return (
              <div key={type} className="flex items-center gap-3 px-5 py-4">
                <span className="w-9 h-9 rounded-lg bg-secondary grid place-items-center text-muted-foreground shrink-0"><FileStack className="w-4 h-4" /></span>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{page?.title || TYPE_LABELS[type]}</p>
                  <p className="text-xs text-muted-foreground truncate">/{page?.slug || type}</p>
                </div>
                {page ? <StatusBadge status={page.status} /> : <span className="text-xs text-muted-foreground">Not created yet</span>}
                <Link to={`/admin/cms/pages/${type}/edit`} className="p-2 rounded-lg hover:bg-secondary shrink-0"><Pencil className="w-4 h-4" /></Link>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default StaticPagesList;
