import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import PageHeader from '../../components/PageHeader';
import MediaPickerField from '../../../components/media/MediaPickerField';
import { Field, inputClass, textareaClass } from '../../components/FormSheet';
import TagsInput from '../../components/TagsInput';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../../../components/ui/select';
import { getPageByType, createPage, updatePage } from '../../../services/adminPageService';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

const TYPE_LABELS = {
  'about-us': 'About Us',
  'contact-us': 'Contact Us',
  'privacy-policy': 'Privacy Policy',
  'terms-conditions': 'Terms & Conditions',
  faq: 'FAQ',
  'refund-policy': 'Refund Policy',
  'shipping-policy': 'Shipping Policy',
  'cookie-policy': 'Cookie Policy',
};

const EMPTY = {
  title: '', slug: '', content: '', featuredImage: '', status: 'draft',
  metaTitle: '', metaDescription: '', metaKeywords: [], canonicalUrl: '', ogImage: '',
};

/**
 * Phase 15C, Part 11 — real `/pages` create-or-update, keyed by the
 * fixed `pageType` in the URL rather than a Mongo id, since a page for
 * a given type may not exist yet (create) or may already (update) —
 * one lookup (`GET /pages/type/:pageType`) tells us which.
 */
const StaticPageForm = () => {
  const { pageType } = useParams();
  const { toast } = useToast();
  const [pageId, setPageId] = useState(null);
  const [form, setForm] = useState(EMPTY);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setLoading(true);
    getPageByType(pageType)
      .then((page) => {
        if (page) {
          setPageId(page.id);
          setForm({
            title: page.title, slug: page.slug, content: page.content || '',
            featuredImage: page.featuredImage?.url || '', status: page.status,
            metaTitle: page.seo?.metaTitle || '', metaDescription: page.seo?.metaDescription || '',
            metaKeywords: page.seo?.metaKeywords || [], canonicalUrl: page.seo?.canonicalUrl || '',
            ogImage: page.seo?.ogImage?.url || '',
          });
        } else {
          setPageId(null);
          setForm({ ...EMPTY, title: TYPE_LABELS[pageType] || '' });
        }
      })
      .catch((err) => toast({ title: 'Could not load page', description: getErrorMessage(err), variant: 'destructive' }))
      .finally(() => setLoading(false));
  }, [pageType]);

  const handleSubmit = async (status) => {
    if (!form.title.trim()) { toast({ title: 'Title is required', variant: 'destructive' }); return; }
    setSaving(true);
    try {
      const payload = {
        title: form.title,
        slug: form.slug || undefined,
        content: form.content,
        featuredImage: form.featuredImage ? { url: form.featuredImage } : undefined,
        status: status || form.status,
        seo: {
          metaTitle: form.metaTitle,
          metaDescription: form.metaDescription,
          metaKeywords: form.metaKeywords,
          canonicalUrl: form.canonicalUrl,
          ogImage: form.ogImage ? { url: form.ogImage } : undefined,
        },
      };
      if (pageId) {
        await updatePage(pageId, payload);
      } else {
        const created = await createPage({ ...payload, pageType });
        setPageId(created.id);
      }
      toast({ title: pageId ? 'Page updated' : 'Page created', description: form.title });
    } catch (err) {
      toast({ title: 'Save failed', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>;

  return (
    <div>
      <PageHeader
        title={`Edit — ${TYPE_LABELS[pageType] || pageType}`}
        backTo="/admin/cms/pages"
        backLabel="Static Pages"
        actions={(
          <>
            <button onClick={() => handleSubmit('draft')} disabled={saving} className="px-4 py-2.5 rounded-full text-sm font-semibold border border-border hover:bg-secondary disabled:opacity-60">Save Draft</button>
            <button onClick={() => handleSubmit('published')} disabled={saving} className="px-4 py-2.5 rounded-full text-sm font-semibold brand-gradient text-white disabled:opacity-60">{saving ? 'Saving…' : 'Publish'}</button>
          </>
        )}
      />

      <div className="grid lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 space-y-5">
          <div className="bg-white rounded-2xl border border-border p-5 soft-shadow space-y-4">
            <Field label="Title">
              <input className={inputClass} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
            </Field>
            <Field label="Slug" hint="Leave blank to auto-generate from title.">
              <input className={inputClass} value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} />
            </Field>
            <Field label="Content">
              <textarea className={`${textareaClass} min-h-[300px]`} value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} placeholder="HTML content for this page…" />
            </Field>
          </div>

          <div className="bg-white rounded-2xl border border-border p-5 soft-shadow space-y-4">
            <h2 className="font-semibold">SEO</h2>
            <Field label="Meta Title">
              <input className={inputClass} value={form.metaTitle} onChange={(e) => setForm({ ...form, metaTitle: e.target.value })} />
            </Field>
            <Field label="Meta Description">
              <textarea className={textareaClass} value={form.metaDescription} onChange={(e) => setForm({ ...form, metaDescription: e.target.value })} />
            </Field>
            <Field label="Meta Keywords">
              <TagsInput value={form.metaKeywords} onChange={(v) => setForm({ ...form, metaKeywords: v })} placeholder="Add keyword…" />
            </Field>
            <Field label="Canonical URL">
              <input className={inputClass} value={form.canonicalUrl} onChange={(e) => setForm({ ...form, canonicalUrl: e.target.value })} />
            </Field>
            <MediaPickerField label="Open Graph Image" value={form.ogImage} onChange={(v) => setForm({ ...form, ogImage: v })} modalTitle="Select OG Image" />
          </div>
        </div>

        <div className="space-y-5">
          <div className="bg-white rounded-2xl border border-border p-5 soft-shadow space-y-4">
            <Field label="Status">
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="published">Published</SelectItem>
                </SelectContent>
              </Select>
            </Field>
          </div>
          <div className="bg-white rounded-2xl border border-border p-5 soft-shadow">
            <MediaPickerField label="Featured Image" value={form.featuredImage} onChange={(v) => setForm({ ...form, featuredImage: v })} modalTitle="Select Featured Image" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default StaticPageForm;
