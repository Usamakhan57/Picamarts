import React, { useEffect, useState } from 'react';
import { Download, Mail } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import EmptyState from '../../components/EmptyState';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../../../components/ui/select';
import { listSubscribers, exportSubscribers } from '../../../services/adminNewsletterService';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

const formatDate = (d) => (d ? new Date(d).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : '—');

/**
 * Phase 15C, Part 11 (CMS) — real `/newsletter/subscribers` +
 * `/newsletter/export`. The old mock's NewsletterCms page actually
 * managed campaign/design settings (subject line templates, sender
 * name, etc.) — the real backend has no such model, only a subscriber
 * list, so this is rebuilt as a subscriber-management view instead of
 * kept as a non-functional relic.
 */
const NewsletterCms = () => {
  const { toast } = useToast();
  const [subscribers, setSubscribers] = useState([]);
  const [meta, setMeta] = useState({ totalPages: 1, totalItems: 0 });
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState('all');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [exporting, setExporting] = useState(false);

  const load = () => {
    setLoading(true);
    setError('');
    const params = { page, limit: 20 };
    if (statusFilter !== 'all') params.status = statusFilter;
    listSubscribers(params)
      .then((res) => { setSubscribers(res.subscribers || []); setMeta(res.meta || { totalPages: 1, totalItems: 0 }); })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };
  useEffect(load, [page, statusFilter]);

  const handleExport = async () => {
    setExporting(true);
    try {
      await exportSubscribers(statusFilter !== 'all' ? { status: statusFilter } : {});
    } catch (err) {
      toast({ title: 'Export failed', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setExporting(false);
    }
  };

  const columns = [
    { key: 'email', label: 'Email', render: (row) => <span className="font-medium">{row.email}</span> },
    { key: 'status', label: 'Status', render: (row) => <StatusBadge status={row.status === 'subscribed' ? 'active' : 'inactive'} /> },
    { key: 'subscribedAt', label: 'Subscribed', render: (row) => formatDate(row.subscribedAt) },
    { key: 'unsubscribedAt', label: 'Unsubscribed', render: (row) => formatDate(row.unsubscribedAt) },
  ];

  return (
    <div>
      <PageHeader
        title="Newsletter"
        description={`${meta.totalItems ?? 0} total subscribers.`}
        actions={<button onClick={handleExport} disabled={exporting} className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-full text-sm font-semibold border border-border hover:bg-secondary disabled:opacity-60"><Download className="w-4 h-4" /> {exporting ? 'Exporting…' : 'Export CSV'}</button>}
      />

      <div className="flex items-center gap-2 mb-4">
        <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setPage(1); }}>
          <SelectTrigger className="w-[170px] rounded-full text-sm"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Subscribers</SelectItem>
            <SelectItem value="subscribed">Subscribed</SelectItem>
            <SelectItem value="unsubscribed">Unsubscribed</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {error ? (
        <p className="text-sm text-destructive py-8 text-center">{error}</p>
      ) : subscribers.length === 0 && !loading ? (
        <EmptyState icon={Mail} title="No subscribers yet" description="Newsletter sign-ups will appear here." />
      ) : (
        <>
          <DataTable columns={columns} data={subscribers} isLoading={loading} emptyState={{ title: 'No subscribers yet.' }} />
          {meta.totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 mt-4 text-sm">
              <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className="px-3 py-1.5 rounded-full border border-border disabled:opacity-40">Prev</button>
              <span className="text-muted-foreground">Page {page} of {meta.totalPages}</span>
              <button disabled={page >= meta.totalPages} onClick={() => setPage((p) => p + 1)} className="px-3 py-1.5 rounded-full border border-border disabled:opacity-40">Next</button>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default NewsletterCms;
