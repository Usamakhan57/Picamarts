import React, { useEffect, useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import MediaPickerField from '../../../components/media/MediaPickerField';
import { Field, inputClass, textareaClass } from '../../components/FormSheet';
import { getHomepage, updateHomepage } from '../../../services/adminHomepageService';
import { listAllCategories } from '../../../services/adminCategoryService';
import { listAdminProducts } from '../../../services/adminProductService';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

/**
 * Phase 15C, Part 11 (CMS) — real `/homepage` singleton editor.
 *
 * This one page now covers what used to be six separate mock admin
 * pages (Homepage, Hero Slider, Testimonials, FAQ, Footer, Social
 * Settings) — HomepageConfig is a single document, so those were
 * really just six forms PATCHing the same resource. See
 * adminHomepageService.js for the full mapping/drop rationale
 * (multi-slide Hero Slider folds to one real `heroBanner`; Header CMS,
 * Nav Menus, Popup Manager, Global Settings, and a standalone SEO
 * Manager have no backend equivalent and are dropped).
 *
 * Every section below sends the WHOLE current form on Save — the
 * backend supports partial updates, but a single combined save keeps
 * this page's UX simple (one Save button, one loading state) rather
 * than six independent ones.
 */

const emptyTestimonial = () => ({ name: '', role: '', avatar: '', quote: '', rating: 5 });
const emptyPromo = () => ({ title: '', description: '', image: '', link: '', position: 0 });
const emptyFaq = () => ({ question: '', answer: '' });
const emptySocial = () => ({ platform: '', url: '' });

const EMPTY = {
  heroBanner: { title: '', subtitle: '', image: '', ctaText: '', ctaLink: '' },
  featuredCategoryIds: [],
  featuredProductIds: [],
  testimonials: [],
  promotionalSections: [],
  faqSection: [],
  footerContent: { aboutText: '', socialLinks: [], contactInfo: { email: '', phone: '', address: '' }, copyrightText: '' },
  metaTitle: '', metaDescription: '', metaKeywords: [], canonicalUrl: '', ogImage: '',
};

const HomepageCms = () => {
  const { toast } = useToast();
  const [form, setForm] = useState(EMPTY);
  const [categories, setCategories] = useState([]);
  const [productQuery, setProductQuery] = useState('');
  const [productResults, setProductResults] = useState([]);
  const [selectedProducts, setSelectedProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    listAllCategories().then(setCategories).catch(() => {});
    getHomepage()
      .then((h) => {
        setForm({
          heroBanner: { title: h.heroBanner?.title || '', subtitle: h.heroBanner?.subtitle || '', image: h.heroBanner?.image?.url || '', ctaText: h.heroBanner?.ctaText || '', ctaLink: h.heroBanner?.ctaLink || '' },
          featuredCategoryIds: h.featuredCategories || [],
          featuredProductIds: h.featuredProducts || [],
          testimonials: (h.testimonials || []).map((t) => ({ ...t, avatar: t.avatar?.url || '' })),
          promotionalSections: (h.promotionalSections || []).map((p) => ({ ...p, image: p.image?.url || '' })),
          faqSection: h.faqSection || [],
          footerContent: {
            aboutText: h.footerContent?.aboutText || '',
            socialLinks: h.footerContent?.socialLinks || [],
            contactInfo: h.footerContent?.contactInfo || { email: '', phone: '', address: '' },
            copyrightText: h.footerContent?.copyrightText || '',
          },
          metaTitle: h.seo?.metaTitle || '', metaDescription: h.seo?.metaDescription || '',
          metaKeywords: h.seo?.metaKeywords || [], canonicalUrl: h.seo?.canonicalUrl || '', ogImage: h.seo?.ogImage?.url || '',
        });
      })
      .catch((err) => toast({ title: 'Could not load homepage', description: getErrorMessage(err), variant: 'destructive' }))
      .finally(() => setLoading(false));
  }, []);

  // Resolve featured product titles for display once products/categories are known.
  useEffect(() => {
    if (!form.featuredProductIds.length) { setSelectedProducts([]); return; }
    listAdminProducts({ limit: 100 }).then((res) => {
      setSelectedProducts(res.products.filter((p) => form.featuredProductIds.includes(p.id)));
    }).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading]);

  useEffect(() => {
    if (!productQuery.trim()) { setProductResults([]); return; }
    const t = setTimeout(() => {
      listAdminProducts({ q: productQuery, limit: 10 }).then((res) => setProductResults(res.products)).catch(() => {});
    }, 300);
    return () => clearTimeout(t);
  }, [productQuery]);

  const addFeaturedProduct = (product) => {
    if (form.featuredProductIds.includes(product.id)) return;
    setForm({ ...form, featuredProductIds: [...form.featuredProductIds, product.id] });
    setSelectedProducts([...selectedProducts, product]);
    setProductQuery('');
    setProductResults([]);
  };
  const removeFeaturedProduct = (id) => {
    setForm({ ...form, featuredProductIds: form.featuredProductIds.filter((pid) => pid !== id) });
    setSelectedProducts(selectedProducts.filter((p) => p.id !== id));
  };

  const toggleCategory = (id) => {
    setForm({
      ...form,
      featuredCategoryIds: form.featuredCategoryIds.includes(id)
        ? form.featuredCategoryIds.filter((c) => c !== id)
        : [...form.featuredCategoryIds, id],
    });
  };

  const updateArrayItem = (key, index, patch) => {
    const next = [...form[key]];
    next[index] = { ...next[index], ...patch };
    setForm({ ...form, [key]: next });
  };
  const addArrayItem = (key, factory) => setForm({ ...form, [key]: [...form[key], factory()] });
  const removeArrayItem = (key, index) => setForm({ ...form, [key]: form[key].filter((_, i) => i !== index) });

  const handleSave = async () => {
    setSaving(true);
    try {
      const payload = {
        heroBanner: {
          title: form.heroBanner.title, subtitle: form.heroBanner.subtitle,
          image: form.heroBanner.image ? { url: form.heroBanner.image } : undefined,
          ctaText: form.heroBanner.ctaText, ctaLink: form.heroBanner.ctaLink,
        },
        featuredCategories: form.featuredCategoryIds,
        featuredProducts: form.featuredProductIds,
        testimonials: form.testimonials.map((t) => ({ ...t, avatar: t.avatar ? { url: t.avatar } : undefined })),
        promotionalSections: form.promotionalSections.map((p) => ({ ...p, image: p.image ? { url: p.image } : undefined })),
        faqSection: form.faqSection,
        footerContent: form.footerContent,
        seo: {
          metaTitle: form.metaTitle, metaDescription: form.metaDescription,
          metaKeywords: form.metaKeywords, canonicalUrl: form.canonicalUrl,
          ogImage: form.ogImage ? { url: form.ogImage } : undefined,
        },
      };
      await updateHomepage(payload);
      toast({ title: 'Homepage updated' });
    } catch (err) {
      toast({ title: 'Save failed', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>;

  return (
    <div>
      <PageHeader
        title="Homepage"
        description="Manage the live homepage — hero banner, featured picks, testimonials, FAQ, footer, and SEO."
        actions={<button onClick={handleSave} disabled={saving} className="px-5 py-2.5 rounded-full text-sm font-semibold brand-gradient text-white disabled:opacity-60">{saving ? 'Saving…' : 'Save Changes'}</button>}
      />

      <div className="space-y-5">
        {/* Hero Banner */}
        <section className="bg-white rounded-2xl border border-border p-5 soft-shadow space-y-4">
          <h2 className="font-semibold">Hero Banner</h2>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Title">
              <input className={inputClass} value={form.heroBanner.title} onChange={(e) => setForm({ ...form, heroBanner: { ...form.heroBanner, title: e.target.value } })} />
            </Field>
            <Field label="Subtitle">
              <input className={inputClass} value={form.heroBanner.subtitle} onChange={(e) => setForm({ ...form, heroBanner: { ...form.heroBanner, subtitle: e.target.value } })} />
            </Field>
            <Field label="CTA Text">
              <input className={inputClass} value={form.heroBanner.ctaText} onChange={(e) => setForm({ ...form, heroBanner: { ...form.heroBanner, ctaText: e.target.value } })} />
            </Field>
            <Field label="CTA Link">
              <input className={inputClass} value={form.heroBanner.ctaLink} onChange={(e) => setForm({ ...form, heroBanner: { ...form.heroBanner, ctaLink: e.target.value } })} />
            </Field>
          </div>
          <MediaPickerField label="Banner Image" value={form.heroBanner.image} onChange={(v) => setForm({ ...form, heroBanner: { ...form.heroBanner, image: v } })} modalTitle="Select Hero Banner Image" />
        </section>

        {/* Featured Categories & Products */}
        <section className="bg-white rounded-2xl border border-border p-5 soft-shadow space-y-4">
          <h2 className="font-semibold">Featured Categories</h2>
          <div className="flex flex-wrap gap-2">
            {categories.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => toggleCategory(c.id)}
                className={`px-3 py-1.5 rounded-full text-sm font-medium border transition-colors ${form.featuredCategoryIds.includes(c.id) ? 'brand-gradient text-white border-transparent' : 'border-border hover:bg-secondary'}`}
              >
                {c.name}
              </button>
            ))}
          </div>

          <h2 className="font-semibold pt-2">Featured Products</h2>
          <div className="relative">
            <input
              className={inputClass}
              placeholder="Search products to feature…"
              value={productQuery}
              onChange={(e) => setProductQuery(e.target.value)}
            />
            {productResults.length > 0 && (
              <div className="absolute z-10 mt-1 w-full bg-white border border-border rounded-xl soft-shadow max-h-56 overflow-y-auto">
                {productResults.map((p) => (
                  <button key={p.id} type="button" onClick={() => addFeaturedProduct(p)} className="w-full text-left px-3 py-2 text-sm hover:bg-secondary">
                    {p.title}
                  </button>
                ))}
              </div>
            )}
          </div>
          <ul className="divide-y divide-border">
            {selectedProducts.map((p) => (
              <li key={p.id} className="flex items-center justify-between py-2">
                <span className="text-sm font-medium">{p.title}</span>
                <button onClick={() => removeFeaturedProduct(p.id)} className="p-1.5 rounded-lg hover:bg-secondary text-destructive"><Trash2 className="w-4 h-4" /></button>
              </li>
            ))}
          </ul>
        </section>

        {/* Promotional Sections */}
        <section className="bg-white rounded-2xl border border-border p-5 soft-shadow space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold">Promotional Banners</h2>
            <button onClick={() => addArrayItem('promotionalSections', emptyPromo)} className="inline-flex items-center gap-1 text-sm font-semibold text-primary"><Plus className="w-4 h-4" /> Add</button>
          </div>
          {form.promotionalSections.map((p, i) => (
            <div key={i} className="border border-border rounded-xl p-4 space-y-3">
              <div className="flex justify-end"><button onClick={() => removeArrayItem('promotionalSections', i)} className="p-1.5 rounded-lg hover:bg-secondary text-destructive"><Trash2 className="w-4 h-4" /></button></div>
              <div className="grid sm:grid-cols-2 gap-3">
                <Field label="Title"><input className={inputClass} value={p.title} onChange={(e) => updateArrayItem('promotionalSections', i, { title: e.target.value })} /></Field>
                <Field label="Link"><input className={inputClass} value={p.link} onChange={(e) => updateArrayItem('promotionalSections', i, { link: e.target.value })} /></Field>
              </div>
              <Field label="Description"><textarea className={textareaClass} value={p.description} onChange={(e) => updateArrayItem('promotionalSections', i, { description: e.target.value })} /></Field>
              <MediaPickerField label="Image" value={p.image} onChange={(v) => updateArrayItem('promotionalSections', i, { image: v })} modalTitle="Select Banner Image" />
            </div>
          ))}
          {form.promotionalSections.length === 0 && <p className="text-sm text-muted-foreground">No promotional banners yet.</p>}
        </section>

        {/* Testimonials */}
        <section className="bg-white rounded-2xl border border-border p-5 soft-shadow space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold">Testimonials</h2>
            <button onClick={() => addArrayItem('testimonials', emptyTestimonial)} className="inline-flex items-center gap-1 text-sm font-semibold text-primary"><Plus className="w-4 h-4" /> Add</button>
          </div>
          {form.testimonials.map((t, i) => (
            <div key={i} className="border border-border rounded-xl p-4 space-y-3">
              <div className="flex justify-end"><button onClick={() => removeArrayItem('testimonials', i)} className="p-1.5 rounded-lg hover:bg-secondary text-destructive"><Trash2 className="w-4 h-4" /></button></div>
              <div className="grid sm:grid-cols-3 gap-3">
                <Field label="Name"><input className={inputClass} value={t.name} onChange={(e) => updateArrayItem('testimonials', i, { name: e.target.value })} /></Field>
                <Field label="Role"><input className={inputClass} value={t.role} onChange={(e) => updateArrayItem('testimonials', i, { role: e.target.value })} /></Field>
                <Field label="Rating">
                  <input type="number" min={1} max={5} className={inputClass} value={t.rating} onChange={(e) => updateArrayItem('testimonials', i, { rating: Number(e.target.value) })} />
                </Field>
              </div>
              <Field label="Quote"><textarea className={textareaClass} value={t.quote} onChange={(e) => updateArrayItem('testimonials', i, { quote: e.target.value })} /></Field>
              <MediaPickerField label="Avatar" value={t.avatar} onChange={(v) => updateArrayItem('testimonials', i, { avatar: v })} modalTitle="Select Avatar" />
            </div>
          ))}
          {form.testimonials.length === 0 && <p className="text-sm text-muted-foreground">No testimonials yet.</p>}
        </section>

        {/* FAQ Section */}
        <section className="bg-white rounded-2xl border border-border p-5 soft-shadow space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold">FAQ Section</h2>
            <button onClick={() => addArrayItem('faqSection', emptyFaq)} className="inline-flex items-center gap-1 text-sm font-semibold text-primary"><Plus className="w-4 h-4" /> Add</button>
          </div>
          {form.faqSection.map((f, i) => (
            <div key={i} className="border border-border rounded-xl p-4 space-y-3">
              <div className="flex justify-end"><button onClick={() => removeArrayItem('faqSection', i)} className="p-1.5 rounded-lg hover:bg-secondary text-destructive"><Trash2 className="w-4 h-4" /></button></div>
              <Field label="Question"><input className={inputClass} value={f.question} onChange={(e) => updateArrayItem('faqSection', i, { question: e.target.value })} /></Field>
              <Field label="Answer"><textarea className={textareaClass} value={f.answer} onChange={(e) => updateArrayItem('faqSection', i, { answer: e.target.value })} /></Field>
            </div>
          ))}
          {form.faqSection.length === 0 && <p className="text-sm text-muted-foreground">No FAQ items yet.</p>}
        </section>

        {/* Footer Content (incl. Social Links + Contact Info) */}
        <section className="bg-white rounded-2xl border border-border p-5 soft-shadow space-y-4">
          <h2 className="font-semibold">Footer</h2>
          <Field label="About Text">
            <textarea className={textareaClass} value={form.footerContent.aboutText} onChange={(e) => setForm({ ...form, footerContent: { ...form.footerContent, aboutText: e.target.value } })} />
          </Field>
          <div className="grid sm:grid-cols-3 gap-3">
            <Field label="Contact Email">
              <input className={inputClass} value={form.footerContent.contactInfo.email} onChange={(e) => setForm({ ...form, footerContent: { ...form.footerContent, contactInfo: { ...form.footerContent.contactInfo, email: e.target.value } } })} />
            </Field>
            <Field label="Contact Phone">
              <input className={inputClass} value={form.footerContent.contactInfo.phone} onChange={(e) => setForm({ ...form, footerContent: { ...form.footerContent, contactInfo: { ...form.footerContent.contactInfo, phone: e.target.value } } })} />
            </Field>
            <Field label="Address">
              <input className={inputClass} value={form.footerContent.contactInfo.address} onChange={(e) => setForm({ ...form, footerContent: { ...form.footerContent, contactInfo: { ...form.footerContent.contactInfo, address: e.target.value } } })} />
            </Field>
          </div>
          <Field label="Copyright Text">
            <input className={inputClass} value={form.footerContent.copyrightText} onChange={(e) => setForm({ ...form, footerContent: { ...form.footerContent, copyrightText: e.target.value } })} />
          </Field>

          <div className="flex items-center justify-between pt-2">
            <h3 className="font-medium text-sm">Social Links</h3>
            <button onClick={() => setForm({ ...form, footerContent: { ...form.footerContent, socialLinks: [...form.footerContent.socialLinks, emptySocial()] } })} className="inline-flex items-center gap-1 text-sm font-semibold text-primary"><Plus className="w-4 h-4" /> Add</button>
          </div>
          {form.footerContent.socialLinks.map((s, i) => (
            <div key={i} className="flex items-center gap-2">
              <input className={inputClass} placeholder="Platform (e.g. Instagram)" value={s.platform} onChange={(e) => {
                const next = [...form.footerContent.socialLinks]; next[i] = { ...next[i], platform: e.target.value };
                setForm({ ...form, footerContent: { ...form.footerContent, socialLinks: next } });
              }} />
              <input className={inputClass} placeholder="URL" value={s.url} onChange={(e) => {
                const next = [...form.footerContent.socialLinks]; next[i] = { ...next[i], url: e.target.value };
                setForm({ ...form, footerContent: { ...form.footerContent, socialLinks: next } });
              }} />
              <button onClick={() => setForm({ ...form, footerContent: { ...form.footerContent, socialLinks: form.footerContent.socialLinks.filter((_, idx) => idx !== i) } })} className="p-2 rounded-lg hover:bg-secondary text-destructive shrink-0"><Trash2 className="w-4 h-4" /></button>
            </div>
          ))}
        </section>

        {/* SEO */}
        <section className="bg-white rounded-2xl border border-border p-5 soft-shadow space-y-4">
          <h2 className="font-semibold">SEO</h2>
          <Field label="Meta Title"><input className={inputClass} value={form.metaTitle} onChange={(e) => setForm({ ...form, metaTitle: e.target.value })} /></Field>
          <Field label="Meta Description"><textarea className={textareaClass} value={form.metaDescription} onChange={(e) => setForm({ ...form, metaDescription: e.target.value })} /></Field>
          <Field label="Canonical URL"><input className={inputClass} value={form.canonicalUrl} onChange={(e) => setForm({ ...form, canonicalUrl: e.target.value })} /></Field>
          <MediaPickerField label="Open Graph Image" value={form.ogImage} onChange={(v) => setForm({ ...form, ogImage: v })} modalTitle="Select OG Image" />
        </section>
      </div>
    </div>
  );
};

export default HomepageCms;
