import React, { useEffect, useState } from 'react';
import { Mail, Trash2, Check } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import EmptyState from '../../components/EmptyState';
import ConfirmDeleteDialog from '../../components/ConfirmDeleteDialog';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '../../../components/ui/sheet';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../../../components/ui/select';
import { Field, textareaClass } from '../../components/FormSheet';
import { listMessages, getMessage, updateMessageStatus, deleteMessage } from '../../../services/adminContactService';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

const formatDate = (d) => (d ? new Date(d).toLocaleString(undefined, { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—');

/**
 * Phase 15C, Part 11 (CMS) — brand-new admin page. The real backend
 * has had a full Contact Message inbox (`/contact`) since Phase 10.3
 * with zero admin UI at all — the old mock CMS instead had a "Contact
 * Settings" page for editable business info (email/phone/address),
 * which has no backend model of its own; that content actually lives
 * on the Homepage's `footerContent.contactInfo` (see HomepageCms.jsx).
 * This page replaces that nav slot with the real, previously-missing
 * inbox: view submissions, move new → in progress → resolved, add
 * internal notes, and delete.
 */
const ContactMessagesList = () => {
  const { toast } = useToast();
  const [messages, setMessages] = useState([]);
  const [meta, setMeta] = useState({ totalPages: 1 });
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState('all');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [detail, setDetail] = useState(null);
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const load = () => {
    setLoading(true);
    setError('');
    const params = { page, limit: 20 };
    if (statusFilter !== 'all') params.status = statusFilter;
    listMessages(params)
      .then((res) => { setMessages(res.messages || []); setMeta(res.meta || { totalPages: 1 }); })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };
  useEffect(load, [page, statusFilter]);

  const openDetail = (row) => {
    getMessage(row.id).then((full) => { setDetail(full); setNotes(full.adminNotes || ''); });
  };

  const handleStatusChange = async (status) => {
    setSaving(true);
    try {
      const updated = await updateMessageStatus(detail.id, { status, adminNotes: notes });
      setDetail(updated);
      toast({ title: 'Message updated' });
      load();
    } catch (err) {
      toast({ title: 'Update failed', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await deleteMessage(deleteTarget.id);
      toast({ title: 'Message deleted' });
      setDeleteTarget(null);
      setDetail(null);
      load();
    } catch (err) {
      toast({ title: 'Delete failed', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setDeleting(false);
    }
  };

  const columns = [
    { key: 'name', label: 'From', render: (row) => <div><p className="font-medium">{row.name}</p><p className="text-xs text-muted-foreground">{row.email}</p></div> },
    { key: 'subject', label: 'Subject', render: (row) => row.subject || '(no subject)' },
    { key: 'status', label: 'Status', render: (row) => <StatusBadge status={row.status} /> },
    { key: 'createdAt', label: 'Received', render: (row) => formatDate(row.createdAt) },
    {
      key: 'actions', label: '', render: (row) => (
        <div className="flex items-center gap-1 justify-end">
          <button onClick={() => openDetail(row)} className="p-2 rounded-lg hover:bg-secondary"><Mail className="w-4 h-4" /></button>
          <button onClick={() => setDeleteTarget(row)} className="p-2 rounded-lg hover:bg-secondary text-destructive"><Trash2 className="w-4 h-4" /></button>
        </div>
      ),
    },
  ];

  return (
    <div>
      <PageHeader title="Contact Messages" description="Submissions from the site's contact form." />

      <div className="flex items-center gap-2 mb-4">
        <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setPage(1); }}>
          <SelectTrigger className="w-[160px] rounded-full text-sm"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="new">New</SelectItem>
            <SelectItem value="in_progress">In Progress</SelectItem>
            <SelectItem value="resolved">Resolved</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {error ? (
        <p className="text-sm text-destructive py-8 text-center">{error}</p>
      ) : messages.length === 0 && !loading ? (
        <EmptyState icon={Mail} title="No messages yet" description="Contact form submissions will appear here." />
      ) : (
        <>
          <DataTable columns={columns} data={messages} isLoading={loading} onRowClick={openDetail} emptyState={{ title: 'No messages yet.' }} />
          {meta.totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 mt-4 text-sm">
              <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className="px-3 py-1.5 rounded-full border border-border disabled:opacity-40">Prev</button>
              <span className="text-muted-foreground">Page {page} of {meta.totalPages}</span>
              <button disabled={page >= meta.totalPages} onClick={() => setPage((p) => p + 1)} className="px-3 py-1.5 rounded-full border border-border disabled:opacity-40">Next</button>
            </div>
          )}
        </>
      )}

      <Sheet open={!!detail} onOpenChange={(v) => !v && setDetail(null)}>
        <SheetContent className="w-full sm:max-w-lg overflow-y-auto">
          <SheetHeader><SheetTitle>Message from {detail?.name}</SheetTitle></SheetHeader>
          {detail && (
            <div className="mt-6 space-y-4">
              <p className="text-sm text-muted-foreground">{detail.email}{detail.phone ? ` · ${detail.phone}` : ''}</p>
              {detail.subject && <p className="font-semibold">{detail.subject}</p>}
              <p className="text-sm whitespace-pre-wrap bg-secondary/50 rounded-xl p-4">{detail.message}</p>
              <p className="text-xs text-muted-foreground">Received {formatDate(detail.createdAt)}</p>

              <Field label="Internal Notes">
                <textarea className={textareaClass} value={notes} onChange={(e) => setNotes(e.target.value)} />
              </Field>

              <div className="flex flex-wrap gap-2 pt-2">
                {detail.status !== 'in_progress' && (
                  <button onClick={() => handleStatusChange('in_progress')} disabled={saving} className="px-4 py-2 rounded-full text-sm font-semibold border border-border hover:bg-secondary disabled:opacity-60">Mark In Progress</button>
                )}
                {detail.status !== 'resolved' && (
                  <button onClick={() => handleStatusChange('resolved')} disabled={saving} className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-semibold brand-gradient text-white disabled:opacity-60"><Check className="w-4 h-4" /> Mark Resolved</button>
                )}
                <button onClick={() => handleStatusChange(detail.status)} disabled={saving} className="px-4 py-2 rounded-full text-sm font-semibold border border-border hover:bg-secondary disabled:opacity-60">Save Notes</button>
              </div>
            </div>
          )}
        </SheetContent>
      </Sheet>

      <ConfirmDeleteDialog
        open={!!deleteTarget}
        onOpenChange={(v) => !v && setDeleteTarget(null)}
        onConfirm={handleDelete}
        busy={deleting}
        title="Delete message?"
        description="This message will be permanently deleted."
      />
    </div>
  );
};

export default ContactMessagesList;
