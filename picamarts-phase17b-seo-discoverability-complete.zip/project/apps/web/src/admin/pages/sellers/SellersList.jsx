import React, { useEffect, useState } from 'react';
import { Pencil, Trash2, Check, X, Ban, RotateCcw, Store, Search, Eye } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import StatusBadge from '../../components/StatusBadge';
import EmptyState from '../../components/EmptyState';
import ConfirmDeleteDialog from '../../components/ConfirmDeleteDialog';
import FormSheet, { inputClass } from '../../components/FormSheet';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../../../components/ui/select';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '../../../components/ui/dropdown-menu';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '../../../components/ui/sheet';
import Pagination from '../../../pages/seller/components/Pagination';
import {
  listSellers, getSellerById, approveSeller, rejectSeller, suspendSeller, reinstateSeller, updateSellerByAdmin, deleteSellerByAdmin,
} from '../../../services/sellerService';
import { getSellerAnalytics } from '../../../services/analyticsService';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

const PAGE_SIZE = 20;
const fmtDate = (iso) => (iso ? new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) : '—');
const fmtMoney = (n) => `$${Number(n || 0).toFixed(2)}`;

/**
 * Phase 15C, Part 4 — Admin Seller Management. Wired to the real
 * backend's /sellers admin endpoints (all pre-existing since Phase 5 —
 * only the frontend wiring was missing). "Products"/"Total Sales"
 * columns from the old mock are dropped from the base list (Seller has
 * no such fields, and /analytics/sellers is a top-performer leaderboard
 * that can omit sellers with zero orders — not a reliable per-row join);
 * a "View Details" panel fetches real per-seller performance from
 * /analytics/sellers?sellerId= on demand instead of faking list columns.
 */
const SellersList = () => {
  const { toast } = useToast();
  const [sellers, setSellers] = useState([]);
  const [meta, setMeta] = useState({ totalPages: 1, totalItems: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [status, setStatus] = useState('all');
  const [page, setPage] = useState(1);
  const [busyId, setBusyId] = useState(null);

  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ storeName: '', storeDescription: '', commissionRate: '15' });
  const [saving, setSaving] = useState(false);

  const [detailTarget, setDetailTarget] = useState(null);
  const [detail, setDetail] = useState(null);
  const [detailLoading, setDetailLoading] = useState(false);

  const [reasonPrompt, setReasonPrompt] = useState(null); // { row, action: 'reject'|'suspend' }
  const [reason, setReason] = useState('');
  const [reasonBusy, setReasonBusy] = useState(false);

  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => { setDebouncedQuery(query); setPage(1); }, 350);
    return () => clearTimeout(t);
  }, [query]);

  useEffect(() => { setPage(1); }, [status]);

  const load = () => {
    setLoading(true);
    setError('');
    const params = { page, limit: PAGE_SIZE };
    if (debouncedQuery.trim()) params.q = debouncedQuery.trim();
    if (status !== 'all') params.status = status;

    listSellers(params)
      .then(({ sellers: rows, meta: m }) => {
        setSellers(rows);
        setMeta(m || { totalPages: 1, totalItems: rows.length });
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };

  useEffect(load, [page, debouncedQuery, status]); // eslint-disable-line react-hooks/exhaustive-deps

  const runAction = async (fn, row, message) => {
    setBusyId(row.id);
    try {
      await fn(row.id);
      toast({ title: message, description: row.storeName });
      load();
    } catch (err) {
      toast({ title: 'Action failed', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setBusyId(null);
    }
  };

  const openReasonPrompt = (row, action) => { setReason(''); setReasonPrompt({ row, action }); };
  const submitReasonPrompt = async () => {
    setReasonBusy(true);
    try {
      if (reasonPrompt.action === 'reject') await rejectSeller(reasonPrompt.row.id, reason);
      else await suspendSeller(reasonPrompt.row.id, reason);
      toast({ title: reasonPrompt.action === 'reject' ? 'Seller rejected' : 'Seller suspended', description: reasonPrompt.row.storeName });
      setReasonPrompt(null);
      load();
    } catch (err) {
      toast({ title: 'Action failed', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setReasonBusy(false);
    }
  };

  const openEdit = (row) => {
    setEditing(row);
    setForm({ storeName: row.storeName, storeDescription: row.storeDescription || '', commissionRate: String(row.commissionRate ?? 15) });
  };

  const handleSubmitEdit = async () => {
    if (!form.storeName.trim()) { toast({ title: 'Store name is required', variant: 'destructive' }); return; }
    setSaving(true);
    try {
      await updateSellerByAdmin(editing.id, {
        storeName: form.storeName,
        storeDescription: form.storeDescription,
        commissionRate: Number(form.commissionRate || 15),
      });
      toast({ title: 'Seller updated', description: form.storeName });
      setEditing(null);
      load();
    } catch (err) {
      toast({ title: 'Could not update seller', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const openDetail = (row) => {
    setDetailTarget(row);
    setDetail(null);
    setDetailLoading(true);
    Promise.all([getSellerById(row.id), getSellerAnalytics({ sellerId: row.id, limit: 1 })])
      .then(([seller, analytics]) => setDetail({ seller, performance: analytics?.sellers?.[0] || null }))
      .catch((err) => toast({ title: 'Could not load seller details', description: getErrorMessage(err), variant: 'destructive' }))
      .finally(() => setDetailLoading(false));
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await deleteSellerByAdmin(deleteTarget.id);
      toast({ title: 'Seller deleted', description: deleteTarget.storeName });
      setDeleteTarget(null);
      load();
    } catch (err) {
      toast({ title: 'Could not delete seller', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div>
      <PageHeader title="Sellers" description={`${meta.totalItems ?? sellers.length} marketplace sellers`} />

      <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-4">
        <div className="flex items-center gap-2 bg-secondary/60 rounded-full px-3.5 py-2 flex-1 max-w-sm">
          <Search className="w-4 h-4 text-muted-foreground shrink-0" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search store name…"
            className="bg-transparent outline-none text-sm w-full placeholder:text-muted-foreground"
          />
        </div>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-[160px] rounded-full text-sm"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
            <SelectItem value="rejected">Rejected</SelectItem>
            <SelectItem value="suspended">Suspended</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="bg-white rounded-2xl border border-border overflow-hidden">
        {loading ? (
          <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>
        ) : error ? (
          <div className="p-8 text-center">
            <p className="text-sm text-destructive mb-3">{error}</p>
            <button onClick={load} className="text-sm font-semibold text-primary hover:underline">Try again</button>
          </div>
        ) : sellers.length === 0 ? (
          <EmptyState icon={Store} title="No sellers found" description="Try adjusting your search or filters." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-muted-foreground border-b border-border">
                  <th className="font-medium px-5 py-3">Store</th>
                  <th className="font-medium px-5 py-3">Owner</th>
                  <th className="font-medium px-5 py-3">Commission</th>
                  <th className="font-medium px-5 py-3">Applied</th>
                  <th className="font-medium px-5 py-3">Status</th>
                  <th className="font-medium px-5 py-3 w-10"><span className="sr-only">Actions</span></th>
                </tr>
              </thead>
              <tbody>
                {sellers.map((row) => (
                  <tr key={row.id} className="border-b border-border last:border-0 hover:bg-secondary/30 cursor-pointer" onClick={() => openDetail(row)}>
                    <td className="px-5 py-3 font-medium">{row.storeName}</td>
                    <td className="px-5 py-3">
                      <p>{row.user?.name || '—'}</p>
                      <p className="text-xs text-muted-foreground">{row.user?.email}</p>
                    </td>
                    <td className="px-5 py-3">{row.commissionRate}%</td>
                    <td className="px-5 py-3 text-muted-foreground">{fmtDate(row.submittedAt || row.createdAt)}</td>
                    <td className="px-5 py-3"><StatusBadge status={row.status} /></td>
                    <td className="px-5 py-3" data-no-row-click onClick={(e) => e.stopPropagation()}>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <button disabled={busyId === row.id} className="p-1.5 rounded-lg hover:bg-secondary transition-colors disabled:opacity-50" aria-label="Row actions">
                            <Eye className="w-4 h-4" />
                          </button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => openDetail(row)}><Eye className="w-4 h-4 mr-2" /> View Details</DropdownMenuItem>
                          {row.status === 'pending' && (
                            <>
                              <DropdownMenuItem onClick={() => runAction(approveSeller, row, 'Seller approved')}><Check className="w-4 h-4 mr-2" /> Approve</DropdownMenuItem>
                              <DropdownMenuItem onClick={() => openReasonPrompt(row, 'reject')}><X className="w-4 h-4 mr-2" /> Reject</DropdownMenuItem>
                            </>
                          )}
                          {row.status === 'approved' && (
                            <DropdownMenuItem onClick={() => openReasonPrompt(row, 'suspend')}><Ban className="w-4 h-4 mr-2" /> Suspend</DropdownMenuItem>
                          )}
                          {row.status === 'suspended' && (
                            <DropdownMenuItem onClick={() => runAction(reinstateSeller, row, 'Seller reinstated')}><RotateCcw className="w-4 h-4 mr-2" /> Reinstate</DropdownMenuItem>
                          )}
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => openEdit(row)}><Pencil className="w-4 h-4 mr-2" /> Edit</DropdownMenuItem>
                          <DropdownMenuItem className="text-red-600 focus:text-red-600" onClick={() => setDeleteTarget(row)}><Trash2 className="w-4 h-4 mr-2" /> Delete</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Pagination page={page} totalPages={meta.totalPages || 1} onPageChange={setPage} />

      <FormSheet open={!!editing} onOpenChange={(v) => !v && setEditing(null)} title="Edit Seller" onSubmit={handleSubmitEdit} submitting={saving}>
        <div>
          <label className="block text-sm font-medium mb-1.5">Store Name</label>
          <input value={form.storeName} onChange={(e) => setForm((f) => ({ ...f, storeName: e.target.value }))} className={inputClass} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1.5">Store Description</label>
          <input value={form.storeDescription} onChange={(e) => setForm((f) => ({ ...f, storeDescription: e.target.value }))} className={inputClass} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1.5">Commission (%)</label>
          <input type="number" min="0" max="100" value={form.commissionRate} onChange={(e) => setForm((f) => ({ ...f, commissionRate: e.target.value }))} className={inputClass} />
        </div>
      </FormSheet>

      <FormSheet
        open={!!reasonPrompt}
        onOpenChange={(v) => !v && setReasonPrompt(null)}
        title={reasonPrompt?.action === 'reject' ? 'Reject Seller' : 'Suspend Seller'}
        onSubmit={submitReasonPrompt}
        submitting={reasonBusy}
      >
        <div>
          <label className="block text-sm font-medium mb-1.5">Reason (shown to the seller)</label>
          <input value={reason} onChange={(e) => setReason(e.target.value)} className={inputClass} placeholder="Optional but recommended" />
        </div>
      </FormSheet>

      <Sheet open={!!detailTarget} onOpenChange={(v) => !v && setDetailTarget(null)}>
        <SheetContent className="overflow-y-auto">
          <SheetHeader>
            <SheetTitle>{detailTarget?.storeName}</SheetTitle>
          </SheetHeader>
          {detailLoading ? (
            <p className="text-sm text-muted-foreground mt-6">Loading…</p>
          ) : detail ? (
            <div className="mt-6 space-y-5 text-sm">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Owner</p>
                <p className="font-medium">{detail.seller.user?.name}</p>
                <p className="text-muted-foreground">{detail.seller.user?.email}</p>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-secondary/40 rounded-xl p-3">
                  <p className="text-xs text-muted-foreground">Status</p>
                  <StatusBadge status={detail.seller.status} />
                </div>
                <div className="bg-secondary/40 rounded-xl p-3">
                  <p className="text-xs text-muted-foreground">Commission</p>
                  <p className="font-semibold">{detail.seller.commissionRate}%</p>
                </div>
              </div>
              {detail.performance ? (
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-secondary/40 rounded-xl p-3">
                    <p className="text-xs text-muted-foreground">Revenue</p>
                    <p className="font-semibold">{fmtMoney(detail.performance.revenue)}</p>
                  </div>
                  <div className="bg-secondary/40 rounded-xl p-3">
                    <p className="text-xs text-muted-foreground">Orders</p>
                    <p className="font-semibold">{detail.performance.orderCount ?? 0}</p>
                  </div>
                  <div className="bg-secondary/40 rounded-xl p-3">
                    <p className="text-xs text-muted-foreground">Products</p>
                    <p className="font-semibold">{detail.performance.productCount ?? 0}</p>
                  </div>
                  <div className="bg-secondary/40 rounded-xl p-3">
                    <p className="text-xs text-muted-foreground">Avg Rating</p>
                    <p className="font-semibold">{detail.performance.averageRating ? Number(detail.performance.averageRating).toFixed(1) : '—'}</p>
                  </div>
                </div>
              ) : (
                <p className="text-xs text-muted-foreground">No sales activity yet for this store.</p>
              )}
              {detail.seller.statusReason && (
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Last admin note</p>
                  <p>{detail.seller.statusReason}</p>
                </div>
              )}
            </div>
          ) : null}
        </SheetContent>
      </Sheet>

      <ConfirmDeleteDialog
        open={!!deleteTarget}
        onOpenChange={(v) => !v && setDeleteTarget(null)}
        title="Delete this seller?"
        description={deleteTarget ? `"${deleteTarget.storeName}" will be permanently removed.` : ''}
        onConfirm={handleDelete}
        busy={deleting}
      />
    </div>
  );
};

export default SellersList;
