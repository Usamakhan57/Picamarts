import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Ban, Undo2, Truck, Download as DownloadIcon, Package } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import StatusBadge from '../../components/StatusBadge';
import ConfirmDeleteDialog from '../../components/ConfirmDeleteDialog';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../../../components/ui/select';
import { getOrderById, updateOrderStatus, cancelOrder } from '../../../services/orderService';
import { listShipmentsForOrder } from '../../../services/shippingService';
import { findPaymentForOrder, refundPayment } from '../../../services/paymentService';
import { findDeliveriesForOrder, revokeDownload } from '../../../services/sellerDownloadService';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

const fmtDate = (iso) => new Date(iso).toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
const fmtMoney = (n) => `$${Number(n || 0).toFixed(2)}`;

// Statuses settable via the generic PATCH /orders/:id/status — deliberately
// excludes 'cancelled' (has its own endpoint that also restores stock) and
// 'refunded' (payment-centric, only ever set by an actual Payment refund).
const SETTABLE_STATUSES = ['pending', 'confirmed', 'processing', 'packed', 'shipped', 'delivered', 'completed', 'returned', 'refund_requested'];
const TERMINAL_STATUSES = ['cancelled', 'refunded'];

/**
 * Phase 15C, Part 6 — Admin Order Detail. Wired to the real backend
 * (Phase 8 orders, Phase 9 payments, Phase 14.2 shipments, Phase 14.1
 * digital delivery) — see orderService.js/paymentService.js/
 * shippingService.js/sellerDownloadService.js. The old mock's item
 * "License" column is dropped (the real Product model has no license
 * concept). Payment/digital-delivery lookups are a bounded, best-effort
 * client-side match on order id (see paymentService.js#findPaymentForOrder
 * and sellerDownloadService.js#findDeliveriesForOrder) since the backend
 * has no orderId filter on those endpoints and neither module may be
 * modified this phase.
 */
const OrderDetail = () => {
  const { id } = useParams();
  const { toast } = useToast();
  const [order, setOrder] = useState(null);
  const [shipments, setShipments] = useState([]);
  const [payment, setPayment] = useState(null);
  const [deliveries, setDeliveries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const [cancelOpen, setCancelOpen] = useState(false);
  const [refundOpen, setRefundOpen] = useState(false);

  const load = () => {
    setLoading(true);
    setError('');
    Promise.all([
      getOrderById(id),
      listShipmentsForOrder(id).catch(() => []),
      findPaymentForOrder(id).catch(() => null),
      findDeliveriesForOrder(id).catch(() => []),
    ])
      .then(([o, ships, pay, dels]) => {
        setOrder(o);
        setShipments(ships || []);
        setPayment(pay);
        setDeliveries(dels || []);
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };

  useEffect(load, [id]); // eslint-disable-line react-hooks/exhaustive-deps

  const isTerminal = order && TERMINAL_STATUSES.includes(order.status);

  const handleStatusChange = async (value) => {
    setSaving(true);
    try {
      const updated = await updateOrderStatus(id, value);
      setOrder(updated);
      toast({ title: 'Order updated', description: `Status set to ${value}.` });
    } catch (err) {
      toast({ title: 'Could not update order', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleCancel = async () => {
    setSaving(true);
    try {
      const updated = await cancelOrder(id);
      setOrder(updated);
      toast({ title: 'Order cancelled', description: 'Stock has been restored.' });
      setCancelOpen(false);
    } catch (err) {
      toast({ title: 'Could not cancel order', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleRefund = async () => {
    setSaving(true);
    try {
      await refundPayment(payment.id);
      toast({ title: 'Payment refunded' });
      setRefundOpen(false);
      load();
    } catch (err) {
      toast({ title: 'Could not refund payment', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleRevokeDownload = async (downloadId) => {
    try {
      await revokeDownload(downloadId, 'Revoked from Order Detail (admin).');
      toast({ title: 'Download access revoked' });
      load();
    } catch (err) {
      toast({ title: 'Could not revoke download', description: getErrorMessage(err), variant: 'destructive' });
    }
  };

  if (loading) return <p className="text-sm text-muted-foreground">Loading…</p>;
  if (error) {
    return (
      <div className="bg-white rounded-2xl border border-border p-8 text-center">
        <p className="text-sm text-destructive mb-3">{error}</p>
        <button onClick={load} className="text-sm font-semibold text-primary hover:underline">Try again</button>
      </div>
    );
  }
  if (!order) return <p className="text-sm text-muted-foreground">Order not found.</p>;

  return (
    <div>
      <PageHeader
        title={`Order ${order.orderNumber}`}
        description={fmtDate(order.createdAt)}
        backTo="/admin/orders"
        backLabel="Orders"
        actions={
          !isTerminal && (
            <button
              onClick={() => setCancelOpen(true)}
              disabled={saving}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-full border border-border text-sm font-semibold hover:bg-secondary transition-colors disabled:opacity-60"
            >
              <Ban className="w-4 h-4" /> Cancel Order
            </button>
          )
        }
      />

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-2xl border border-border overflow-hidden">
            <div className="p-5 border-b border-border">
              <h3 className="font-semibold text-sm">Items</h3>
            </div>
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-muted-foreground">
                  <th className="font-medium px-5 py-3">Product</th>
                  <th className="font-medium px-5 py-3 text-center">Qty</th>
                  <th className="font-medium px-5 py-3 text-right">Price</th>
                  <th className="font-medium px-5 py-3 text-right">Line Total</th>
                </tr>
              </thead>
              <tbody>
                {order.items.map((item) => (
                  <tr key={item.id} className="border-t border-border">
                    <td className="px-5 py-3 font-medium flex items-center gap-2.5">
                      {item.thumbnail?.url && <img src={item.thumbnail.url} alt="" className="w-8 h-8 rounded-lg object-cover bg-secondary shrink-0" />}
                      {item.title}
                    </td>
                    <td className="px-5 py-3 text-center">{item.quantity}</td>
                    <td className="px-5 py-3 text-right">{fmtMoney(item.lockedPrice)}</td>
                    <td className="px-5 py-3 text-right font-medium">{fmtMoney(item.lineTotal)}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="border-t border-border"><td colSpan={3} className="px-5 py-2 text-right text-muted-foreground">Subtotal</td><td className="px-5 py-2 text-right">{fmtMoney(order.subtotal)}</td></tr>
                {order.discount > 0 && <tr><td colSpan={3} className="px-5 py-2 text-right text-muted-foreground">Discount</td><td className="px-5 py-2 text-right">-{fmtMoney(order.discount)}</td></tr>}
                <tr><td colSpan={3} className="px-5 py-2 text-right text-muted-foreground">Tax</td><td className="px-5 py-2 text-right">{fmtMoney(order.tax)}</td></tr>
                <tr><td colSpan={3} className="px-5 py-2 text-right text-muted-foreground">Shipping</td><td className="px-5 py-2 text-right">{fmtMoney(order.shipping)}</td></tr>
                <tr className="border-t border-border"><td colSpan={3} className="px-5 py-3 text-right font-semibold">Total</td><td className="px-5 py-3 text-right font-bold">{fmtMoney(order.grandTotal)}</td></tr>
              </tfoot>
            </table>
          </div>

          {shipments.length > 0 && (
            <div className="bg-white rounded-2xl border border-border p-5">
              <h3 className="font-semibold text-sm mb-4 flex items-center gap-2"><Truck className="w-4 h-4" /> Shipments</h3>
              <div className="space-y-3">
                {shipments.map((s) => (
                  <div key={s.id} className="flex items-center justify-between text-sm border-b border-border last:border-0 pb-3 last:pb-0">
                    <div>
                      <p className="font-medium">{s.carrier || 'Carrier not set'} {s.trackingNumber && `— ${s.trackingNumber}`}</p>
                      <p className="text-xs text-muted-foreground">{s.estimatedDelivery ? `Est. delivery ${fmtDate(s.estimatedDelivery)}` : 'No estimate yet'}</p>
                    </div>
                    <StatusBadge status={s.status} />
                  </div>
                ))}
              </div>
            </div>
          )}

          {deliveries.length > 0 && (
            <div className="bg-white rounded-2xl border border-border p-5">
              <h3 className="font-semibold text-sm mb-4 flex items-center gap-2"><DownloadIcon className="w-4 h-4" /> Digital Deliveries</h3>
              <div className="space-y-3">
                {deliveries.map((d) => (
                  <div key={d.id} className="flex items-center justify-between text-sm border-b border-border last:border-0 pb-3 last:pb-0">
                    <div>
                      <p className="font-medium">{typeof d.product === 'object' ? d.product.title : d.product}</p>
                      <p className="text-xs text-muted-foreground">{d.downloadCount} / {d.maxDownloads} downloads used</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <StatusBadge status={d.status} />
                      {d.status !== 'revoked' && (
                        <button onClick={() => handleRevokeDownload(d.id)} className="text-xs font-semibold text-red-600 hover:underline">Revoke</button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-border p-5 space-y-4">
            <h3 className="font-semibold text-sm flex items-center gap-2"><Package className="w-4 h-4" /> Status</h3>
            {isTerminal ? (
              <StatusBadge status={order.status} />
            ) : (
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">Order Status</label>
                <Select value={order.status} onValueChange={handleStatusChange} disabled={saving}>
                  <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {SETTABLE_STATUSES.map((s) => <SelectItem key={s} value={s}>{s.replace('_', ' ')}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            )}
            <div className="flex items-center justify-between text-xs text-muted-foreground pt-2 border-t border-border">
              <span>Payment status</span>
              <StatusBadge status={order.paymentStatus} />
            </div>
            {payment && (
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>Payment method</span>
                <span className="font-medium text-foreground capitalize">{payment.paymentMethod || payment.provider}</span>
              </div>
            )}
            {payment && payment.status === 'succeeded' && payment.refundStatus !== 'full' && (
              <button
                onClick={() => setRefundOpen(true)}
                disabled={saving}
                className="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-full border border-border text-sm font-semibold hover:bg-secondary transition-colors disabled:opacity-60"
              >
                <Undo2 className="w-4 h-4" /> Refund Payment
              </button>
            )}
            {order.paymentStatus === 'paid' && !payment && (
              <p className="text-xs text-muted-foreground">No matching payment record found in the most recent 100 payments.</p>
            )}
          </div>

          <div className="bg-white rounded-2xl border border-border p-5 space-y-3">
            <h3 className="font-semibold text-sm">Customer</h3>
            <p className="font-medium">{order.shippingAddress?.fullName}</p>
            <p className="text-sm text-muted-foreground">
              {order.shippingAddress?.line1}{order.shippingAddress?.line2 ? `, ${order.shippingAddress.line2}` : ''}<br />
              {order.shippingAddress?.city}{order.shippingAddress?.state ? `, ${order.shippingAddress.state}` : ''} {order.shippingAddress?.postalCode}<br />
              {order.shippingAddress?.country}
            </p>
            {order.shippingAddress?.phone && <p className="text-sm text-muted-foreground">{order.shippingAddress.phone}</p>}
          </div>

          {order.timeline?.length > 0 && (
            <div className="bg-white rounded-2xl border border-border p-5">
              <h3 className="font-semibold text-sm mb-3">Timeline</h3>
              <ul className="space-y-3">
                {order.timeline.slice().reverse().map((entry, i) => (
                  <li key={i} className="text-xs">
                    <p className="font-medium capitalize">{entry.status.replace('_', ' ')}</p>
                    <p className="text-muted-foreground">{fmtDate(entry.at)}</p>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>

      <ConfirmDeleteDialog
        open={cancelOpen}
        onOpenChange={setCancelOpen}
        title="Cancel this order?"
        description="Stock for every item will be restored. This cannot be undone."
        onConfirm={handleCancel}
        busy={saving}
        confirmLabel="Cancel Order"
        busyLabel="Cancelling…"
      />

      <ConfirmDeleteDialog
        open={refundOpen}
        onOpenChange={setRefundOpen}
        title="Refund this payment?"
        description={payment ? `Refunds the full remaining amount for payment ${payment.id}.` : ''}
        onConfirm={handleRefund}
        busy={saving}
        confirmLabel="Refund"
        busyLabel="Refunding…"
      />
    </div>
  );
};

export default OrderDetail;
