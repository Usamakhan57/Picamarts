import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Eye, ShoppingCart, Search } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import StatusBadge from '../../components/StatusBadge';
import EmptyState from '../../components/EmptyState';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../../../components/ui/select';
import Pagination from '../../../pages/seller/components/Pagination';
import { listOrders, mapOrderSummary } from '../../../services/orderService';
import { getErrorMessage } from '../../../lib/errorMessage';

const PAGE_SIZE = 20;
const fmtDate = (iso) => new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
const fmtMoney = (n) => `$${Number(n || 0).toFixed(2)}`;

const ORDER_STATUSES = ['pending', 'confirmed', 'processing', 'packed', 'shipped', 'delivered', 'completed', 'returned', 'refund_requested', 'cancelled', 'refunded'];

/**
 * Phase 15C, Part 6 — Admin Order Management. Wired to the real
 * backend's /orders endpoint (admin sees every order server-side,
 * Phase 8) — pure frontend wiring, no backend changes. The old mock's
 * `paymentStatus` filter/refund-from-list action is dropped here in
 * favor of a proper refund flow on Order Detail (real refunds are
 * payment-centric, not a settable order field — see OrderDetail.jsx).
 */
const OrdersList = () => {
  const navigate = useNavigate();
  const [orders, setOrders] = useState([]);
  const [meta, setMeta] = useState({ totalPages: 1, totalItems: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('all');
  const [page, setPage] = useState(1);

  useEffect(() => { setPage(1); }, [status]);

  const load = () => {
    setLoading(true);
    setError('');
    const params = { page, limit: PAGE_SIZE, sort: '-createdAt' };
    if (status !== 'all') params.status = status;

    listOrders(params)
      .then(({ orders: rows, meta: m }) => {
        setOrders(rows.map(mapOrderSummary));
        setMeta(m || { totalPages: 1, totalItems: rows.length });
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };

  useEffect(load, [page, status]); // eslint-disable-line react-hooks/exhaustive-deps

  const visibleOrders = query.trim()
    ? orders.filter((o) => {
        const q = query.trim().toLowerCase();
        return o.id.toLowerCase().includes(q) || o.customerName?.toLowerCase().includes(q);
      })
    : orders;

  return (
    <div>
      <PageHeader title="Orders" description={`${meta.totalItems ?? orders.length} orders`} />

      <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-4">
        <div className="flex items-center gap-2 bg-secondary/60 rounded-full px-3.5 py-2 flex-1 max-w-sm">
          <Search className="w-4 h-4 text-muted-foreground shrink-0" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search this page (order # or customer)…"
            className="bg-transparent outline-none text-sm w-full placeholder:text-muted-foreground"
          />
        </div>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-[170px] rounded-full text-sm"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            {ORDER_STATUSES.map((s) => (
              <SelectItem key={s} value={s}>{s.replace('_', ' ').replace(/^\w/, (c) => c.toUpperCase())}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="bg-white rounded-2xl border border-border overflow-hidden">
        {loading ? (
          <p className="text-sm text-muted-foreground py-12 text-center">Loading…</p>
        ) : error ? (
          <div className="p-8 text-center">
            <p className="text-sm text-destructive mb-3">{error}</p>
            <button onClick={load} className="text-sm font-semibold text-primary hover:underline">Try again</button>
          </div>
        ) : visibleOrders.length === 0 ? (
          <EmptyState icon={ShoppingCart} title="No orders found" description="Try adjusting your search or filters." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-muted-foreground border-b border-border">
                  <th className="font-medium px-5 py-3">Order</th>
                  <th className="font-medium px-5 py-3">Customer</th>
                  <th className="font-medium px-5 py-3">Date</th>
                  <th className="font-medium px-5 py-3">Items</th>
                  <th className="font-medium px-5 py-3">Total</th>
                  <th className="font-medium px-5 py-3">Payment</th>
                  <th className="font-medium px-5 py-3">Status</th>
                  <th className="font-medium px-5 py-3 w-10"><span className="sr-only">Actions</span></th>
                </tr>
              </thead>
              <tbody>
                {visibleOrders.map((row) => (
                  <tr
                    key={row.orderId}
                    className="border-b border-border last:border-0 hover:bg-secondary/30 cursor-pointer"
                    onClick={() => navigate(`/admin/orders/${row.orderId}`)}
                  >
                    <td className="px-5 py-3 font-semibold text-primary">{row.id}</td>
                    <td className="px-5 py-3">{row.customerName || '—'}</td>
                    <td className="px-5 py-3 text-muted-foreground">{fmtDate(row.date)}</td>
                    <td className="px-5 py-3">{row.items.reduce((s, i) => s + i.qty, 0)}</td>
                    <td className="px-5 py-3 font-medium">{fmtMoney(row.total)}</td>
                    <td className="px-5 py-3"><StatusBadge status={row.paymentStatus} /></td>
                    <td className="px-5 py-3"><StatusBadge status={row.rawStatus} /></td>
                    <td className="px-5 py-3" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => navigate(`/admin/orders/${row.orderId}`)}
                        className="p-1.5 rounded-lg hover:bg-secondary transition-colors"
                        aria-label="View details"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Pagination page={page} totalPages={meta.totalPages || 1} onPageChange={setPage} />
    </div>
  );
};

export default OrdersList;
