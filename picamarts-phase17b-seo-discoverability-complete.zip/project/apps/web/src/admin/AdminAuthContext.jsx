import React, { createContext, useContext, useCallback } from 'react';
import { useStore } from '../context/StoreContext';

const AdminAuthContext = createContext(null);

/**
 * Wraps the single, real backend session (StoreContext/useStore) with an
 * admin-specific view: role gating only. There is no separate admin
 * "database" or token — admins are just User accounts with role='admin'
 * (provisioned directly in the database/seed scripts; no public
 * self-registration route exists for this role, by design — see
 * auth.validator.js's register schema).
 *
 * Replaces the old hardcoded-credential mock entirely.
 */
export const AdminAuthProvider = ({ children }) => {
  const { user, authLoading, login: storeLogin, logout: storeLogout } = useStore();

  const isAdminAccount = !!user && user.role === 'admin';

  const login = useCallback(async (email, password) => {
    const loggedInUser = await storeLogin(email, password);
    if (loggedInUser.role !== 'admin') {
      await storeLogout();
      const err = new Error('This account does not have admin access.');
      err.status = 403;
      throw err;
    }
    return loggedInUser;
  }, [storeLogin, storeLogout]);

  const logout = useCallback(async () => {
    await storeLogout();
  }, [storeLogout]);

  const admin = isAdminAccount ? { name: user.name, email: user.email, role: user.role } : null;

  return (
    <AdminAuthContext.Provider value={{ admin, isAuthenticated: isAdminAccount, authLoading, login, logout }}>
      {children}
    </AdminAuthContext.Provider>
  );
};

export const useAdminAuth = () => {
  const ctx = useContext(AdminAuthContext);
  if (!ctx) throw new Error('useAdminAuth must be used within AdminAuthProvider');
  return ctx;
};
