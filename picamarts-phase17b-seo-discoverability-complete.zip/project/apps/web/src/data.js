import picamartsLogo from './assets/picamarts-logo.png';

export const LOGO = picamartsLogo;

// Turns a category name into a URL-safe slug, e.g. "T-Shirt Design" -> "t-shirt-design"
export const slugify = (name) =>
  name.toLowerCase().trim().replace(/&/g, 'and').replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

// NOTE: categories used to be hardcoded here, completely disconnected
// from the Admin Category CMS — a category created in Admin never showed
// up anywhere on the storefront. Categories now live entirely in
// services/categoryRepository.js (backed by the Admin Category CMS via
// pm_admin_categories), which is the only place any page/component
// should read categories from.

const img = {
  wall: 'https://images.hostinger.com/14c75e77-0a1d-4eff-aeb3-c2f48b8d05b6.png',
  floral: 'https://images.hostinger.com/1aabeebf-b3be-4e50-bda3-c9d079f186bc.png',
  canva: 'https://images.hostinger.com/44bf45d5-8b11-4c36-bc33-ee5b4579d328.png',
  font: 'https://images.hostinger.com/bb373382-441e-48e3-8f24-9bddc6578f8b.png',
  color: 'https://images.hostinger.com/29d71df9-7e01-4110-bdfc-a8a59ac08e88.png',
  icons: 'https://images.hostinger.com/aaa4f72b-3b0f-490f-9733-ba3aad15c3c6.png',
  planner: 'https://images.hostinger.com/b0df72e9-f32f-4fb4-ac50-4e521c8509a3.png',
  vector: 'https://images.hostinger.com/cf257400-b18a-4756-ae1e-d3b8c8e6c2db.png',
};

// Shared license tiers — most products offer both; a few (bundles, fonts)
// are Commercial-only or Personal-only, set per-product via `licenseIds`.
export const licenseCatalog = {
  personal: {
    id: 'personal',
    name: 'Personal Use',
    priceMultiplier: 1,
    description: 'For personal projects, gifts, and non-commercial use only. Not for resale or client work.',
    permissions: ['Use in personal projects', 'Print for personal/gift use', 'Unlimited personal downloads'],
    restrictions: ['No resale or redistribution', 'No use in client or commercial work', 'No claiming as your own design'],
  },
  commercial: {
    id: 'commercial',
    name: 'Commercial Use',
    priceMultiplier: 1.8,
    description: 'For small business use, client work, and products for resale — up to 500 end-product sales.',
    permissions: ['Everything in Personal', 'Use in client and commercial projects', 'Sell up to 500 physical/digital end products', 'Use in branding and marketing'],
    restrictions: ['No reselling the raw files themselves', 'No claiming original design credit'],
  },
  extended: {
    id: 'extended',
    name: 'Extended Commercial',
    priceMultiplier: 3,
    description: 'Unlimited commercial end-product sales, for agencies and high-volume sellers.',
    permissions: ['Everything in Commercial', 'Unlimited end-product sales', 'Use across multiple brands/clients'],
    restrictions: ['No reselling the raw files themselves'],
  },
};

const included = (fileTypes) => [
  `${fileTypes.join(', ')} files`,
  '300 DPI print-ready resolution',
  'Instant download after checkout',
  'Commercial license PDF (if selected)',
];

const defaultFaqs = [
  { q: 'What file formats do I get?', a: 'You\'ll receive all listed file formats in a single ZIP download, available immediately in My Account after purchase.' },
  { q: 'Can I use this for a client project?', a: 'Yes, with a Commercial or Extended license. The Personal license is for non-commercial use only.' },
  { q: 'Do I need special software to open the files?', a: 'Most files work with common design tools (Photoshop, Canva, Procreate, Cricut Design Space) — check the file type list above for compatibility.' },
];

export const products = [
  {
    id: 1, title: 'Boho Arch Wall Art Set', cat: 'Wall Arts', price: 12, old: 18, rating: 4.9, reviewCount: 128, downloads: 3120,
    img: img.wall, images: [img.wall, img.floral, img.vector], badge: 'Sale', artist: 'Studio Lume',
    fileTypes: ['PNG', 'SVG', 'PDF'], dimensions: '5000×5000px, 300DPI', version: 'v1.2',
    description: 'A set of 8 minimalist boho arch wall art prints, perfect for gallery walls, nurseries, or client mockups. Hand-illustrated line work with a warm, earthy palette.',
    whatsIncluded: included(['PNG', 'SVG', 'PDF']),
    licenseIds: ['personal', 'commercial'],
    faqs: defaultFaqs,
  },
  {
    id: 2, title: 'Watercolor Floral Clipart', cat: 'Cliparts', price: 9, old: null, rating: 4.8, reviewCount: 312, downloads: 5240,
    img: img.floral, images: [img.floral, img.wall, img.color], badge: 'Best Seller', artist: 'Petal & Ink',
    fileTypes: ['PNG', 'SVG'], dimensions: '4000×4000px, transparent background', version: 'v2.0',
    description: 'Hand-painted watercolor floral clipart bundle — 24 individual elements including roses, eucalyptus, and wildflowers. Perfect for invitations, branding, and stationery.',
    whatsIncluded: included(['PNG', 'SVG']),
    licenseIds: ['personal', 'commercial', 'extended'],
    faqs: defaultFaqs,
  },
  {
    id: 3, title: 'Minimal Motivation Poster', cat: 'Posters', price: 8, old: 14, rating: 5.0, reviewCount: 64, downloads: 1890,
    img: img.canva, images: [img.canva, img.font], badge: 'New', artist: 'Nova Grid',
    fileTypes: ['PDF', 'PNG'], dimensions: 'A4 & US Letter, 300DPI', version: 'v1.0',
    description: 'A set of 6 minimal typography motivation posters, ready to print at home or through a print shop. Clean, modern layout that fits any wall.',
    whatsIncluded: included(['PDF', 'PNG']),
    licenseIds: ['personal', 'commercial'],
    faqs: defaultFaqs,
  },
  {
    id: 4, title: 'Elegant Wedding Card Suite', cat: 'Cards', price: 15, old: null, rating: 4.9, reviewCount: 201, downloads: 980,
    img: img.font, images: [img.font, img.floral], badge: 'Premium', artist: 'Paper Muse',
    fileTypes: ['Canva Template', 'PDF'], dimensions: '5×7in, editable in Canva', version: 'v1.4',
    description: 'A complete editable wedding stationery suite — invitation, RSVP, and details card — built as a Canva template so you can customize text and colors instantly.',
    whatsIncluded: included(['Canva Template', 'PDF']),
    licenseIds: ['personal', 'commercial'],
    faqs: defaultFaqs,
  },
  {
    id: 5, title: 'Dino Kids Coloring Pages', cat: 'Coloring Pages', price: 6, old: 10, rating: 4.7, reviewCount: 87, downloads: 4110,
    img: img.color, images: [img.color, img.vector], badge: 'Sale', artist: 'Little Doodles',
    fileTypes: ['PDF', 'PNG'], dimensions: 'US Letter, 300DPI', version: 'v1.1',
    description: '20 dinosaur-themed coloring pages for kids ages 3-8. Bold outlines sized for little hands, printable at home.',
    whatsIncluded: included(['PDF', 'PNG']),
    licenseIds: ['personal', 'commercial'],
    faqs: defaultFaqs,
  },
  {
    id: 6, title: 'Mega PNG Bundle Vol.3', cat: 'PNG Bundles', price: 14, old: null, rating: 4.9, reviewCount: 445, downloads: 2760,
    img: img.icons, images: [img.icons, img.vector, img.color], badge: 'Best Seller', artist: 'Pixel Craft',
    fileTypes: ['PNG'], dimensions: '4000×4000px, transparent background', version: 'v3.0',
    description: '150+ transparent PNG graphics spanning seasonal, sports, and novelty themes — a huge time-saver for print-on-demand sellers.',
    whatsIncluded: included(['PNG']),
    licenseIds: ['commercial', 'extended'],
    faqs: defaultFaqs,
  },
  {
    id: 7, title: 'Aesthetic Digital Planner', cat: 'Planner', price: 16, old: 22, rating: 4.8, reviewCount: 156, downloads: 1540,
    img: img.planner, images: [img.planner, img.canva], badge: 'Sale', artist: 'Daily Flow',
    fileTypes: ['PDF (Hyperlinked)', 'GoodNotes'], dimensions: 'iPad & tablet optimized', version: 'v2.1',
    description: 'A fully hyperlinked digital planner with daily, weekly, and monthly spreads — built for GoodNotes, Notability, and iPad note-taking apps.',
    whatsIncluded: included(['PDF (Hyperlinked)', 'GoodNotes']),
    licenseIds: ['personal'],
    faqs: defaultFaqs,
  },
  {
    id: 8, title: 'Botanical Nature Prints', cat: 'Nature', price: 11, old: null, rating: 4.6, reviewCount: 93, downloads: 2230,
    img: img.vector, images: [img.vector, img.wall], badge: 'New', artist: 'Form Lab',
    fileTypes: ['SVG', 'PNG', 'EPS'], dimensions: '5000×5000px, 300DPI', version: 'v1.0',
    description: 'A vector botanical print collection featuring 10 hand-drawn leaf and branch illustrations, ideal for wall art and packaging design.',
    whatsIncluded: included(['SVG', 'PNG', 'EPS']),
    licenseIds: ['personal', 'commercial'],
    faqs: defaultFaqs,
  },
  {
    id: 9, title: 'Vintage Sports Tee Graphics', cat: 'T-Shirt Design', price: 13, old: 20, rating: 4.8, reviewCount: 178, downloads: 1720,
    img: img.icons, images: [img.icons, img.vector], badge: 'Sale', artist: 'Bold Press',
    fileTypes: ['SVG', 'PNG', 'DXF'], dimensions: '12×12in, 300DPI', version: 'v1.3',
    description: 'A retro-style sports graphics bundle designed for t-shirt printing and DTF transfers — includes Cricut/Silhouette-ready cut files.',
    whatsIncluded: included(['SVG', 'PNG', 'DXF']),
    licenseIds: ['commercial', 'extended'],
    faqs: defaultFaqs,
  },
  {
    id: 10, title: 'Championship Sports Badges', cat: 'Sports', price: 10, old: null, rating: 4.7, reviewCount: 51, downloads: 1330,
    img: img.vector, images: [img.vector, img.icons], badge: 'New', artist: 'Field Mark',
    fileTypes: ['SVG', 'PNG'], dimensions: '3000×3000px, transparent background', version: 'v1.0',
    description: 'A set of 15 championship badge and emblem graphics — great for team merch, banners, and sports branding projects.',
    whatsIncluded: included(['SVG', 'PNG']),
    licenseIds: ['personal', 'commercial'],
    faqs: defaultFaqs,
  },
  {
    id: 11, title: 'Abstract Gallery Wall Set', cat: 'Wall Arts', price: 17, old: 25, rating: 4.9, reviewCount: 267, downloads: 2040,
    img: img.wall, images: [img.wall, img.floral], badge: 'Best Seller', artist: 'Studio Lume',
    fileTypes: ['PNG', 'SVG', 'PDF'], dimensions: '6000×6000px, 300DPI', version: 'v2.0',
    description: 'A 12-piece abstract gallery wall art collection with a cohesive earth-tone palette — designed to be printed and framed as a full set.',
    whatsIncluded: included(['PNG', 'SVG', 'PDF']),
    licenseIds: ['personal', 'commercial'],
    faqs: defaultFaqs,
  },
  {
    id: 12, title: 'Seasonal Greeting Cards Pack', cat: 'Cards', price: 7, old: null, rating: 4.6, reviewCount: 42, downloads: 1610,
    img: img.floral, images: [img.floral, img.font], badge: null, artist: 'Paper Muse',
    fileTypes: ['PDF', 'PNG'], dimensions: '5×7in, 300DPI', version: 'v1.0',
    description: 'A 10-card seasonal greeting card pack covering every major holiday — print at home or send to a local print shop.',
    whatsIncluded: included(['PDF', 'PNG']),
    licenseIds: ['personal', 'commercial'],
    faqs: defaultFaqs,
  },
];

export const artists = [
  { name: 'Studio Lume', slug: 'studio-lume', sales: '12.4k', specialty: 'Wall Arts', initials: 'SL', rating: 4.9, joined: '2021', bio: 'Studio Lume is a two-person design collective crafting minimalist wall art and gallery sets for modern homes and client mockups.' },
  { name: 'Petal & Ink', slug: 'petal-and-ink', sales: '18.9k', specialty: 'Cliparts', initials: 'PI', rating: 4.8, joined: '2020', bio: 'Petal & Ink hand-paints watercolor florals and botanicals, turned into crisp, print-ready clipart bundles for makers everywhere.' },
  { name: 'Nova Grid', slug: 'nova-grid', sales: '9.2k', specialty: 'Posters', initials: 'NG', rating: 5.0, joined: '2022', bio: 'Nova Grid designs clean, modern typography posters built on a strict grid system — bold, minimal, and endlessly printable.' },
  { name: 'Pixel Craft', slug: 'pixel-craft', sales: '15.1k', specialty: 'PNG Bundles', initials: 'PC', rating: 4.9, joined: '2019', bio: 'Pixel Craft ships massive transparent PNG bundles for print-on-demand sellers who need volume without sacrificing quality.' },
  { name: 'Bold Press', slug: 'bold-press', sales: '7.8k', specialty: 'T-Shirt Design', initials: 'BP', rating: 4.8, joined: '2022', bio: 'Bold Press specializes in retro sports and streetwear graphics, cut-file ready for DTF, Cricut, and Silhouette workflows.' },
  { name: 'Daily Flow', slug: 'daily-flow', sales: '6.1k', specialty: 'Planner', initials: 'DF', rating: 4.8, joined: '2023', bio: 'Daily Flow builds hyperlinked digital planners designed for GoodNotes and Notability, made for people who love a clean spread.' },
  { name: 'Form Lab', slug: 'form-lab', sales: '5.4k', specialty: 'Nature', initials: 'FL', rating: 4.6, joined: '2023', bio: 'Form Lab creates vector botanical and nature illustrations for packaging, branding, and wall art projects.' },
  { name: 'Field Mark', slug: 'field-mark', sales: '4.2k', specialty: 'Sports', initials: 'FM', rating: 4.7, joined: '2023', bio: 'Field Mark designs championship badges and sports emblems for team merch and league branding.' },
  { name: 'Little Doodles', slug: 'little-doodles', sales: '8.6k', specialty: 'Coloring Pages', initials: 'LD', rating: 4.7, joined: '2021', bio: 'Little Doodles draws bold, kid-friendly coloring pages sized for little hands and big imaginations.' },
];

export const getArtistBySlug = (slug) => artists.find((a) => a.slug === slug);
export const artistProducts = (name) => products.filter((p) => p.artist === name);

export const collections = [
  { slug: 'cozy-home-edit', title: 'The Cozy Home Edit', description: 'Warm, earthy wall art and prints to soften any room.', cover: img.wall, cat: 'Wall Arts' },
  { slug: 'botanical-dreams', title: 'Botanical Dreams', description: 'Hand-painted florals and leafy vectors for stationery and branding.', cover: img.floral, cat: 'Cliparts' },
  { slug: 'print-shop-starter', title: 'Print Shop Starter Kit', description: 'Everything a new POD seller needs — bundles, tees, and badges.', cover: img.icons, cat: 'PNG Bundles' },
  { slug: 'plan-your-year', title: 'Plan Your Year', description: 'Digital planners and printables to keep every season organized.', cover: img.planner, cat: 'Planner' },
  { slug: 'celebration-station', title: 'Celebration Station', description: 'Cards, invites, and party graphics for every occasion.', cover: img.font, cat: 'Cards' },
  { slug: 'kids-corner', title: 'Kids Corner', description: 'Playful coloring pages and doodles made for little artists.', cover: img.color, cat: 'Coloring Pages' },
];

export const blogPosts = [
  { slug: 'choosing-the-right-license', title: 'Choosing the Right License for Your Project', excerpt: 'Personal, Commercial, or Extended — here\'s how to pick the license that actually matches how you plan to use your download.', cover: img.font, author: 'PicaMarts Team', date: '2026-06-18', category: 'Guides', readTime: '5 min read',
    content: [
      'Every product on PicaMarts ships with at least one license tier, and picking the right one is less about the price and more about what you plan to do with the file after checkout.',
      'A Personal license covers gifts, home projects, and anything that never touches a sale. A Commercial license opens the door to client work and limited-run resale, while Extended Commercial removes the sales cap entirely for agencies and high-volume shops.',
      'When in doubt, start with the smallest license that covers your current project — you can always come back and upgrade later if your use case grows.',
    ] },
  { slug: 'five-ways-to-use-clipart', title: '5 Ways to Use Clipart Beyond the Obvious', excerpt: 'Clipart is not just for scrapbooking — see how sellers are using it in packaging, social templates, and more.', cover: img.floral, author: 'Petal & Ink', date: '2026-06-05', category: 'Inspiration', readTime: '4 min read',
    content: [
      'Clipart libraries are often thought of as a scrapbooking tool, but the most creative shop owners are using them everywhere from product packaging to social media templates.',
      'Try layering clipart elements behind your logo for packaging inserts, or use single elements as accent graphics in a slide deck or newsletter header.',
      'The key is treating each element as a flexible building block rather than a finished graphic — resize, recolor, and recombine to get something that feels custom.',
    ] },
  { slug: 'setting-up-your-print-on-demand-shop', title: 'Setting Up Your Print-on-Demand Shop in a Weekend', excerpt: 'A practical, no-fluff walkthrough for turning a folder of downloads into a live storefront.', cover: img.icons, author: 'Pixel Craft', date: '2026-05-22', category: 'Business', readTime: '7 min read',
    content: [
      'You do not need months of planning to launch a print-on-demand shop — with the right assets, a weekend is plenty of time.',
      'Start by picking one tight niche and 10-15 designs with a commercial license, then mock them up on your chosen products using a free mockup generator.',
      'List your first batch, set realistic shipping expectations, and treat your first two weeks as a feedback loop rather than a finish line.',
    ] },
  { slug: 'trends-in-digital-planning', title: '2026 Trends in Digital Planning', excerpt: 'From hyperlinked spreads to minimalist widgets, here is what is shaping digital planner design this year.', cover: img.planner, author: 'Daily Flow', date: '2026-04-30', category: 'Trends', readTime: '4 min read',
    content: [
      'Digital planning has moved well past simple PDF grids — this year’s most popular spreads lean on deep hyperlinking so every tap feels instant.',
      'Minimalist, low-contrast palettes are trending over busy stickers, giving planners a calmer, more focused feel on-screen.',
      'Expect to see more modular spreads too, where users mix and match widgets like habit trackers and mood logs instead of using one fixed layout.',
    ] },
  { slug: 'watercolor-technique-breakdown', title: 'Behind the Scenes: Our Watercolor Technique', excerpt: 'A peek into how our best-selling floral clipart sets go from real paint to layered PNG files.', cover: img.color, author: 'Petal & Ink', date: '2026-04-11', category: 'Behind the Scenes', readTime: '6 min read',
    content: [
      'Every floral element starts as a real watercolor painting on cold-press paper, scanned at high resolution to preserve the texture of the pigment.',
      'From there, each piece is hand-cut in layers so shadows and highlights stay separate, which is what lets you recolor elements without losing the painted texture.',
      'The final export pass checks every file at multiple sizes to make sure the details still hold up whether it is printed at 3 inches or 30.',
    ] },
  { slug: 'sports-graphics-for-team-merch', title: 'Designing Sports Graphics That Sell as Team Merch', excerpt: 'What makes a badge or emblem actually work on a jersey, tumbler, or banner.', cover: img.vector, author: 'Field Mark', date: '2026-03-27', category: 'Inspiration', readTime: '5 min read',
    content: [
      'Good team merch graphics need to survive being shrunk down to a two-inch patch and blown up to a six-foot banner without losing legibility.',
      'That usually means bold, simple shapes, high contrast, and text that is set in a sturdy, condensed typeface rather than anything delicate.',
      'Test every design in grayscale first — if it still reads clearly without color, it will hold up across every product it gets printed on.',
    ] },
];

export const faqCategories = [
  { title: 'Orders & Downloads', items: [
    { q: 'When do I get my files?', a: 'Immediately after checkout. Every order unlocks instant downloads in your account, no waiting.' },
    { q: 'Can I re-download a purchase later?', a: 'Yes, all past purchases stay available in your account for re-download at any time.' },
  ]},
  { title: 'Licensing', items: [
    { q: 'What license do I need for a client project?', a: 'Commercial or Extended Commercial, depending on your expected sales volume. Personal license is non-commercial only.' },
    { q: 'Can I resell the raw files?', a: 'No license tier permits reselling the original files themselves — only end products made using them.' },
  ]},
];

export const testimonials = [
  { name: 'Amelia Carter', role: 'Etsy Shop Owner', text: 'PicaMarts is my go-to for premium cliparts. The instant downloads and clean licensing saved my launch week.', initials: 'AC' },
  { name: 'Marcus Bailey', role: 'Freelance Designer', text: 'The quality here is unreal. Every asset is crisp, layered, and print-ready. Checkout took ten seconds.', initials: 'MB' },
  { name: 'Priya Nair', role: 'Content Creator', text: 'Beautiful templates that actually look luxury. My engagement doubled after switching packs.', initials: 'PN' },
];

/** Sample reviews shown on the product detail page — same shape a real
 *  review submission would produce, so wiring a review form to this
 *  array later is a drop-in change. */
export const sampleReviews = [
  { name: 'Jordan K.', rating: 5, date: '2025-06-02', text: 'Exactly what I needed for my shop mockups. Files were clean and easy to edit.' },
  { name: 'Sam R.', rating: 4, date: '2025-05-18', text: 'Great quality, wish there were a couple more color variations but still worth it.' },
  { name: 'Taylor M.', rating: 5, date: '2025-04-30', text: 'Instant download worked perfectly and the commercial license PDF was included right away.' },
];
