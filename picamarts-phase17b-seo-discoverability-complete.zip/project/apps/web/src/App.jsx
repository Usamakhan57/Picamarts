import React, { Suspense, lazy } from 'react';
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import { StoreProvider } from './context/StoreContext';
import ScrollToTop from './components/ScrollToTop';
import CompareBar from './components/CompareBar';
import { Toaster } from './components/ui/toaster';
import { ErrorBoundary } from './components/ErrorState';
import { Spinner } from './components/ui/spinner';

// Storefront (eagerly loaded — first paint matters here)
import HomePage from './pages/HomePage';
import ShopPage from './pages/ShopPage';
import ProductDetailPage from './pages/ProductDetailPage';
import CategoriesPage from './pages/CategoriesPage';
import CategoryPage from './pages/CategoryPage';
import CollectionsPage from './pages/CollectionsPage';
import BlogPage from './pages/BlogPage';
import BlogPostPage from './pages/BlogPostPage';
import AboutPage from './pages/AboutPage';
import WishlistPage from './pages/WishlistPage';
import CartPage from './pages/CartPage';
import ComparePage from './pages/ComparePage';
import OrderFailedPage from './pages/OrderFailedPage';
import ForbiddenPage from './pages/ForbiddenPage';
import MaintenancePage from './pages/MaintenancePage';
import ComingSoonPage from './pages/ComingSoonPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import ForgotPasswordPage from './pages/ForgotPasswordPage';
import ResetPasswordPage from './pages/ResetPasswordPage';
import SearchResultsPage from './pages/SearchResultsPage';
import SellerProfilePage from './pages/SellerProfilePage';
import BecomeASellerPage from './pages/BecomeASellerPage';
import SellerLoginPage from './pages/SellerLoginPage';
import SellerRegisterPage from './pages/SellerRegisterPage';
import SellerDashboard from './pages/SellerDashboard';
import NewProductPage from './pages/seller/NewProductPage';
import SellerHubPage from './pages/SellerHubPage';
import { SellerAuthProvider } from './context/SellerAuthContext';
import RequireSellerAuth from './components/RequireSellerAuth';
import RequireCustomerAuth from './components/RequireCustomerAuth';
import ContactPage from './pages/ContactPage';
import PrivacyPolicyPage from './pages/PrivacyPolicyPage';
import TermsPage from './pages/TermsPage';
import FAQPage from './pages/FAQPage';
import RefundPolicyPage from './pages/RefundPolicyPage';
import CheckoutPage from './pages/CheckoutPage';
import ProfilePage from './pages/account/ProfilePage';
import AccountOrdersPage from './pages/account/OrdersPage';
import AccountDownloadsPage from './pages/account/DownloadsPage';
import AccountSettingsPage from './pages/account/SettingsPage';
import ServerErrorPage from './pages/ServerErrorPage';
import NetworkErrorPage from './pages/NetworkErrorPage';
import NotFoundPage from './pages/NotFoundPage';

// Buyer Dashboard (lazy-loaded — keeps these out of the initial storefront bundle)
const AccountDashboardPage = lazy(() => import('./pages/account/DashboardPage'));
const AccountReviewsPage = lazy(() => import('./pages/account/ReviewsPage'));
const AccountSecurityPage = lazy(() => import('./pages/account/SecurityPage'));
const AccountNotificationsPage = lazy(() => import('./pages/account/NotificationsPage'));
const AccountAddressesPage = lazy(() => import('./pages/account/AddressesPage'));
const AccountPaymentMethodsPage = lazy(() => import('./pages/account/PaymentMethodsPage'));
const AccountSupportPage = lazy(() => import('./pages/account/SupportPage'));
const AccountInvoicesPage = lazy(() => import('./pages/account/InvoicesPage'));
const AccountPaymentsPage = lazy(() => import('./pages/account/PaymentsPage'));
const AccountCouponsPage = lazy(() => import('./pages/account/CouponsPage'));
const AccountFollowingPage = lazy(() => import('./pages/account/FollowingPage'));
const AccountBrowsingHistoryPage = lazy(() => import('./pages/account/BrowsingHistoryPage'));
const AccountShipmentsPage = lazy(() => import('./pages/account/ShipmentsPage'));
const AccountWishlistsPage = lazy(() => import('./pages/account/WishlistsPage'));
const AccountWishlistDetailPage = lazy(() => import('./pages/account/WishlistDetailPage'));
const SharedWishlistPage = lazy(() => import('./pages/SharedWishlistPage'));

// Admin (lazy-loaded — keeps the admin panel out of the storefront bundle)
import { AdminAuthProvider } from './admin/AdminAuthContext';
import RequireAdminAuth from './admin/RequireAdminAuth';

const AdminLoginPage = lazy(() => import('./admin/pages/AdminLoginPage'));
const AdminLayout = lazy(() => import('./admin/layout/AdminLayout'));
const Dashboard = lazy(() => import('./admin/pages/dashboard/Dashboard'));
const ProductsList = lazy(() => import('./admin/pages/products/ProductsList'));
const ProductForm = lazy(() => import('./admin/pages/products/ProductForm'));
const CategoriesList = lazy(() => import('./admin/pages/categories/CategoriesList'));
const CollectionsList = lazy(() => import('./admin/pages/collections/CollectionsList'));
const BrandsList = lazy(() => import('./admin/pages/brands/BrandsList'));
const InventoryList = lazy(() => import('./admin/pages/inventory/InventoryList'));
const OrdersList = lazy(() => import('./admin/pages/orders/OrdersList'));
const ShippingDashboard = lazy(() => import('./admin/pages/shipping/ShippingDashboard'));
const DigitalDeliveryDashboard = lazy(() => import('./admin/pages/downloads/DigitalDeliveryDashboard'));
const OrderDetail = lazy(() => import('./admin/pages/orders/OrderDetail'));
const SellersList = lazy(() => import('./admin/pages/sellers/SellersList'));
const CouponsList = lazy(() => import('./admin/pages/coupons/CouponsList'));
const ReviewsList = lazy(() => import('./admin/pages/reviews/ReviewsList'));
const MediaLibrary = lazy(() => import('./admin/pages/media/MediaLibrary'));
const SettingsPage = lazy(() => import('./admin/pages/settings/Settings'));
const UsersList = lazy(() => import('./admin/pages/users/UsersList'));
const AdminNotificationsList = lazy(() => import('./admin/pages/notifications/NotificationsList'));
const Analytics = lazy(() => import('./admin/pages/analytics/Analytics'));
const FinanceDashboard = lazy(() => import('./admin/pages/finance/FinanceDashboard'));
const CommissionSettings = lazy(() => import('./admin/pages/finance/CommissionSettings'));
const PayoutQueue = lazy(() => import('./admin/pages/finance/PayoutQueue'));
const RefundQueue = lazy(() => import('./admin/pages/finance/RefundQueue'));
const ReturnQueue = lazy(() => import('./admin/pages/finance/ReturnQueue'));
const DisputeQueue = lazy(() => import('./admin/pages/finance/DisputeQueue'));
const BlogPostsList = lazy(() => import('./admin/pages/blog/BlogPostsList'));
const BlogPostForm = lazy(() => import('./admin/pages/blog/BlogPostForm'));
const BlogCategoriesList = lazy(() => import('./admin/pages/blog/BlogCategoriesList'));
const BlogTagsList = lazy(() => import('./admin/pages/blog/BlogTagsList'));
const HomepageCms = lazy(() => import('./admin/pages/cms/HomepageCms'));
const StaticPagesList = lazy(() => import('./admin/pages/cms/StaticPagesList'));
const StaticPageForm = lazy(() => import('./admin/pages/cms/StaticPageForm'));
const NewsletterCms = lazy(() => import('./admin/pages/cms/NewsletterCms'));
const ContactMessagesList = lazy(() => import('./admin/pages/cms/ContactMessagesList'));

const AdminFallback = () => (
  <div className="min-h-screen grid place-items-center" role="status" aria-label="Loading admin panel">
    <Spinner className="w-8 h-8 text-primary" />
  </div>
);

function App() {
    return (
        <ErrorBoundary>
        <StoreProvider>
            <AdminAuthProvider>
            <SellerAuthProvider>
            <Router>
                <ScrollToTop />
                <Suspense fallback={<AdminFallback />}>
                <Routes>
                    {/* Storefront */}
                    <Route path="/" element={<HomePage />} />
                    <Route path="/shop" element={<ShopPage />} />
                    <Route path="/product/:id" element={<ProductDetailPage />} />
                    <Route path="/categories" element={<CategoriesPage />} />
                    <Route path="/category/:slug" element={<CategoryPage />} />
                    <Route path="/collections" element={<CollectionsPage />} />
                    <Route path="/blog" element={<BlogPage />} />
                    <Route path="/blog/:slug" element={<BlogPostPage />} />
                    <Route path="/about" element={<AboutPage />} />
                    <Route path="/wishlist" element={<WishlistPage />} />
                    <Route path="/wishlists" element={<RequireCustomerAuth><AccountWishlistsPage /></RequireCustomerAuth>} />
                    <Route path="/wishlists/shared/:token" element={<SharedWishlistPage />} />
                    <Route path="/wishlists/:id" element={<RequireCustomerAuth><AccountWishlistDetailPage /></RequireCustomerAuth>} />
                    <Route path="/cart" element={<CartPage />} />
                    <Route path="/compare" element={<ComparePage />} />
                    <Route path="/403" element={<ForbiddenPage />} />
                    <Route path="/maintenance" element={<MaintenancePage />} />
                    <Route path="/coming-soon" element={<ComingSoonPage />} />
                    <Route path="/login" element={<LoginPage />} />
                    <Route path="/register" element={<RegisterPage />} />
                    <Route path="/forgot-password" element={<ForgotPasswordPage />} />
                    <Route path="/reset-password/:token" element={<ResetPasswordPage />} />
                    <Route path="/search" element={<SearchResultsPage />} />
                    <Route path="/checkout" element={<CheckoutPage />} />
                    <Route path="/order-failed" element={<OrderFailedPage />} />
                    <Route path="/profile" element={<RequireCustomerAuth><ProfilePage /></RequireCustomerAuth>} />
                    <Route path="/dashboard" element={<RequireCustomerAuth><AccountDashboardPage /></RequireCustomerAuth>} />
                    <Route path="/orders" element={<RequireCustomerAuth><AccountOrdersPage /></RequireCustomerAuth>} />
                    <Route path="/downloads" element={<RequireCustomerAuth><AccountDownloadsPage /></RequireCustomerAuth>} />
                    <Route path="/shipments" element={<RequireCustomerAuth><AccountShipmentsPage /></RequireCustomerAuth>} />
                    <Route path="/settings" element={<RequireCustomerAuth><AccountSettingsPage /></RequireCustomerAuth>} />
                    <Route path="/reviews" element={<RequireCustomerAuth><AccountReviewsPage /></RequireCustomerAuth>} />
                    <Route path="/security" element={<RequireCustomerAuth><AccountSecurityPage /></RequireCustomerAuth>} />
                    <Route path="/notifications" element={<RequireCustomerAuth><AccountNotificationsPage /></RequireCustomerAuth>} />
                    <Route path="/addresses" element={<RequireCustomerAuth><AccountAddressesPage /></RequireCustomerAuth>} />
                    <Route path="/payment-methods" element={<RequireCustomerAuth><AccountPaymentMethodsPage /></RequireCustomerAuth>} />
                    <Route path="/support" element={<RequireCustomerAuth><AccountSupportPage /></RequireCustomerAuth>} />
                    <Route path="/invoices" element={<RequireCustomerAuth><AccountInvoicesPage /></RequireCustomerAuth>} />
                    <Route path="/payments" element={<RequireCustomerAuth><AccountPaymentsPage /></RequireCustomerAuth>} />
                    <Route path="/coupons" element={<RequireCustomerAuth><AccountCouponsPage /></RequireCustomerAuth>} />
                    <Route path="/following" element={<RequireCustomerAuth><AccountFollowingPage /></RequireCustomerAuth>} />
                    <Route path="/browsing-history" element={<RequireCustomerAuth><AccountBrowsingHistoryPage /></RequireCustomerAuth>} />
                    <Route path="/become-a-seller" element={<BecomeASellerPage />} />
                    <Route path="/seller" element={<SellerHubPage />} />
                    <Route path="/seller/login" element={<SellerLoginPage />} />
                    <Route path="/seller/register" element={<SellerRegisterPage />} />
                    <Route path="/seller/dashboard" element={<RequireSellerAuth><SellerDashboard /></RequireSellerAuth>} />
                    <Route path="/seller/overview" element={<RequireSellerAuth><SellerDashboard /></RequireSellerAuth>} />
                    <Route path="/seller/products" element={<RequireSellerAuth><SellerDashboard /></RequireSellerAuth>} />
                    <Route path="/seller/products/new" element={<RequireSellerAuth><NewProductPage /></RequireSellerAuth>} />
                    <Route path="/seller/products/:id/edit" element={<RequireSellerAuth><NewProductPage /></RequireSellerAuth>} />
                    <Route path="/seller/orders" element={<RequireSellerAuth><SellerDashboard /></RequireSellerAuth>} />
                    <Route path="/seller/shipping" element={<RequireSellerAuth><SellerDashboard /></RequireSellerAuth>} />
                    <Route path="/seller/downloads" element={<RequireSellerAuth><SellerDashboard /></RequireSellerAuth>} />
                    <Route path="/seller/earnings" element={<RequireSellerAuth><SellerDashboard /></RequireSellerAuth>} />
                    <Route path="/seller/analytics" element={<RequireSellerAuth><SellerDashboard /></RequireSellerAuth>} />
                    <Route path="/seller/reviews" element={<RequireSellerAuth><SellerDashboard /></RequireSellerAuth>} />
                    <Route path="/seller/notifications" element={<RequireSellerAuth><SellerDashboard /></RequireSellerAuth>} />
                    <Route path="/seller/store" element={<RequireSellerAuth><SellerDashboard /></RequireSellerAuth>} />
                    <Route path="/seller/profile" element={<RequireSellerAuth><SellerDashboard /></RequireSellerAuth>} />
                    <Route path="/seller/settings" element={<RequireSellerAuth><SellerDashboard /></RequireSellerAuth>} />
                    <Route path="/seller/:slug" element={<SellerProfilePage />} />
                    <Route path="/contact" element={<ContactPage />} />
                    <Route path="/privacy" element={<PrivacyPolicyPage />} />
                    <Route path="/terms" element={<TermsPage />} />
                    <Route path="/faq" element={<FAQPage />} />
                    <Route path="/refund-policy" element={<RefundPolicyPage />} />
                    <Route path="/500" element={<ServerErrorPage />} />
                    <Route path="/network-error" element={<NetworkErrorPage />} />

                    {/* Admin Panel */}
                    <Route path="/admin/login" element={<AdminLoginPage />} />
                    <Route path="/admin" element={<RequireAdminAuth><AdminLayout /></RequireAdminAuth>}>
                        <Route index element={<Dashboard />} />
                        <Route path="analytics" element={<Analytics />} />
                        <Route path="finance" element={<FinanceDashboard />} />
                        <Route path="finance/commission" element={<CommissionSettings />} />
                        <Route path="finance/payouts" element={<PayoutQueue />} />
                        <Route path="finance/refunds" element={<RefundQueue />} />
                        <Route path="finance/returns" element={<ReturnQueue />} />
                        <Route path="finance/disputes" element={<DisputeQueue />} />
                        <Route path="products" element={<ProductsList />} />
                        <Route path="products/new" element={<ProductForm />} />
                        <Route path="products/:id/edit" element={<ProductForm />} />
                        <Route path="categories" element={<CategoriesList />} />
                        <Route path="collections" element={<CollectionsList />} />
                        <Route path="brands" element={<BrandsList />} />
                        <Route path="inventory" element={<InventoryList />} />
                        <Route path="orders" element={<OrdersList />} />
                        <Route path="orders/:id" element={<OrderDetail />} />
                        <Route path="shipping" element={<ShippingDashboard />} />
                        <Route path="digital-delivery" element={<DigitalDeliveryDashboard />} />
                        <Route path="sellers" element={<SellersList />} />
                        <Route path="coupons" element={<CouponsList />} />
                        <Route path="reviews" element={<ReviewsList />} />
                        <Route path="media" element={<MediaLibrary />} />
                        <Route path="settings" element={<SettingsPage />} />
                        <Route path="users" element={<UsersList />} />
                        <Route path="notifications" element={<AdminNotificationsList />} />
                        <Route path="blog" element={<BlogPostsList />} />
                        <Route path="blog/new" element={<BlogPostForm />} />
                        <Route path="blog/edit/:id" element={<BlogPostForm />} />
                        <Route path="blog/categories" element={<BlogCategoriesList />} />
                        <Route path="blog/tags" element={<BlogTagsList />} />
                        <Route path="cms/homepage" element={<HomepageCms />} />
                        <Route path="cms/pages" element={<StaticPagesList />} />
                        <Route path="cms/pages/:pageType/edit" element={<StaticPageForm />} />
                        <Route path="cms/contact-messages" element={<ContactMessagesList />} />
                        <Route path="cms/newsletter" element={<NewsletterCms />} />
                    </Route>

                    {/* 404 */}
                    <Route path="*" element={<NotFoundPage />} />
                </Routes>
                </Suspense>
                <CompareBar />
                <Toaster />
            </Router>
            </SellerAuthProvider>
            </AdminAuthProvider>
        </StoreProvider>
        </ErrorBoundary>
    );
}

export default App;
