import React, { useState } from 'react';
import { Plus, Trash2, X } from 'lucide-react';

const ZONE_TYPES = ['worldwide', 'country', 'state', 'region', 'postal_code'];
const RATE_TYPES = ['flat', 'free', 'weight_based', 'quantity_based', 'order_total_based'];

const emptyRate = () => ({ methodName: 'Standard', type: 'flat', baseRate: 0, perUnitRate: 0, freeOverAmount: null, estimatedDeliveryDays: { min: 3, max: 7 }, active: true });
const emptyZone = () => ({ name: 'Domestic', type: 'worldwide', countries: [], states: [], rates: [emptyRate()] });

const toCsv = (arr = []) => arr.join(', ');
const fromCsv = (str) => str.split(',').map((s) => s.trim()).filter(Boolean);

const inputCls = 'w-full bg-secondary/60 rounded-lg px-3 py-2 text-sm outline-none border border-transparent focus:border-primary';
const labelCls = 'text-xs font-medium text-muted-foreground block mb-1';

/**
 * Phase 14.2, Part 1/2/3 — create/edit form for a seller's Shipping
 * Profile, including its nested zones and per-zone rates. Submits the
 * full profile payload in one PATCH/POST, matching how
 * shippingProfile.validator.js accepts `zones` as a full replacement
 * array — no partial zone/rate endpoints exist on the backend.
 */
const ShippingProfileEditor = ({ initial, onCancel, onSave, saving }) => {
  const [form, setForm] = useState(() => ({
    name: initial?.name || '',
    processingTime: initial?.processingTime || { min: 1, max: 3 },
    freeShipping: initial?.freeShipping || false,
    active: initial?.active ?? true,
    shippingOrigin: initial?.shippingOrigin || { country: '', state: '', city: '', postalCode: '' },
    zones: initial?.zones?.length ? initial.zones.map((z) => ({ ...z, countries: z.countries || [], states: z.states || [] })) : [emptyZone()],
  }));

  const setField = (key, value) => setForm((f) => ({ ...f, [key]: value }));

  const updateZone = (zIdx, patch) =>
    setForm((f) => ({ ...f, zones: f.zones.map((z, i) => (i === zIdx ? { ...z, ...patch } : z)) }));

  const updateRate = (zIdx, rIdx, patch) =>
    setForm((f) => ({
      ...f,
      zones: f.zones.map((z, i) => (i !== zIdx ? z : { ...z, rates: z.rates.map((r, j) => (j === rIdx ? { ...r, ...patch } : r)) })),
    }));

  const addZone = () => setForm((f) => ({ ...f, zones: [...f.zones, emptyZone()] }));
  const removeZone = (zIdx) => setForm((f) => ({ ...f, zones: f.zones.filter((_, i) => i !== zIdx) }));
  const addRate = (zIdx) => updateZone(zIdx, { rates: [...form.zones[zIdx].rates, emptyRate()] });
  const removeRate = (zIdx, rIdx) => updateZone(zIdx, { rates: form.zones[zIdx].rates.filter((_, j) => j !== rIdx) });

  const submit = (e) => {
    e.preventDefault();
    onSave(form);
  };

  return (
    <form onSubmit={submit} className="bg-white rounded-3xl border border-border soft-shadow p-6 space-y-5">
      <div className="flex items-center justify-between">
        <h3 className="font-bold">{initial ? 'Edit Shipping Profile' : 'New Shipping Profile'}</h3>
        <button type="button" onClick={onCancel} className="text-muted-foreground hover:text-foreground">
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label className={labelCls}>Profile name</label>
          <input required value={form.name} onChange={(e) => setField('name', e.target.value)} className={inputCls} placeholder="e.g. Small Parcels" />
        </div>
        <div className="flex items-center gap-4 pt-5">
          <label className="flex items-center gap-2 text-sm cursor-pointer">
            <input type="checkbox" checked={form.freeShipping} onChange={(e) => setField('freeShipping', e.target.checked)} className="rounded" />
            Free shipping (overrides all zones/rates)
          </label>
        </div>
        <div>
          <label className={labelCls}>Processing time (days)</label>
          <div className="flex items-center gap-2">
            <input type="number" min="0" value={form.processingTime.min} onChange={(e) => setField('processingTime', { ...form.processingTime, min: Number(e.target.value) })} className={inputCls} />
            <span className="text-muted-foreground text-sm">to</span>
            <input type="number" min="0" value={form.processingTime.max} onChange={(e) => setField('processingTime', { ...form.processingTime, max: Number(e.target.value) })} className={inputCls} />
          </div>
        </div>
        <div>
          <label className={labelCls}>Ships from (country)</label>
          <input value={form.shippingOrigin.country} onChange={(e) => setField('shippingOrigin', { ...form.shippingOrigin, country: e.target.value })} className={inputCls} placeholder="e.g. US" />
        </div>
      </div>

      {!form.freeShipping && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold">Zones &amp; Rates</h4>
            <button type="button" onClick={addZone} className="inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline">
              <Plus className="w-3.5 h-3.5" /> Add zone
            </button>
          </div>

          {form.zones.map((zone, zIdx) => (
            <div key={zIdx} className="border border-border rounded-2xl p-4 space-y-3">
              <div className="flex items-start gap-2">
                <input value={zone.name} onChange={(e) => updateZone(zIdx, { name: e.target.value })} className={`${inputCls} font-semibold flex-1`} placeholder="Zone name" />
                <select value={zone.type} onChange={(e) => updateZone(zIdx, { type: e.target.value })} className={`${inputCls} w-40`}>
                  {ZONE_TYPES.map((t) => <option key={t} value={t}>{t.replace('_', ' ')}</option>)}
                </select>
                {form.zones.length > 1 && (
                  <button type="button" onClick={() => removeZone(zIdx)} className="text-muted-foreground hover:text-destructive shrink-0 p-2">
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>

              {zone.type === 'country' && (
                <input
                  value={toCsv(zone.countries)}
                  onChange={(e) => updateZone(zIdx, { countries: fromCsv(e.target.value) })}
                  className={inputCls}
                  placeholder="ISO country codes, comma separated (e.g. US, CA)"
                />
              )}
              {zone.type === 'state' && (
                <input
                  value={toCsv(zone.states)}
                  onChange={(e) => updateZone(zIdx, { states: fromCsv(e.target.value) })}
                  className={inputCls}
                  placeholder="States/provinces, comma separated"
                />
              )}

              <div className="space-y-2">
                {zone.rates.map((rate, rIdx) => (
                  <div key={rIdx} className="grid grid-cols-2 sm:grid-cols-6 gap-2 items-end bg-secondary/40 rounded-xl p-3">
                    <div className="col-span-2 sm:col-span-2">
                      <label className={labelCls}>Method name</label>
                      <input value={rate.methodName} onChange={(e) => updateRate(zIdx, rIdx, { methodName: e.target.value })} className={inputCls} />
                    </div>
                    <div>
                      <label className={labelCls}>Rate type</label>
                      <select value={rate.type} onChange={(e) => updateRate(zIdx, rIdx, { type: e.target.value })} className={inputCls}>
                        {RATE_TYPES.map((t) => <option key={t} value={t}>{t.replace(/_/g, ' ')}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className={labelCls}>Base rate ($)</label>
                      <input type="number" min="0" step="0.01" value={rate.baseRate} onChange={(e) => updateRate(zIdx, rIdx, { baseRate: Number(e.target.value) })} className={inputCls} />
                    </div>
                    <div>
                      <label className={labelCls}>Per-unit rate</label>
                      <input type="number" min="0" step="0.01" value={rate.perUnitRate} onChange={(e) => updateRate(zIdx, rIdx, { perUnitRate: Number(e.target.value) })} className={inputCls} />
                    </div>
                    <div className="flex items-center gap-1.5">
                      {zone.rates.length > 1 && (
                        <button type="button" onClick={() => removeRate(zIdx, rIdx)} className="text-muted-foreground hover:text-destructive p-2">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
                <button type="button" onClick={() => addRate(zIdx)} className="inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline">
                  <Plus className="w-3.5 h-3.5" /> Add rate
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="flex items-center gap-3 pt-2">
        <button type="submit" disabled={saving} className="px-5 py-2.5 rounded-full brand-gradient text-white text-sm font-semibold hover:opacity-95 transition-opacity disabled:opacity-60">
          {saving ? 'Saving…' : 'Save Profile'}
        </button>
        <button type="button" onClick={onCancel} className="px-5 py-2.5 rounded-full border border-border text-sm font-semibold hover:bg-secondary transition-colors">
          Cancel
        </button>
      </div>
    </form>
  );
};

export default ShippingProfileEditor;
