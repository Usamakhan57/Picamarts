import React, { useEffect, useState } from 'react';
import { MessageSquare } from 'lucide-react';
import { Progress } from '../../../components/ui/progress';
import EmptyState from '../../../admin/components/EmptyState';
import { getReviewAnalytics } from '../../../services/analyticsService';
import { getErrorMessage } from '../../../lib/errorMessage';

const RatingStars = ({ value }) => (
  <span className="flex items-center gap-0.5" aria-label={`${value} out of 5 stars`}>
    {[1, 2, 3, 4, 5].map((n) => (
      <span key={n} className={`text-sm ${n <= Math.round(value) ? 'text-amber-400' : 'text-border'}`}>★</span>
    ))}
  </span>
);

// Real /analytics/reviews — auto-scoped to the acting seller's own
// products. The backend has no per-review "seller reply" feature and no
// endpoint that lists individual reviews across all of a seller's
// products (only per-product `GET /products/:id/reviews`), so this tab
// shows the real rating summary + a per-product breakdown rather than
// fabricating a reply feature that wouldn't actually save anywhere.
const SellerReviewsTab = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    setError('');
    getReviewAnalytics()
      .then(setStats)
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p className="text-sm text-muted-foreground py-12 text-center">Loading reviews…</p>;
  if (error) {
    return (
      <div className="bg-white rounded-3xl border border-border soft-shadow p-8 text-center">
        <p className="text-sm text-destructive">{error}</p>
      </div>
    );
  }

  const total = stats?.totalReviews || 0;
  const distribution = stats?.distribution || {};
  const perProduct = stats?.perProduct || [];

  return (
    <div>
      <div className="grid lg:grid-cols-3 gap-5 mb-6">
        <div className="bg-white rounded-3xl border border-border soft-shadow p-6 text-center">
          <p className="text-5xl font-black tracking-tight">{(stats?.averageRating ?? 0).toFixed(1)}</p>
          <div className="flex justify-center mt-2"><RatingStars value={stats?.averageRating ?? 0} /></div>
          <p className="text-xs text-muted-foreground mt-1.5">Based on {total} reviews</p>
        </div>

        <div className="lg:col-span-2 bg-white rounded-3xl border border-border soft-shadow p-6 space-y-2.5">
          <h3 className="font-bold mb-1">Rating Breakdown</h3>
          {[5, 4, 3, 2, 1].map((star) => {
            const count = distribution[`dist${star}`] || 0;
            const pct = total ? (count / total) * 100 : 0;
            return (
              <div key={star} className="flex items-center gap-3 text-xs">
                <span className="w-10 shrink-0 font-medium">{star} star</span>
                <Progress value={pct} className="flex-1" />
                <span className="w-6 shrink-0 text-right text-muted-foreground">{count}</span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="flex items-center justify-between mb-4">
        <h3 className="font-bold">Reviews by Product</h3>
      </div>

      <div className="bg-white rounded-3xl border border-border soft-shadow p-6">
        {perProduct.length === 0 ? (
          <EmptyState icon={MessageSquare} title="No reviews yet" description="Reviews on your products will show up here." />
        ) : (
          <ul className="divide-y divide-border">
            {perProduct.map((p) => (
              <li key={p.productId} className="flex items-center justify-between gap-3 py-3.5 first:pt-0">
                <span className="font-medium text-sm truncate">{p.title}</span>
                <div className="flex items-center gap-3 shrink-0">
                  <RatingStars value={p.averageRating} />
                  <span className="text-xs text-muted-foreground">{p.reviewCount} review{p.reviewCount === 1 ? '' : 's'}</span>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default SellerReviewsTab;
