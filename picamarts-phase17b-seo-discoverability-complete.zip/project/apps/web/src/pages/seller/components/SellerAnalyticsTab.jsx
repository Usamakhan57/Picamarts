import React, { useEffect, useState } from 'react';
import { DollarSign, ShoppingCart, Package, Star } from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid, PieChart, Pie, Cell } from 'recharts';
import StatCard from '../../../admin/components/StatCard';
import { getDashboard, getSales, getProductAnalytics, getRevenue } from '../../../services/analyticsService';
import { getErrorMessage } from '../../../lib/errorMessage';

const COLORS = ['#6C3BFF', '#FF7A59', '#22C55E', '#F59E0B', '#3B82F6', '#EC4899'];

// Real /analytics/dashboard, /sales, /products, and /revenue?groupBy=category
// — all auto-scoped to the acting seller server-side. Real backend has no
// storefront-visitor/conversion tracking yet, so this pass reports what it
// genuinely has (revenue/orders/best sellers/category mix) rather than
// showing fabricated view-count numbers.
const SellerAnalyticsTab = () => {
  const [dashboard, setDashboard] = useState(null);
  const [salesSeries, setSalesSeries] = useState([]);
  const [bestSelling, setBestSelling] = useState([]);
  const [categoryBreakdown, setCategoryBreakdown] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    setError('');
    Promise.all([
      getDashboard(),
      getSales({ period: 'monthly' }),
      getProductAnalytics({ type: 'best_selling', limit: 8 }),
      getRevenue({ groupBy: 'category' }),
    ])
      .then(([dash, sales, products, revenue]) => {
        setDashboard(dash);
        setSalesSeries(sales.series || []);
        setBestSelling(products.items || []);
        setCategoryBreakdown((revenue.breakdown || []).slice(0, 6));
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p className="text-sm text-muted-foreground py-12 text-center">Loading analytics…</p>;
  if (error) {
    return (
      <div className="bg-white rounded-3xl border border-border soft-shadow p-8 text-center">
        <p className="text-sm text-destructive">{error}</p>
      </div>
    );
  }

  return (
    <div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Revenue (total)" value={`$${Number(dashboard?.revenue?.total ?? 0).toFixed(2)}`} icon={DollarSign} />
        <StatCard label="Revenue (30d)" value={`$${Number(dashboard?.revenue?.month ?? 0).toFixed(2)}`} icon={DollarSign} />
        <StatCard label="Orders (total)" value={dashboard?.orders?.total ?? 0} icon={ShoppingCart} />
        <StatCard label="Published Products" value={dashboard?.products?.active ?? 0} icon={Package} />
      </div>

      <div className="grid lg:grid-cols-3 gap-5 mb-6">
        <div className="lg:col-span-2 bg-white rounded-3xl border border-border soft-shadow p-6">
          <h3 className="font-bold mb-4">Revenue Trend</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={salesSeries} margin={{ left: -20 }}>
                <defs>
                  <linearGradient id="sellerAnalyticsFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#6C3BFF" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="#6C3BFF" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#EEE" />
                <XAxis dataKey="label" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                <Tooltip formatter={(v) => [`$${v}`, 'Revenue']} />
                <Area type="monotone" dataKey="revenue" stroke="#6C3BFF" strokeWidth={2} fill="url(#sellerAnalyticsFill)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white rounded-3xl border border-border soft-shadow p-6">
          <h3 className="font-bold mb-4">Revenue by Category</h3>
          {categoryBreakdown.length === 0 ? (
            <p className="text-sm text-muted-foreground">No category data yet.</p>
          ) : (
            <>
              <div className="h-40">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={categoryBreakdown} dataKey="revenue" nameKey="category" innerRadius={40} outerRadius={65} paddingAngle={2}>
                      {categoryBreakdown.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                    </Pie>
                    <Tooltip formatter={(v) => `$${Number(v).toFixed(2)}`} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <ul className="space-y-1.5 mt-2">
                {categoryBreakdown.map((c, i) => (
                  <li key={c.categoryId || c.category} className="flex items-center gap-2 text-xs">
                    <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                    <span className="flex-1 truncate">{c.category}</span>
                    <span className="text-muted-foreground">${Number(c.revenue).toFixed(2)}</span>
                  </li>
                ))}
              </ul>
            </>
          )}
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-border soft-shadow p-6">
        <h3 className="font-bold mb-4">Best Selling Products</h3>
        {bestSelling.length === 0 ? (
          <p className="text-sm text-muted-foreground">No sales data yet.</p>
        ) : (
          <ul className="divide-y divide-border">
            {bestSelling.map((p) => (
              <li key={p.productId} className="flex items-center gap-3 py-3">
                <span className="w-10 h-10 rounded-lg bg-secondary shrink-0 grid place-items-center text-muted-foreground"><Star className="w-4 h-4" /></span>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium truncate">{p.title}</p>
                  <p className="text-xs text-muted-foreground">{p.stock ?? 0} in stock</p>
                </div>
                <span className="text-xs font-medium text-muted-foreground shrink-0">{(p.salesCount || 0).toLocaleString()} sold</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default SellerAnalyticsTab;
