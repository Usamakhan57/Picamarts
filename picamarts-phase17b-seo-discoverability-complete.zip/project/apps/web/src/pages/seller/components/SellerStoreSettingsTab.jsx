import React, { useEffect, useState } from 'react';
import ImageUploadInput from '../../../admin/components/ImageUploadInput';
import { inputClass, textareaClass } from '../../../admin/components/FormSheet';
import { Switch } from '../../../components/ui/switch';
import { useToast } from '../../../hooks/use-toast';
import { useSellerAuth } from '../../../context/SellerAuthContext';
import { updateMySellerProfile } from '../../../services/sellerService';
import { getNotificationPreferences, updateNotificationPreferences } from '../../../services/notificationService';
import { getErrorMessage } from '../../../lib/errorMessage';

// Store branding/contact/social persist to the real /sellers/me PATCH.
// Notification toggles persist to the real /notifications/preferences
// (which only has two global switches — email/in-app — not the
// per-category toggles this panel used to fake). Payout and shipping-
// policy fields have no backing model yet on this backend (payouts:
// this marketplace has no payout/payment-method concept at all yet;
// shipping: real per-product shipping profiles already live on the
// Shipping tab) — left as local-only with a disclosure note rather than
// silently dropped from the UI.
const SellerStoreSettingsTab = ({ seller }) => {
  const { toast } = useToast();
  const { refreshProfile } = useSellerAuth();
  const [form, setForm] = useState({
    logo: seller?.logo?.url || '', banner: seller?.banner?.url || '',
    storeName: seller?.storeName || '', description: seller?.storeDescription || '',
    phone: seller?.phone || '', website: seller?.website || '',
    facebook: seller?.socialLinks?.facebook || '', instagram: seller?.socialLinks?.instagram || '', twitter: seller?.socialLinks?.twitter || '',
    payoutMethod: 'paypal', payoutEmail: seller?.email || '', bankAccountName: '', bankAccountNumber: '', bankRoutingNumber: '',
    shippingPolicy: '', defaultProcessingTime: '1-2 business days',
  });
  const [prefs, setPrefs] = useState({ emailEnabled: true, inAppEnabled: true });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    getNotificationPreferences()
      .then((p) => setPrefs({ emailEnabled: p.emailEnabled !== false, inAppEnabled: p.inAppEnabled !== false }))
      .catch(() => {});
  }, []);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const togglePref = async (key) => {
    const next = { ...prefs, [key]: !prefs[key] };
    setPrefs(next);
    try {
      await updateNotificationPreferences({ [key]: next[key] });
    } catch (err) {
      setPrefs(prefs); // revert on failure
      toast({ title: 'Could not update notification setting', description: getErrorMessage(err), variant: 'destructive' });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await updateMySellerProfile({
        storeName: form.storeName,
        storeDescription: form.description,
        phone: form.phone,
        website: form.website,
        socialLinks: { facebook: form.facebook, instagram: form.instagram, twitter: form.twitter },
      });
      await refreshProfile();
      toast({ title: 'Store settings saved', description: 'Your storefront settings were updated.' });
    } catch (err) {
      toast({ title: 'Could not save settings', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="grid lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-6">
        <div className="bg-white rounded-3xl border border-border soft-shadow p-6 space-y-4">
          <h3 className="font-bold">Store Branding</h3>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1.5">Store Logo</label>
              <ImageUploadInput value={form.logo} onChange={(v) => setForm((f) => ({ ...f, logo: v }))} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5">Banner Image</label>
              <ImageUploadInput value={form.banner} onChange={(v) => setForm((f) => ({ ...f, banner: v }))} />
            </div>
          </div>
          <p className="text-xs text-muted-foreground">Images are previewed locally for now — real uploads are coming in the next update.</p>
          <div>
            <label className="block text-sm font-medium mb-1.5">Store Name</label>
            <input value={form.storeName} onChange={set('storeName')} className={inputClass} />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">Store Description</label>
            <textarea value={form.description} onChange={set('description')} className={textareaClass} placeholder="Tell buyers what your store is all about…" />
          </div>
        </div>

        <div className="bg-white rounded-3xl border border-border soft-shadow p-6 space-y-4">
          <h3 className="font-bold">Contact Details</h3>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1.5">Email</label>
              <input type="email" value={seller?.email || ''} disabled className={`${inputClass} opacity-60 cursor-not-allowed`} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5">Phone</label>
              <input type="tel" value={form.phone} onChange={set('phone')} className={inputClass} />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">Website</label>
            <input value={form.website} onChange={set('website')} className={inputClass} placeholder="https://…" />
          </div>
        </div>

        <div className="bg-white rounded-3xl border border-border soft-shadow p-6 space-y-4">
          <h3 className="font-bold">Social Links</h3>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1.5">Facebook</label>
              <input value={form.facebook} onChange={set('facebook')} className={inputClass} placeholder="https://facebook.com/…" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5">Instagram</label>
              <input value={form.instagram} onChange={set('instagram')} className={inputClass} placeholder="https://instagram.com/…" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5">Twitter</label>
              <input value={form.twitter} onChange={set('twitter')} className={inputClass} placeholder="https://twitter.com/…" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-3xl border border-border soft-shadow p-6 space-y-4">
          <h3 className="font-bold">Payment Information</h3>
          <p className="text-xs text-muted-foreground -mt-2">Payouts aren't part of the marketplace yet — these fields aren't saved.</p>
          <div>
            <label className="block text-sm font-medium mb-1.5">Payout Email</label>
            <input type="email" value={form.payoutEmail} onChange={set('payoutEmail')} disabled className={`${inputClass} opacity-60 cursor-not-allowed`} />
          </div>
        </div>

        <div className="bg-white rounded-3xl border border-border soft-shadow p-6 space-y-4">
          <h3 className="font-bold">Shipping Settings</h3>
          <p className="text-xs text-muted-foreground -mt-2">Per-product shipping rates and profiles are managed on the Shipping tab. This note is preview-only.</p>
          <div>
            <label className="block text-sm font-medium mb-1.5">Store Shipping Policy</label>
            <textarea value={form.shippingPolicy} onChange={set('shippingPolicy')} className={textareaClass} placeholder="Describe your store's shipping and delivery policy…" />
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <div className="bg-white rounded-3xl border border-border soft-shadow p-6 space-y-4">
          <h3 className="font-bold">Notification Settings</h3>
          <label className="flex items-start justify-between gap-3 cursor-pointer">
            <span>
              <span className="block text-sm font-medium">Email notifications</span>
              <span className="block text-xs text-muted-foreground mt-0.5">Order, payment, and review updates by email.</span>
            </span>
            <Switch checked={prefs.emailEnabled} onCheckedChange={() => togglePref('emailEnabled')} className="mt-0.5 shrink-0" />
          </label>
          <label className="flex items-start justify-between gap-3 cursor-pointer">
            <span>
              <span className="block text-sm font-medium">In-app notifications</span>
              <span className="block text-xs text-muted-foreground mt-0.5">Show updates in your Notifications tab.</span>
            </span>
            <Switch checked={prefs.inAppEnabled} onCheckedChange={() => togglePref('inAppEnabled')} className="mt-0.5 shrink-0" />
          </label>
        </div>

        <button type="submit" disabled={saving} className="w-full px-5 py-3 rounded-full brand-gradient text-white text-sm font-semibold soft-shadow hover:opacity-95 transition-all disabled:opacity-60">
          {saving ? 'Saving…' : 'Save Changes'}
        </button>
      </div>
    </form>
  );
};

export default SellerStoreSettingsTab;
