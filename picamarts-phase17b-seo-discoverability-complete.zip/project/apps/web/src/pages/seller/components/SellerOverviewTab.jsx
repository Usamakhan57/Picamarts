import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Package, ShoppingCart, Wallet, Star, Boxes } from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import StatCard from '../../../admin/components/StatCard';
import StatusBadge from '../../../admin/components/StatusBadge';
import { getDashboard, getSales, getProductAnalytics, getReviewAnalytics } from '../../../services/analyticsService';
import { listOrders, mapOrderSummary } from '../../../services/orderService';
import { getErrorMessage } from '../../../lib/errorMessage';

const fmtDate = (iso) => new Date(iso).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });

// Real /analytics/dashboard + /analytics/sales + /analytics/products +
// /analytics/orders + /analytics/reviews — all auto-scoped to the acting
// seller server-side.
const SellerOverviewTab = () => {
  const [dashboard, setDashboard] = useState(null);
  const [salesSeries, setSalesSeries] = useState([]);
  const [bestSelling, setBestSelling] = useState([]);
  const [recentOrders, setRecentOrders] = useState([]);
  const [reviewStats, setReviewStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    setError('');
    Promise.all([
      getDashboard(),
      getSales({ period: 'daily' }),
      getProductAnalytics({ type: 'best_selling', limit: 5 }),
      listOrders({ page: 1, limit: 5, sort: 'newest' }),
      getReviewAnalytics(),
    ])
      .then(([dash, sales, products, ordersRes, reviews]) => {
        setDashboard(dash);
        setSalesSeries(sales.series || []);
        setBestSelling(products.items || []);
        setRecentOrders((ordersRes.orders || []).map(mapOrderSummary));
        setReviewStats(reviews);
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p className="text-sm text-muted-foreground py-12 text-center">Loading your overview…</p>;
  if (error) {
    return (
      <div className="bg-white rounded-3xl border border-border soft-shadow p-8 text-center">
        <p className="text-sm text-destructive">{error}</p>
      </div>
    );
  }

  return (
    <div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Total Products" value={dashboard?.products?.total ?? 0} icon={Package} />
        <StatCard label="Total Orders" value={dashboard?.orders?.total ?? 0} icon={ShoppingCart} />
        <StatCard label="Lifetime Revenue" value={`$${Number(dashboard?.revenue?.total ?? 0).toFixed(2)}`} icon={Wallet} />
        <StatCard label="Active Listings" value={dashboard?.products?.active ?? 0} icon={Boxes} />
      </div>

      <div className="grid lg:grid-cols-3 gap-5 mb-6">
        <div className="lg:col-span-2 bg-white rounded-3xl border border-border soft-shadow p-6">
          <h3 className="font-bold mb-4">Sales Overview</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={salesSeries} margin={{ left: -20 }}>
                <defs>
                  <linearGradient id="sellerSalesFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#6C3BFF" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="#6C3BFF" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#EEE" />
                <XAxis dataKey="label" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                <Tooltip formatter={(v) => [`$${v}`, 'Revenue']} />
                <Area type="monotone" dataKey="revenue" stroke="#6C3BFF" strokeWidth={2} fill="url(#sellerSalesFill)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white rounded-3xl border border-border soft-shadow p-6">
          <h3 className="font-bold mb-4">Top Selling Products</h3>
          {bestSelling.length === 0 ? (
            <p className="text-sm text-muted-foreground">No sales data yet.</p>
          ) : (
            <ul className="space-y-3">
              {bestSelling.map((p) => (
                <li key={p.productId} className="flex items-center gap-3">
                  <span className="w-10 h-10 rounded-lg bg-secondary shrink-0 grid place-items-center text-muted-foreground"><Package className="w-4 h-4" /></span>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium truncate">{p.title}</p>
                    <p className="text-xs text-muted-foreground">{(p.salesCount || 0).toLocaleString()} sold</p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-5">
        <div className="bg-white rounded-3xl border border-border soft-shadow overflow-hidden">
          <div className="flex items-center justify-between p-5 pb-3">
            <h3 className="font-bold">Recent Orders</h3>
            <Link to="/seller/orders" className="text-xs font-semibold text-primary">View all</Link>
          </div>
          {recentOrders.length === 0 ? (
            <p className="text-sm text-muted-foreground px-5 pb-5">No orders yet.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <tbody className="divide-y divide-border">
                  {recentOrders.map((o) => (
                    <tr key={o.orderId}>
                      <td className="px-5 py-3">
                        <p className="font-medium truncate max-w-[180px]">{o.items[0]?.title || o.id}</p>
                        <p className="text-xs text-muted-foreground">{o.id} · {fmtDate(o.date)}</p>
                      </td>
                      <td className="px-5 py-3 text-right font-semibold">${Number(o.total).toFixed(2)}</td>
                      <td className="px-5 py-3 text-right"><StatusBadge status={o.rawStatus} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <div className="bg-white rounded-3xl border border-border soft-shadow p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold">Reviews</h3>
            <Link to="/seller/reviews" className="text-xs font-semibold text-primary">View all</Link>
          </div>
          <div className="flex items-center gap-2 mb-3">
            <Star className="w-5 h-5 text-amber-400 fill-amber-400" />
            <span className="text-2xl font-black">{(reviewStats?.averageRating ?? 0).toFixed(1)}</span>
            <span className="text-sm text-muted-foreground">({(reviewStats?.totalReviews ?? 0).toLocaleString()} reviews)</span>
          </div>
          {[5, 4, 3, 2, 1].map((star) => {
            const count = reviewStats?.distribution?.[`dist${star}`] || 0;
            const total = reviewStats?.totalReviews || 1;
            const pct = Math.round((count / total) * 100);
            return (
              <div key={star} className="flex items-center gap-2 text-xs mb-1.5">
                <span className="w-8 text-muted-foreground">{star}★</span>
                <div className="flex-1 h-1.5 rounded-full bg-secondary overflow-hidden">
                  <div className="h-full bg-amber-400" style={{ width: `${pct}%` }} />
                </div>
                <span className="w-8 text-right text-muted-foreground">{count}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default SellerOverviewTab;
