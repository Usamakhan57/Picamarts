import React, { useEffect, useState } from 'react';
import { RotateCcw, Gavel, CheckCircle2, XCircle, PackageCheck, PackageOpen, MessageSquarePlus } from 'lucide-react';
import StatusBadge from '../../../admin/components/StatusBadge';
import EmptyState from '../../../admin/components/EmptyState';
import Pagination from './Pagination';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '../../../components/ui/dialog';
import {
  getSellerReturnRequests,
  approveReturnRequest,
  rejectReturnRequest,
  markReturnReceived,
  completeReturnRequest,
} from '../../../services/returnService';
import { getMyDisputes, addDisputeEvidence } from '../../../services/disputeService';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

const PAGE_SIZE = 10;
const fmtMoney = (n) => `$${Number(n || 0).toFixed(2)}`;
const fmtDate = (iso) => (iso ? new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) : '—');

/**
 * Phase 16D, Part 9 — Seller "Refunds, Returns, Disputes, History".
 * Only Returns and Disputes have a seller-scoped backend surface
 * (see return.routes.js's `/returns/seller/*` and dispute.routes.js's
 * shared `/disputes/me`) — refunds themselves are a buyer-request /
 * admin-approval flow with no seller endpoint, so this tab covers the
 * two the seller can actually act on; each list doubles as its own
 * History view (every past status stays visible, not just open ones).
 */
const SUB_TABS = [
  { key: 'returns', label: 'Returns', icon: RotateCcw },
  { key: 'disputes', label: 'Disputes', icon: Gavel },
];

const ReturnsPanel = () => {
  const { toast } = useToast();
  const [requests, setRequests] = useState([]);
  const [meta, setMeta] = useState({ totalPages: 1 });
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [actioningId, setActioningId] = useState(null);
  const [rejectTarget, setRejectTarget] = useState(null);
  const [rejectNote, setRejectNote] = useState('');
  const [rejecting, setRejecting] = useState(false);

  const load = () => {
    setLoading(true);
    setError('');
    getSellerReturnRequests({ page, limit: PAGE_SIZE })
      .then(({ requests: rows, meta: m }) => {
        setRequests(rows || []);
        setMeta(m || { totalPages: 1 });
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };
  useEffect(load, [page]); // eslint-disable-line react-hooks/exhaustive-deps

  const runAction = async (action, requestId, ...args) => {
    setActioningId(requestId);
    try {
      const updated = await action(requestId, ...args);
      toast({ title: `Return ${updated.status.replace('_', ' ')}` });
      load();
    } catch (err) {
      toast({ title: 'Could not update return', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setActioningId(null);
    }
  };

  const handleReject = async () => {
    setRejecting(true);
    try {
      await rejectReturnRequest(rejectTarget.id, rejectNote || undefined);
      toast({ title: 'Return rejected' });
      setRejectTarget(null);
      setRejectNote('');
      load();
    } catch (err) {
      toast({ title: 'Could not reject return', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setRejecting(false);
    }
  };

  if (loading) return <p className="text-sm text-muted-foreground py-12 text-center">Loading returns…</p>;
  if (error) return <p className="text-sm text-destructive py-12 text-center">{error}</p>;
  if (requests.length === 0) {
    return <EmptyState icon={RotateCcw} title="No return requests yet" description="Return requests buyers open on your orders will show up here." />;
  }

  return (
    <>
      <ul className="divide-y divide-border">
        {requests.map((r) => (
          <li key={r.id} className="flex flex-wrap items-center justify-between gap-3 py-4">
            <div className="min-w-0">
              <p className="text-sm font-medium">Order {r.order}</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                {r.reason?.replace(/_/g, ' ')} · Requested {fmtDate(r.createdAt)}
              </p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <StatusBadge status={r.status} />
              {r.status === 'requested' && (
                <>
                  <button
                    onClick={() => runAction(approveReturnRequest, r.id)}
                    disabled={actioningId === r.id}
                    className="p-1.5 rounded-lg hover:bg-secondary transition-colors text-emerald-600 disabled:opacity-50"
                    aria-label="Approve return"
                    title="Approve"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setRejectTarget(r)}
                    disabled={actioningId === r.id}
                    className="p-1.5 rounded-lg hover:bg-secondary transition-colors text-red-600 disabled:opacity-50"
                    aria-label="Reject return"
                    title="Reject"
                  >
                    <XCircle className="w-4 h-4" />
                  </button>
                </>
              )}
              {r.status === 'return_shipped' && (
                <button
                  onClick={() => runAction(markReturnReceived, r.id)}
                  disabled={actioningId === r.id}
                  className="p-1.5 rounded-lg hover:bg-secondary transition-colors text-blue-600 disabled:opacity-50"
                  aria-label="Mark received"
                  title="Mark received"
                >
                  <PackageOpen className="w-4 h-4" />
                </button>
              )}
              {r.status === 'received' && (
                <button
                  onClick={() => runAction(completeReturnRequest, r.id)}
                  disabled={actioningId === r.id}
                  className="p-1.5 rounded-lg hover:bg-secondary transition-colors text-emerald-600 disabled:opacity-50"
                  aria-label="Complete return"
                  title="Complete (opens the refund)"
                >
                  <PackageCheck className="w-4 h-4" />
                </button>
              )}
            </div>
          </li>
        ))}
      </ul>
      {meta.totalPages > 1 && <Pagination page={page} totalPages={meta.totalPages} onPageChange={setPage} />}

      <Dialog open={!!rejectTarget} onOpenChange={(v) => { if (!v) { setRejectTarget(null); setRejectNote(''); } }}>
        <DialogContent className="max-w-md rounded-3xl">
          <DialogTitle>Reject this return?</DialogTitle>
          <DialogDescription>Let the buyer know why. This cannot be undone.</DialogDescription>
          <form onSubmit={(e) => { e.preventDefault(); handleReject(); }} className="space-y-4 mt-2">
            <textarea
              value={rejectNote}
              onChange={(e) => setRejectNote(e.target.value)}
              placeholder="Reason (optional)"
              rows={3}
              className="w-full bg-secondary/60 rounded-xl px-4 py-2.5 text-sm outline-none border border-transparent focus:border-primary resize-none"
            />
            <div className="flex gap-2 justify-end">
              <button type="button" onClick={() => setRejectTarget(null)} disabled={rejecting} className="px-5 py-2.5 rounded-full text-sm font-semibold border border-border hover:bg-secondary transition-colors disabled:opacity-50">
                Cancel
              </button>
              <button type="submit" disabled={rejecting} className="px-5 py-2.5 rounded-full text-sm font-semibold bg-red-600 text-white hover:bg-red-700 transition-colors disabled:opacity-60">
                {rejecting ? 'Rejecting…' : 'Reject Return'}
              </button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};

const DisputeEvidenceDialog = ({ disputeId, open, onOpenChange, onSubmitted }) => {
  const { toast } = useToast();
  const [note, setNote] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => { if (open) setNote(''); }, [open]);

  const submit = async (e) => {
    e.preventDefault();
    if (!note.trim()) {
      toast({ title: 'Add a note before submitting', variant: 'destructive' });
      return;
    }
    setSubmitting(true);
    try {
      await addDisputeEvidence(disputeId, { note: note.trim() });
      toast({ title: 'Evidence submitted' });
      onOpenChange(false);
      onSubmitted();
    } catch (err) {
      toast({ title: 'Could not submit evidence', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md rounded-3xl">
        <DialogTitle>Submit evidence</DialogTitle>
        <DialogDescription>Explain your side — this is shared with the buyer and any reviewing admin.</DialogDescription>
        <form onSubmit={submit} className="space-y-4 mt-2">
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="e.g. Tracking shows delivery on..."
            rows={4}
            className="w-full bg-secondary/60 rounded-xl px-4 py-2.5 text-sm outline-none border border-transparent focus:border-primary resize-none"
          />
          <button type="submit" disabled={submitting} className="brand-gradient text-white font-semibold px-6 py-2.5 rounded-full hover:opacity-95 transition-all w-full disabled:opacity-60">
            {submitting ? 'Submitting…' : 'Submit Evidence'}
          </button>
        </form>
      </DialogContent>
    </Dialog>
  );
};

const DisputesPanel = () => {
  const [disputes, setDisputes] = useState([]);
  const [meta, setMeta] = useState({ totalPages: 1 });
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [evidenceTarget, setEvidenceTarget] = useState(null);

  const load = () => {
    setLoading(true);
    setError('');
    getMyDisputes({ page, limit: PAGE_SIZE })
      .then(({ disputes: rows, meta: m }) => {
        setDisputes(rows || []);
        setMeta(m || { totalPages: 1 });
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };
  useEffect(load, [page]); // eslint-disable-line react-hooks/exhaustive-deps

  if (loading) return <p className="text-sm text-muted-foreground py-12 text-center">Loading disputes…</p>;
  if (error) return <p className="text-sm text-destructive py-12 text-center">{error}</p>;
  if (disputes.length === 0) {
    return <EmptyState icon={Gavel} title="No disputes" description="Buyer-opened disputes and Stripe chargebacks on your orders will show up here." />;
  }

  return (
    <>
      <ul className="divide-y divide-border">
        {disputes.map((d) => (
          <li key={d.id} className="flex flex-wrap items-center justify-between gap-3 py-4">
            <div className="min-w-0">
              <p className="text-sm font-medium">
                {d.origin === 'stripe_chargeback' ? 'Chargeback' : 'Dispute'} — {fmtMoney(d.amount)}
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">
                {(d.reason || '').replace(/_/g, ' ')} · Opened {fmtDate(d.createdAt)}
                {d.evidenceDueBy ? ` · Evidence due ${fmtDate(d.evidenceDueBy)}` : ''}
              </p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <StatusBadge status={d.status} />
              {!['won', 'lost', 'closed'].includes(d.status) && (
                <button
                  onClick={() => setEvidenceTarget(d.id)}
                  className="p-1.5 rounded-lg hover:bg-secondary transition-colors text-blue-600"
                  aria-label="Add evidence"
                  title="Add evidence"
                >
                  <MessageSquarePlus className="w-4 h-4" />
                </button>
              )}
            </div>
          </li>
        ))}
      </ul>
      {meta.totalPages > 1 && <Pagination page={page} totalPages={meta.totalPages} onPageChange={setPage} />}

      <DisputeEvidenceDialog
        disputeId={evidenceTarget}
        open={!!evidenceTarget}
        onOpenChange={(v) => { if (!v) setEvidenceTarget(null); }}
        onSubmitted={() => { setEvidenceTarget(null); load(); }}
      />
    </>
  );
};

const SellerCasesTab = () => {
  const [subTab, setSubTab] = useState('returns');

  return (
    <div className="bg-white rounded-3xl border border-border soft-shadow p-6">
      <div className="flex gap-1.5 mb-2 border-b border-border">
        {SUB_TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setSubTab(t.key)}
            className={`flex items-center gap-2 px-4 py-3 text-sm font-semibold whitespace-nowrap border-b-2 -mb-px transition-colors ${subTab === t.key ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'}`}
          >
            <t.icon className="w-4 h-4" /> {t.label}
          </button>
        ))}
      </div>
      <div className="pt-4">
        {subTab === 'returns' && <ReturnsPanel />}
        {subTab === 'disputes' && <DisputesPanel />}
      </div>
    </div>
  );
};

export default SellerCasesTab;
