import React, { useState } from 'react';
import { Store, Clock, XCircle, ShieldAlert, LogOut } from 'lucide-react';
import { useToast } from '../../../hooks/use-toast';

const STATUS_COPY = {
  pending: {
    icon: Clock,
    title: 'Your application is under review',
    body: "We're reviewing your store application. This usually doesn't take long — we'll email you as soon as a decision is made.",
  },
  rejected: {
    icon: XCircle,
    title: 'Your application was not approved',
    body: 'Your seller application was rejected. You can update your details and resubmit below.',
  },
  suspended: {
    icon: ShieldAlert,
    title: 'Your store has been suspended',
    body: 'An administrator has temporarily suspended your store. Contact support if you believe this is a mistake.',
  },
};

const inputClass = 'w-full bg-secondary/60 rounded-2xl px-4 py-3 text-sm outline-none border border-transparent focus:border-primary transition-colors';

/**
 * Shown in place of the seller dashboard whenever the authenticated
 * seller account doesn't (yet) have an approved Seller store profile —
 * covers "never applied", "pending", "rejected" (resubmit), and
 * "suspended" (admin-only reinstatement, no self-serve action).
 */
const SellerStatusGate = ({ status, statusReason, onApply, onLogout }) => {
  const { toast } = useToast();
  const [storeName, setStoreName] = useState('');
  const [storeDescription, setStoreDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const needsForm = status === 'not_applied' || status === 'rejected';
  const copy = STATUS_COPY[status];

  const handleApply = async (e) => {
    e.preventDefault();
    if (!storeName.trim() || storeName.trim().length < 2) {
      setError('Please enter a store name (at least 2 characters).');
      return;
    }
    setError('');
    setSubmitting(true);
    try {
      await onApply({ storeName: storeName.trim(), storeDescription: storeDescription.trim(), verificationDocument: {} });
      toast({ title: 'Application submitted', description: "We'll email you once it's reviewed." });
    } catch (err) {
      setError(err?.message || 'Unable to submit your application. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen grid place-items-center px-5 py-16 bg-secondary/30">
      <div className="w-full max-w-lg bg-white rounded-3xl border border-border soft-shadow p-8">
        {needsForm ? (
          <>
            <div className="w-12 h-12 rounded-2xl brand-gradient grid place-items-center mb-5">
              <Store className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-2xl font-black tracking-tight">
              {status === 'rejected' ? 'Update and resubmit your application' : 'Set up your store'}
            </h1>
            <p className="text-sm text-muted-foreground mt-2">
              {status === 'rejected' && statusReason
                ? `Your previous application was rejected: "${statusReason}". Update your details and resubmit.`
                : 'Tell us a bit about your store to start selling on PicaMarts.'}
            </p>
            <form onSubmit={handleApply} className="mt-6 space-y-4">
              <div>
                <label htmlFor="storeName" className="text-sm font-medium block mb-1.5">Store name</label>
                <input id="storeName" value={storeName} onChange={(e) => setStoreName(e.target.value)} placeholder="Studio Lume" className={inputClass} />
              </div>
              <div>
                <label htmlFor="storeDescription" className="text-sm font-medium block mb-1.5">Store description (optional)</label>
                <textarea id="storeDescription" rows={3} value={storeDescription} onChange={(e) => setStoreDescription(e.target.value)} placeholder="What do you sell?" className={inputClass} />
              </div>
              {error && <p className="text-sm text-destructive" role="alert">{error}</p>}
              <button type="submit" disabled={submitting} className="w-full brand-gradient text-white font-semibold py-3.5 rounded-2xl hover:opacity-95 active:scale-[0.99] transition-all disabled:opacity-60 disabled:cursor-not-allowed">
                {submitting ? 'Submitting…' : 'Submit application'}
              </button>
            </form>
          </>
        ) : (
          <>
            <div className="w-12 h-12 rounded-2xl bg-secondary grid place-items-center mb-5">
              <copy.icon className="w-6 h-6 text-foreground" />
            </div>
            <h1 className="text-2xl font-black tracking-tight">{copy.title}</h1>
            <p className="text-sm text-muted-foreground mt-2">{copy.body}</p>
            {status === 'suspended' && statusReason && (
              <p className="text-sm text-muted-foreground mt-2 italic">Reason: {statusReason}</p>
            )}
          </>
        )}
        <button onClick={onLogout} className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground hover:text-foreground transition-colors">
          <LogOut className="w-4 h-4" /> Sign out
        </button>
      </div>
    </div>
  );
};

export default SellerStatusGate;
