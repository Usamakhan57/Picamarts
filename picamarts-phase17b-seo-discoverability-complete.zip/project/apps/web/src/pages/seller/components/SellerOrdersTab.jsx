import React, { useEffect, useState } from 'react';
import { ShoppingCart } from 'lucide-react';
import StatusBadge from '../../../admin/components/StatusBadge';
import EmptyState from '../../../admin/components/EmptyState';
import Pagination from './Pagination';
import { listOrders, updateOrderStatus, mapOrderSummary } from '../../../services/orderService';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

const PAGE_SIZE = 10;

const fmtDate = (iso) => new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });

const ORDER_TABS = [
  { key: 'all', label: 'All' },
  { key: 'pending', label: 'Pending' },
  { key: 'confirmed', label: 'Confirmed' },
  { key: 'processing', label: 'Processing' },
  { key: 'packed', label: 'Packed' },
  { key: 'shipped', label: 'Shipped' },
  { key: 'delivered', label: 'Delivered' },
  { key: 'cancelled', label: 'Cancelled' },
  { key: 'refunded', label: 'Refunded' },
];

// A seller may only move an order forward through fulfillment — never
// cancel or refund (those stay buyer/admin/payment-driven) — mirrors
// SELLER_UPDATABLE_ORDER_STATUSES in the backend's orderEnums.js.
const NEXT_STATUS_OPTIONS = ['confirmed', 'processing', 'packed', 'shipped', 'delivered'];

const SellerOrdersTab = () => {
  const { toast } = useToast();
  const [orders, setOrders] = useState([]);
  const [meta, setMeta] = useState({ totalPages: 1 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [tab, setTab] = useState('all');
  const [page, setPage] = useState(1);
  const [updatingId, setUpdatingId] = useState(null);

  useEffect(() => { setPage(1); }, [tab]);

  const load = () => {
    setLoading(true);
    setError('');
    const params = { page, limit: PAGE_SIZE };
    if (tab !== 'all') params.status = tab;
    listOrders(params)
      .then(({ orders: rows, meta: m }) => {
        setOrders(rows.map(mapOrderSummary));
        setMeta(m || { totalPages: 1 });
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };

  useEffect(load, [page, tab]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleStatusChange = async (order, nextStatus) => {
    setUpdatingId(order.orderId);
    try {
      await updateOrderStatus(order.orderId, nextStatus);
      toast({ title: 'Order updated', description: `${order.id} marked as ${nextStatus}.` });
      load();
    } catch (err) {
      toast({ title: 'Could not update order', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setUpdatingId(null);
    }
  };

  return (
    <div>
      <div className="flex gap-1.5 overflow-x-auto pb-1 mb-5 border-b border-border">
        {ORDER_TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`px-4 py-2.5 text-sm font-semibold whitespace-nowrap border-b-2 -mb-px transition-colors ${tab === t.key ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'}`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-3xl border border-border soft-shadow overflow-hidden">
        {loading ? (
          <p className="text-sm text-muted-foreground py-12 text-center">Loading orders…</p>
        ) : error ? (
          <div className="p-8 text-center">
            <p className="text-sm text-destructive mb-3">{error}</p>
            <button onClick={load} className="text-sm font-semibold text-primary hover:underline">Try again</button>
          </div>
        ) : orders.length === 0 ? (
          <EmptyState icon={ShoppingCart} title="No orders here" description="Orders matching this status will show up here." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-secondary/60 text-left text-xs uppercase tracking-wide text-muted-foreground">
                <tr>
                  <th className="px-5 py-3 font-semibold">Order</th>
                  <th className="px-5 py-3 font-semibold">Items</th>
                  <th className="px-5 py-3 font-semibold">Amount</th>
                  <th className="px-5 py-3 font-semibold">Date</th>
                  <th className="px-5 py-3 font-semibold">Status</th>
                  <th className="px-5 py-3 font-semibold text-right">Update</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {orders.map((o) => (
                  <tr key={o.orderId}>
                    <td className="px-5 py-3.5 font-medium text-primary">{o.id}</td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2.5">
                        {o.items[0]?.img && <img src={o.items[0].img} alt="" className="w-8 h-8 rounded-lg object-cover bg-secondary shrink-0" />}
                        <span className="truncate max-w-[200px]">
                          {o.items[0]?.title}{o.items.length > 1 ? ` +${o.items.length - 1} more` : ''}
                        </span>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 font-semibold">${Number(o.total).toFixed(2)}</td>
                    <td className="px-5 py-3.5 text-muted-foreground">{fmtDate(o.date)}</td>
                    <td className="px-5 py-3.5"><StatusBadge status={o.rawStatus} /></td>
                    <td className="px-5 py-3.5 text-right">
                      {!['cancelled', 'refunded', 'delivered', 'completed', 'returned', 'refund_requested'].includes(o.rawStatus) ? (
                        <select
                          disabled={updatingId === o.orderId}
                          value=""
                          onChange={(e) => e.target.value && handleStatusChange(o, e.target.value)}
                          className="text-xs border border-border rounded-full px-3 py-1.5 bg-white disabled:opacity-50"
                        >
                          <option value="">Move to…</option>
                          {NEXT_STATUS_OPTIONS.filter((s) => s !== o.rawStatus).map((s) => (
                            <option key={s} value={s}>{s}</option>
                          ))}
                        </select>
                      ) : (
                        <span className="text-xs text-muted-foreground">—</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      <Pagination page={page} totalPages={meta.totalPages || 1} onPageChange={setPage} />
    </div>
  );
};

export default SellerOrdersTab;
