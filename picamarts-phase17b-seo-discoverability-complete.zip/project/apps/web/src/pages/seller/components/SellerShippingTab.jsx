import React, { useEffect, useState } from 'react';
import { Plus, Truck, PackageSearch, Settings2, ChevronDown, ChevronUp, Send } from 'lucide-react';
import StatusBadge from '../../../admin/components/StatusBadge';
import EmptyState from '../../../admin/components/EmptyState';
import ShipmentStatusBadge from '../../../components/shipping/ShipmentStatusBadge';
import TrackingInfo from '../../../components/shipping/TrackingInfo';
import ShipmentTimeline from '../../../components/shipping/ShipmentTimeline';
import ShippingProfileEditor from './ShippingProfileEditor';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';
import {
  listMyShippingProfiles,
  createShippingProfile,
  updateShippingProfile,
  deleteShippingProfile,
  listOrdersToShip,
  createShipment,
  listShipments,
  updateShipmentStatus,
  addShipmentTracking,
} from '../../../services/shippingService';

const SUB_TABS = [
  { key: 'profiles', label: 'Shipping Profiles', icon: Settings2 },
  { key: 'to-ship', label: 'Orders to Ship', icon: PackageSearch },
  { key: 'shipments', label: 'Shipments', icon: Truck },
];

const STATUS_OPTIONS = ['pending', 'shipped', 'in_transit', 'delivered', 'returned'];
const fmtDate = (iso) => (iso ? new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) : '—');

// -----------------------------------------------------------------------
// Profiles
// -----------------------------------------------------------------------
const ProfilesPanel = () => {
  const { toast } = useToast();
  const [profiles, setProfiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null); // null = closed, {} = new, {...profile} = edit
  const [saving, setSaving] = useState(false);

  const load = () => {
    setLoading(true);
    listMyShippingProfiles()
      .then((res) => setProfiles(res.profiles || []))
      .catch((err) => toast({ title: "Couldn't load shipping profiles", description: getErrorMessage(err), variant: 'destructive' }))
      .finally(() => setLoading(false));
  };
  useEffect(load, []); // eslint-disable-line react-hooks/exhaustive-deps

  const handleSave = async (form) => {
    setSaving(true);
    try {
      if (editing?.id) {
        await updateShippingProfile(editing.id, form);
        toast({ title: 'Shipping profile updated' });
      } else {
        await createShippingProfile(form);
        toast({ title: 'Shipping profile created' });
      }
      setEditing(null);
      load();
    } catch (err) {
      toast({ title: "Couldn't save shipping profile", description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (profile) => {
    try {
      await deleteShippingProfile(profile.id);
      toast({ title: 'Shipping profile deleted', description: profile.name });
      load();
    } catch (err) {
      toast({ title: "Couldn't delete shipping profile", description: getErrorMessage(err), variant: 'destructive' });
    }
  };

  if (editing) {
    return <ShippingProfileEditor initial={editing.id ? editing : null} saving={saving} onCancel={() => setEditing(null)} onSave={handleSave} />;
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <p className="text-sm text-muted-foreground">Assign these to your physical products to control shipping cost and delivery estimates.</p>
        <button
          onClick={() => setEditing({})}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full brand-gradient text-white text-xs font-semibold hover:opacity-95 transition-opacity shrink-0"
        >
          <Plus className="w-3.5 h-3.5" /> New Profile
        </button>
      </div>

      {loading ? (
        <div className="space-y-3">{[1, 2].map((i) => <div key={i} className="h-20 rounded-2xl bg-secondary/60 animate-pulse" />)}</div>
      ) : profiles.length === 0 ? (
        <div className="bg-white rounded-3xl border border-border soft-shadow">
          <EmptyState icon={Settings2} title="No shipping profiles yet" description="Create one to assign shipping rates to your physical products." />
        </div>
      ) : (
        <div className="space-y-3">
          {profiles.map((p) => (
            <div key={p.id} className="bg-white rounded-3xl border border-border soft-shadow p-5 flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="font-semibold text-sm flex items-center gap-2">
                  {p.name} <StatusBadge status={p.active ? 'active' : 'inactive'} />
                  {p.freeShipping && <StatusBadge status="published" />}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {p.zones.length} zone{p.zones.length !== 1 ? 's' : ''} · Processing {p.processingTime.min}-{p.processingTime.max} days
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => setEditing(p)} className="px-4 py-2 rounded-full border border-border text-xs font-semibold hover:bg-secondary transition-colors">Edit</button>
                <button onClick={() => handleDelete(p)} className="px-4 py-2 rounded-full border border-border text-xs font-semibold text-destructive hover:bg-destructive/10 transition-colors">Delete</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// -----------------------------------------------------------------------
// Orders to Ship
// -----------------------------------------------------------------------
const OrdersToShipPanel = ({ onShipped }) => {
  const { toast } = useToast();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [shippingOrder, setShippingOrder] = useState(null); // order being shipped right now
  const [trackingForm, setTrackingForm] = useState({ carrier: '', trackingNumber: '', trackingUrl: '' });
  const [busy, setBusy] = useState(false);

  const load = () => {
    setLoading(true);
    listOrdersToShip()
      .then(setOrders)
      .catch((err) => toast({ title: "Couldn't load orders to ship", description: getErrorMessage(err), variant: 'destructive' }))
      .finally(() => setLoading(false));
  };
  useEffect(load, []); // eslint-disable-line react-hooks/exhaustive-deps

  const submitShipment = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await createShipment(shippingOrder.id, trackingForm.trackingNumber ? trackingForm : {});
      toast({ title: 'Shipment created', description: `Order ${shippingOrder.orderNumber}` });
      setShippingOrder(null);
      setTrackingForm({ carrier: '', trackingNumber: '', trackingUrl: '' });
      load();
      onShipped?.();
    } catch (err) {
      toast({ title: "Couldn't create shipment", description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  if (loading) return <div className="space-y-3">{[1, 2].map((i) => <div key={i} className="h-20 rounded-2xl bg-secondary/60 animate-pulse" />)}</div>;

  if (orders.length === 0) {
    return (
      <div className="bg-white rounded-3xl border border-border soft-shadow">
        <EmptyState icon={PackageSearch} title="Nothing to ship right now" description="Orders with physical items awaiting fulfillment will show up here." />
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {orders.map((o) => (
        <div key={o.id} className="bg-white rounded-3xl border border-border soft-shadow p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="font-semibold text-sm">{o.orderNumber}</p>
              <p className="text-xs text-muted-foreground mt-1">
                {o.items.map((i) => `${i.title} ×${i.quantity}`).join(', ')} · Placed {fmtDate(o.createdAt)}
              </p>
            </div>
            <button
              onClick={() => setShippingOrder(o)}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full brand-gradient text-white text-xs font-semibold hover:opacity-95 transition-opacity shrink-0"
            >
              <Send className="w-3.5 h-3.5" /> Ship Order
            </button>
          </div>

          {shippingOrder?.id === o.id && (
            <form onSubmit={submitShipment} className="mt-4 pt-4 border-t border-border grid sm:grid-cols-3 gap-3">
              <input placeholder="Carrier (optional)" value={trackingForm.carrier} onChange={(e) => setTrackingForm((f) => ({ ...f, carrier: e.target.value }))} className="bg-secondary/60 rounded-lg px-3 py-2 text-sm outline-none border border-transparent focus:border-primary" />
              <input placeholder="Tracking number (optional)" value={trackingForm.trackingNumber} onChange={(e) => setTrackingForm((f) => ({ ...f, trackingNumber: e.target.value }))} className="bg-secondary/60 rounded-lg px-3 py-2 text-sm outline-none border border-transparent focus:border-primary" />
              <div className="flex items-center gap-2">
                <button type="submit" disabled={busy} className="px-4 py-2 rounded-full brand-gradient text-white text-xs font-semibold disabled:opacity-60">{busy ? 'Creating…' : 'Confirm'}</button>
                <button type="button" onClick={() => setShippingOrder(null)} className="px-4 py-2 rounded-full border border-border text-xs font-semibold hover:bg-secondary">Cancel</button>
              </div>
              <p className="sm:col-span-3 text-[11px] text-muted-foreground">Leave tracking blank to create a pending shipment you can update later.</p>
            </form>
          )}
        </div>
      ))}
    </div>
  );
};

// -----------------------------------------------------------------------
// Shipments (this seller's own, paginated)
// -----------------------------------------------------------------------
const ShipmentsPanel = ({ refreshKey }) => {
  const { toast } = useToast();
  const [shipments, setShipments] = useState([]);
  const [meta, setMeta] = useState(null);
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [expandedId, setExpandedId] = useState(null);
  const [trackingDraft, setTrackingDraft] = useState({});

  const load = () => {
    setLoading(true);
    listShipments({ page, limit: 10, ...(statusFilter ? { status: statusFilter } : {}) })
      .then((res) => { setShipments(res.shipments || []); setMeta(res.meta); })
      .catch((err) => toast({ title: "Couldn't load shipments", description: getErrorMessage(err), variant: 'destructive' }))
      .finally(() => setLoading(false));
  };
  useEffect(load, [page, statusFilter, refreshKey]); // eslint-disable-line react-hooks/exhaustive-deps

  const changeStatus = async (shipment, status) => {
    try {
      await updateShipmentStatus(shipment.id, status);
      toast({ title: 'Shipment status updated', description: status.replace('_', ' ') });
      load();
    } catch (err) {
      toast({ title: "Couldn't update status", description: getErrorMessage(err), variant: 'destructive' });
    }
  };

  const saveTracking = async (shipment) => {
    const draft = trackingDraft[shipment.id];
    if (!draft?.trackingNumber) return;
    try {
      await addShipmentTracking(shipment.id, draft);
      toast({ title: 'Tracking added' });
      load();
    } catch (err) {
      toast({ title: "Couldn't add tracking", description: getErrorMessage(err), variant: 'destructive' });
    }
  };

  return (
    <div>
      <div className="flex items-center gap-2 mb-4 overflow-x-auto pb-1">
        <button onClick={() => { setStatusFilter(''); setPage(1); }} className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap ${!statusFilter ? 'bg-primary text-white' : 'bg-secondary text-muted-foreground'}`}>All</button>
        {STATUS_OPTIONS.map((s) => (
          <button key={s} onClick={() => { setStatusFilter(s); setPage(1); }} className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap capitalize ${statusFilter === s ? 'bg-primary text-white' : 'bg-secondary text-muted-foreground'}`}>
            {s.replace('_', ' ')}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-3">{[1, 2, 3].map((i) => <div key={i} className="h-20 rounded-2xl bg-secondary/60 animate-pulse" />)}</div>
      ) : shipments.length === 0 ? (
        <div className="bg-white rounded-3xl border border-border soft-shadow">
          <EmptyState icon={Truck} title="No shipments" description="Shipments matching this filter will show up here." />
        </div>
      ) : (
        <div className="space-y-3">
          {shipments.map((s) => {
            const expanded = expandedId === s.id;
            return (
              <div key={s.id} className="bg-white rounded-3xl border border-border soft-shadow p-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="text-sm font-semibold">{s.orderNumber} <span className="text-muted-foreground font-normal">· {s.items.map((i) => i.title).join(', ')}</span></p>
                    <p className="text-xs text-muted-foreground mt-1">{s.estimatedDelivery ? `Est. delivery ${fmtDate(s.estimatedDelivery)}` : `Created ${fmtDate(s.createdAt)}`}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <ShipmentStatusBadge status={s.status} />
                    <select
                      value={s.status}
                      onChange={(e) => changeStatus(s, e.target.value)}
                      className="text-xs font-semibold border border-border rounded-full px-2.5 py-1 bg-white"
                    >
                      {STATUS_OPTIONS.map((opt) => <option key={opt} value={opt}>{opt.replace('_', ' ')}</option>)}
                    </select>
                  </div>
                </div>

                <TrackingInfo carrier={s.carrier} trackingNumber={s.trackingNumber} trackingUrl={s.trackingUrl} className="mt-3" />

                {!s.trackingNumber && (
                  <div className="mt-3 grid sm:grid-cols-3 gap-2">
                    <input placeholder="Carrier" value={trackingDraft[s.id]?.carrier || ''} onChange={(e) => setTrackingDraft((d) => ({ ...d, [s.id]: { ...d[s.id], carrier: e.target.value } }))} className="bg-secondary/60 rounded-lg px-3 py-1.5 text-xs outline-none border border-transparent focus:border-primary" />
                    <input placeholder="Tracking number" value={trackingDraft[s.id]?.trackingNumber || ''} onChange={(e) => setTrackingDraft((d) => ({ ...d, [s.id]: { ...d[s.id], trackingNumber: e.target.value } }))} className="bg-secondary/60 rounded-lg px-3 py-1.5 text-xs outline-none border border-transparent focus:border-primary" />
                    <button onClick={() => saveTracking(s)} className="px-3 py-1.5 rounded-full border border-border text-xs font-semibold hover:bg-secondary">Add Tracking</button>
                  </div>
                )}

                <button onClick={() => setExpandedId(expanded ? null : s.id)} className="mt-3 inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline">
                  {expanded ? 'Hide timeline' : 'View timeline'} {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                </button>
                {expanded && <div className="mt-3 pt-3 border-t border-border"><ShipmentTimeline timeline={s.timeline} /></div>}
              </div>
            );
          })}
        </div>
      )}

      {meta && meta.totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 mt-6">
          <button disabled={page === 1} onClick={() => setPage((p) => p - 1)} className="w-8 h-8 grid place-items-center rounded-full border border-border disabled:opacity-40">‹</button>
          <span className="text-xs font-medium text-muted-foreground">Page {page} of {meta.totalPages}</span>
          <button disabled={page === meta.totalPages} onClick={() => setPage((p) => p + 1)} className="w-8 h-8 grid place-items-center rounded-full border border-border disabled:opacity-40">›</button>
        </div>
      )}
    </div>
  );
};

// -----------------------------------------------------------------------
// Container
// -----------------------------------------------------------------------
const SellerShippingTab = () => {
  const [subTab, setSubTab] = useState('profiles');
  const [refreshKey, setRefreshKey] = useState(0);

  return (
    <div>
      <div className="flex gap-1.5 overflow-x-auto pb-1 mb-5 border-b border-border">
        {SUB_TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setSubTab(t.key)}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-semibold whitespace-nowrap border-b-2 -mb-px transition-colors ${subTab === t.key ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'}`}
          >
            <t.icon className="w-4 h-4" /> {t.label}
          </button>
        ))}
      </div>

      {subTab === 'profiles' && <ProfilesPanel />}
      {subTab === 'to-ship' && <OrdersToShipPanel onShipped={() => setRefreshKey((k) => k + 1)} />}
      {subTab === 'shipments' && <ShipmentsPanel refreshKey={refreshKey} />}
    </div>
  );
};

export default SellerShippingTab;
