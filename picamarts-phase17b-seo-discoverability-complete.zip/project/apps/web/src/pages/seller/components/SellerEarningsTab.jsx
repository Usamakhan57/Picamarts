import React, { useEffect, useState } from 'react';
import { Wallet, TrendingUp, Clock, Banknote, Lock, Send, X } from 'lucide-react';
import StatCard from '../../../admin/components/StatCard';
import StatusBadge from '../../../admin/components/StatusBadge';
import EmptyState from '../../../admin/components/EmptyState';
import Pagination from './Pagination';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '../../../components/ui/dialog';
import { getMyWalletSummary, getMyTransactions } from '../../../services/walletService';
import { requestWithdrawal, getMyWithdrawals, cancelWithdrawal } from '../../../services/payoutService';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

const fmtMoney = (n) => `$${Number(n || 0).toFixed(2)}`;
const fmtDate = (iso) => new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });

const CATEGORY_LABELS = {
  sale: 'Sale',
  commission_deduction: 'Commission',
  refund_adjustment: 'Refund Adjustment',
  manual_adjustment: 'Admin Adjustment',
  opening_balance: 'Opening Balance',
  closing_balance: 'Closing Balance',
  withdrawal_hold: 'Withdrawal Held',
  withdrawal_release: 'Withdrawal Released',
  withdrawal_completed: 'Withdrawal Paid Out',
};

/**
 * Phase 16C, Parts 1/2/6 — "Request Withdrawal" dialog. Amount is
 * validated client-side against the seller's own `availableBalance`
 * as a UX nicety only — the real, authoritative check happens
 * server-side (payout.service.js#createWithdrawalRequest), which is
 * also where the balance actually gets locked.
 */
const RequestWithdrawalDialog = ({ open, onOpenChange, availableBalance, onRequested }) => {
  const { toast } = useToast();
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (open) { setAmount(''); setNote(''); }
  }, [open]);

  const submit = async (e) => {
    e.preventDefault();
    const numeric = Number(amount);
    if (!(numeric > 0)) {
      toast({ title: 'Enter an amount greater than $0', variant: 'destructive' });
      return;
    }
    if (numeric > availableBalance) {
      toast({ title: 'Amount exceeds your available balance', variant: 'destructive' });
      return;
    }
    setSubmitting(true);
    try {
      await requestWithdrawal({ amount: numeric, note: note || undefined });
      toast({ title: 'Withdrawal requested', description: 'Your available balance has been held pending approval.' });
      onOpenChange(false);
      onRequested();
    } catch (err) {
      toast({ title: 'Could not request withdrawal', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md rounded-3xl">
        <DialogTitle>Request Withdrawal</DialogTitle>
        <DialogDescription>Available balance: {fmtMoney(availableBalance)}</DialogDescription>
        <form onSubmit={submit} className="space-y-4 mt-2">
          <div>
            <label className="text-sm font-medium block mb-1.5">Amount</label>
            <input
              type="number"
              min="0.01"
              step="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
              placeholder="0.00"
              className="w-full bg-secondary/60 rounded-xl px-4 py-2.5 text-sm outline-none border border-transparent focus:border-primary"
            />
          </div>
          <div>
            <label className="text-sm font-medium block mb-1.5">Note (optional)</label>
            <input
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Anything you'd like us to know"
              className="w-full bg-secondary/60 rounded-xl px-4 py-2.5 text-sm outline-none border border-transparent focus:border-primary"
            />
          </div>
          <p className="text-xs text-muted-foreground">The requested amount is held from your available balance immediately and released back if the request is cancelled or rejected.</p>
          <button
            type="submit"
            disabled={submitting}
            className="brand-gradient text-white font-semibold px-6 py-2.5 rounded-full hover:opacity-95 transition-all w-full disabled:opacity-60"
          >
            {submitting ? 'Requesting…' : 'Request Withdrawal'}
          </button>
        </form>
      </DialogContent>
    </Dialog>
  );
};

/**
 * Phase 16C, Part 6 — Payout History. Self-fetches from
 * `/payouts/me`, same self-contained pattern the ledger transaction
 * list below already established (Phase 16B). A PENDING request shows
 * a Cancel action (Part 1's "before processing" — the button
 * disappears once it moves to any other status).
 */
const PayoutHistory = ({ refreshKey, onChanged }) => {
  const { toast } = useToast();
  const [requests, setRequests] = useState([]);
  const [meta, setMeta] = useState({ totalPages: 1 });
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [cancellingId, setCancellingId] = useState(null);

  const load = () => {
    setLoading(true);
    setError('');
    getMyWithdrawals({ page, limit: 10 })
      .then((res) => {
        setRequests(res.requests || []);
        setMeta(res.meta || { totalPages: 1 });
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };

  useEffect(load, [page, refreshKey]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleCancel = async (requestId) => {
    setCancellingId(requestId);
    try {
      await cancelWithdrawal(requestId);
      toast({ title: 'Withdrawal request cancelled', description: 'The held balance has been released back to you.' });
      load();
      onChanged();
    } catch (err) {
      toast({ title: 'Could not cancel request', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setCancellingId(null);
    }
  };

  return (
    <div className="bg-white rounded-3xl border border-border soft-shadow p-6 mt-6">
      <h3 className="font-bold mb-4">Payout History</h3>
      {loading ? (
        <p className="text-sm text-muted-foreground py-6 text-center">Loading…</p>
      ) : error ? (
        <p className="text-sm text-destructive py-6 text-center">{error}</p>
      ) : requests.length === 0 ? (
        <EmptyState icon={Send} title="No withdrawal requests yet" description="Request a withdrawal from your available balance above." />
      ) : (
        <>
          <ul className="divide-y divide-border">
            {requests.map((r) => (
              <li key={r.id} className="flex items-center justify-between gap-3 py-3">
                <div className="min-w-0">
                  <p className="text-sm font-medium">{fmtMoney(r.amount)}</p>
                  <p className="text-xs text-muted-foreground">
                    {fmtDate(r.requestedAt || r.createdAt)}
                    {r.stripeTransferId ? ` · Transfer ${r.stripeTransferId}` : ''}
                    {r.status === 'failed' && r.failureReason ? ` · ${r.failureReason}` : ''}
                  </p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <StatusBadge status={r.status} />
                  {r.status === 'pending' && (
                    <button
                      onClick={() => handleCancel(r.id)}
                      disabled={cancellingId === r.id}
                      className="p-1.5 rounded-lg hover:bg-secondary transition-colors text-muted-foreground disabled:opacity-50"
                      aria-label="Cancel request"
                      title="Cancel request"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </li>
            ))}
          </ul>
          {meta.totalPages > 1 && (
            <div className="mt-4">
              <Pagination page={page} totalPages={meta.totalPages} onPageChange={setPage} />
            </div>
          )}
        </>
      )}
    </div>
  );
};

/**
 * Phase 16B, Part 6 (extended in Phase 16C) — self-fetches from the
 * real `/wallet/me` + `/wallet/me/transactions` endpoints, same
 * self-contained pattern `SellerAnalyticsTab.jsx` already established.
 * `availableBalance` here is the seller's real, current wallet
 * balance (already net of any locked/held withdrawal amounts — see
 * wallet.service.js#getWalletSummary); `lockedBalance` is the sum of
 * currently-open withdrawal requests (Phase 16C).
 */
const SellerEarningsTab = () => {
  const [summary, setSummary] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [meta, setMeta] = useState({ totalPages: 1 });
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [withdrawOpen, setWithdrawOpen] = useState(false);
  const [payoutRefreshKey, setPayoutRefreshKey] = useState(0);

  const load = () => {
    setLoading(true);
    setError('');
    Promise.all([getMyWalletSummary(), getMyTransactions({ page, limit: 10 })])
      .then(([wallet, tx]) => {
        setSummary(wallet);
        setTransactions(tx.transactions || []);
        setMeta(tx.meta || { totalPages: 1 });
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };

  useEffect(load, [page]); // eslint-disable-line react-hooks/exhaustive-deps

  const refreshAfterPayoutChange = () => {
    load();
    setPayoutRefreshKey((k) => k + 1);
  };

  if (loading) return <p className="text-sm text-muted-foreground py-12 text-center">Loading earnings…</p>;
  if (error) {
    return (
      <div className="bg-white rounded-3xl border border-border soft-shadow p-8 text-center">
        <p className="text-sm text-destructive">{error}</p>
      </div>
    );
  }

  return (
    <div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
        <StatCard label="Available Balance" value={fmtMoney(summary?.availableBalance)} icon={Wallet} />
        <StatCard label="Pending (this month)" value={fmtMoney(summary?.pendingBalance)} icon={Clock} />
        <StatCard label="Held in Withdrawals" value={fmtMoney(summary?.lockedBalance)} icon={Lock} />
        <StatCard label="Total Earnings" value={fmtMoney(summary?.totalEarnings)} icon={TrendingUp} />
        <StatCard label="Total Withdrawn" value={fmtMoney(summary?.totalWithdrawn)} icon={Banknote} />
      </div>

      <div className="flex justify-end mb-6">
        <button
          onClick={() => setWithdrawOpen(true)}
          disabled={!summary?.availableBalance}
          className="inline-flex items-center gap-2 brand-gradient text-white font-semibold px-5 py-2.5 rounded-full hover:opacity-95 transition-all disabled:opacity-50"
        >
          <Send className="w-4 h-4" /> Request Withdrawal
        </button>
      </div>

      <div className="bg-white rounded-3xl border border-border soft-shadow p-6">
        <h3 className="font-bold mb-4">Recent Transactions</h3>
        {transactions.length === 0 ? (
          <EmptyState icon={Wallet} title="No transactions yet" description="Sales, commission deductions, and any adjustments will show up here." />
        ) : (
          <>
            <ul className="divide-y divide-border">
              {transactions.map((t) => (
                <li key={t.id} className="flex items-center justify-between gap-3 py-3">
                  <div className="min-w-0">
                    <p className="text-sm font-medium">{CATEGORY_LABELS[t.category] || t.category}</p>
                    <p className="text-xs text-muted-foreground">{fmtDate(t.createdAt)}{t.note ? ` · ${t.note}` : ''}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className={`text-sm font-semibold ${t.direction === 'credit' ? 'text-emerald-600' : 'text-red-500'}`}>
                      {t.direction === 'credit' ? '+' : '−'}{fmtMoney(t.amount)}
                    </p>
                    <StatusBadge status={t.direction === 'credit' ? 'paid' : 'pending'} />
                  </div>
                </li>
              ))}
            </ul>
            {meta.totalPages > 1 && (
              <div className="mt-4">
                <Pagination page={page} totalPages={meta.totalPages} onPageChange={setPage} />
              </div>
            )}
          </>
        )}
      </div>

      <PayoutHistory refreshKey={payoutRefreshKey} onChanged={refreshAfterPayoutChange} />

      <RequestWithdrawalDialog
        open={withdrawOpen}
        onOpenChange={setWithdrawOpen}
        availableBalance={summary?.availableBalance || 0}
        onRequested={refreshAfterPayoutChange}
      />
    </div>
  );
};

export default SellerEarningsTab;
