import React, { useEffect, useState } from 'react';
import { Download } from 'lucide-react';
import EmptyState from '../../../admin/components/EmptyState';
import Pagination from './Pagination';
import { getDeliveryStats, listDeliveries } from '../../../services/sellerDownloadService';
import { getErrorMessage } from '../../../lib/errorMessage';

const PAGE_SIZE = 10;

const fmtDate = (iso) => (iso ? new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) : '—');

// Real /downloads/stats + /downloads/deliveries (Phase 14.1) — auto-scoped
// to the acting seller's own products. Note: the backend doesn't return a
// buyer name/email on a delivery record (only the order id), so that
// column is left out rather than fabricated.
const SellerDownloadsTab = () => {
  const [stats, setStats] = useState([]);
  const [deliveries, setDeliveries] = useState([]);
  const [meta, setMeta] = useState({ totalPages: 1 });
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = () => {
    setLoading(true);
    setError('');
    Promise.all([getDeliveryStats(), listDeliveries({ page, limit: PAGE_SIZE })])
      .then(([statsRes, { deliveries: rows, meta: m }]) => {
        setStats(statsRes || []);
        setDeliveries(rows || []);
        setMeta(m || { totalPages: 1 });
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };

  useEffect(load, [page]); // eslint-disable-line react-hooks/exhaustive-deps

  if (loading) return <p className="text-sm text-muted-foreground py-12 text-center">Loading downloads…</p>;
  if (error) {
    return (
      <div className="bg-white rounded-3xl border border-border soft-shadow p-8 text-center">
        <p className="text-sm text-destructive mb-3">{error}</p>
        <button onClick={load} className="text-sm font-semibold text-primary hover:underline">Try again</button>
      </div>
    );
  }

  return (
    <div>
      {stats.length > 0 && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {stats.slice(0, 4).map((s) => (
            <div key={typeof s.product === 'string' ? s.product : s.product.id} className="bg-white rounded-2xl border border-border soft-shadow p-4">
              <p className="text-xs font-semibold text-muted-foreground truncate">{typeof s.product === 'string' ? s.product : s.product.title}</p>
              <p className="text-2xl font-black mt-1">{s.totalDownloads}</p>
              <p className="text-xs text-muted-foreground">{s.totalPurchases} purchase{s.totalPurchases === 1 ? '' : 's'}{s.revoked ? ` · ${s.revoked} revoked` : ''}</p>
            </div>
          ))}
        </div>
      )}

      <div className="bg-white rounded-3xl border border-border soft-shadow overflow-hidden">
        {deliveries.length === 0 ? (
          <EmptyState icon={Download} title="No downloads yet" description="Buyer download activity for your products will show up here." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-secondary/60 text-left text-xs uppercase tracking-wide text-muted-foreground">
                <tr>
                  <th className="px-5 py-3 font-semibold">Product</th>
                  <th className="px-5 py-3 font-semibold">License Key</th>
                  <th className="px-5 py-3 font-semibold">Download Count</th>
                  <th className="px-5 py-3 font-semibold">Purchased</th>
                  <th className="px-5 py-3 font-semibold">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {deliveries.map((d) => (
                  <tr key={d.id}>
                    <td className="px-5 py-3.5 font-medium">
                      <div className="flex items-center gap-2.5">
                        {d.product?.thumbnail?.url && <img src={d.product.thumbnail.url} alt="" className="w-9 h-9 rounded-lg object-cover bg-secondary shrink-0" />}
                        <span className="truncate max-w-[220px]">{typeof d.product === 'string' ? d.product : d.product?.title}</span>
                      </div>
                    </td>
                    <td className="px-5 py-3.5"><code className="text-xs">{d.licenseKey}</code></td>
                    <td className="px-5 py-3.5 flex items-center gap-1.5 text-muted-foreground"><Download className="w-3.5 h-3.5" /> {d.downloadCount}{d.maxDownloads ? ` / ${d.maxDownloads}` : ''}</td>
                    <td className="px-5 py-3.5 text-muted-foreground">{fmtDate(d.purchasedAt)}</td>
                    <td className="px-5 py-3.5">
                      <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${d.status === 'revoked' ? 'bg-red-50 text-red-600' : 'bg-secondary'}`}>{d.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      <Pagination page={page} totalPages={meta.totalPages || 1} onPageChange={setPage} />
    </div>
  );
};

export default SellerDownloadsTab;
