import React, { useEffect, useState } from 'react';
import { Bell, ShoppingCart, MessageSquare, CreditCard, Download, Info, Trash2 } from 'lucide-react';
import EmptyState from '../../../admin/components/EmptyState';
import Pagination from './Pagination';
import { listNotifications, markAsRead, markAllAsRead, deleteNotification } from '../../../services/notificationService';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

const PAGE_SIZE = 15;

const iconFor = (type = '') => {
  if (type.startsWith('order') || type === 'tracking_added') return ShoppingCart;
  if (type.startsWith('payment') || type === 'refund_issued') return CreditCard;
  if (type.startsWith('review')) return MessageSquare;
  if (type.startsWith('digital') || type === 'license_assigned' || type === 'download_expiring') return Download;
  return Info;
};

const fmtRelative = (iso) => {
  const diffMs = Date.now() - new Date(iso).getTime();
  const hours = Math.round(diffMs / (1000 * 60 * 60));
  if (hours < 1) return 'Just now';
  if (hours < 24) return `${hours}h ago`;
  return `${Math.round(hours / 24)}d ago`;
};

// Real backend notifications (Phase 10.2) — the same /notifications
// endpoints power buyer, seller, and admin alike.
const SellerNotificationsTab = () => {
  const { toast } = useToast();
  const [notifications, setNotifications] = useState([]);
  const [meta, setMeta] = useState({ totalPages: 1 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState('all');
  const [page, setPage] = useState(1);

  useEffect(() => { setPage(1); }, [filter]);

  const load = () => {
    setLoading(true);
    setError('');
    const params = { page, limit: PAGE_SIZE };
    if (filter === 'unread') params.isRead = false;
    if (filter === 'read') params.isRead = true;
    listNotifications(params)
      .then(({ notifications: rows, meta: m }) => {
        setNotifications(rows);
        setMeta(m || { totalPages: 1 });
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };

  useEffect(load, [page, filter]); // eslint-disable-line react-hooks/exhaustive-deps

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const handleMarkRead = async (n) => {
    if (n.isRead) return;
    setNotifications((prev) => prev.map((x) => (x.id === n.id ? { ...x, isRead: true } : x)));
    try {
      await markAsRead(n.id);
    } catch (err) {
      toast({ title: 'Could not mark as read', description: getErrorMessage(err), variant: 'destructive' });
    }
  };

  const handleMarkAllRead = async () => {
    try {
      await markAllAsRead();
      load();
    } catch (err) {
      toast({ title: 'Could not mark all as read', description: getErrorMessage(err), variant: 'destructive' });
    }
  };

  const handleDelete = async (n) => {
    try {
      await deleteNotification(n.id);
      setNotifications((prev) => prev.filter((x) => x.id !== n.id));
    } catch (err) {
      toast({ title: 'Could not delete notification', description: getErrorMessage(err), variant: 'destructive' });
    }
  };

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
        <div className="flex flex-wrap gap-1.5">
          {[
            { key: 'all', label: 'All' },
            { key: 'unread', label: `Unread${unreadCount ? ` (${unreadCount})` : ''}` },
            { key: 'read', label: 'Read' },
          ].map((t) => (
            <button
              key={t.key}
              onClick={() => setFilter(t.key)}
              className={`px-4 py-2 rounded-full text-sm font-semibold transition-colors ${filter === t.key ? 'brand-gradient text-white' : 'border border-border hover:bg-secondary'}`}
            >
              {t.label}
            </button>
          ))}
        </div>
        <button onClick={handleMarkAllRead} disabled={unreadCount === 0} className="text-sm font-semibold text-primary disabled:opacity-40 disabled:cursor-not-allowed hover:underline">
          Mark all read
        </button>
      </div>

      <div className="bg-white rounded-3xl border border-border soft-shadow overflow-hidden">
        {loading ? (
          <p className="text-sm text-muted-foreground py-12 text-center">Loading notifications…</p>
        ) : error ? (
          <div className="p-8 text-center">
            <p className="text-sm text-destructive mb-3">{error}</p>
            <button onClick={load} className="text-sm font-semibold text-primary hover:underline">Try again</button>
          </div>
        ) : notifications.length === 0 ? (
          <EmptyState icon={Bell} title="No notifications" description="You're all caught up." />
        ) : (
          <ul className="divide-y divide-border">
            {notifications.map((n) => {
              const Icon = iconFor(n.type);
              return (
                <li
                  key={n.id}
                  onClick={() => handleMarkRead(n)}
                  className={`flex items-start gap-3.5 px-5 py-4 cursor-pointer transition-colors hover:bg-secondary/40 ${!n.isRead ? 'bg-primary/5' : ''}`}
                >
                  <span className="w-9 h-9 rounded-xl bg-secondary grid place-items-center shrink-0"><Icon className="w-4 h-4 text-primary" /></span>
                  <div className="min-w-0 flex-1">
                    <p className={`text-sm ${!n.isRead ? 'font-semibold' : ''}`}>{n.title}</p>
                    <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{n.message}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{fmtRelative(n.createdAt)}</p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {!n.isRead && <span className="w-2 h-2 rounded-full bg-primary mt-1.5" />}
                    <button
                      onClick={(e) => { e.stopPropagation(); handleDelete(n); }}
                      aria-label="Delete notification"
                      className="p-1.5 rounded-lg text-muted-foreground hover:text-red-600 hover:bg-red-50 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
      <Pagination page={page} totalPages={meta.totalPages || 1} onPageChange={setPage} />
    </div>
  );
};

export default SellerNotificationsTab;
