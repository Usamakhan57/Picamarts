import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, LayoutGrid, List as ListIcon, Plus, Pencil, Trash2, Package, Download } from 'lucide-react';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../../../components/ui/select';
import StatusBadge from '../../../admin/components/StatusBadge';
import EmptyState from '../../../admin/components/EmptyState';
import ConfirmDeleteDialog from '../../../admin/components/ConfirmDeleteDialog';
import Pagination from './Pagination';
import { getSellerProducts, deleteSellerProduct } from '../api/sellerProducts';
import { getStorefrontCategories } from '../../../services/categoryRepository';
import { useCatalogVersion } from '../../../hooks/useCatalogVersion';
import { useToast } from '../../../hooks/use-toast';
import { getErrorMessage } from '../../../lib/errorMessage';

const PAGE_SIZE = 8;

const STATUS_OPTIONS = [
  { value: 'draft', label: 'Draft' },
  { value: 'published', label: 'Published' },
  { value: 'archived', label: 'Archived' },
];

// Server-side pagination/filtering/search against the real /products/mine
// endpoint — replaces the old client-side array filter over the full
// mock catalog.
const SellerProductsTab = () => {
  const { toast } = useToast();
  const [products, setProducts] = useState([]);
  const [meta, setMeta] = useState({ totalPages: 1 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [category, setCategory] = useState('all');
  const [status, setStatus] = useState('all');
  const [view, setView] = useState('grid');
  const [page, setPage] = useState(1);
  const [pendingDelete, setPendingDelete] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const catalogVersion = useCatalogVersion();
  const categories = useMemo(() => getStorefrontCategories(), [catalogVersion]);

  // Debounce free-text search so every keystroke doesn't fire a request.
  useEffect(() => {
    const t = setTimeout(() => setDebouncedQuery(query.trim()), 300);
    return () => clearTimeout(t);
  }, [query]);

  useEffect(() => { setPage(1); }, [debouncedQuery, category, status]);

  const load = () => {
    setLoading(true);
    setError('');
    const params = { page, limit: PAGE_SIZE, sort: 'newest' };
    if (debouncedQuery) params.q = debouncedQuery;
    if (status !== 'all') params.status = status;
    if (category !== 'all') params.category = category;
    getSellerProducts(params)
      .then(({ products: rows, meta: m }) => {
        setProducts(rows);
        setMeta(m || { totalPages: 1 });
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  };

  useEffect(load, [page, debouncedQuery, category, status]); // eslint-disable-line react-hooks/exhaustive-deps

  const confirmDelete = async () => {
    if (!pendingDelete) return;
    setDeleting(true);
    try {
      await deleteSellerProduct(pendingDelete.id);
      toast({ title: 'Product deleted', description: pendingDelete.title });
      setPendingDelete(null);
      load();
    } catch (err) {
      toast({ title: 'Could not delete product', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div>
      {/* Toolbar */}
      <div className="flex flex-col lg:flex-row lg:items-center gap-3 mb-6">
        <div className="flex items-center gap-2 bg-secondary/60 rounded-full px-4 py-2.5 flex-1 max-w-sm">
          <Search className="w-4 h-4 text-muted-foreground shrink-0" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search your products…"
            className="bg-transparent outline-none text-sm w-full placeholder:text-muted-foreground"
          />
        </div>

        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger className="w-full lg:w-[170px] rounded-full text-sm"><SelectValue placeholder="Category" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {categories.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
          </SelectContent>
        </Select>

        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-full lg:w-[170px] rounded-full text-sm"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            {STATUS_OPTIONS.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
          </SelectContent>
        </Select>

        <div className="flex items-center gap-1 bg-secondary/60 rounded-full p-1 shrink-0">
          <button
            onClick={() => setView('grid')}
            aria-label="Grid view"
            aria-pressed={view === 'grid'}
            className={`p-2 rounded-full transition-colors ${view === 'grid' ? 'bg-white soft-shadow text-primary' : 'text-muted-foreground hover:text-foreground'}`}
          >
            <LayoutGrid className="w-4 h-4" />
          </button>
          <button
            onClick={() => setView('list')}
            aria-label="List view"
            aria-pressed={view === 'list'}
            className={`p-2 rounded-full transition-colors ${view === 'list' ? 'bg-white soft-shadow text-primary' : 'text-muted-foreground hover:text-foreground'}`}
          >
            <ListIcon className="w-4 h-4" />
          </button>
        </div>

        <Link
          to="/seller/products/new"
          className="inline-flex items-center justify-center gap-2 brand-gradient text-white text-sm font-semibold px-5 py-2.5 rounded-full hover:opacity-95 transition-all shrink-0"
        >
          <Plus className="w-4 h-4" /> New Product
        </Link>
      </div>

      {loading ? (
        <p className="text-sm text-muted-foreground py-12 text-center">Loading your products…</p>
      ) : error ? (
        <div className="bg-white rounded-3xl border border-border soft-shadow p-8 text-center">
          <p className="text-sm text-destructive mb-3">{error}</p>
          <button onClick={load} className="text-sm font-semibold text-primary hover:underline">Try again</button>
        </div>
      ) : products.length === 0 ? (
        <div className="bg-white rounded-3xl border border-border soft-shadow">
          <EmptyState
            icon={Package}
            title={debouncedQuery || category !== 'all' || status !== 'all' ? 'No products match your filters' : 'No products yet'}
            description={debouncedQuery || category !== 'all' || status !== 'all' ? 'Try adjusting your search, category, or status filter.' : 'List your first product to start selling on PicaMarts.'}
            action={
              !(debouncedQuery || category !== 'all' || status !== 'all') ? (
                <Link to="/seller/products/new" className="inline-flex items-center gap-2 brand-gradient text-white text-sm font-semibold px-5 py-2.5 rounded-full">
                  <Plus className="w-4 h-4" /> New Product
                </Link>
              ) : null
            }
          />
        </div>
      ) : view === 'grid' ? (
        <>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {products.map((p) => (
              <div key={p.id} className="bg-white rounded-2xl border border-border soft-shadow overflow-hidden group">
                <div className="aspect-square bg-secondary relative overflow-hidden">
                  {p.thumbnail ? (
                    <img src={p.thumbnail} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full grid place-items-center text-muted-foreground text-xs">No image</div>
                  )}
                  <span className="absolute top-2.5 left-2.5"><StatusBadge status={p.status} /></span>
                </div>
                <div className="p-4">
                  <p className="font-semibold text-sm truncate">{p.title}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{p.category}</p>
                  <div className="flex items-center justify-between mt-2.5">
                    <span className="font-bold text-sm">${Number(p.price).toFixed(2)}</span>
                    <span className="flex items-center gap-1 text-xs text-muted-foreground"><Download className="w-3 h-3" /> {p.downloads?.toLocaleString() || 0}</span>
                  </div>
                  <div className="flex items-center gap-2 mt-3">
                    <Link to={`/seller/products/${p.id}/edit`} className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-full border border-border text-xs font-semibold hover:bg-secondary transition-colors">
                      <Pencil className="w-3.5 h-3.5" /> Edit
                    </Link>
                    <button
                      onClick={() => setPendingDelete(p)}
                      aria-label={`Delete ${p.title}`}
                      className="p-2 rounded-full border border-border text-red-600 hover:bg-red-50 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <Pagination page={page} totalPages={meta.totalPages || 1} onPageChange={setPage} />
        </>
      ) : (
        <>
          <div className="bg-white rounded-3xl border border-border soft-shadow overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-secondary/60 text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <tr>
                    <th className="px-5 py-3 font-semibold">Product</th>
                    <th className="px-5 py-3 font-semibold">Category</th>
                    <th className="px-5 py-3 font-semibold">Price</th>
                    <th className="px-5 py-3 font-semibold">Downloads</th>
                    <th className="px-5 py-3 font-semibold">Status</th>
                    <th className="px-5 py-3 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {products.map((p) => (
                    <tr key={p.id}>
                      <td className="px-5 py-3.5 font-medium">
                        <div className="flex items-center gap-3">
                          <img src={p.thumbnail} alt="" className="w-10 h-10 rounded-lg object-cover bg-secondary shrink-0" />
                          <span className="truncate max-w-[220px]">{p.title}</span>
                        </div>
                      </td>
                      <td className="px-5 py-3.5 text-muted-foreground">{p.category}</td>
                      <td className="px-5 py-3.5">${Number(p.price).toFixed(2)}</td>
                      <td className="px-5 py-3.5 text-muted-foreground">{p.downloads?.toLocaleString() || 0}</td>
                      <td className="px-5 py-3.5"><StatusBadge status={p.status} /></td>
                      <td className="px-5 py-3.5">
                        <div className="flex items-center justify-end gap-1.5">
                          <Link to={`/seller/products/${p.id}/edit`} aria-label={`Edit ${p.title}`} className="p-1.5 rounded-lg hover:bg-secondary transition-colors">
                            <Pencil className="w-4 h-4" />
                          </Link>
                          <button onClick={() => setPendingDelete(p)} aria-label={`Delete ${p.title}`} className="p-1.5 rounded-lg text-red-600 hover:bg-red-50 transition-colors">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          <Pagination page={page} totalPages={meta.totalPages || 1} onPageChange={setPage} />
        </>
      )}

      <ConfirmDeleteDialog
        open={!!pendingDelete}
        onOpenChange={(open) => !open && setPendingDelete(null)}
        title="Delete this product?"
        description={pendingDelete ? `"${pendingDelete.title}" will be permanently removed from your store.` : ''}
        onConfirm={confirmDelete}
        busy={deleting}
      />
    </div>
  );
};

export default SellerProductsTab;
