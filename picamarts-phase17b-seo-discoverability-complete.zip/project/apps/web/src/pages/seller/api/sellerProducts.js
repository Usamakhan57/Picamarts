/**
 * sellerProducts.js — real backend-backed adapter for the Seller
 * Dashboard's Products tab and New/Edit Product page.
 *
 * Replaces the old mock DB (admin/api/db.js#createResource) entirely.
 * Maps between the real Product schema (apps/api/src/models/Product.js)
 * and the flat form shape this page's existing UI already reads/writes
 * (see productSchema.js's EMPTY_EXTENDED_PRODUCT) — so the tabbed form
 * itself didn't need to be rebuilt field-by-field.
 *
 * Known, disclosed gap: thumbnail/gallery/digital-file fields are kept
 * in local form state (so those UI tabs still work for preview) but are
 * NOT sent to the backend — the shared `ImageUploadInput`/`FileUploadInput`
 * components (used across the entire Admin Panel) only produce data-URL
 * strings today, not real Cloudinary uploads. Real upload wrappers exist
 * and are ready in `services/sellerProductService.js#uploadThumbnail`
 * etc. — wiring them into these shared components is its own media-
 * upload sub-phase (flagged, not forgotten).
 */
import {
  listMyProducts,
  getProduct,
  createProduct as createProductRequest,
  updateProduct as updateProductRequest,
  deleteProduct as deleteProductRequest,
} from '../../../services/sellerProductService';

/** Backend Product → the flat shape ProductsTab/NewProductPage already read. */
const mapToForm = (p) => ({
  id: p.id,
  title: p.title,
  slug: p.slug,
  shortDescription: p.shortDescription || '',
  description: p.description || '',
  category: p.category?.name || '',
  categoryId: typeof p.category === 'string' ? p.category : p.category?.id || '',
  tags: (p.tags || []).map((t) => (typeof t === 'string' ? t : t.id)),
  price: p.basePrice,
  salePrice: p.salePrice ?? null,
  thumbnail: p.thumbnail?.url || '',
  gallery: (p.gallery || []).map((g) => g.url),
  downloadFiles: p.downloadFiles || [],
  sku: p.sku || '',
  stock: p.stock ?? 0,
  lowStockThreshold: p.lowStockThreshold ?? 10,
  status: p.status,
  downloads: p.salesCount || 0,
  rating: p.ratingAverage ?? 0,
  reviewCount: p.ratingCount ?? 0,
  createdAt: p.createdAt,
});

/** Flat form shape → the real backend's writable Product fields. Fields the backend doesn't model yet (variations, licensing editor, shipping-profile editor extras, barcode, live demo URL, changelog, etc.) are intentionally dropped here, not sent. */
const mapToBackend = (form) => {
  const payload = {
    title: form.title,
    shortDescription: form.shortDescription || undefined,
    description: form.description || undefined,
    category: form.categoryId || undefined,
    tags: (form.tags || []).filter(Boolean),
    basePrice: Number(form.price) || 0,
    salePrice: form.salePrice ? Number(form.salePrice) : null,
    sku: form.sku || undefined,
    stock: Number(form.stock || 0),
    lowStockThreshold: Number(form.lowStockThreshold || 10),
    status: form.status,
    seoTitle: form.seoTitle || undefined,
    seoDescription: form.seoDescription || undefined,
  };
  Object.keys(payload).forEach((key) => payload[key] === undefined && delete payload[key]);
  return payload;
};

/** Paginated, filterable, searchable — mirrors the params the real /products/mine endpoint accepts (page, limit, sort, q, status, category). Returns { products, meta } instead of a bare array (upgrade from the old mock signature — see SellerProductsTab.jsx). */
export const getSellerProducts = async (params = {}) => {
  const { products, meta } = await listMyProducts(params);
  return { products: products.map(mapToForm), meta };
};

export const getSellerProduct = (id) => getProduct(id).then(mapToForm);

export const createSellerProduct = (form) => createProductRequest(mapToBackend(form)).then(mapToForm);

export const updateSellerProduct = (id, form) => updateProductRequest(id, mapToBackend(form)).then(mapToForm);

export const deleteSellerProduct = (id) => deleteProductRequest(id);
