import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import Seo from '../../components/Seo';
import PageHeader from '../../admin/components/PageHeader';
import ImageUploadInput from '../../admin/components/ImageUploadInput';
import FileUploadInput, { FileVideo, FileArchive } from '../../admin/components/FileUploadInput';
import TagsInput from '../../admin/components/TagsInput';
import RichTextEditorPlaceholder from '../../components/blog/RichTextEditorPlaceholder';
import FaqRepeater from '../../admin/components/FaqRepeater';
import { inputClass, textareaClass } from '../../admin/components/FormSheet';
import FormTabs from '../../admin/components/product-editor/FormTabs';
import LicensingEditor from '../../admin/components/product-editor/LicensingEditor';
import VariationsEditor from '../../admin/components/product-editor/VariationsEditor';
import ShippingSection from '../../admin/components/product-editor/ShippingSection';
import { EMPTY_EXTENDED_PRODUCT, DEFAULT_COMMISSION_RATE, CURRENCIES, TAX_CLASSES } from '../../admin/components/product-editor/productSchema';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../../components/ui/select';
import { Checkbox } from '../../components/ui/checkbox';
import { getStorefrontCategories } from '../../services/categoryRepository';
import { useCatalogVersion } from '../../hooks/useCatalogVersion';
import { getSellerProduct, createSellerProduct, updateSellerProduct } from './api/sellerProducts';
import { slugify } from '../../data';
import { useToast } from '../../hooks/use-toast';

const TABS = ['Basic Info', 'Pricing', 'Digital Files', 'Licensing', 'Shipping', 'Inventory', 'SEO', 'Options'];

const EMPTY = {
  title: '', shortDescription: '', description: '', whatsIncluded: '', faq: [],
  category: '', categoryId: '', tags: [],
  price: '', salePrice: '',
  thumbnail: '', gallery: [], downloadFiles: [], previewImages: [], previewVideo: null,
  seoTitle: '', seoDescription: '', seoKeywords: [],
  sku: '', stock: '', lowStockThreshold: '10',
  status: 'draft',
  ...EMPTY_EXTENDED_PRODUCT,
};

const NewProductPage = () => {
  const { id } = useParams();
  const isEdit = Boolean(id);
  const navigate = useNavigate();
  const { toast } = useToast();

  const [form, setForm] = useState(EMPTY);
  const [tab, setTab] = useState(TABS[0]);
  const [loading, setLoading] = useState(isEdit);
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState({});

  const catalogVersion = useCatalogVersion();
  const categories = useMemo(() => getStorefrontCategories(), [catalogVersion]);

  useEffect(() => {
    if (!isEdit) return;
    getSellerProduct(id).then((p) => {
      if (p) {
        setForm({
          ...EMPTY, ...p,
          price: String(p.price ?? ''),
          salePrice: p.salePrice != null ? String(p.salePrice) : '',
          tags: p.tags || [],
          faq: Array.isArray(p.faq) ? p.faq : [],
          seoKeywords: p.seoKeywords || [],
          licenses: p.licenses || EMPTY_EXTENDED_PRODUCT.licenses,
          shipping: p.shipping || EMPTY_EXTENDED_PRODUCT.shipping,
          variations: p.variations || EMPTY_EXTENDED_PRODUCT.variations,
        });
      }
      setLoading(false);
    });
  }, [id, isEdit]);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e?.target ? e.target.value : e }));

  const setCategory = (categoryId) => {
    const found = categories.find((c) => c.id === categoryId);
    setForm((f) => ({ ...f, categoryId, category: found?.name || f.category }));
  };

  const validate = () => {
    const errs = {};
    if (!form.title.trim()) errs.title = 'Title is required';
    if (!form.categoryId) errs.categoryId = 'Select a category';
    if (!form.price || Number(form.price) <= 0) errs.price = 'Enter a valid price';
    if (form.salePrice && Number(form.salePrice) >= Number(form.price)) errs.salePrice = 'Sale price must be lower than regular price';
    if (!form.thumbnail) errs.thumbnail = 'Add a thumbnail image';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const buildPayload = (overrides = {}) => ({
    ...form,
    slug: slugify(form.title),
    price: Number(form.price),
    salePrice: form.salePrice ? Number(form.salePrice) : null,
    stock: Number(form.stock || 0),
    lowStockThreshold: Number(form.lowStockThreshold || 10),
    faq: form.faq.filter((item) => item.question && item.question.trim()),
    ...overrides,
  });

  const persist = async (payload, successMsg) => {
    setSaving(true);
    try {
      if (isEdit) await updateSellerProduct(id, payload);
      else await createSellerProduct(payload);
      toast({ title: successMsg, description: form.title || 'Your product' });
      navigate('/seller/products');
    } catch (err) {
      toast({ title: 'Something went wrong', description: err.message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleSaveDraft = async () => {
    if (!form.title.trim()) {
      setErrors({ title: 'Title is required' });
      return;
    }
    await persist(buildPayload({ status: 'draft' }), 'Saved as draft');
  };

  const handlePublish = async () => {
    if (!validate()) return;
    await persist(buildPayload({ status: 'published' }), 'Product published');
  };

  const handlePreview = () => {
    if (!isEdit) {
      toast({ title: 'Save as draft first', description: 'Preview is available once your product has been saved.' });
      return;
    }
    window.open(`/product/${form.slug || id}`, '_blank', 'noopener,noreferrer');
  };

  const effectivePrice = form.salePrice ? Number(form.salePrice) : Number(form.price || 0);
  const commissionAmount = Math.round(effectivePrice * DEFAULT_COMMISSION_RATE * 100) / 100;
  const sellerNet = Math.round((effectivePrice - commissionAmount) * 100) / 100;

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="flex-1 mx-auto max-w-[90rem] w-full px-5 lg:px-8 pt-10 pb-20">
          <p className="text-sm text-muted-foreground">Loading…</p>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Seo title={isEdit ? 'Edit Product' : 'New Product'} description="Create or edit a product listing on your PicaMarts store." noIndex />
      <Header />

      <div className="flex-1 mx-auto max-w-[90rem] w-full px-5 lg:px-8 pt-10 pb-20">
        <PageHeader
          title={isEdit ? 'Edit Product' : 'New Product'}
          description={isEdit ? 'Update your listing details below.' : 'List a new digital product on your store.'}
          backTo="/seller/products"
          backLabel="Products"
        />

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-3xl border border-border soft-shadow p-6">
              <FormTabs tabs={TABS} active={tab} onChange={setTab} />

              {tab === 'Basic Info' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Product Title</label>
                    <input value={form.title} onChange={set('title')} className={inputClass} placeholder="e.g. Boho Arch Wall Art Set" />
                    {errors.title && <p className="text-xs text-red-600 mt-1">{errors.title}</p>}
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Short Description</label>
                    <input value={form.shortDescription} onChange={set('shortDescription')} className={inputClass} placeholder="A one-line summary shown in listings" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Full Description</label>
                    <RichTextEditorPlaceholder value={form.description} onChange={(v) => setForm((f) => ({ ...f, description: v }))} placeholder="Describe this product in detail…" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">What's Included</label>
                    <RichTextEditorPlaceholder value={form.whatsIncluded} onChange={(v) => setForm((f) => ({ ...f, whatsIncluded: v }))} placeholder="List everything the buyer receives…" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">FAQ</label>
                    <FaqRepeater value={form.faq} onChange={(v) => setForm((f) => ({ ...f, faq: v }))} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Category</label>
                    <Select value={form.categoryId} onValueChange={setCategory}>
                      <SelectTrigger className="rounded-xl"><SelectValue placeholder="Select category" /></SelectTrigger>
                      <SelectContent>
                        {categories.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                    {errors.categoryId && <p className="text-xs text-red-600 mt-1">{errors.categoryId}</p>}
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Tags</label>
                    <TagsInput value={form.tags} onChange={(v) => setForm((f) => ({ ...f, tags: v }))} placeholder="e.g. printable, wall-art…" />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <label className="flex items-center gap-2 text-sm cursor-pointer">
                      <Checkbox checked={form.trending} onCheckedChange={(v) => setForm((f) => ({ ...f, trending: !!v }))} /> Trending
                    </label>
                    <label className="flex items-center gap-2 text-sm cursor-pointer">
                      <Checkbox checked={form.bestSeller} onCheckedChange={(v) => setForm((f) => ({ ...f, bestSeller: !!v }))} /> Best Seller
                    </label>
                    <label className="flex items-center gap-2 text-sm cursor-pointer">
                      <Checkbox checked={form.newArrival} onCheckedChange={(v) => setForm((f) => ({ ...f, newArrival: !!v }))} /> New Arrival
                    </label>
                  </div>
                </div>
              )}

              {tab === 'Pricing' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1.5">Regular Price ($)</label>
                      <input type="number" step="0.01" min="0" value={form.price} onChange={set('price')} className={inputClass} />
                      {errors.price && <p className="text-xs text-red-600 mt-1">{errors.price}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1.5">Sale Price ($)</label>
                      <input type="number" step="0.01" min="0" value={form.salePrice} onChange={set('salePrice')} className={inputClass} placeholder="Optional" />
                      {errors.salePrice && <p className="text-xs text-red-600 mt-1">{errors.salePrice}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1.5">Discount (%)</label>
                      <input type="number" step="1" min="0" max="100" value={form.discountPercent} onChange={set('discountPercent')} className={inputClass} placeholder="Optional" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1.5">Tax Class</label>
                      <Select value={form.taxClass} onValueChange={set('taxClass')}>
                        <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {TAX_CLASSES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1.5">Currency</label>
                      <Select value={form.currency} onValueChange={set('currency')}>
                        <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {CURRENCIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="rounded-xl border border-dashed border-primary/40 bg-primary/[0.03] p-4">
                    <h4 className="text-sm font-semibold mb-2">Commission Preview</h4>
                    <div className="flex items-center justify-between text-sm"><span className="text-muted-foreground">Sale price</span><span className="font-semibold">${effectivePrice.toFixed(2)}</span></div>
                    <div className="flex items-center justify-between text-sm mt-1"><span className="text-muted-foreground">Platform commission ({(DEFAULT_COMMISSION_RATE * 100).toFixed(0)}%)</span><span className="font-semibold text-destructive">-${commissionAmount.toFixed(2)}</span></div>
                    <div className="flex items-center justify-between text-sm mt-1 pt-1 border-t border-border"><span className="font-semibold">You earn</span><span className="font-bold">${sellerNet.toFixed(2)}</span></div>
                    <p className="text-xs text-muted-foreground mt-2">Preview only — Picamarts' commission rate is set by the platform.</p>
                  </div>
                </div>
              )}

              {tab === 'Digital Files' && (
                <div className="space-y-4">
                  <p className="text-xs text-muted-foreground bg-secondary/60 rounded-xl px-3 py-2">
                    Image and file uploads are shown as a local preview for now — they aren't saved to your live store yet. That's coming in the next update.
                  </p>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Thumbnail</label>
                    <ImageUploadInput value={form.thumbnail} onChange={(v) => setForm((f) => ({ ...f, thumbnail: v }))} />
                    {errors.thumbnail && <p className="text-xs text-red-600 mt-1">{errors.thumbnail}</p>}
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Gallery Images</label>
                    <ImageUploadInput value={form.gallery} onChange={(v) => setForm((f) => ({ ...f, gallery: v }))} multiple />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Preview Images</label>
                    <ImageUploadInput value={form.previewImages} onChange={(v) => setForm((f) => ({ ...f, previewImages: v }))} multiple />
                  </div>
                  <FileUploadInput
                    label="Preview Video (optional)"
                    icon={FileVideo}
                    accept="video/*"
                    value={form.previewVideo}
                    onChange={(v) => setForm((f) => ({ ...f, previewVideo: v }))}
                    hint="A short clip showing the product in use."
                  />
                  <FileUploadInput
                    label="Digital Download Files"
                    icon={FileArchive}
                    accept=".zip,application/zip"
                    multiple
                    value={form.downloadFiles}
                    onChange={(v) => setForm((f) => ({ ...f, downloadFiles: v }))}
                    hint="The actual files a buyer receives after purchase."
                  />
                  <FileUploadInput
                    label="Additional Download Files"
                    icon={FileArchive}
                    multiple
                    value={form.additionalFiles}
                    onChange={(v) => setForm((f) => ({ ...f, additionalFiles: v }))}
                    hint="Bonus files or alternate formats bundled with the main download."
                  />
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Live Demo URL</label>
                    <input value={form.liveDemoUrl} onChange={set('liveDemoUrl')} className={inputClass} placeholder="https://…" />
                  </div>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1.5">Version Number</label>
                      <input value={form.version} onChange={set('version')} className={inputClass} placeholder="1.0.0" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1.5">File Size</label>
                      <input value={form.fileSize} onChange={set('fileSize')} className={inputClass} placeholder="e.g. 42 MB" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Changelog</label>
                    <textarea value={form.changelog} onChange={set('changelog')} className={`${textareaClass} min-h-[70px]`} placeholder="What changed in this version…" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Supported Software</label>
                    <TagsInput value={form.supportedSoftware} onChange={(v) => setForm((f) => ({ ...f, supportedSoftware: v }))} placeholder="e.g. photoshop, canva…" />
                  </div>
                </div>
              )}

              {tab === 'Licensing' && (
                <LicensingEditor value={form.licenses} onChange={(v) => setForm((f) => ({ ...f, licenses: v }))} />
              )}

              {tab === 'Shipping' && (
                <ShippingSection value={form.shipping} onChange={(v) => setForm((f) => ({ ...f, shipping: v }))} />
              )}

              {tab === 'Inventory' && (
                <div className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1.5">SKU</label>
                      <input value={form.sku} onChange={set('sku')} className={inputClass} placeholder="e.g. PM-WA-001" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1.5">Barcode</label>
                      <input value={form.barcode} onChange={set('barcode')} className={inputClass} placeholder="Optional" />
                    </div>
                  </div>
                  <label className="flex items-center gap-2.5 cursor-pointer">
                    <Checkbox checked={form.unlimitedStock} onCheckedChange={(v) => setForm((f) => ({ ...f, unlimitedStock: !!v }))} />
                    <span className="text-sm font-semibold">Unlimited Stock</span>
                  </label>
                  {!form.unlimitedStock && (
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-1.5">Stock Quantity</label>
                        <input type="number" min="0" value={form.stock} onChange={set('stock')} className={inputClass} />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1.5">Low Stock Alert At</label>
                        <input type="number" min="0" value={form.lowStockThreshold} onChange={set('lowStockThreshold')} className={inputClass} />
                      </div>
                    </div>
                  )}
                </div>
              )}

              {tab === 'SEO' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1.5">SEO Title</label>
                    <input value={form.seoTitle} onChange={set('seoTitle')} className={inputClass} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">SEO Description</label>
                    <textarea value={form.seoDescription} onChange={set('seoDescription')} className={textareaClass} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">SEO Keywords</label>
                    <TagsInput value={form.seoKeywords} onChange={(v) => setForm((f) => ({ ...f, seoKeywords: v }))} placeholder="e.g. wall art, boho decor…" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Open Graph Image</label>
                    <ImageUploadInput value={form.ogImage} onChange={(v) => setForm((f) => ({ ...f, ogImage: v }))} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Canonical URL</label>
                    <input value={form.canonicalUrl} onChange={set('canonicalUrl')} className={inputClass} placeholder="https://picamarts.com/product/…" />
                  </div>
                </div>
              )}

              {tab === 'Options' && (
                <VariationsEditor value={form.variations} onChange={(v) => setForm((f) => ({ ...f, variations: v }))} />
              )}
            </div>
          </div>

          {/* Publishing */}
          <div className="space-y-6">
            <div className="bg-white rounded-3xl border border-border soft-shadow p-6 space-y-3 lg:sticky lg:top-[7rem]">
              <h3 className="font-bold mb-1">Publishing</h3>
              <p className="text-xs text-muted-foreground mb-3">
                {isEdit ? `Current status: ${form.status}` : 'Save a draft, preview, or submit for review.'}
              </p>
              <button
                type="button"
                onClick={handlePublish}
                disabled={saving}
                className="w-full px-5 py-3 rounded-full brand-gradient text-white text-sm font-semibold soft-shadow disabled:opacity-60"
              >
                {saving ? 'Saving…' : 'Publish'}
              </button>
              <button
                type="button"
                onClick={handleSaveDraft}
                disabled={saving}
                className="w-full px-5 py-3 rounded-full border border-border text-sm font-semibold hover:bg-secondary transition-colors disabled:opacity-60"
              >
                Save Draft
              </button>
              <button
                type="button"
                onClick={handlePreview}
                className="w-full px-5 py-3 rounded-full border border-border text-sm font-semibold hover:bg-secondary transition-colors"
              >
                Preview
              </button>
              <button
                type="button"
                onClick={() => navigate('/seller/products')}
                className="w-full px-5 py-2.5 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default NewProductPage;
