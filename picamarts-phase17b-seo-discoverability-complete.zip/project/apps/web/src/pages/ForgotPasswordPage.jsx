import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Mail } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import Seo from '../components/Seo';
import { forgotPasswordRequest } from '../services/authService';

/**
 * Shared "forgot password" page for every account type (buyer, seller,
 * admin) — the backend has one User model and one /auth/forgot-password
 * endpoint regardless of role, so one page covers all three login flows.
 * Always shows a generic success message, matching the backend's
 * deliberate non-enumeration behavior (it never reveals whether an email
 * exists).
 */
const ForgotPasswordPage = () => {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email.trim()) {
      setError('Please enter your email address.');
      return;
    }
    setError('');
    setSubmitting(true);
    try {
      await forgotPasswordRequest(email.trim());
      setSent(true);
    } catch (err) {
      setError(err?.message || 'Something went wrong. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Seo title="Reset Your Password" description="Request a password reset link for your PicaMarts account." noIndex />
      <Header />
      <div className="flex-1 grid place-items-center px-5 py-16">
        <div className="w-full max-w-md">
          <div className="bg-white rounded-3xl border border-border soft-shadow p-8">
            <h1 className="text-2xl font-black tracking-tight text-center">Forgot your password?</h1>
            <p className="text-sm text-muted-foreground text-center mt-2">
              Enter the email on your account and we'll send you a link to reset it.
            </p>

            {sent ? (
              <div className="mt-8 text-sm text-center bg-secondary/60 rounded-2xl p-5">
                If an account exists for <span className="font-semibold">{email.trim()}</span>, a password reset
                link is on its way. Check your inbox (and spam folder).
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="mt-8 space-y-4" noValidate>
                <div>
                  <label htmlFor="email" className="text-sm font-medium block mb-1.5">Email</label>
                  <div className="flex items-center gap-2 bg-secondary/60 rounded-2xl px-4 py-3 border border-transparent focus-within:border-primary transition-colors">
                    <Mail className="w-4 h-4 text-muted-foreground shrink-0" />
                    <input id="email" type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" className="bg-transparent outline-none text-sm w-full" />
                  </div>
                </div>

                {error && <p className="text-sm text-destructive" role="alert">{error}</p>}

                <button type="submit" disabled={submitting} className="w-full px-6 py-3.5 rounded-full brand-gradient text-white font-semibold soft-shadow hover:soft-shadow-lg transition-shadow disabled:opacity-60 disabled:cursor-not-allowed">
                  {submitting ? 'Sending…' : 'Send reset link'}
                </button>
              </form>
            )}

            <p className="text-sm text-center text-muted-foreground mt-6">
              Remembered it? <Link to="/login" className="font-semibold text-primary hover:underline">Back to sign in</Link>
            </p>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default ForgotPasswordPage;
