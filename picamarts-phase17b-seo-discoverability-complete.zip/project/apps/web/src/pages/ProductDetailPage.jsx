import React, { useMemo, useState, useEffect } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import {
  Heart, Star, Download, Facebook, Twitter, Link2, Check, X as XIcon, MessageCircle, Flag, Scale,
  Package, Truck, ShieldCheck, Users, UserPlus, UserCheck, FileText, AlertTriangle, ExternalLink,
} from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ProductCard from '../components/ProductCard';
import Seo from '../components/Seo';
import Breadcrumbs from '../components/Breadcrumbs';
import { ProductDetailSkeleton } from '../components/Skeletons';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../components/ui/tabs';
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from '../components/ui/accordion';
import RecentlyViewedSection from '../components/RecentlyViewedSection';
import FrequentlyBoughtTogether from '../components/FrequentlyBoughtTogether';
import ReportModal from '../components/ReportModal';
import { sampleReviews, artists, artistProducts, licenseCatalog, slugify } from '../data';
import { useStore } from '../context/StoreContext';
import { useToast } from '../hooks/use-toast';
import { productsApi } from '../services/api';
import { recommendationService } from '../services/recommendationService';
import { useFetch } from '../hooks/useFetch';
import { trackProductView, getRecentCategories } from '../services/recentlyViewed';
import { isFollowingSeller, toggleFollowSeller } from '../services/buyerDashboard';
import { SITE } from '../constants';

const RatingStars = ({ value, size = 'w-4 h-4' }) => (
  <div className="flex items-center gap-0.5" aria-label={`Rated ${value} out of 5`}>
    {[1, 2, 3, 4, 5].map((n) => (
      <Star key={n} className={`${size} ${n <= Math.round(value ?? 0) ? 'fill-amber-400 text-amber-400' : 'text-border'}`} />
    ))}
  </div>
);

/**
 * normaliseProduct maps any product shape (legacy mock OR admin/seller
 * -created via the upgraded Product Editor) to a guaranteed-safe object.
 * Every field accessed in render is filled with a safe fallback (null/[]
 * /false) rather than fabricated text, so the page can show/hide rows
 * based on what the product actually has instead of hardcoding content.
 */
function normaliseProduct(p) {
  if (!p) return null;

  const thumbnail = p.thumbnail || p.img || '';

  // Build images array: prefer images[], then gallery[], then thumbnail
  let images = [];
  if (Array.isArray(p.images) && p.images.length > 0) images = p.images;
  else if (Array.isArray(p.gallery) && p.gallery.length > 0) images = p.gallery;
  if (images.length === 0 && thumbnail) images = [thumbnail];
  if (images.length === 0) images = [''];

  // Artist / seller
  const artistName = p.artist || p.brandName || p.brand || 'PicaMarts Marketplace';
  const knownArtist = artists.find((a) => a.name === artistName);
  const artistSlug = knownArtist?.slug || slugify(artistName);

  return {
    id: p.id,
    title: p.title || 'Untitled Product',
    slug: p.slug || slugify(p.title || String(p.id)),
    cat: p.cat || p.categoryId || 'Others',
    description: p.description || 'No description available.',
    shortDescription: p.shortDescription || null,
    img: thumbnail || images[0] || '',
    images,
    price: p.price ?? 0,
    old: p.old ?? null,
    rating: p.rating ?? 4.5,
    reviewCount: p.reviewCount ?? 0,
    downloads: p.downloads ?? 0,
    views: p.views ?? null,
    artist: artistName,
    artistSlug,
    knownArtist: knownArtist || null,
    whatsIncluded: typeof p.whatsIncluded === 'string' ? p.whatsIncluded : '',
    fileTypes: Array.isArray(p.fileTypes) ? p.fileTypes : [],
    dimensions: p.dimensions || null,
    resolution: p.resolution || null,
    orientation: p.orientation || null,
    colorSpace: p.colorSpace || null,
    requirements: p.requirements || null,
    version: p.version || null,
    changelog: p.changelog || null,
    fileSize: p.fileSize || null,
    supportedSoftware: Array.isArray(p.supportedSoftware) ? p.supportedSoftware : [],
    compatibleVersions: Array.isArray(p.compatibleVersions) ? p.compatibleVersions : [],
    liveDemoUrl: p.liveDemoUrl || null,
    documentationPdf: p.documentationPdf || null,
    zipFile: p.zipFile || null,
    downloadFiles: Array.isArray(p.downloadFiles) ? p.downloadFiles : [],
    additionalFiles: Array.isArray(p.additionalFiles) ? p.additionalFiles : [],
    faqs: Array.isArray(p.faqs) ? p.faqs : [],
    badge: p.badge || null,
    featured: !!p.featured,
    tags: Array.isArray(p.tags) ? p.tags : [],
    updatedAt: p.updatedAt || p.createdAt || null,

    // Licensing — new multi-license schema (Section 4 of the product editor)
    licenses: Array.isArray(p.licenses) ? p.licenses.filter((l) => l && l.enabled) : [],
    licenseIds: Array.isArray(p.licenseIds) ? p.licenseIds : [],

    // Shipping — productType is stored inside the shipping object by the
    // Product Editor, but mapAdminToStorefront also surfaces it at the top
    // level for convenience. Read both so we never miss a physical product.
    productType: p.productType || p.shipping?.productType || 'digital',
    // Preserve the full shipping object regardless of productType so
    // isPhysicalItem() / getItemShippingInfo() always have their data.
    shipping: p.shipping && typeof p.shipping === 'object' ? p.shipping : null,

    // Inventory
    sku: p.sku || null,
    unlimitedStock: p.unlimitedStock ?? null,
    stock: p.stock ?? null,
    lowStockThreshold: p.lowStockThreshold ?? null,
    barcode: p.barcode || null,

    // SEO (read-only here — used for meta tags, not displayed as content)
    seoTitle: p.seoTitle || null,
    metaDescription: p.metaDescription || null,
    keywords: Array.isArray(p.keywords) ? p.keywords : [],
  };
}

const ProductDetailPage = () => {
  const { id } = useParams();
  const { toast } = useToast();
  const navigate = useNavigate();
  const { addToCart, toggleWishlist, inWishlist, toggleCompare, inCompare, compareList, MAX_COMPARE, user } = useStore();

  const { data: rawProduct, loading } = useFetch(() => productsApi.get(id), [id]);

  const product = useMemo(() => normaliseProduct(rawProduct), [rawProduct]);

  // Effective licenses: prefer the new multi-license schema; fall back to
  // the legacy licenseCatalog lookup so older mock products keep working.
  const effectiveLicenses = useMemo(() => {
    if (!product) return [];
    if (product.licenses.length > 0) {
      return product.licenses.map((l) => ({
        id: l.id,
        name: l.name,
        price: Number(l.price) || product.price,
        description: l.description || '',
        commercialRights: !!l.commercialRights,
      }));
    }
    if (product.licenseIds.length > 0) {
      return product.licenseIds
        .map((id) => licenseCatalog[id])
        .filter(Boolean)
        .map((l) => ({
          id: l.id,
          name: l.name,
          price: Math.round(product.price * l.priceMultiplier * 100) / 100,
          description: l.description || '',
          commercialRights: l.id !== 'personal',
        }));
    }
    return [];
  }, [product]);

  const [selectedLicenseId, setSelectedLicenseId] = useState(null);
  useEffect(() => {
    setSelectedLicenseId(effectiveLicenses[0]?.id || null);
  }, [product?.id, effectiveLicenses.length]);

  const selectedLicense = effectiveLicenses.find((l) => l.id === selectedLicenseId) || effectiveLicenses[0] || null;
  const displayPrice = selectedLicense ? selectedLicense.price : (product?.price ?? 0);

  const [activeImage, setActiveImage] = useState(0);
  const [lightboxOpen, setLightboxOpen] = useState(false);

  useEffect(() => {
    setActiveImage(0);
  }, [product?.id]);

  // IMPORTANT: this hook must run on every render, in the same position,
  // regardless of loading/not-found state below — React requires hooks to
  // be called unconditionally. Guard the fetcher body instead of skipping
  // the hook call itself (previously this was declared after the early
  // `return`s for loading/not-found, which changed the hook count between
  // renders and crashed the page with "Rendered more hooks than during the
  // previous render").
  // Phase 17A.2, Part 1 — Recommendation Engine. Real backend-ranked
  // results (same category/tags, rating+sales ordered) replace the old
  // client-side `productsApi.related` category match.
  const { data: related = [] } = useFetch(
    () => (product ? recommendationService.getRelated(product.id, 4) : Promise.resolve([])),
    [product?.id]
  );

  // Real co-purchase and co-view signals — falls back to the old
  // client-side `productsApi.related` result only if the request fails
  // (e.g. offline), so the bundle widget never goes empty on error.
  const { data: frequentlyBoughtTogether = [] } = useFetch(
    () => (product
      ? recommendationService.getFrequentlyBoughtTogether(product.id, 3).then((items) => (items.length ? items : productsApi.related(product, 3)))
      : Promise.resolve([])),
    [product?.id]
  );

  const { data: alsoViewed = [] } = useFetch(
    () => (product ? recommendationService.getAlsoViewed(product.id, 6) : Promise.resolve([])),
    [product?.id]
  );

  // Personalized for a signed-in buyer (purchase history + wishlist +
  // recently-viewed categories); a signed-out visitor gets the
  // platform-wide trending feed instead, since /recommendations/personalized
  // requires auth. Old category-weighted `productsApi.recommended` kept
  // only as a same-shape fallback on request failure.
  const { data: recommended = [] } = useFetch(
    () => {
      if (!product) return Promise.resolve([]);
      const fetcher = user ? recommendationService.getPersonalized(6) : recommendationService.getTrending(6);
      return fetcher.catch(() => productsApi.recommended(getRecentCategories(), product.id, 6));
    },
    [product?.id, user?.id]
  );

  const [reportOpen, setReportOpen] = useState(false);
  const [following, setFollowing] = useState(false);

  useEffect(() => {
    if (product?.artistSlug) setFollowing(isFollowingSeller(product.artistSlug));
  }, [product?.artistSlug]);

  useEffect(() => {
    if (product) trackProductView(product);
  }, [product?.id]);

  if (loading) {
    return (
      <div className="min-h-screen">
        <Header />
        <main id="main-content" className="mx-auto max-w-[90rem] px-5 lg:px-8 pt-8 pb-24">
          <ProductDetailSkeleton />
        </main>
        <Footer />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="flex-1 grid place-items-center px-5 py-24 text-center">
          <div>
            <h1 className="text-2xl font-bold mb-2">Product not found</h1>
            <p className="text-muted-foreground mb-6">This item may have been removed or the link is incorrect.</p>
            <Link to="/shop" className="inline-flex items-center justify-center px-6 py-3 rounded-full brand-gradient text-white font-semibold">Back to Shop</Link>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  const wishlisted = inWishlist(product.id);
  const compared = inCompare(product.id);

  const handleToggleCompare = () => {
    if (!compared && compareList.length >= MAX_COMPARE) {
      toast({ title: 'Compare list is full', description: `You can compare up to ${MAX_COMPARE} products at a time.` });
      return;
    }
    toggleCompare(product);
    toast({ title: compared ? 'Removed from compare' : 'Added to compare', description: product.title });
  };

  // NOTE: the real backend cart has no per-line license concept (see
  // apps/api/src/models/Cart.js) — it always prices a cart line at the
  // product's own basePrice/salePrice. The license selector above still
  // shows real license terms/pricing for the buyer's information, but
  // Add to Cart / Buy Now always add the product at its base price
  // regardless of which license is selected. Flagged as a known gap
  // until the backend grows a per-line license field.
  const handleAddToCart = async () => {
    try {
      await addToCart(product, 1);
      toast({ title: 'Added to cart', description: product.title });
    } catch (err) {
      if (err?.requiresAuth) {
        toast({ title: 'Please log in', description: 'Log in to add items to your cart.' });
        navigate('/login');
      } else {
        toast({ title: 'Could not add to cart', description: err?.message || 'Please try again.', variant: 'destructive' });
      }
    }
  };

  const handleToggleWishlist = async () => {
    try {
      await toggleWishlist(product);
    } catch (err) {
      if (err?.requiresAuth) {
        toast({ title: 'Please log in', description: 'Log in to save items to your wishlist.' });
        navigate('/login');
      } else {
        toast({ title: 'Could not update wishlist', description: err?.message || 'Please try again.', variant: 'destructive' });
      }
    }
  };

  const handleBuyNow = async () => {
    await handleAddToCart();
    navigate('/cart');
  };

  const handleToggleFollow = () => {
    const sellerRef = product.knownArtist || { slug: product.artistSlug, name: product.artist, initials: product.artist.slice(0, 2).toUpperCase(), specialty: product.cat, sales: '0' };
    toggleFollowSeller(sellerRef);
    setFollowing((prev) => !prev);
    toast({ title: following ? 'Unfollowed' : 'Following', description: product.artist });
  };

  const shareUrl = typeof window !== 'undefined' ? window.location.href : '';
  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      toast({ title: 'Link copied to clipboard' });
    } catch {
      toast({ title: 'Could not copy link', variant: 'destructive' });
    }
  };

  const productJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: product.title,
    image: product.images,
    description: product.description,
    brand: { '@type': 'Brand', name: product.artist },
    aggregateRating: {
      '@type': 'AggregateRating',
      ratingValue: product.rating,
      reviewCount: product.reviewCount,
    },
    offers: {
      '@type': 'Offer',
      url: `${SITE?.url || ''}/product/${product.id}`,
      priceCurrency: 'USD',
      price: displayPrice,
      availability: 'https://schema.org/InStock',
    },
  };

  // Clamp activeImage to valid index range
  const clampedImage = Math.min(activeImage, product.images.length - 1);
  const currentImageSrc = product.images[clampedImage] || product.img || '';

  // Product Information tab: only worth showing if at least one spec is present
  const productInfoRows = [
    ['Version', product.version],
    ['File Size', product.fileSize],
    ['Dimensions', product.dimensions],
    ['Resolution', product.resolution],
    ['Orientation', product.orientation],
    ['Color Space', product.colorSpace],
    ['Compatible Software', product.supportedSoftware.length ? product.supportedSoftware.join(', ') : null],
    ['Requirements', product.requirements],
  ].filter(([, value]) => !!value);

  // Inventory tab: hidden entirely for products with no inventory data at all
  const hasInventoryData = product.sku || product.unlimitedStock != null || product.stock != null;
  const lowStock = !product.unlimitedStock && product.stock != null && product.lowStockThreshold != null && product.stock <= product.lowStockThreshold;
  const outOfStock = !product.unlimitedStock && product.stock != null && product.stock <= 0;

  // Policies tab: license terms come from whichever license is selected
  const hasPolicies = selectedLicense || effectiveLicenses.length > 0;

  return (
    <div className="min-h-screen">
      <Seo
        title={product.seoTitle || product.title}
        description={product.seoDescription || product.description}
        image={product.ogImage || product.img}
        type="product"
        canonical={product.canonicalUrl || undefined}
        noIndex={product.noIndex}
        jsonLd={productJsonLd}
      />
      <Header />

      <main id="main-content" className="mx-auto max-w-[90rem] px-5 lg:px-8 pt-8">
        <Breadcrumbs
          className="mb-6"
          items={[
            { name: 'Shop', to: '/shop' },
            { name: product.cat, to: `/category/${product.catSlug || slugify(product.cat)}` },
            { name: product.title },
          ]}
        />

        <div className="grid lg:grid-cols-2 gap-10 lg:gap-14">
          {/* Gallery */}
          <div className="lg:sticky lg:top-[9.5rem] lg:self-start">
            <button
              type="button"
              onClick={() => setLightboxOpen(true)}
              className="block w-full aspect-square rounded-3xl overflow-hidden bg-secondary border border-border soft-shadow cursor-zoom-in"
              aria-label="Click to zoom"
            >
              {currentImageSrc ? (
                <img src={currentImageSrc} alt={product.title} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-muted-foreground text-sm">No image</div>
              )}
            </button>

            {product.images.length > 1 && (
              <div className="flex gap-3 mt-4 overflow-x-auto no-scrollbar pb-1 -mx-5 px-5 lg:mx-0 lg:px-0">
                {product.images.map((src, i) => (
                  <button
                    key={(src || '') + i}
                    onClick={() => setActiveImage(i)}
                    className={`w-20 h-20 rounded-2xl overflow-hidden border-2 transition-colors shrink-0 ${activeImage === i ? 'border-primary' : 'border-transparent'}`}
                    aria-label={`View image ${i + 1}`}
                    aria-current={activeImage === i}
                  >
                    {src ? (
                      <img src={src} alt="" loading="lazy" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-secondary" />
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Info */}
          <div>
            <h1 className="text-3xl md:text-4xl font-black tracking-tight leading-tight">{product.title}</h1>

            <div className="flex items-center gap-4 mt-3 text-sm text-muted-foreground flex-wrap">
              <div className="flex items-center gap-1.5">
                <RatingStars value={product.rating} />
                <span className="font-medium text-foreground">{product.rating}</span>
                <span>({product.reviewCount})</span>
              </div>
              <span className="flex items-center gap-1">
                <Download className="w-4 h-4" /> {(product.downloads ?? 0).toLocaleString()} downloads
              </span>
              {product.views != null && (
                <span className="flex items-center gap-1">{product.views.toLocaleString()} views</span>
              )}
            </div>

            {/* Product Overview — every row is read straight from the product object and hidden when empty */}
            <dl className="mt-5 grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-2.5 text-sm rounded-2xl border border-border bg-secondary/20 p-4">
              <div><dt className="text-xs text-muted-foreground">Category</dt><dd className="font-medium">{product.cat}</dd></div>
              <div><dt className="text-xs text-muted-foreground">Seller</dt><dd className="font-medium truncate">{product.artist}</dd></div>
              {product.fileSize && <div><dt className="text-xs text-muted-foreground">File Size</dt><dd className="font-medium">{product.fileSize}</dd></div>}
              {product.supportedSoftware.length > 0 && (
                <div><dt className="text-xs text-muted-foreground">Compatible Software</dt><dd className="font-medium">{product.supportedSoftware.join(', ')}</dd></div>
              )}
            </dl>

            {product.tags.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-4">
                {product.tags.map((t) => (
                  <Link key={t} to={`/search?q=${encodeURIComponent(t)}`} className="text-[11px] font-medium px-2.5 py-1 rounded-full bg-secondary text-secondary-foreground hover:bg-secondary/70 transition-colors">
                    #{t}
                  </Link>
                ))}
              </div>
            )}

            {/* Pricing — a license selector appears only when the product has more than one enabled license */}
            <div className="mt-6">
              {effectiveLicenses.length > 1 ? (
                <div className="space-y-2.5">
                  {effectiveLicenses.map((l) => (
                    <label
                      key={l.id}
                      className={`flex items-center justify-between gap-3 rounded-2xl border p-4 cursor-pointer transition-colors ${selectedLicenseId === l.id ? 'border-primary bg-primary/[0.04]' : 'border-border hover:bg-secondary/40'}`}
                    >
                      <span className="flex items-center gap-3">
                        <input
                          type="radio"
                          name="license"
                          checked={selectedLicenseId === l.id}
                          onChange={() => setSelectedLicenseId(l.id)}
                          className="accent-current"
                        />
                        <span>
                          <span className="block text-sm font-semibold">{l.name}</span>
                          {l.description && <span className="block text-xs text-muted-foreground mt-0.5 max-w-md">{l.description}</span>}
                        </span>
                      </span>
                      <span className="text-lg font-bold shrink-0">${l.price.toFixed(2)}</span>
                    </label>
                  ))}
                </div>
              ) : (
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-bold">${displayPrice.toFixed(2)}</span>
                  {product.old && (
                    <span className="text-lg text-muted-foreground line-through">${product.old}</span>
                  )}
                </div>
              )}
            </div>

            {/* Digital Download info — every line is derived from actual product data */}
            {product.productType !== 'physical' && (() => {
              const items = [
                { show: true, label: 'Instant Digital Download' },
                { show: true, label: 'Lifetime Access' },
                { show: product.zipFile || product.downloadFiles.length > 0, label: 'ZIP File Included' },
                { show: !!(product.version || product.changelog), label: 'Free Updates Included' },
                { show: !!product.documentationPdf, label: 'Documentation Included' },
              ].filter((i) => i.show);
              return items.length > 0 ? (
                <div className="mt-6 rounded-2xl border border-border bg-secondary/40 p-5">
                  <ul className="space-y-2.5 text-sm">
                    {items.map((i) => (
                      <li key={i.label} className="flex items-center gap-2.5 text-foreground/90"><Check className="w-4 h-4 text-primary shrink-0" /> {i.label}</li>
                    ))}
                  </ul>
                </div>
              ) : null;
            })()}

            {/* Shipping — hidden entirely for digital products; shown only when the seller marked this product Physical */}
            {product.shipping && (
              <div className="mt-6 rounded-2xl border border-border p-5">
                <h3 className="flex items-center gap-2 font-bold text-sm mb-3"><Truck className="w-4 h-4 text-primary" /> Shipping</h3>
                <dl className="grid grid-cols-2 gap-3 text-sm">
                  {product.shipping.freeShipping && (
                    <div className="col-span-2"><span className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-700">Free Shipping</span></div>
                  )}
                  {product.shipping.weight && <div><dt className="text-xs text-muted-foreground">Weight</dt><dd className="font-medium">{product.shipping.weight} kg</dd></div>}
                  {(product.shipping.length || product.shipping.width || product.shipping.height) && (
                    <div><dt className="text-xs text-muted-foreground">Dimensions</dt><dd className="font-medium">{[product.shipping.length, product.shipping.width, product.shipping.height].filter(Boolean).join(' × ')} cm</dd></div>
                  )}
                  {product.shipping.shipsFrom && <div><dt className="text-xs text-muted-foreground">Ships From</dt><dd className="font-medium">{product.shipping.shipsFrom}</dd></div>}
                  {product.shipping.processingTime && <div><dt className="text-xs text-muted-foreground">Processing Time</dt><dd className="font-medium">{product.shipping.processingTime}</dd></div>}
                  {product.shipping.estimatedDelivery && <div><dt className="text-xs text-muted-foreground">Estimated Delivery</dt><dd className="font-medium">{product.shipping.estimatedDelivery}</dd></div>}
                  {!product.shipping.freeShipping && product.shipping.shippingCost && (
                    <div><dt className="text-xs text-muted-foreground">Shipping Cost</dt><dd className="font-medium">${Number(product.shipping.shippingCost).toFixed(2)}</dd></div>
                  )}
                  {product.shipping.internationalShipping && <div><dt className="text-xs text-muted-foreground">International</dt><dd className="font-medium">Available</dd></div>}
                  {product.shipping.localPickup && <div><dt className="text-xs text-muted-foreground">Local Pickup</dt><dd className="font-medium">Available</dd></div>}
                </dl>
              </div>
            )}

            {/* Actions */}
            <div className="flex flex-wrap items-center gap-3 mt-7">
              <button
                type="button"
                aria-label={wishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
                aria-pressed={wishlisted}
                onClick={handleToggleWishlist}
                className="w-12 h-12 grid place-items-center rounded-full border border-border hover:bg-secondary transition-colors shrink-0"
              >
                <Heart className={`w-5 h-5 ${wishlisted ? 'fill-accent text-accent' : ''}`} />
              </button>
              <button
                type="button"
                aria-label={compared ? 'Remove from compare' : 'Add to compare'}
                aria-pressed={compared}
                onClick={handleToggleCompare}
                className={`w-12 h-12 grid place-items-center rounded-full border transition-colors shrink-0 ${compared ? 'border-primary text-primary bg-primary/10' : 'border-border hover:bg-secondary'}`}
              >
                <Scale className="w-5 h-5" />
              </button>
              <button onClick={handleAddToCart} className="basis-full sm:basis-0 sm:flex-1 px-6 py-3.5 rounded-full border-2 border-foreground font-semibold hover:bg-foreground hover:text-white transition-colors">
                Add to Cart
              </button>
              <button onClick={handleBuyNow} className="basis-full sm:basis-0 sm:flex-1 px-6 py-3.5 rounded-full brand-gradient text-white font-semibold soft-shadow hover:soft-shadow-lg transition-shadow">
                Buy Now
              </button>
            </div>

            {/* Seller Information */}
            <div className="flex items-center gap-4 mt-6 p-4 rounded-2xl border border-border">
              <Link to={`/seller/${product.artistSlug}`} className="flex items-center gap-3 flex-1 min-w-0 group">
                <span className="w-12 h-12 rounded-full brand-gradient text-white grid place-items-center text-sm font-bold shrink-0">
                  {product.artist.split(' ').filter(Boolean).map((w) => w[0]).slice(0, 2).join('')}
                </span>
                <span className="min-w-0">
                  <span className="text-sm font-semibold block group-hover:text-primary transition-colors truncate">{product.artist}</span>
                  <span className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5 flex-wrap">
                    {product.knownArtist && (
                      <span className="flex items-center gap-1"><Star className="w-3 h-3 fill-amber-400 text-amber-400" /> {product.knownArtist.rating}</span>
                    )}
                    <span className="flex items-center gap-1"><Package className="w-3 h-3" /> {artistProducts(product.artist).length} products</span>
                    {product.knownArtist && (
                      <span className="flex items-center gap-1"><Users className="w-3 h-3" /> {Math.round((parseFloat(product.knownArtist.sales) || 1) * 340).toLocaleString()} followers</span>
                    )}
                  </span>
                </span>
              </Link>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={handleToggleFollow}
                  aria-pressed={following}
                  className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-semibold transition-colors ${following ? 'border border-border hover:bg-secondary' : 'brand-gradient text-white hover:opacity-95'}`}
                >
                  {following ? <UserCheck className="w-3.5 h-3.5" /> : <UserPlus className="w-3.5 h-3.5" />} {following ? 'Following' : 'Follow'}
                </button>
                <Link to={`/seller/${product.artistSlug}`} className="hidden sm:inline text-xs font-semibold px-4 py-2 rounded-full border border-border hover:bg-secondary transition-colors">
                  Visit Store
                </Link>
              </div>
            </div>

            {/* Social share */}
            <div className="flex items-center gap-2 mt-6">
              <a href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`} target="_blank" rel="noopener noreferrer" aria-label="Share on Facebook" className="w-9 h-9 grid place-items-center rounded-full border border-border hover:bg-secondary transition-colors">
                <Facebook className="w-4 h-4" />
              </a>
              <a href={`https://twitter.com/intent/tweet?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(product.title)}`} target="_blank" rel="noopener noreferrer" aria-label="Share on X" className="w-9 h-9 grid place-items-center rounded-full border border-border hover:bg-secondary transition-colors">
                <Twitter className="w-4 h-4" />
              </a>
              <a href={`https://wa.me/?text=${encodeURIComponent(`${product.title} ${shareUrl}`)}`} target="_blank" rel="noopener noreferrer" aria-label="Share on WhatsApp" className="w-9 h-9 grid place-items-center rounded-full border border-border hover:bg-secondary transition-colors">
                <MessageCircle className="w-4 h-4" />
              </a>
              <button onClick={copyLink} aria-label="Copy link" className="w-9 h-9 grid place-items-center rounded-full border border-border hover:bg-secondary transition-colors">
                <Link2 className="w-4 h-4" />
              </button>
              <button onClick={() => setReportOpen(true)} aria-label="Report this product" className="ml-auto w-9 h-9 grid place-items-center rounded-full border border-border hover:bg-destructive/10 hover:text-destructive transition-colors">
                <Flag className="w-4 h-4" />
              </button>
            </div>

            {/* Description tabs (Description / What's Included / FAQ / Reviews) — lives in the right column, below Seller Info & Social Share */}
            <div className="mt-10">
              <Tabs defaultValue="description">
                <TabsList className="bg-secondary/60 rounded-full p-1.5 h-auto flex-wrap gap-1 justify-start">
                  <TabsTrigger value="description" className="rounded-full px-4 py-2 data-[state=active]:brand-gradient data-[state=active]:text-white data-[state=active]:shadow-none">Description</TabsTrigger>
                  <TabsTrigger value="included" className="rounded-full px-4 py-2 data-[state=active]:brand-gradient data-[state=active]:text-white data-[state=active]:shadow-none">What's Included</TabsTrigger>
                  {productInfoRows.length > 0 && (
                    <TabsTrigger value="info" className="rounded-full px-4 py-2 data-[state=active]:brand-gradient data-[state=active]:text-white data-[state=active]:shadow-none">Product Info</TabsTrigger>
                  )}
                  {hasInventoryData && (
                    <TabsTrigger value="inventory" className="rounded-full px-4 py-2 data-[state=active]:brand-gradient data-[state=active]:text-white data-[state=active]:shadow-none">Inventory</TabsTrigger>
                  )}
                  {hasPolicies && (
                    <TabsTrigger value="policies" className="rounded-full px-4 py-2 data-[state=active]:brand-gradient data-[state=active]:text-white data-[state=active]:shadow-none">Policies</TabsTrigger>
                  )}
                  <TabsTrigger value="faq" className="rounded-full px-4 py-2 data-[state=active]:brand-gradient data-[state=active]:text-white data-[state=active]:shadow-none">FAQ</TabsTrigger>
                  <TabsTrigger value="reviews" className="rounded-full px-4 py-2 data-[state=active]:brand-gradient data-[state=active]:text-white data-[state=active]:shadow-none">Reviews ({product.reviewCount})</TabsTrigger>
                </TabsList>

                <TabsContent value="description" className="mt-6 text-sm leading-relaxed text-foreground/80">
                  <p>{product.description}</p>
                </TabsContent>

                <TabsContent value="included" className="mt-6">
                  {product.whatsIncluded.trim() ? (
                    <div className="space-y-3 text-sm leading-relaxed text-foreground/80">
                      {product.whatsIncluded.split('\n\n').filter(Boolean).map((para, i) => (
                        <p key={i}>{para}</p>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">No details available.</p>
                  )}
                  {product.fileTypes.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-4">
                      {product.fileTypes.map((t) => (
                        <span key={t} className="text-xs font-semibold px-3 py-1.5 rounded-full bg-secondary text-secondary-foreground">{t}</span>
                      ))}
                    </div>
                  )}
                  {(product.dimensions || product.version) && (
                    <dl className="mt-6 grid grid-cols-2 gap-4 text-sm">
                      {product.dimensions && <div><dt className="text-muted-foreground">Dimensions</dt><dd className="font-medium">{product.dimensions}</dd></div>}
                      {product.version && <div><dt className="text-muted-foreground">Version</dt><dd className="font-medium">{product.version}</dd></div>}
                    </dl>
                  )}
                </TabsContent>

                {productInfoRows.length > 0 && (
                  <TabsContent value="info" className="mt-6">
                    <dl className="grid sm:grid-cols-2 gap-4 text-sm">
                      {productInfoRows.map(([label, value]) => (
                        <div key={label}><dt className="text-muted-foreground">{label}</dt><dd className="font-medium">{value}</dd></div>
                      ))}
                    </dl>
                  </TabsContent>
                )}

                {hasInventoryData && (
                  <TabsContent value="inventory" className="mt-6">
                    <dl className="grid sm:grid-cols-2 gap-4 text-sm">
                      {product.sku && <div><dt className="text-muted-foreground">SKU</dt><dd className="font-medium">{product.sku}</dd></div>}
                      <div>
                        <dt className="text-muted-foreground">Availability</dt>
                        <dd className="font-medium">
                          {product.unlimitedStock ? 'Unlimited Stock' : outOfStock ? 'Out of Stock' : 'In Stock'}
                        </dd>
                      </div>
                      {!product.unlimitedStock && product.stock != null && (
                        <div><dt className="text-muted-foreground">Stock Status</dt><dd className="font-medium">{product.stock} unit{product.stock === 1 ? '' : 's'} remaining</dd></div>
                      )}
                    </dl>
                    {lowStock && !outOfStock && (
                      <p className="flex items-center gap-1.5 text-xs font-semibold text-amber-600 mt-4">
                        <AlertTriangle className="w-3.5 h-3.5" /> Low stock — only {product.stock} left
                      </p>
                    )}
                    {outOfStock && (
                      <p className="flex items-center gap-1.5 text-xs font-semibold text-destructive mt-4">
                        <AlertTriangle className="w-3.5 h-3.5" /> Currently out of stock
                      </p>
                    )}
                  </TabsContent>
                )}

                {hasPolicies && (
                  <TabsContent value="policies" className="mt-6 space-y-5 text-sm">
                    {selectedLicense && (
                      <div>
                        <h4 className="font-semibold flex items-center gap-1.5 mb-1"><FileText className="w-3.5 h-3.5 text-primary" /> License Terms</h4>
                        <p className="text-foreground/80 leading-relaxed">{selectedLicense.description || `${selectedLicense.name} — terms provided by the seller.`}</p>
                        <p className="text-xs text-muted-foreground mt-1">{selectedLicense.commercialRights ? 'Includes commercial usage rights.' : 'Personal use only — no commercial rights included.'}</p>
                      </div>
                    )}
                    <div>
                      <h4 className="font-semibold mb-1">Refund Policy</h4>
                      <p className="text-foreground/80 leading-relaxed">
                        Digital purchases follow PicaMarts' standard refund policy.{' '}
                        <Link to="/refund-policy" className="text-primary hover:underline inline-flex items-center gap-1">Read the full policy <ExternalLink className="w-3 h-3" /></Link>
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-1">Support Policy</h4>
                      <p className="text-foreground/80 leading-relaxed">
                        Need help with this download? Check the FAQ below or{' '}
                        <Link to="/support" className="text-primary hover:underline inline-flex items-center gap-1">contact support <ExternalLink className="w-3 h-3" /></Link>.
                      </p>
                    </div>
                  </TabsContent>
                )}

                <TabsContent value="faq" className="mt-6">
                  {product.faqs.length > 0 ? (
                    <Accordion type="single" collapsible>
                      {product.faqs.map((faq, i) => (
                        <AccordionItem key={(faq?.question || '') + i} value={`faq-${i}`}>
                          <AccordionTrigger className="text-sm font-medium">{faq?.question}</AccordionTrigger>
                          <AccordionContent className="text-sm text-foreground/80">{faq?.answer}</AccordionContent>
                        </AccordionItem>
                      ))}
                    </Accordion>
                  ) : (
                    <p className="text-sm text-muted-foreground">No FAQs available for this product.</p>
                  )}
                </TabsContent>

                <TabsContent value="reviews" className="mt-6">
                  <div className="flex items-center gap-3 mb-6">
                    <span className="text-3xl font-bold">{product.rating}</span>
                    <div>
                      <RatingStars value={product.rating} />
                      <p className="text-xs text-muted-foreground mt-0.5">Based on {product.reviewCount} reviews</p>
                    </div>
                  </div>
                  {Array.isArray(sampleReviews) && sampleReviews.length > 0 ? (
                    <ul className="space-y-5">
                      {sampleReviews.map((r) => (
                        <li key={(r.name || '') + (r.date || '')} className="pb-5 border-b border-border last:border-0">
                          <div className="flex items-center justify-between mb-1.5">
                            <span className="font-semibold text-sm">{r.name}</span>
                            <RatingStars value={r.rating} size="w-3.5 h-3.5" />
                          </div>
                          <p className="text-sm text-foreground/80">{r.text}</p>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-sm text-muted-foreground">No reviews yet. Be the first to review this product!</p>
                  )}
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>

        {/* Related products */}
        {Array.isArray(related) && related.length > 0 && (
          <div className="mt-20">
            <h2 className="text-2xl font-bold mb-6">Related Products</h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-5">
              {related.map((p) => <ProductCard key={p.id} p={p} />)}
            </div>
          </div>
        )}

        {/* Frequently bought together — real co-purchase signal (Phase 17A.2) */}
        <FrequentlyBoughtTogether product={product} related={frequentlyBoughtTogether} />

        {/* Customers Also Viewed — real co-view signal (Phase 17A.2) */}
        {Array.isArray(alsoViewed) && alsoViewed.length > 0 && (
          <div className="mt-20">
            <h2 className="text-2xl font-bold mb-6">Customers Also Viewed</h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 xl:grid-cols-6 gap-5">
              {alsoViewed.map((p) => <ProductCard key={p.id} p={p} />)}
            </div>
          </div>
        )}

        {/* Recommended for you — personalized (signed in) or trending (Phase 17A.2) */}
        {Array.isArray(recommended) && recommended.length > 0 && (
          <div className="mt-20">
            <h2 className="text-2xl font-bold mb-6">Recommended For You</h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 xl:grid-cols-6 gap-5">
              {recommended.map((p) => <ProductCard key={p.id} p={p} />)}
            </div>
          </div>
        )}

        {/* Recently viewed */}
        <RecentlyViewedSection excludeId={product.id} />
      </main>

      <div className="h-16" />
      <Footer />

      <ReportModal open={reportOpen} onOpenChange={setReportOpen} subjectType="product" subjectName={product.title} />

      {/* Lightbox */}
      {lightboxOpen && currentImageSrc && (
        <div
          className="fixed inset-0 bg-black/90 z-[100] grid place-items-center p-8"
          onClick={() => setLightboxOpen(false)}
          role="dialog"
          aria-modal="true"
          aria-label="Zoomed product image"
        >
          <button
            onClick={() => setLightboxOpen(false)}
            aria-label="Close zoom"
            className="absolute top-6 right-6 w-10 h-10 grid place-items-center rounded-full bg-white text-foreground"
          >
            <XIcon className="w-5 h-5" />
          </button>
          <img
            src={currentImageSrc}
            alt={product.title}
            className="max-w-[90vw] max-h-[85vh] object-contain rounded-2xl"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
};

export default ProductDetailPage;
