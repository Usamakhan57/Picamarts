import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Heart, Loader2 } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import Seo from '../components/Seo';
import EmptyState from '../components/EmptyState';
import { wishlistsService } from '../services/wishlistsService';

const money = (n, currency = 'USD') => new Intl.NumberFormat('en-US', { style: 'currency', currency: currency || 'USD' }).format(n || 0);

/**
 * Phase 17A.2, Part 2 — public, read-only view of a wishlist someone
 * has made public and shared the link to (`GET /wishlists/shared/:token`,
 * no auth). A wrong/expired/unpublished token 404s on the backend —
 * shown here as a friendly "not found" state rather than an error page.
 */
const SharedWishlistPage = () => {
  const { token } = useParams();
  const [wishlist, setWishlist] = useState(null);

  useEffect(() => {
    let cancelled = false;
    wishlistsService.getShared(token)
      .then((wl) => { if (!cancelled) setWishlist(wl); })
      .catch(() => { if (!cancelled) setWishlist(false); });
    return () => { cancelled = true; };
  }, [token]);

  return (
    <div className="min-h-screen">
      <Seo title={wishlist ? `${wishlist.name} — Shared Wishlist` : 'Shared Wishlist'} description="A wishlist shared from PicaMarts." noIndex />
      <Header />
      <div className="mx-auto max-w-[90rem] px-5 lg:px-8 pt-10 pb-24">
        {wishlist === null ? (
          <div className="grid place-items-center py-24"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
        ) : wishlist === false ? (
          <EmptyState title="This wishlist isn't available" message="The link may be expired, or the owner has made this wishlist private again." actionLabel="Browse the Shop" actionTo="/shop" />
        ) : (
          <>
            <span className="grid place-items-center w-14 h-14 rounded-full bg-secondary mb-5"><Heart className="w-6 h-6 text-primary" /></span>
            <h1 className="text-4xl md:text-5xl font-black tracking-tight">{wishlist.name}</h1>
            {wishlist.description && <p className="text-muted-foreground mt-3 max-w-lg">{wishlist.description}</p>}
            <p className="text-sm text-muted-foreground mt-2">{wishlist.itemCount} item{wishlist.itemCount === 1 ? '' : 's'} · Shared wishlist</p>

            {wishlist.items.length === 0 ? (
              <p className="mt-10 text-sm text-muted-foreground">This wishlist is empty right now.</p>
            ) : (
              <div className="mt-8 grid grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-5">
                {wishlist.items.filter((item) => item.product).map((item) => (
                  <Link
                    key={item.id}
                    to={`/product/${item.product.slug || item.product.id}`}
                    className="bg-white rounded-2xl border border-border overflow-hidden hover:soft-shadow transition-shadow group"
                  >
                    <div className="aspect-square bg-secondary overflow-hidden">
                      {item.product.thumbnail?.url && (
                        <img src={item.product.thumbnail.url} alt={item.product.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                      )}
                    </div>
                    <div className="p-3">
                      <p className="text-sm font-semibold line-clamp-2">{item.product.title}</p>
                      <p className="text-sm font-bold mt-1">{money(item.product.salePrice != null ? item.product.salePrice : item.product.basePrice, item.product.currency)}</p>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </>
        )}
      </div>
      <Footer />
    </div>
  );
};

export default SharedWishlistPage;
