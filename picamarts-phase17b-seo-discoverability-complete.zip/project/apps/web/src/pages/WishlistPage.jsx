import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, ArrowRight, Search, Layers } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import Seo from '../components/Seo';
import Breadcrumbs from '../components/Breadcrumbs';
import ProductCard from '../components/ProductCard';
import { useStore } from '../context/StoreContext';
import { useToast } from '../hooks/use-toast';

const WishlistPage = () => {
  const { wishlist, moveWishlistItemToCart } = useStore();
  const { toast } = useToast();
  const [query, setQuery] = useState('');

  const filtered = useMemo(
    () => wishlist.filter((p) => !query || p.title.toLowerCase().includes(query.toLowerCase())),
    [wishlist, query]
  );

  const moveToCart = async (p) => {
    try {
      await moveWishlistItemToCart(p.id);
      toast({ title: 'Moved to cart', description: p.title });
    } catch (err) {
      toast({ title: 'Could not move to cart', description: err?.message || 'Please try again.', variant: 'destructive' });
    }
  };

  return (
    <div className="min-h-screen">
      <Seo title="Your Wishlist" description="Items you've saved for later on PicaMarts." noIndex />
    <Header />
      <div className="mx-auto max-w-[90rem] px-5 lg:px-8 pt-10 pb-24">
        <Breadcrumbs items={[{ name: 'Wishlist' }]} />
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h1 className="text-4xl md:text-5xl font-black tracking-tight">Your <span className="brand-text">Wishlist</span></h1>
            <p className="text-muted-foreground mt-3">{wishlist.length} item{wishlist.length === 1 ? '' : 's'} saved for later.</p>
          </div>
          <Link to="/wishlists" className="inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:opacity-80 transition-opacity">
            <Layers className="w-4 h-4" /> Manage multiple wishlists
          </Link>
        </div>

        {wishlist.length === 0 ? (
          <div className="mt-10 bg-white rounded-3xl border border-border p-16 text-center max-w-lg mx-auto">
            <span className="grid place-items-center w-16 h-16 rounded-full bg-secondary mx-auto mb-5">
              <Heart className="w-7 h-7 text-primary" />
            </span>
            <h2 className="text-lg font-bold">Your wishlist is empty</h2>
            <p className="text-sm text-muted-foreground mt-1.5">Tap the heart icon on any product to save it here for later.</p>
            <Link to="/shop" className="inline-flex items-center gap-1.5 justify-center mt-6 px-6 py-3 rounded-full brand-gradient text-white font-semibold">
              Browse the Shop <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        ) : (
          <>
            <div className="mt-8 flex items-center gap-2 bg-white rounded-full px-4 py-2.5 border border-border max-w-md">
              <Search className="w-4 h-4 text-muted-foreground shrink-0" />
              <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search your wishlist…" aria-label="Search wishlist" className="bg-transparent outline-none text-sm w-full" />
            </div>

            {filtered.length === 0 ? (
              <p className="mt-8 text-sm text-muted-foreground">No wishlist items match "{query}".</p>
            ) : (
              <div className="mt-8 grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
                {filtered.map((p) => (
                  <div key={p.id}>
                    <ProductCard p={p} />
                    <button
                      onClick={() => moveToCart(p)}
                      className="mt-2 w-full text-center text-xs font-semibold px-4 py-2 rounded-full border border-border hover:bg-secondary transition-colors"
                    >
                      Move to Cart
                    </button>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>
      <Footer />
    </div>
  );
};

export default WishlistPage;
