import React, { useEffect, useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import {
  LayoutDashboard, Package, ShoppingCart, Wallet, BarChart3, User, Store, LogOut, Plus,
  Download, MessageSquare, Bell, Truck, Gavel,
} from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import Seo from '../components/Seo';
import { useSellerAuth } from '../context/SellerAuthContext';
import { getMySellerDashboard } from '../services/sellerService';

import SellerOverviewTab from './seller/components/SellerOverviewTab';
import SellerProductsTab from './seller/components/SellerProductsTab';
import SellerOrdersTab from './seller/components/SellerOrdersTab';
import SellerShippingTab from './seller/components/SellerShippingTab';
import SellerDownloadsTab from './seller/components/SellerDownloadsTab';
import SellerEarningsTab from './seller/components/SellerEarningsTab';
import SellerAnalyticsTab from './seller/components/SellerAnalyticsTab';
import SellerReviewsTab from './seller/components/SellerReviewsTab';
import SellerStoreSettingsTab from './seller/components/SellerStoreSettingsTab';
import SellerProfileTab from './seller/components/SellerProfileTab';
import SellerNotificationsTab from './seller/components/SellerNotificationsTab';
import SellerCasesTab from './seller/components/SellerCasesTab';
import SellerStatusGate from './seller/components/SellerStatusGate';

const tabs = [
  { key: 'overview', label: 'Overview', icon: LayoutDashboard },
  { key: 'products', label: 'Products', icon: Package },
  { key: 'orders', label: 'Orders', icon: ShoppingCart },
  { key: 'shipping', label: 'Shipping', icon: Truck },
  { key: 'downloads', label: 'Downloads', icon: Download },
  { key: 'earnings', label: 'Earnings', icon: Wallet },
  { key: 'cases', label: 'Returns & Disputes', icon: Gavel },
  { key: 'analytics', label: 'Analytics', icon: BarChart3 },
  { key: 'reviews', label: 'Reviews', icon: MessageSquare },
  { key: 'notifications', label: 'Notifications', icon: Bell },
  { key: 'store', label: 'Store', icon: Store },
  { key: 'profile', label: 'Profile', icon: User },
  { key: 'settings', label: 'Settings', icon: Store },
];
const TAB_KEYS = tabs.map((t) => t.key);

// Every tab below fetches its own real backend data (Products/Orders/
// Downloads/Analytics/Reviews/Notifications all self-fetch) — this shell
// only fetches the lightweight /sellers/me/dashboard summary, needed for
// the Profile tab's product count. Earnings stays a disclosed
// placeholder: this backend has no payout/wallet model yet.
const SellerDashboard = () => {
  const { seller, logout, profileChecked, applyAsSeller } = useSellerAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const urlTab = location.pathname.split('/seller/')[1];
  const [tab, setTab] = useState(TAB_KEYS.includes(urlTab) ? urlTab : 'overview');
  const [productsCount, setProductsCount] = useState(0);

  useEffect(() => {
    if (seller?.status !== 'approved') return;
    getMySellerDashboard().then((d) => setProductsCount(d.products?.total || 0)).catch(() => {});
  }, [seller?.status]);

  const changeTab = (key) => {
    setTab(key);
    navigate(`/seller/${key}`, { replace: true });
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const joinedDate = seller?.joinedAt
    ? new Date(seller.joinedAt).toLocaleDateString(undefined, { year: 'numeric', month: 'long' })
    : 'Recently';

  // Gate on the real Seller application/profile status before showing the
  // dashboard — a seller-role account can exist without an approved (or
  // even submitted) store profile yet.
  if (!profileChecked) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="flex-1 grid place-items-center"><p className="text-sm text-muted-foreground py-12">Loading your seller account…</p></div>
        <Footer />
      </div>
    );
  }

  if (seller?.status && seller.status !== 'approved') {
    return (
      <SellerStatusGate
        status={seller.status}
        statusReason={seller.statusReason}
        onApply={applyAsSeller}
        onLogout={() => { logout(); navigate('/'); }}
      />
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Seo title="Seller Dashboard" description="Manage your PicaMarts store, listings, and earnings." noIndex />
      <Header />
      <div className="flex-1 mx-auto max-w-[90rem] w-full px-5 lg:px-8 pt-10 pb-20">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-primary">Seller Dashboard</p>
            <h1 className="text-3xl md:text-4xl font-black tracking-tight mt-1">{seller?.storeName || 'Your Store'}</h1>
            <p className="text-sm text-muted-foreground mt-1">Signed in as {seller?.email}</p>
          </div>
          <div className="flex items-center gap-3">
            <Link
              to="/seller/products/new"
              className="hidden sm:inline-flex items-center gap-2 brand-gradient text-white text-sm font-semibold px-5 py-2.5 rounded-full hover:opacity-95 transition-all"
            >
              <Plus className="w-4 h-4" /> New Product
            </Link>
            <button onClick={handleLogout} className="inline-flex items-center gap-2 bg-white text-foreground text-sm font-semibold px-5 py-2.5 rounded-full border border-border hover:bg-secondary transition-all">
              <LogOut className="w-4 h-4" /> Sign out
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="mt-8 flex gap-1.5 overflow-x-auto pb-1 border-b border-border">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => changeTab(t.key)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-semibold whitespace-nowrap border-b-2 -mb-px transition-colors ${tab === t.key ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'}`}
            >
              <t.icon className="w-4 h-4" /> {t.label}
            </button>
          ))}
        </div>

        <div className="mt-8">
          {tab === 'overview' && <SellerOverviewTab />}
          {tab === 'products' && <SellerProductsTab />}
          {tab === 'orders' && <SellerOrdersTab />}
          {tab === 'shipping' && <SellerShippingTab />}
          {tab === 'downloads' && <SellerDownloadsTab />}
          {tab === 'earnings' && <SellerEarningsTab />}
          {tab === 'cases' && <SellerCasesTab />}
          {tab === 'analytics' && <SellerAnalyticsTab />}
          {tab === 'reviews' && <SellerReviewsTab />}
          {tab === 'notifications' && <SellerNotificationsTab />}
          {tab === 'store' && (
            <div className="bg-white rounded-3xl border border-border soft-shadow p-6">
              <h3 className="font-bold mb-1">Your public storefront</h3>
              <p className="text-sm text-muted-foreground mb-5">This is what buyers see when they visit your store page.</p>
              <a
                href={`/seller/${(seller?.storeName || 'your-store').toLowerCase().replace(/\s+/g, '-')}`}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-border text-sm font-semibold hover:bg-secondary transition-colors"
              >
                <Store className="w-4 h-4" /> View storefront
              </a>
            </div>
          )}
          {tab === 'profile' && <SellerProfileTab seller={seller} productsCount={productsCount} joinedDate={joinedDate} />}
          {tab === 'settings' && <SellerStoreSettingsTab seller={seller} />}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default SellerDashboard;
