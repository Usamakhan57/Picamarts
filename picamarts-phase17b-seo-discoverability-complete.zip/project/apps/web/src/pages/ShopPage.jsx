import React, { useState, useMemo, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import Seo from '../components/Seo';
import Breadcrumbs from '../components/Breadcrumbs';
import ProductCard from '../components/ProductCard';
import FilterSidebar from '../components/FilterSidebar';
import EmptyState from '../components/EmptyState';
import { NetworkErrorState } from '../components/ErrorState';
import { ProductGridSkeleton } from '../components/Skeletons';
import { useFetch } from '../hooks/useFetch';
import { productsApi } from '../services/api';
import { getStorefrontCategories } from '../services/categoryRepository';
import { getChildren } from '../services/categoryTree';
import { getBrandsRaw } from '../services/catalogStore';
import { useCatalogVersion } from '../hooks/useCatalogVersion';
import { DEFAULT_FILTERS, SORT_OPTIONS } from '../constants';

const ShopPage = () => {
  const [searchParams] = useSearchParams();
  const [filters, setFilters] = useState({
    ...DEFAULT_FILTERS,
    category: searchParams.get('category') || 'All',
    // Phase 17B — SEO & Discoverability. Lets a shared/crawled
    // `/shop?brand=<id>` link (see the sitemap's brand entries) land
    // on an actually brand-filtered view, the same way `category`
    // above already does.
    brands: searchParams.get('brand') ? [searchParams.get('brand')] : DEFAULT_FILTERS.brands,
    collections: searchParams.get('collection') ? [searchParams.get('collection')] : DEFAULT_FILTERS.collections,
  });
  const [query, setQuery] = useState(searchParams.get('search') || '');
  const [sort, setSort] = useState(searchParams.get('sort') === 'top-rated' ? 'Top Rated' : 'Popular');

  const catalogVersion = useCatalogVersion();
  // Leaf categories only (no children) — these are what products actually
  // reference, so every pill here is guaranteed to match real products.
  const leafCategories = useMemo(() => {
    const all = getStorefrontCategories();
    return all.filter((c) => getChildren(all, c.id).length === 0);
  }, [catalogVersion]);

  // Phase 17A.2 — Storefront Filters: option lists for the sidebar's new
  // multi-select "Categories" and "Brand" checkbox groups.
  const categoryOptions = useMemo(() => leafCategories.map((c) => ({ id: c.id, name: c.name })), [leafCategories]);
  const brandOptions = useMemo(
    () => getBrandsRaw().filter((b) => b.active !== false).map((b) => ({ id: b.id, name: b.name })),
    [catalogVersion]
  );

  useEffect(() => {
    const fromUrl = searchParams.get('search');
    if (fromUrl) setQuery(fromUrl);
    const catFromUrl = searchParams.get('category');
    if (catFromUrl) setFilters((f) => ({ ...f, category: catFromUrl }));
  }, [searchParams]);

  const { data: list, loading, error, retry } = useFetch(
    () => productsApi.list({ filters, sort, query }),
    [filters, sort, query]
  );

  const categorySlot = useMemo(() => (
    <div className="pb-4 mb-4 border-b border-border">
      <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2.5">Category</p>
      <div className="flex flex-wrap gap-1.5">
        {['All', ...leafCategories.map((c) => c.name)].map((c) => (
          <button
            key={c}
            onClick={() => setFilters((f) => ({ ...f, category: c }))}
            className={`text-sm px-3.5 py-1.5 rounded-full whitespace-nowrap transition-colors ${filters.category === c ? 'brand-gradient text-white font-semibold' : 'bg-secondary/70 hover:bg-secondary text-foreground/80'}`}
          >
            {c}
          </button>
        ))}
      </div>
    </div>
  ), [filters.category, leafCategories]);

  return (
    <div className="min-h-screen">
      <Seo
        title="Shop All Digital Art"
        description="Browse thousands of premium SVGs, cliparts, wall art, planners and templates from verified creators. Filter by price, rating, file type and license."
      />
      <Header />
      <div className="mx-auto max-w-[90rem] px-5 lg:px-8 pt-10">
        <Breadcrumbs items={[{ name: 'Shop' }]} />
        <h1 className="text-4xl md:text-5xl font-black tracking-tight">Shop all <span className="brand-text">digital art</span></h1>
        <p className="text-muted-foreground mt-3 max-w-lg">Browse premium assets across every category. Filter, sort, and download instantly.</p>

        <div className="mt-8 flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <aside className="lg:w-72 shrink-0">
            <FilterSidebar
              filters={filters}
              onChange={setFilters}
              categorySlot={categorySlot}
              resultCount={list?.length}
              categoryOptions={categoryOptions}
              brandOptions={brandOptions}
              query={query}
            />
          </aside>

          {/* Main */}
          <div className="flex-1 min-w-0">
            <div className="flex flex-col sm:flex-row gap-3 mb-6">
              <div className="flex items-center gap-2 flex-1 bg-white rounded-full px-4 py-2.5 border border-border">
                <Search className="w-4 h-4 text-muted-foreground shrink-0" />
                <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search products…" aria-label="Search products" className="bg-transparent outline-none text-sm w-full" />
              </div>
              <div className="relative">
                <select value={sort} onChange={(e) => setSort(e.target.value)} aria-label="Sort by" className="appearance-none bg-white rounded-full pl-4 pr-10 py-2.5 border border-border text-sm font-medium outline-none cursor-pointer w-full sm:w-auto">
                  {SORT_OPTIONS.map((s) => <option key={s}>{s}</option>)}
                </select>
              </div>
            </div>

            {loading ? (
              <ProductGridSkeleton count={8} />
            ) : error ? (
              <NetworkErrorState onRetry={retry} message="We couldn't load products right now. Please try again." />
            ) : list.length === 0 ? (
              <EmptyState
                title="No products match those filters"
                message="Try widening your price range, clearing a filter, or searching a different term."
                secondaryLabel="Reset filters"
                onSecondary={() => { setFilters(DEFAULT_FILTERS); setQuery(''); setSort('Popular'); }}
              />
            ) : (
              <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
                {list.map((p) => <ProductCard key={p.id} p={p} />)}
              </div>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default ShopPage;
