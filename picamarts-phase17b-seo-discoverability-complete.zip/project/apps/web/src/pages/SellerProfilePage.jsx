import React, { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Star, Download, CalendarDays, ShieldCheck, UserPlus, UserCheck, Flag, Users } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import Seo from '../components/Seo';
import Breadcrumbs from '../components/Breadcrumbs';
import ProductCard from '../components/ProductCard';
import ReportModal from '../components/ReportModal';
import { getArtistBySlug, artistProducts } from '../data';
import { isFollowingSeller, toggleFollowSeller } from '../services/buyerDashboard';
import { useToast } from '../hooks/use-toast';

const SellerProfilePage = () => {
  const { slug } = useParams();
  const artist = getArtistBySlug(slug);
  const { toast } = useToast();
  const [following, setFollowing] = useState(() => (artist ? isFollowingSeller(artist.slug) : false));
  const [reportOpen, setReportOpen] = useState(false);

  if (!artist) {
    return (
      <div className="min-h-screen flex flex-col">
        <Seo title="Seller Not Found" description="This seller profile may have been removed or the link is incorrect." noIndex />
    <Header />
        <div className="flex-1 grid place-items-center px-5 py-24 text-center">
          <div>
            <h1 className="text-2xl font-bold mb-2">Seller not found</h1>
            <p className="text-muted-foreground mb-6">This seller profile may have been removed or the link is incorrect.</p>
            <Link to="/shop" className="inline-flex items-center justify-center px-6 py-3 rounded-full brand-gradient text-white font-semibold">Back to Shop</Link>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  const handleToggleFollow = () => {
    toggleFollowSeller(artist);
    setFollowing((prev) => !prev);
    toast({ title: following ? 'Unfollowed' : 'Following', description: artist.name });
  };

  const items = artistProducts(artist.name);
  const totalDownloads = items.reduce((s, p) => s + p.downloads, 0);
  const followerCount = Math.round((parseFloat(artist.sales) || 1) * 340) + (following ? 1 : 0);

  return (
    <div className="min-h-screen">
      <Seo title={`${artist.name} — Artist Store`} description={artist.bio} />
      <Header />
      <div className="mx-auto max-w-[90rem] px-5 lg:px-8 pt-10 pb-24">
        <Breadcrumbs items={[{ name: 'Artists', to: '/shop' }, { name: artist.name }]} />

        <div className="bg-white rounded-3xl border border-border soft-shadow p-8 flex flex-col sm:flex-row items-start sm:items-center gap-6">
          <span className="w-20 h-20 rounded-full brand-gradient text-white grid place-items-center text-2xl font-bold shrink-0">{artist.initials}</span>
          <div className="flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-2xl font-black tracking-tight">{artist.name}</h1>
              <span className="flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full bg-secondary text-secondary-foreground"><ShieldCheck className="w-3.5 h-3.5" /> Verified Artist</span>
            </div>
            <p className="text-sm text-muted-foreground mt-2 max-w-xl leading-relaxed">{artist.bio}</p>
            <div className="flex flex-wrap items-center gap-5 mt-4 text-sm text-muted-foreground">
              <span className="flex items-center gap-1.5"><Star className="w-4 h-4 fill-amber-400 text-amber-400" /> {artist.rating} rating</span>
              <span className="flex items-center gap-1.5"><Download className="w-4 h-4" /> {artist.sales} sales</span>
              <span className="flex items-center gap-1.5"><CalendarDays className="w-4 h-4" /> Joined {artist.joined}</span>
              <span className="flex items-center gap-1.5"><Users className="w-4 h-4" /> {followerCount.toLocaleString()} followers</span>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleToggleFollow}
              aria-pressed={following}
              className={`inline-flex items-center gap-1.5 px-5 py-2.5 rounded-full text-sm font-semibold transition-colors ${following ? 'border border-border hover:bg-secondary' : 'brand-gradient text-white hover:opacity-95'}`}
            >
              {following ? <UserCheck className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />} {following ? 'Following' : 'Follow'}
            </button>
            <button
              type="button"
              onClick={() => setReportOpen(true)}
              aria-label="Report this seller"
              className="w-10 h-10 grid place-items-center rounded-full border border-border hover:bg-destructive/10 hover:text-destructive transition-colors"
            >
              <Flag className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 mt-6">
          <div className="bg-white rounded-2xl border border-border p-5 text-center">
            <p className="text-2xl font-black">{items.length}</p>
            <p className="text-xs text-muted-foreground mt-1">Products</p>
          </div>
          <div className="bg-white rounded-2xl border border-border p-5 text-center">
            <p className="text-2xl font-black">{totalDownloads.toLocaleString()}</p>
            <p className="text-xs text-muted-foreground mt-1">Downloads</p>
          </div>
          <div className="bg-white rounded-2xl border border-border p-5 text-center">
            <p className="text-2xl font-black">{artist.specialty}</p>
            <p className="text-xs text-muted-foreground mt-1">Specialty</p>
          </div>
        </div>

        <div className="mt-14">
          <h2 className="text-2xl font-bold mb-6">Products by {artist.name}</h2>
          {items.length === 0 ? (
            <div className="bg-white rounded-3xl border border-border p-16 text-center">
              <p className="text-lg font-semibold">No products listed yet</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {items.map((p) => <ProductCard key={p.id} p={p} />)}
            </div>
          )}
        </div>
      </div>
      <Footer />
      <ReportModal open={reportOpen} onOpenChange={setReportOpen} subjectType="seller" subjectName={artist.name} />
    </div>
  );
};

export default SellerProfilePage;
