import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, ShieldCheck, Zap, BadgeCheck, Star, Quote,
} from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ProductCard from '../components/ProductCard';
import HeroSection from '../components/HeroSection';
import SellerCTA from '../components/SellerCTA';
import Seo from '../components/Seo';
import { ProductGridSkeleton } from '../components/Skeletons';
import { artists, testimonials } from '../data';
import { productsApi } from '../services/api';
import { recommendationService } from '../services/recommendationService';
import { useFetch } from '../hooks/useFetch';
import { getRecentlyViewedForUser } from '../services/recentlyViewed';
import { useStore } from '../context/StoreContext';
import { SITE } from '../constants';

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  show: (i = 0) => ({ opacity: 1, y: 0, transition: { duration: 0.5, delay: i * 0.06, ease: 'easeOut' } }),
};

const Section = ({ eyebrow, title, cta, ctaTo = '/shop', children }) => (
  <section className="mx-auto max-w-[90rem] px-5 lg:px-8 mt-24">
    <div className="flex items-end justify-between gap-6 mb-8">
      <div>
        {eyebrow && <p className="text-sm font-semibold text-primary mb-2">{eyebrow}</p>}
        <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight">{title}</h2>
      </div>
      {cta && (
        <Link to={ctaTo} className="hidden sm:flex items-center gap-1.5 text-sm font-semibold text-primary hover:gap-2.5 transition-all shrink-0 focus-visible:outline-none focus-visible:underline">
          {cta} <ArrowRight className="w-4 h-4" aria-hidden="true" />
        </Link>
      )}
    </div>
    {children}
  </section>
);

const homeJsonLd = {
  '@context': 'https://schema.org',
  '@graph': [
    {
      '@type': 'Organization',
      name: SITE.name,
      url: SITE.url,
      description: SITE.description,
    },
    {
      '@type': 'WebSite',
      name: SITE.name,
      url: SITE.url,
      potentialAction: {
        '@type': 'SearchAction',
        target: { '@type': 'EntryPoint', urlTemplate: `${SITE.url}/search?q={search_term_string}` },
        'query-input': 'required name=search_term_string',
      },
    },
  ],
};

const HomePage = () => {
  const marqueeWords = ['SVG', 'Cliparts', 'Wall Arts', 'Canva Templates', 'Fonts', 'Mockups', 'Printables', 'Icons', 'AI Prompts', '3D Assets'];
  const { data: popular, loading } = useFetch(() => productsApi.popular(12), []);
  const { user } = useStore();
  const [recentlyViewed, setRecentlyViewed] = useState([]);

  // Phase 17A.2, Part 1 — Recommendation Engine. Signed-in shoppers get
  // buyer-specific picks (purchase/wishlist/browsing signal); everyone
  // else sees the platform-wide trending feed.
  const { data: forYou = [] } = useFetch(
    () => (user ? recommendationService.getPersonalized(6) : recommendationService.getTrending(6)),
    [user?.id]
  );

  useEffect(() => {
    let cancelled = false;
    getRecentlyViewedForUser(user, null, 6).then((items) => { if (!cancelled) setRecentlyViewed(items); });
    return () => { cancelled = true; };
  }, [user]);

  return (
    <div className="min-h-screen">
      <Seo jsonLd={homeJsonLd} />
      <Header />

      <main id="main-content">
        {/* HERO — recreated from the approved reference */}
        <HeroSection />

        {/* Marquee */}
        <div className="mt-10 py-4 border-y border-border/70 overflow-hidden bg-white/40" aria-hidden="true">
          <div className="flex whitespace-nowrap animate-marquee w-max">
            {[...marqueeWords, ...marqueeWords].map((w, i) => (
              <span key={i} className="mx-6 text-2xl font-bold text-foreground/15 uppercase tracking-tight">{w}</span>
            ))}
          </div>
        </div>

        {/* FEATURED COLLECTIONS */}
        <Section eyebrow="Curated" title="Featured collections" cta="See all" ctaTo="/collections">
          <div className="grid md:grid-cols-3 gap-5">
            {[
              { t: 'Boho Wall Art Studio', d: '120 curated prints', c: 'linear-gradient(135deg,#6C3BFF,#8F63FF)' },
              { t: 'Creator Font Vault', d: '80 luxury typefaces', c: 'linear-gradient(135deg,#8F63FF,#FF4FD8)' },
              { t: 'Social Template Lab', d: '200+ Canva sets', c: 'linear-gradient(135deg,#FF4FD8,#6C3BFF)' },
            ].map((col) => (
              <Link key={col.t} to="/shop" className="group relative overflow-hidden rounded-3xl p-8 h-56 flex flex-col justify-end text-white soft-shadow focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2" style={{ background: col.c }}>
                <div className="absolute inset-0 opacity-30 mix-blend-overlay" style={{ background: 'radial-gradient(circle at 70% 20%, #fff, transparent 60%)' }} aria-hidden="true" />
                <h3 className="relative text-2xl font-extrabold">{col.t}</h3>
                <p className="relative text-sm text-white/85 mt-1">{col.d}</p>
                <span className="relative mt-4 inline-flex items-center gap-1.5 text-sm font-semibold group-hover:gap-3 transition-all">Explore <ArrowRight className="w-4 h-4" aria-hidden="true" /></span>
              </Link>
            ))}
          </div>
        </Section>

        {/* POPULAR PRODUCTS */}
        <Section eyebrow="Loved by creators" title="Popular products" cta="Shop all">
          {loading ? (
            <ProductGridSkeleton count={8} className="grid grid-cols-2 lg:grid-cols-4 gap-5" />
          ) : (
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-5">
              {(popular || []).map((p) => <ProductCard key={p.id} p={p} />)}
            </div>
          )}
        </Section>

        {/* WHY CHOOSE US */}
        <section className="mx-auto max-w-[90rem] px-5 lg:px-8 mt-24">
          <div className="rounded-[2.5rem] bg-white border border-border soft-shadow p-10 lg:p-14">
            <div className="max-w-xl mb-10">
              <p className="text-sm font-semibold text-primary mb-2">Why PicaMarts</p>
              <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight">Built for creators who care about craft</h2>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                { icon: Zap, t: 'Instant delivery', d: 'Files ready the second you check out. No waiting, no emails to chase.' },
                { icon: ShieldCheck, t: 'Clean licensing', d: 'Every asset ships with a clear license PDF for personal and commercial use.' },
                { icon: BadgeCheck, t: 'Hand-picked quality', d: 'Curated from top creators. Layered, print-ready, and pixel-perfect.' },
              ].map((f) => (
                <div key={f.t}>
                  <span className="grid place-items-center w-12 h-12 rounded-2xl brand-gradient text-white mb-4"><f.icon className="w-6 h-6" aria-hidden="true" /></span>
                  <h3 className="text-lg font-bold">{f.t}</h3>
                  <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{f.d}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* TOP ARTISTS */}
        <Section eyebrow="Meet the makers" title="Top artists" cta="View all artists">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {artists.slice(0, 10).map((a, i) => (
              <motion.div key={a.name} initial="hidden" whileInView="show" viewport={{ once: true }} custom={i % 5} variants={fadeUp}>
                <Link to={`/seller/${a.slug}`} className="block bg-white rounded-3xl p-6 border border-border text-center hover:soft-shadow hover:-translate-y-1 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
                  <span className="mx-auto grid place-items-center w-16 h-16 rounded-full brand-gradient text-white text-lg font-bold" aria-hidden="true">{a.initials}</span>
                  <h3 className="mt-4 font-semibold text-sm">{a.name}</h3>
                  <p className="text-xs text-muted-foreground">{a.specialty}</p>
                  <p className="mt-2 text-xs font-semibold text-primary">{a.sales} sales</p>
                </Link>
              </motion.div>
            ))}
          </div>
        </Section>

        {/* BECOME A SELLER */}
        <SellerCTA />

        {/* TESTIMONIALS */}
        <Section eyebrow="Trusted worldwide" title="What creators say">
          <div className="grid md:grid-cols-3 gap-5">
            {testimonials.map((t) => (
              <figure key={t.name} className="bg-white rounded-3xl p-7 border border-border soft-shadow">
                <Quote className="w-8 h-8 text-primary/25" aria-hidden="true" />
                <blockquote className="mt-3 text-[15px] leading-relaxed text-foreground/90">{t.text}</blockquote>
                <figcaption className="mt-5 flex items-center gap-3">
                  <span className="grid place-items-center w-11 h-11 rounded-full bg-secondary text-primary font-bold" aria-hidden="true">{t.initials}</span>
                  <div>
                    <div className="text-sm font-semibold">{t.name}</div>
                    <div className="text-xs text-muted-foreground">{t.role}</div>
                  </div>
                  <div className="ml-auto flex gap-0.5" aria-label="Rated 5 out of 5">
                    {[...Array(5)].map((_, i) => <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" aria-hidden="true" />)}
                  </div>
                </figcaption>
              </figure>
            ))}
          </div>
        </Section>

        {/* RECOMMENDED FOR YOU — personalized (signed in) or trending (Phase 17A.2) */}
        {forYou.length > 0 && (
          <Section eyebrow={user ? 'Picked for you' : 'Right now'} title={user ? 'Recommended For You' : 'Trending Now'}>
            <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-5">
              {forYou.map((p) => <ProductCard key={p.id} p={p} />)}
            </div>
          </Section>
        )}

        {/* RECENTLY VIEWED — only shows once the shopper has browsing history */}
        {recentlyViewed.length > 0 && (
          <Section eyebrow="Pick up where you left off" title="Recently Viewed">
            <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-5">
              {recentlyViewed.map((p) => <ProductCard key={p.id} p={p} />)}
            </div>
          </Section>
        )}

        {/* NEWSLETTER */}
        <section className="mx-auto max-w-[90rem] px-5 lg:px-8 mt-24" aria-label="Newsletter">
          <div className="relative overflow-hidden rounded-[2.5rem] brand-gradient text-white p-10 lg:p-16 text-center soft-shadow-lg">
            <div className="absolute inset-0 opacity-20" style={{ background: 'radial-gradient(circle at 20% 20%, #fff, transparent 50%)' }} aria-hidden="true" />
            <div className="relative max-w-xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-extrabold">Get 5 free assets every week</h2>
              <p className="mt-3 text-white/85">Join 40,000+ creators. Fresh drops, exclusive deals, and free downloads in your inbox.</p>
              <form onSubmit={(e) => e.preventDefault()} className="mt-7 flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
                <input required type="email" placeholder="you@studio.com" aria-label="Email address" className="flex-1 rounded-full px-5 py-3.5 text-foreground outline-none focus-visible:ring-2 focus-visible:ring-white" />
                <button className="bg-foreground text-white font-semibold px-7 py-3.5 rounded-full hover:opacity-90 active:scale-[0.98] transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white">Subscribe</button>
              </form>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default HomePage;
