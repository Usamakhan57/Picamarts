import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Heart, Globe, Lock, BarChart3, Trash2, Copy, Loader2 } from 'lucide-react';
import Seo from '../../components/Seo';
import AccountLayout from './AccountLayout';
import EmptyState from '../../components/EmptyState';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '../../components/ui/dialog';
import {
  AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription,
  AlertDialogFooter, AlertDialogCancel, AlertDialogAction,
} from '../../components/ui/alert-dialog';
import { Input } from '../../components/ui/input';
import { wishlistsService } from '../../services/wishlistsService';
import { useToast } from '../../hooks/use-toast';

/**
 * Phase 17A.2, Part 2 — Wishlist Enhancements (frontend). "My
 * Wishlists" — lists every named wishlist the buyer owns (their
 * default one included), lets them create new ones, rename, toggle
 * public/private (with a copyable share link once public), delete a
 * non-default one, and jump to per-wishlist analytics. Item
 * management for a single wishlist lives on WishlistDetailPage
 * (`/wishlists/:id`) — this page is the picker/overview only.
 *
 * Deliberately separate from the pre-existing `/wishlist` (singular)
 * page, which still only ever shows the buyer's one default wishlist
 * and is unchanged.
 */
const WishlistsPage = () => {
  const { toast } = useToast();
  const [wishlists, setWishlists] = useState(null);
  const [creating, setCreating] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [busyId, setBusyId] = useState(null);

  const load = () => {
    wishlistsService.list()
      .then(setWishlists)
      .catch(() => setWishlists([]));
  };

  useEffect(() => { load(); }, []);

  const createWishlist = async (e) => {
    e.preventDefault();
    if (!newName.trim()) return;
    setCreating(true);
    try {
      await wishlistsService.create({ name: newName.trim() });
      setNewName('');
      setCreateOpen(false);
      load();
      toast({ title: 'Wishlist created' });
    } catch (err) {
      toast({ title: 'Could not create wishlist', description: err?.message || 'Please try again.', variant: 'destructive' });
    } finally {
      setCreating(false);
    }
  };

  const toggleVisibility = async (wl) => {
    setBusyId(wl.id);
    try {
      await wishlistsService.setVisibility(wl.id, !wl.isPublic);
      load();
      toast({ title: wl.isPublic ? 'Wishlist is now private' : 'Wishlist is now public', description: wl.isPublic ? undefined : 'Anyone with the link can view it.' });
    } catch (err) {
      toast({ title: 'Could not update visibility', description: err?.message || 'Please try again.', variant: 'destructive' });
    } finally {
      setBusyId(null);
    }
  };

  const copyLink = (wl) => {
    if (!wl.shareToken) return;
    const url = `${window.location.origin}/wishlists/shared/${wl.shareToken}`;
    navigator.clipboard?.writeText(url);
    toast({ title: 'Link copied', description: url });
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    setBusyId(deleteTarget.id);
    try {
      await wishlistsService.remove(deleteTarget.id);
      setDeleteTarget(null);
      load();
      toast({ title: 'Wishlist deleted' });
    } catch (err) {
      toast({ title: 'Could not delete wishlist', description: err?.message || 'Please try again.', variant: 'destructive' });
    } finally {
      setBusyId(null);
    }
  };

  return (
    <>
      <Seo title="My Wishlists" description="Manage multiple wishlists, share them, and view wishlist analytics on PicaMarts." noIndex />
      <AccountLayout
        title="My Wishlists"
        subtitle="Organize saved products into multiple named lists, share any of them, and track what's inside."
      >
        <div className="flex justify-end mb-6">
          <button
            type="button"
            onClick={() => setCreateOpen(true)}
            className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-full brand-gradient text-white text-sm font-semibold soft-shadow hover:opacity-95 transition-opacity"
          >
            <Plus className="w-4 h-4" /> New Wishlist
          </button>
        </div>

        {wishlists === null ? (
          <div className="grid place-items-center py-20"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
        ) : wishlists.length === 0 ? (
          <EmptyState
            title="No wishlists yet"
            message="Create a named wishlist to organize saved products — gift ideas, a moodboard, or anything else."
            actionLabel="Browse the Shop"
            actionTo="/shop"
          />
        ) : (
          <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-5">
            {wishlists.map((wl) => (
              <div key={wl.id} className="bg-white rounded-3xl border border-border soft-shadow p-6 flex flex-col">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-lg truncate">{wl.name}</h3>
                      {wl.isDefault && <span className="text-[10px] font-semibold uppercase tracking-wide px-2 py-0.5 rounded-full bg-secondary text-muted-foreground shrink-0">Default</span>}
                    </div>
                    {wl.description && <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{wl.description}</p>}
                  </div>
                  <span className="grid place-items-center w-9 h-9 rounded-full bg-secondary shrink-0"><Heart className="w-4 h-4 text-primary" /></span>
                </div>

                <p className="text-sm text-muted-foreground mt-3">{wl.itemCount} item{wl.itemCount === 1 ? '' : 's'}</p>

                <div className="mt-4 flex items-center gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => toggleVisibility(wl)}
                    disabled={busyId === wl.id}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full font-semibold transition-colors disabled:opacity-60 ${wl.isPublic ? 'bg-primary/10 text-primary' : 'bg-secondary text-foreground/80 hover:bg-secondary/70'}`}
                  >
                    {wl.isPublic ? <Globe className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                    {wl.isPublic ? 'Public' : 'Private'}
                  </button>
                  {wl.isPublic && wl.shareToken && (
                    <button type="button" onClick={() => copyLink(wl)} className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full border border-border font-semibold hover:bg-secondary transition-colors">
                      <Copy className="w-3.5 h-3.5" /> Copy link
                    </button>
                  )}
                </div>

                <div className="mt-5 pt-4 border-t border-border flex items-center gap-2">
                  <Link to={`/wishlists/${wl.id}`} className="flex-1 text-center text-sm font-semibold px-4 py-2 rounded-full border border-border hover:bg-secondary transition-colors">
                    View
                  </Link>
                  <Link to={`/wishlists/${wl.id}?tab=analytics`} aria-label={`${wl.name} analytics`} className="grid place-items-center w-9 h-9 rounded-full border border-border hover:bg-secondary transition-colors shrink-0">
                    <BarChart3 className="w-4 h-4" />
                  </Link>
                  {!wl.isDefault && (
                    <button
                      type="button"
                      aria-label={`Delete ${wl.name}`}
                      onClick={() => setDeleteTarget(wl)}
                      className="grid place-items-center w-9 h-9 rounded-full border border-border hover:bg-destructive/10 hover:text-destructive transition-colors shrink-0"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </AccountLayout>

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create a new wishlist</DialogTitle>
          </DialogHeader>
          <form onSubmit={createWishlist} className="space-y-3">
            <Input
              autoFocus
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="e.g. Wedding gift ideas"
              maxLength={100}
              aria-label="Wishlist name"
            />
            <DialogFooter>
              <button type="submit" disabled={creating || !newName.trim()} className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-full brand-gradient text-white text-sm font-semibold disabled:opacity-60">
                {creating && <Loader2 className="w-4 h-4 animate-spin" />} Create
              </button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete "{deleteTarget?.name}"?</AlertDialogTitle>
            <AlertDialogDescription>This removes the wishlist and every item saved in it. This can't be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default WishlistsPage;
