import React, { useEffect, useMemo, useState } from 'react';
import Seo from '../../components/Seo';
import AccountLayout from './AccountLayout';
import ProductCard from '../../components/ProductCard';
import EmptyState from '../../components/EmptyState';
import { getRecentlyViewedForUser } from '../../services/recentlyViewed';
import { useStore } from '../../context/StoreContext';

const TABS = ['Recently Viewed', 'Recently Downloaded'];

const BrowsingHistoryPage = () => {
  const { orders, user } = useStore();
  const [tab, setTab] = useState(TABS[0]);
  const [recentlyViewed, setRecentlyViewed] = useState([]);

  // Phase 17A, Part 5 — real server-recorded history for a signed-in
  // buyer (this page lives under /account, so `user` is effectively
  // always present here, but the fallback still degrades gracefully
  // to the anonymous localStorage list rather than assuming).
  useEffect(() => {
    let cancelled = false;
    getRecentlyViewedForUser(user, null, 24).then((items) => { if (!cancelled) setRecentlyViewed(items); });
    return () => { cancelled = true; };
  }, [user]);

  const recentlyDownloaded = useMemo(
    () => {
      const seen = new Set();
      return orders.flatMap((o) => o.items).filter((i) => (seen.has(i.id) ? false : (seen.add(i.id), true)));
    },
    [orders]
  );

  const list = tab === TABS[0] ? recentlyViewed : recentlyDownloaded;

  return (
    <>
      <Seo title="Browsing History" description="Products you've recently viewed and downloaded on PicaMarts." noIndex />
      <AccountLayout title="Browsing History" subtitle="Products you've recently viewed and downloaded.">
        <div className="flex items-center gap-1.5 mb-6 overflow-x-auto pb-1">
          {TABS.map((t) => (
            <button key={t} onClick={() => setTab(t)} className={`px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap transition-colors ${tab === t ? 'brand-gradient text-white' : 'bg-white border border-border hover:bg-secondary'}`}>{t}</button>
          ))}
        </div>

        {list.length === 0 ? (
          <EmptyState title="Nothing here yet" message={tab === TABS[0] ? 'Products you view will show up here.' : 'Products you download will show up here.'} actionLabel="Browse the Shop" actionTo="/shop" />
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {list.map((p) => <ProductCard key={p.id} p={p} />)}
          </div>
        )}
      </AccountLayout>
    </>
  );
};

export default BrowsingHistoryPage;
