import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Truck, ChevronDown, ChevronUp } from 'lucide-react';
import Seo from '../../components/Seo';
import AccountLayout from './AccountLayout';
import EmptyState from '../../components/EmptyState';
import ShipmentStatusBadge from '../../components/shipping/ShipmentStatusBadge';
import TrackingInfo from '../../components/shipping/TrackingInfo';
import ShipmentTimeline from '../../components/shipping/ShipmentTimeline';
import { listMyShipments } from '../../services/shippingService';
import { getErrorMessage } from '../../lib/errorMessage';

const fmtDate = (iso) => (iso ? new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) : '—');

/**
 * Phase 14.2, Part 8 — "My Shipments" / order tracking, backed by the
 * real GET /shipments/mine endpoint. One card per shipment (an order
 * can have several, for partial fulfillment) with its own tracking
 * number and expandable timeline.
 */
const ShipmentsPage = () => {
  const [shipments, setShipments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [expandedId, setExpandedId] = useState(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      try {
        const items = await listMyShipments();
        if (!cancelled) setShipments(items || []);
      } catch (err) {
        if (!cancelled) setError(getErrorMessage(err));
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  if (error) {
    return (
      <>
        <Seo title="My Shipments" description="Track every physical order you've placed on PicaMarts." noIndex />
        <AccountLayout title="Shipments" subtitle="Track the delivery of every physical order you've placed.">
          <EmptyState title="Couldn't load your shipments" message={error} actionLabel="Browse the Shop" actionTo="/shop" />
        </AccountLayout>
      </>
    );
  }

  return (
    <>
      <Seo title="My Shipments" description="Track every physical order you've placed on PicaMarts." noIndex />
      <AccountLayout title="Shipments" subtitle="Track the delivery of every physical order you've placed.">
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => <div key={i} className="h-24 rounded-3xl bg-secondary/60 animate-pulse" />)}
          </div>
        ) : shipments.length === 0 ? (
          <EmptyState
            title="No shipments yet"
            message="Once a seller ships a physical order, it'll show up here with live tracking."
            actionLabel="Browse the Shop"
            actionTo="/shop"
          />
        ) : (
          <div className="space-y-4">
            {shipments.map((s) => {
              const expanded = expandedId === s.id;
              return (
                <div key={s.id} className="bg-white rounded-3xl border border-border soft-shadow p-5">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <p className="text-xs text-muted-foreground">Order <Link to="/orders" className="font-semibold text-foreground hover:text-primary">{s.orderNumber}</Link></p>
                      <p className="text-sm font-semibold mt-1">
                        {s.items.map((i) => i.title).join(', ') || 'Shipment'}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {s.estimatedDelivery ? `Estimated delivery ${fmtDate(s.estimatedDelivery)}` : `Created ${fmtDate(s.createdAt)}`}
                      </p>
                    </div>
                    <ShipmentStatusBadge status={s.status} />
                  </div>

                  <TrackingInfo carrier={s.carrier} trackingNumber={s.trackingNumber} trackingUrl={s.trackingUrl} className="mt-4" />

                  <button
                    onClick={() => setExpandedId(expanded ? null : s.id)}
                    className="mt-4 inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline"
                  >
                    {expanded ? 'Hide timeline' : 'View timeline'}
                    {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                  </button>

                  {expanded && (
                    <div className="mt-4 pt-4 border-t border-border">
                      <ShipmentTimeline timeline={s.timeline} />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        <p className="flex items-center gap-1.5 text-xs text-muted-foreground mt-6">
          <Truck className="w-3.5 h-3.5" /> Digital purchases don't ship — see My Downloads for those.
        </p>
      </AccountLayout>
    </>
  );
};

export default ShipmentsPage;
