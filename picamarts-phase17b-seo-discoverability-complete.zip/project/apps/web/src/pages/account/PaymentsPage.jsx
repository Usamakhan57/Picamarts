import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { RotateCw, CreditCard } from 'lucide-react';
import Seo from '../../components/Seo';
import AccountLayout from './AccountLayout';
import EmptyState from '../../components/EmptyState';
import { listPayments } from '../../services/paymentService';
import { getErrorMessage } from '../../lib/errorMessage';

const STATUS_STYLE = {
  succeeded: 'bg-emerald-100 text-emerald-700',
  processing: 'bg-blue-100 text-blue-700',
  pending: 'bg-amber-100 text-amber-700',
  failed: 'bg-red-100 text-red-700',
  cancelled: 'bg-slate-200 text-slate-700',
};

/**
 * Payment History — buyer-facing list of Stripe payment attempts (Phase
 * 13.3, Step 7). Distinct from PaymentMethodsPage (saved cards — not
 * supported by this backend yet, still mock). A "failed" payment links
 * back into Checkout's retry flow via the order it belongs to.
 */
const PaymentsPage = () => {
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      try {
        const { payments: items } = await listPayments({ limit: 100 });
        if (!cancelled) setPayments(items || []);
      } catch (err) {
        if (!cancelled) setError(getErrorMessage(err));
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  return (
    <>
      <Seo title="Payment History" description="Your PicaMarts payment attempts and receipts." noIndex />
      <AccountLayout title="Payment History" subtitle="Every payment attempt against your orders, including failed ones you can retry.">
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => <div key={i} className="h-20 rounded-3xl bg-secondary/60 animate-pulse" />)}
          </div>
        ) : error ? (
          <EmptyState title="Couldn't load payment history" message={error} actionLabel="Browse the Shop" actionTo="/shop" />
        ) : payments.length === 0 ? (
          <EmptyState title="No payments yet" message="Once you check out, your payment attempts will show up here." actionLabel="Browse the Shop" actionTo="/shop" />
        ) : (
          <div className="bg-white rounded-3xl border border-border soft-shadow overflow-hidden">
            <div className="hidden sm:grid grid-cols-[1fr_1fr_1fr_1fr_auto] gap-4 px-5 py-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground border-b border-border">
              <span>Order</span>
              <span>Amount</span>
              <span>Status</span>
              <span>Date</span>
              <span className="text-right">Action</span>
            </div>
            <ul className="divide-y divide-border">
              {payments.map((p) => (
                <li key={p.id} className="grid sm:grid-cols-[1fr_1fr_1fr_1fr_auto] gap-2 sm:gap-4 items-center px-5 py-4">
                  <span className="text-sm font-semibold flex items-center gap-2"><CreditCard className="w-4 h-4 text-primary shrink-0 sm:hidden" /> {p.order?.orderNumber || p.order}</span>
                  <span className="text-sm font-semibold">${Number(p.amount || 0).toFixed(2)} {(p.currency || 'usd').toUpperCase()}</span>
                  <span className={`text-xs font-semibold px-3 py-1 rounded-full w-fit ${STATUS_STYLE[p.status] || 'bg-slate-200 text-slate-700'}`}>{p.status}</span>
                  <span className="text-sm text-muted-foreground">{p.createdAt ? new Date(p.createdAt).toLocaleDateString() : '—'}</span>
                  {p.status === 'failed' ? (
                    <Link
                      to="/checkout"
                      state={{ retryOrderId: typeof p.order === 'string' ? p.order : p.order?.id }}
                      className="inline-flex items-center gap-1.5 justify-center sm:justify-start text-xs font-semibold px-4 py-2 rounded-full brand-gradient text-white sm:justify-self-end"
                    >
                      <RotateCw className="w-3.5 h-3.5" /> Retry Payment
                    </Link>
                  ) : (
                    <span className="sm:justify-self-end" />
                  )}
                </li>
              ))}
            </ul>
          </div>
        )}
      </AccountLayout>
    </>
  );
};

export default PaymentsPage;
