import React, { useState } from 'react';
import { Bell, Package, Users, Ticket as TicketIcon, LifeBuoy, Heart, CheckCheck } from 'lucide-react';
import Seo from '../../components/Seo';
import AccountLayout from './AccountLayout';
import EmptyState from '../../components/EmptyState';
import { useToast } from '../../hooks/use-toast';
import { defaultNotifications, loadLS, saveLS } from '../../services/buyerDashboard';

const KEY = 'pm_notifications';
const TABS = ['All', 'Unread', 'Read'];

const categoryIcon = { order: Package, following: Users, promo: TicketIcon, support: LifeBuoy, wishlist: Heart };

const Toggle = ({ checked, onChange, label, description }) => (
  <label className="flex items-start justify-between gap-4 py-3.5 border-b border-border last:border-0 cursor-pointer">
    <span>
      <span className="text-sm font-semibold block">{label}</span>
      {description && <span className="text-xs text-muted-foreground">{description}</span>}
    </span>
    <span className="relative inline-flex items-center shrink-0">
      <input type="checkbox" checked={checked} onChange={onChange} className="sr-only peer" />
      <span className="w-10 h-6 rounded-full bg-border peer-checked:bg-primary transition-colors" />
      <span className="absolute left-1 top-1 w-4 h-4 rounded-full bg-white transition-transform peer-checked:translate-x-4" />
    </span>
  </label>
);

const timeAgo = (iso) => {
  const diff = Date.now() - new Date(iso).getTime();
  const days = Math.floor(diff / 86400000);
  if (days === 0) return 'Today';
  if (days === 1) return 'Yesterday';
  return `${days} days ago`;
};

const NotificationsPage = () => {
  const { toast } = useToast();
  const [notifications, setNotifications] = useState(() => loadLS(KEY, null) || defaultNotifications);
  const [tab, setTab] = useState('All');
  const [prefs, setPrefs] = useState({ orderUpdates: true, following: true, promos: false, support: true });

  const persist = (next) => { setNotifications(next); saveLS(KEY, next); };

  const filtered = notifications.filter((n) => tab === 'All' || (tab === 'Unread' ? !n.read : n.read));

  const markAllRead = () => {
    persist(notifications.map((n) => ({ ...n, read: true })));
    toast({ title: 'All notifications marked as read' });
  };

  const markRead = (id) => persist(notifications.map((n) => (n.id === id ? { ...n, read: true } : n)));

  return (
    <>
      <Seo title="Notifications" description="Your PicaMarts notification center." noIndex />
      <AccountLayout title="Notifications" subtitle="Order updates, seller activity, and account alerts.">
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
              <div className="flex items-center gap-1.5">
                {TABS.map((t) => (
                  <button key={t} onClick={() => setTab(t)} className={`px-4 py-2 rounded-full text-sm font-semibold transition-colors ${tab === t ? 'brand-gradient text-white' : 'bg-white border border-border hover:bg-secondary'}`}>{t}</button>
                ))}
              </div>
              <button onClick={markAllRead} className="inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:underline">
                <CheckCheck className="w-4 h-4" /> Mark All Read
              </button>
            </div>

            {filtered.length === 0 ? (
              <EmptyState title="Nothing here" message="You're all caught up." actionLabel="Go to Dashboard" actionTo="/dashboard" />
            ) : (
              <div className="bg-white rounded-3xl border border-border soft-shadow divide-y divide-border overflow-hidden">
                {filtered.map((n) => {
                  const Icon = categoryIcon[n.category] || Bell;
                  return (
                    <button key={n.id} onClick={() => markRead(n.id)} className="w-full text-left flex items-start gap-3 p-4 hover:bg-secondary/40 transition-colors">
                      <span className={`w-9 h-9 rounded-xl grid place-items-center shrink-0 ${n.read ? 'bg-secondary' : 'bg-primary/10'}`}>
                        <Icon className={`w-4.5 h-4.5 ${n.read ? 'text-muted-foreground' : 'text-primary'}`} />
                      </span>
                      <div className="flex-1 min-w-0">
                        <p className={`text-sm ${n.read ? 'font-medium' : 'font-bold'}`}>{n.title}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{n.body}</p>
                        <p className="text-[11px] text-muted-foreground/70 mt-1">{timeAgo(n.date)}</p>
                      </div>
                      {!n.read && <span className="w-2 h-2 rounded-full bg-primary mt-1.5 shrink-0" />}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          <div className="bg-white rounded-3xl border border-border soft-shadow p-6 h-fit">
            <h3 className="font-bold text-sm mb-1">Notification Settings</h3>
            <Toggle checked={prefs.orderUpdates} onChange={(e) => setPrefs({ ...prefs, orderUpdates: e.target.checked })} label="Order updates" description="Receipts and status changes." />
            <Toggle checked={prefs.following} onChange={(e) => setPrefs({ ...prefs, following: e.target.checked })} label="Followed sellers" description="New products from sellers you follow." />
            <Toggle checked={prefs.promos} onChange={(e) => setPrefs({ ...prefs, promos: e.target.checked })} label="Promotions & coupons" description="Deals and expiring coupons." />
            <Toggle checked={prefs.support} onChange={(e) => setPrefs({ ...prefs, support: e.target.checked })} label="Support replies" description="Updates on your support tickets." />
          </div>
        </div>
      </AccountLayout>
    </>
  );
};

export default NotificationsPage;
