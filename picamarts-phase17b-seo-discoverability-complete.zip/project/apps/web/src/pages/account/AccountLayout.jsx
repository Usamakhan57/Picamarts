import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, User, Package, Download, Settings, LogOut, Heart, ShoppingBag,
  Star, ShieldCheck, Bell, MapPin, CreditCard, LifeBuoy, FileText, Ticket, Users, Clock, Receipt, Truck, Layers,
} from 'lucide-react';
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import { useStore } from '../../context/StoreContext';

const groups = [
  {
    label: 'Overview',
    links: [
      { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    ],
  },
  {
    label: 'Shopping',
    links: [
      { to: '/orders', label: 'Orders', icon: Package },
      { to: '/shipments', label: 'Shipments', icon: Truck },
      { to: '/payments', label: 'Payment History', icon: Receipt },
      { to: '/downloads', label: 'Downloads', icon: Download },
      { to: '/wishlist', label: 'Wishlist', icon: Heart },
      { to: '/wishlists', label: 'My Wishlists', icon: Layers },
      { to: '/cart', label: 'Cart', icon: ShoppingBag },
      { to: '/coupons', label: 'Coupons', icon: Ticket },
      { to: '/invoices', label: 'Invoices', icon: FileText },
    ],
  },
  {
    label: 'Community',
    links: [
      { to: '/reviews', label: 'Reviews', icon: Star },
      { to: '/following', label: 'Following', icon: Users },
      { to: '/browsing-history', label: 'Browsing History', icon: Clock },
    ],
  },
  {
    label: 'Account',
    links: [
      { to: '/profile', label: 'Profile', icon: User },
      { to: '/security', label: 'Security', icon: ShieldCheck },
      { to: '/notifications', label: 'Notifications', icon: Bell },
      { to: '/addresses', label: 'Addresses', icon: MapPin },
      { to: '/payment-methods', label: 'Payment Methods', icon: CreditCard },
      { to: '/settings', label: 'Settings', icon: Settings },
    ],
  },
  {
    label: 'Help',
    links: [
      { to: '/support', label: 'Support', icon: LifeBuoy },
    ],
  },
];

const AccountLayout = ({ title, subtitle, children }) => {
  const { user, logout } = useStore();
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <div className="flex-1 mx-auto max-w-[90rem] w-full px-5 lg:px-8 pt-10 pb-20">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-primary">My Account</p>
            <h1 className="text-3xl md:text-4xl font-black tracking-tight mt-1">{title}</h1>
            {subtitle && <p className="text-sm text-muted-foreground mt-1">{subtitle}</p>}
          </div>
          <p className="text-sm text-muted-foreground">Signed in as <span className="font-semibold text-foreground">{user?.name}</span></p>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          <aside className="lg:w-64 shrink-0">
            <nav className="bg-white rounded-3xl border border-border soft-shadow p-3 lg:sticky lg:top-24 max-h-[calc(100vh-7rem)] overflow-y-auto">
              <div className="flex lg:flex-col gap-4 overflow-x-auto lg:overflow-visible">
                {groups.map((group) => (
                  <div key={group.label} className="shrink-0 lg:shrink">
                    <p className="hidden lg:block px-3 pb-1.5 text-[11px] font-bold uppercase tracking-wider text-muted-foreground/70">{group.label}</p>
                    <div className="flex lg:flex-col gap-1">
                      {group.links.map((l) => {
                        const active = location.pathname === l.to;
                        return (
                          <Link
                            key={l.to}
                            to={l.to}
                            className={`flex items-center gap-2.5 px-4 py-2.5 rounded-2xl text-sm font-semibold whitespace-nowrap transition-colors ${active ? 'brand-gradient text-white' : 'text-foreground/80 hover:bg-secondary'}`}
                          >
                            <l.icon className="w-4 h-4 shrink-0" /> {l.label}
                          </Link>
                        );
                      })}
                    </div>
                  </div>
                ))}
                <div className="shrink-0 lg:shrink lg:pt-2 lg:border-t lg:border-border">
                  <button
                    onClick={handleLogout}
                    className="flex items-center gap-2.5 px-4 py-2.5 rounded-2xl text-sm font-semibold whitespace-nowrap text-destructive hover:bg-destructive/10 transition-colors"
                  >
                    <LogOut className="w-4 h-4" /> Sign out
                  </button>
                </div>
              </div>
            </nav>
          </aside>
          <div className="flex-1 min-w-0">{children}</div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default AccountLayout;
