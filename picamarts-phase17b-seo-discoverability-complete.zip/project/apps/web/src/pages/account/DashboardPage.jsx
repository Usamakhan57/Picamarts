import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Package, Download, Heart, Star, DollarSign, ArrowRight } from 'lucide-react';
import Seo from '../../components/Seo';
import AccountLayout from './AccountLayout';
import ProductCard from '../../components/ProductCard';
import { useStore } from '../../context/StoreContext';
import { buildDefaultReviews, buildRecommended } from '../../services/buyerDashboard';
import { getRecentlyViewedForUser } from '../../services/recentlyViewed';

const StatCard = ({ label, value, icon: Icon }) => (
  <div className="bg-white rounded-2xl border border-border p-5 soft-shadow">
    <div className="flex items-center justify-between mb-3">
      <span className="text-sm font-medium text-muted-foreground">{label}</span>
      <span className="w-9 h-9 rounded-xl bg-secondary grid place-items-center">
        <Icon className="w-4.5 h-4.5 text-primary" />
      </span>
    </div>
    <p className="text-2xl font-bold tracking-tight">{value}</p>
  </div>
);

const SectionHeader = ({ title, to }) => (
  <div className="flex items-center justify-between mb-4">
    <h2 className="font-bold text-lg">{title}</h2>
    {to && (
      <Link to={to} className="inline-flex items-center gap-1 text-sm font-semibold text-primary hover:gap-1.5 transition-all">
        View all <ArrowRight className="w-3.5 h-3.5" />
      </Link>
    )}
  </div>
);

const DashboardPage = () => {
  const { user, orders, wishlist } = useStore();

  const downloads = useMemo(() => orders.flatMap((o) => o.items.map((item) => ({ ...item, orderId: o.id, date: o.date }))), [orders]);
  const reviews = useMemo(() => buildDefaultReviews(), []);
  const [recentlyViewed, setRecentlyViewed] = useState([]);
  useEffect(() => {
    let cancelled = false;
    getRecentlyViewedForUser(user, null, 6).then((items) => { if (!cancelled) setRecentlyViewed(items); });
    return () => { cancelled = true; };
  }, [user]);
  const recommended = useMemo(() => buildRecommended(), []);
  const totalSpending = orders.reduce((s, o) => s + o.total, 0);

  return (
    <>
      <Seo title="Dashboard" description="Your PicaMarts buyer dashboard overview." noIndex />
      <AccountLayout title="Dashboard" subtitle={`Welcome back${user?.name ? `, ${user.name}` : ''} — here's what's happening with your account.`}>
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
          <StatCard label="Total Orders" value={orders.length} icon={Package} />
          <StatCard label="Total Downloads" value={downloads.length} icon={Download} />
          <StatCard label="Wishlist Items" value={wishlist.length} icon={Heart} />
          <StatCard label="Reviews Given" value={reviews.length} icon={Star} />
          <StatCard label="Total Spending" value={`$${totalSpending.toFixed(2)}`} icon={DollarSign} />
        </div>

        <div className="grid lg:grid-cols-2 gap-6 mb-10">
          <div>
            <SectionHeader title="Recent Orders" to="/orders" />
            {orders.length === 0 ? (
              <p className="text-sm text-muted-foreground bg-white rounded-3xl border border-border p-6">No orders yet — your purchases will show up here.</p>
            ) : (
              <div className="bg-white rounded-3xl border border-border soft-shadow divide-y divide-border overflow-hidden">
                {orders.slice(0, 4).map((o) => (
                  <div key={o.id} className="flex items-center gap-3 p-4">
                    <img src={o.items[0]?.img} alt="" className="w-12 h-12 rounded-xl object-cover bg-secondary shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold truncate">{o.items[0]?.title}{o.items.length > 1 ? ` +${o.items.length - 1} more` : ''}</p>
                      <p className="text-xs text-muted-foreground">{o.id} · {new Date(o.date).toLocaleDateString()}</p>
                    </div>
                    <span className="text-sm font-bold shrink-0">${o.total.toFixed(2)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div>
            <SectionHeader title="Recent Downloads" to="/downloads" />
            {downloads.length === 0 ? (
              <p className="text-sm text-muted-foreground bg-white rounded-3xl border border-border p-6">Files you purchase will appear here.</p>
            ) : (
              <div className="bg-white rounded-3xl border border-border soft-shadow divide-y divide-border overflow-hidden">
                {downloads.slice(0, 4).map((item, i) => (
                  <div key={`${item.orderId}-${item.id}-${i}`} className="flex items-center gap-3 p-4">
                    <img src={item.img} alt="" className="w-12 h-12 rounded-xl object-cover bg-secondary shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold truncate">{item.title}</p>
                      <p className="text-xs text-muted-foreground">{item.licenseName || 'Personal Use'} license</p>
                    </div>
                    <Download className="w-4 h-4 text-primary shrink-0" />
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="mb-10">
          <SectionHeader title="Recommended For You" to="/shop" />
          <div className="grid grid-cols-2 lg:grid-cols-4 xl:grid-cols-6 gap-4">
            {recommended.map((p) => <ProductCard key={p.id} p={p} />)}
          </div>
        </div>

        <div>
          <SectionHeader title="Recently Viewed" to="/browsing-history" />
          <div className="grid grid-cols-2 lg:grid-cols-4 xl:grid-cols-6 gap-4">
            {recentlyViewed.map((p) => <ProductCard key={p.id} p={p} />)}
          </div>
        </div>
      </AccountLayout>
    </>
  );
};

export default DashboardPage;
