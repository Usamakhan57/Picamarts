import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Download, Search, ChevronLeft, ChevronRight, KeyRound, Clock, Ban } from 'lucide-react';
import Seo from '../../components/Seo';
import AccountLayout from './AccountLayout';
import EmptyState from '../../components/EmptyState';
import { useToast } from '../../hooks/use-toast';
import { listMyDownloads, redeemDownload } from '../../services/downloadService';
import { getErrorMessage } from '../../lib/errorMessage';

const PAGE_SIZE = 6;

const formatBytes = (bytes) => {
  if (!bytes) return '';
  const mb = bytes / (1024 * 1024);
  return mb >= 1 ? `${mb.toFixed(mb >= 10 ? 0 : 1)} MB` : `${Math.max(1, Math.round(bytes / 1024))} KB`;
};

/**
 * Phase 14.1, Part 9/17 — "My Downloads", backed by the real
 * /downloads endpoint. Each purchase can carry several files, an
 * optional license key, and its own download-count/limit/expiration —
 * all read straight from the backend's Download record, not derived
 * from order/cart data the way the old mock version did.
 */
const DownloadsPage = () => {
  const { toast } = useToast();
  const [downloads, setDownloads] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [query, setQuery] = useState('');
  const [page, setPage] = useState(1);
  const [redeemingFileId, setRedeemingFileId] = useState(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      try {
        const items = await listMyDownloads();
        if (!cancelled) setDownloads(items || []);
      } catch (err) {
        if (!cancelled) setError(getErrorMessage(err));
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  const filtered = useMemo(
    () => downloads.filter((d) => !query || (d.product?.title || '').toLowerCase().includes(query.toLowerCase())),
    [downloads, query]
  );

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const pageItems = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const changeQuery = (v) => { setQuery(v); setPage(1); };

  const handleDownload = async (download, file) => {
    setRedeemingFileId(file.id);
    try {
      const { url } = await redeemDownload(download.id, file.id);
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch (err) {
      toast({ title: "Can't download this file", description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setRedeemingFileId(null);
    }
  };

  const copyLicenseKey = (key) => {
    navigator.clipboard?.writeText(key).catch(() => {});
    toast({ title: 'License key copied', description: key });
  };

  if (error) {
    return (
      <>
        <Seo title="My Downloads" description="Re-download every file you've purchased on PicaMarts." noIndex />
        <AccountLayout title="Downloads" subtitle="Every file you've purchased, ready to re-download any time.">
          <EmptyState title="Couldn't load your downloads" message={error} actionLabel="Browse the Shop" actionTo="/shop" />
        </AccountLayout>
      </>
    );
  }

  return (
    <>
      <Seo title="My Downloads" description="Re-download every file you've purchased on PicaMarts." noIndex />
      <AccountLayout title="Downloads" subtitle="Every file you've purchased, ready to re-download any time.">
        <div className="flex items-center gap-2 bg-white rounded-full px-4 py-2.5 border border-border mb-6 max-w-md">
          <Search className="w-4 h-4 text-muted-foreground shrink-0" />
          <input
            value={query}
            onChange={(e) => changeQuery(e.target.value)}
            placeholder="Search your downloads…"
            aria-label="Search downloads"
            className="bg-transparent outline-none text-sm w-full"
          />
        </div>

        {loading ? (
          <div className="grid sm:grid-cols-2 gap-4">
            {[1, 2, 3, 4].map((i) => <div key={i} className="h-32 rounded-3xl bg-secondary/60 animate-pulse" />)}
          </div>
        ) : filtered.length === 0 ? (
          <EmptyState
            title={downloads.length === 0 ? 'No downloads yet' : 'No downloads match your search'}
            message={downloads.length === 0 ? 'Files you purchase will appear here for re-download, along with any license key.' : 'Try a different search term.'}
            actionLabel="Browse the Shop"
            actionTo="/shop"
          />
        ) : (
          <>
            <div className="grid sm:grid-cols-2 gap-4">
              {pageItems.map((d) => {
                const revoked = d.status === 'revoked';
                const expired = d.expiresAt && new Date(d.expiresAt).getTime() < Date.now();
                const limitReached = d.maxDownloads != null && d.downloadCount >= d.maxDownloads;
                const blocked = revoked || expired || limitReached;
                return (
                  <div key={d.id} className="bg-white rounded-3xl border border-border soft-shadow p-4 flex gap-3">
                    <Link to={`/product/${d.product?.id}`} className="w-16 h-16 rounded-xl overflow-hidden bg-secondary shrink-0">
                      <img src={d.product?.thumbnail?.url} alt={d.product?.title} className="w-full h-full object-cover" />
                    </Link>
                    <div className="flex-1 min-w-0">
                      <Link to={`/product/${d.product?.id}`} className="text-sm font-semibold hover:text-primary transition-colors line-clamp-1">
                        {d.product?.title || 'Product'}
                      </Link>
                      <p className="text-xs text-muted-foreground mt-1">Purchased {new Date(d.purchasedAt).toLocaleDateString()}</p>

                      {d.licenseKey && (
                        <button
                          onClick={() => copyLicenseKey(d.licenseKey)}
                          className="mt-2 inline-flex items-center gap-1.5 text-[11px] font-mono font-semibold px-2.5 py-1 rounded-md border border-border bg-secondary/40 hover:bg-secondary transition-colors"
                          title="Click to copy"
                        >
                          <KeyRound className="w-3 h-3" /> {d.licenseKey}
                        </button>
                      )}

                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-2 text-xs text-muted-foreground">
                        <span>{d.maxDownloads != null ? `${d.downloadCount}/${d.maxDownloads} downloads` : `${d.downloadCount} downloads · unlimited`}</span>
                        {d.expiresAt && (
                          <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {expired ? 'Expired' : `Expires ${new Date(d.expiresAt).toLocaleDateString()}`}</span>
                        )}
                      </div>

                      {revoked ? (
                        <p className="mt-3 flex items-center gap-1.5 text-xs font-semibold text-destructive"><Ban className="w-3.5 h-3.5" /> Access revoked{d.revokedReason ? `: ${d.revokedReason}` : ''}</p>
                      ) : (
                        <div className="mt-3 flex flex-wrap gap-2">
                          {(d.files || []).map((file) => (
                            <button
                              key={file.id}
                              onClick={() => handleDownload(d, file)}
                              disabled={blocked || redeemingFileId === file.id}
                              className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full brand-gradient text-white text-xs font-semibold hover:opacity-95 transition-opacity disabled:opacity-50"
                              title={file.label}
                            >
                              <Download className="w-3.5 h-3.5" />
                              {redeemingFileId === file.id ? 'Preparing…' : (file.label || 'Download')}
                              {file.size ? <span className="opacity-80">({formatBytes(file.size)})</span> : null}
                            </button>
                          ))}
                          {limitReached && !expired && <p className="w-full text-xs text-destructive">Download limit reached.</p>}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {totalPages > 1 && (
              <div className="flex items-center justify-center gap-2 mt-8">
                <button
                  disabled={page === 1}
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  className="w-9 h-9 grid place-items-center rounded-full border border-border disabled:opacity-40 hover:bg-secondary transition-colors"
                  aria-label="Previous page"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span className="text-sm font-medium text-muted-foreground px-2">Page {page} of {totalPages}</span>
                <button
                  disabled={page === totalPages}
                  onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                  className="w-9 h-9 grid place-items-center rounded-full border border-border disabled:opacity-40 hover:bg-secondary transition-colors"
                  aria-label="Next page"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </>
        )}
      </AccountLayout>
    </>
  );
};

export default DownloadsPage;
