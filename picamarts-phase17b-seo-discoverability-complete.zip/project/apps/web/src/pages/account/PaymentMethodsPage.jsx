import React, { useState } from 'react';
import { Plus, Trash2, CreditCard, CheckCircle2 } from 'lucide-react';
import Seo from '../../components/Seo';
import AccountLayout from './AccountLayout';
import EmptyState from '../../components/EmptyState';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '../../components/ui/dialog';
import { useToast } from '../../hooks/use-toast';
import { defaultPaymentMethods, loadLS, saveLS, uid } from '../../services/buyerDashboard';

const KEY = 'pm_payment_methods';

const typeLabel = { card: 'Card', paypal: 'PayPal', stripe: 'Stripe', bank: 'Bank Account' };

const AddPaymentModal = ({ open, onOpenChange, onSave }) => {
  const [type, setType] = useState('card');
  const [detail, setDetail] = useState('');

  const submit = (e) => {
    e.preventDefault();
    const base = { id: uid('pm'), type, isDefault: false };
    if (type === 'card') onSave({ ...base, brand: 'Card', last4: detail.slice(-4).padStart(4, '0'), expiry: '12/29' });
    else if (type === 'bank') onSave({ ...base, bankName: detail || 'Bank Account', last4: '0000' });
    else onSave({ ...base, email: detail });
    setDetail('');
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md rounded-3xl">
        <DialogTitle>Add Payment Method</DialogTitle>
        <DialogDescription className="sr-only">This is a UI-only demo — no real payment data is stored.</DialogDescription>
        <form onSubmit={submit} className="space-y-4 mt-2">
          <div>
            <label className="text-sm font-medium block mb-1.5">Method type</label>
            <select value={type} onChange={(e) => setType(e.target.value)} className="w-full bg-secondary/60 rounded-xl px-4 py-2.5 text-sm outline-none border border-transparent focus:border-primary">
              <option value="card">Credit / Debit Card</option>
              <option value="paypal">PayPal</option>
              <option value="stripe">Stripe</option>
              <option value="bank">Bank Account</option>
            </select>
          </div>
          <div>
            <label className="text-sm font-medium block mb-1.5">{type === 'card' ? 'Card number' : type === 'bank' ? 'Bank name' : 'Account email'}</label>
            <input value={detail} onChange={(e) => setDetail(e.target.value)} required placeholder={type === 'card' ? '4242 4242 4242 4242' : type === 'bank' ? 'Bank of Karachi' : 'you@example.com'} className="w-full bg-secondary/60 rounded-xl px-4 py-2.5 text-sm outline-none border border-transparent focus:border-primary" />
          </div>
          <p className="text-xs text-muted-foreground">This is a frontend-only demo — no real payment details are transmitted or stored.</p>
          <button type="submit" className="brand-gradient text-white font-semibold px-6 py-2.5 rounded-full hover:opacity-95 transition-all w-full">Add Method</button>
        </form>
      </DialogContent>
    </Dialog>
  );
};

const PaymentMethodsPage = () => {
  const { toast } = useToast();
  const [methods, setMethods] = useState(() => loadLS(KEY, null) || defaultPaymentMethods);
  const [modalOpen, setModalOpen] = useState(false);

  const persist = (next) => { setMethods(next); saveLS(KEY, next); };

  const handleSave = (m) => {
    persist([...methods, m]);
    toast({ title: 'Payment method added' });
  };

  const handleDelete = (id) => {
    persist(methods.filter((m) => m.id !== id));
    toast({ title: 'Payment method removed' });
  };

  const makeDefault = (id) => {
    persist(methods.map((m) => ({ ...m, isDefault: m.id === id })));
    toast({ title: 'Default payment method updated' });
  };

  return (
    <>
      <Seo title="Payment Methods" description="Manage your saved payment methods on PicaMarts." noIndex />
      <AccountLayout title="Payment Methods" subtitle="Frontend UI only — no real payment processing is connected yet.">
        <div className="flex justify-end mb-5">
          <button onClick={() => setModalOpen(true)} className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full brand-gradient text-white text-sm font-semibold hover:opacity-95 transition-opacity">
            <Plus className="w-4 h-4" /> Add Payment Method
          </button>
        </div>

        {methods.length === 0 ? (
          <EmptyState title="No payment methods saved" message="Add a card, PayPal, Stripe, or bank account to speed up checkout." actionLabel="Add Method" actionTo="#" onSecondary={() => setModalOpen(true)} />
        ) : (
          <div className="grid sm:grid-cols-2 gap-4">
            {methods.map((m) => (
              <div key={m.id} className="bg-white rounded-3xl border border-border soft-shadow p-5">
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2">
                    <span className="w-10 h-10 rounded-xl bg-secondary grid place-items-center shrink-0">
                      <CreditCard className="w-5 h-5 text-primary" />
                    </span>
                    <div>
                      <p className="text-sm font-bold">{m.brand || typeLabel[m.type]}{m.last4 ? ` •••• ${m.last4}` : ''}</p>
                      {m.email && <p className="text-xs text-muted-foreground">{m.email}</p>}
                      {m.expiry && <p className="text-xs text-muted-foreground">Expires {m.expiry}</p>}
                    </div>
                  </div>
                  {m.isDefault && <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 shrink-0 inline-flex items-center gap-1"><CheckCircle2 className="w-3 h-3" /> Default</span>}
                </div>
                <div className="flex items-center gap-3 pt-3 border-t border-border">
                  <button onClick={() => handleDelete(m.id)} className="inline-flex items-center gap-1.5 text-xs font-semibold text-destructive hover:underline">
                    <Trash2 className="w-3.5 h-3.5" /> Remove
                  </button>
                  {!m.isDefault && (
                    <button onClick={() => makeDefault(m.id)} className="text-xs font-semibold text-muted-foreground hover:text-foreground ml-auto">Make Default</button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        <AddPaymentModal open={modalOpen} onOpenChange={setModalOpen} onSave={handleSave} />
      </AccountLayout>
    </>
  );
};

export default PaymentMethodsPage;
