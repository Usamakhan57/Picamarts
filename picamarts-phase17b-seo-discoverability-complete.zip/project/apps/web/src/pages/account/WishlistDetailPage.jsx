import React, { useEffect, useState, useCallback } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { Heart, Globe, Lock, Copy, Loader2, X, ArrowRightLeft } from 'lucide-react';
import Seo from '../../components/Seo';
import AccountLayout from './AccountLayout';
import EmptyState from '../../components/EmptyState';
import { Input } from '../../components/ui/input';
import { Switch } from '../../components/ui/switch';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '../../components/ui/select';
import { wishlistsService } from '../../services/wishlistsService';
import { useToast } from '../../hooks/use-toast';

const money = (n, currency = 'USD') => new Intl.NumberFormat('en-US', { style: 'currency', currency: currency || 'USD' }).format(n || 0);

/** Lightweight product tile for a wishlist item — the multi-wishlist API returns a lighter product summary (no rating/category/etc.) than the full storefront product shape ProductCard expects, so this renders its own tile instead of reusing ProductCard. */
const WishlistItemTile = ({ item, wishlists, currentId, onRemove, onMove, busy }) => {
  const { product } = item;
  if (!product) {
    return (
      <div className="bg-white rounded-2xl border border-border p-4 flex items-center justify-between gap-3">
        <p className="text-sm text-muted-foreground">{item.unavailableReason || 'Product no longer available.'}</p>
        <button type="button" onClick={() => onRemove(item)} aria-label="Remove" className="grid place-items-center w-8 h-8 rounded-full hover:bg-secondary transition-colors shrink-0"><X className="w-4 h-4" /></button>
      </div>
    );
  }
  const price = product.salePrice != null ? product.salePrice : product.basePrice;
  const otherWishlists = (wishlists || []).filter((w) => w.id !== currentId);

  return (
    <div className="bg-white rounded-2xl border border-border overflow-hidden group">
      <Link to={`/product/${product.slug || product.id}`} className="block aspect-square bg-secondary overflow-hidden">
        {product.thumbnail?.url && (
          <img src={product.thumbnail.url} alt={product.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
        )}
      </Link>
      <div className="p-3">
        <Link to={`/product/${product.slug || product.id}`} className="text-sm font-semibold line-clamp-2 hover:text-primary transition-colors">{product.title}</Link>
        <p className="text-sm font-bold mt-1">{money(price, product.currency)}</p>
        <div className="mt-2.5 flex items-center gap-1.5">
          {otherWishlists.length > 0 && (
            <Select disabled={busy} onValueChange={(toId) => onMove(item, toId)}>
              <SelectTrigger className="h-8 text-xs flex-1" aria-label="Move to another wishlist">
                <ArrowRightLeft className="w-3 h-3 mr-1 shrink-0" /> <SelectValue placeholder="Move to…" />
              </SelectTrigger>
              <SelectContent>
                {otherWishlists.map((w) => <SelectItem key={w.id} value={w.id}>{w.name}</SelectItem>)}
              </SelectContent>
            </Select>
          )}
          <button
            type="button"
            onClick={() => onRemove(item)}
            disabled={busy}
            aria-label={`Remove ${product.title}`}
            className="grid place-items-center w-8 h-8 rounded-full border border-border hover:bg-destructive/10 hover:text-destructive transition-colors shrink-0 disabled:opacity-60"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};

const AnalyticsPanel = ({ wishlistId }) => {
  const [data, setData] = useState(null);
  useEffect(() => {
    let cancelled = false;
    wishlistsService.getAnalytics(wishlistId).then((res) => { if (!cancelled) setData(res); }).catch(() => { if (!cancelled) setData(false); });
    return () => { cancelled = true; };
  }, [wishlistId]);

  if (data === null) return <div className="grid place-items-center py-10"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>;
  if (data === false) return <p className="text-sm text-muted-foreground">Analytics aren't available for this wishlist right now.</p>;

  const cards = [
    { label: 'Items saved', value: data.itemCount },
    { label: 'Total value', value: money(data.totalValue, data.currency) },
    { label: 'Added last 7 days', value: data.addedLast7Days },
    { label: 'No longer available', value: data.unavailableCount },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {cards.map((c) => (
        <div key={c.label} className="bg-white rounded-2xl border border-border p-5">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{c.label}</p>
          <p className="text-2xl font-black mt-1.5">{c.value}</p>
        </div>
      ))}
    </div>
  );
};

/** Phase 17A.2, Part 2 — single-wishlist view: rename, toggle public/private + share link, manage items, move an item to another wishlist, and per-wishlist analytics (via `?tab=analytics`). */
const WishlistDetailPage = () => {
  const { id } = useParams();
  const [searchParams, setSearchParams] = useSearchParams();
  const { toast } = useToast();
  const [wishlist, setWishlist] = useState(null);
  const [allWishlists, setAllWishlists] = useState([]);
  const [name, setName] = useState('');
  const [savingName, setSavingName] = useState(false);
  const [busyItem, setBusyItem] = useState(null);
  const tab = searchParams.get('tab') === 'analytics' ? 'analytics' : 'items';

  const load = useCallback(() => {
    wishlistsService.getById(id).then((wl) => { setWishlist(wl); setName(wl.name); }).catch(() => setWishlist(false));
    wishlistsService.list().then(setAllWishlists).catch(() => setAllWishlists([]));
  }, [id]);

  useEffect(() => { load(); }, [load]);

  const saveName = async () => {
    if (!name.trim() || name === wishlist.name) return;
    setSavingName(true);
    try {
      const updated = await wishlistsService.rename(id, { name: name.trim() });
      setWishlist((w) => ({ ...w, ...updated }));
      toast({ title: 'Wishlist renamed' });
    } catch (err) {
      toast({ title: 'Could not rename wishlist', description: err?.message || 'Please try again.', variant: 'destructive' });
    } finally {
      setSavingName(false);
    }
  };

  const toggleVisibility = async () => {
    try {
      const updated = await wishlistsService.setVisibility(id, !wishlist.isPublic);
      setWishlist((w) => ({ ...w, ...updated }));
    } catch (err) {
      toast({ title: 'Could not update visibility', description: err?.message || 'Please try again.', variant: 'destructive' });
    }
  };

  const copyLink = () => {
    if (!wishlist?.shareToken) return;
    const url = `${window.location.origin}/wishlists/shared/${wishlist.shareToken}`;
    navigator.clipboard?.writeText(url);
    toast({ title: 'Link copied', description: url });
  };

  const removeItem = async (item) => {
    setBusyItem(item.id);
    try {
      const updated = await wishlistsService.removeItem(id, item.product?.id || item.id);
      setWishlist((w) => ({ ...w, ...updated }));
    } catch (err) {
      toast({ title: 'Could not remove item', description: err?.message || 'Please try again.', variant: 'destructive' });
    } finally {
      setBusyItem(null);
    }
  };

  const moveItem = async (item, toWishlistId) => {
    setBusyItem(item.id);
    try {
      const result = await wishlistsService.moveItem(id, item.product.id, toWishlistId);
      setWishlist((w) => ({ ...w, ...result.source }));
      toast({ title: 'Item moved' });
    } catch (err) {
      toast({ title: 'Could not move item', description: err?.message || 'Please try again.', variant: 'destructive' });
    } finally {
      setBusyItem(null);
    }
  };

  if (wishlist === false) {
    return (
      <>
        <Seo title="Wishlist" noIndex />
        <AccountLayout title="Wishlist" subtitle="">
          <EmptyState title="Wishlist not found" message="It may have been deleted, or it doesn't belong to your account." actionLabel="Back to My Wishlists" actionTo="/wishlists" />
        </AccountLayout>
      </>
    );
  }

  return (
    <>
      <Seo title={wishlist ? wishlist.name : 'Wishlist'} noIndex />
      <AccountLayout title={wishlist?.name || 'Wishlist'} subtitle="Manage items, sharing, and analytics for this wishlist.">
        {!wishlist ? (
          <div className="grid place-items-center py-20"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
        ) : (
          <>
            <div className="bg-white rounded-3xl border border-border p-6 mb-6">
              <div className="flex flex-wrap items-end gap-3">
                <div className="flex-1 min-w-[14rem]">
                  <label htmlFor="wishlist-name" className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Name</label>
                  <Input id="wishlist-name" value={name} onChange={(e) => setName(e.target.value)} onBlur={saveName} maxLength={100} className="mt-1" />
                </div>
                {savingName && <Loader2 className="w-4 h-4 animate-spin text-muted-foreground mb-2.5" />}
                <div className="flex items-center gap-2 mb-1">
                  <Switch checked={!!wishlist.isPublic} onCheckedChange={toggleVisibility} aria-label="Public wishlist" />
                  <span className="text-sm font-medium inline-flex items-center gap-1.5">
                    {wishlist.isPublic ? <Globe className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                    {wishlist.isPublic ? 'Public' : 'Private'}
                  </span>
                </div>
                {wishlist.isPublic && wishlist.shareToken && (
                  <button type="button" onClick={copyLink} className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full border border-border text-sm font-semibold hover:bg-secondary transition-colors mb-1">
                    <Copy className="w-3.5 h-3.5" /> Copy share link
                  </button>
                )}
              </div>
            </div>

            <div className="flex items-center gap-1.5 mb-6">
              {[{ id: 'items', label: 'Items' }, { id: 'analytics', label: 'Analytics' }].map((t) => (
                <button
                  key={t.id}
                  onClick={() => setSearchParams(t.id === 'items' ? {} : { tab: t.id })}
                  className={`px-4 py-2 rounded-full text-sm font-semibold transition-colors ${tab === t.id ? 'brand-gradient text-white' : 'bg-white border border-border hover:bg-secondary'}`}
                >
                  {t.label}
                </button>
              ))}
            </div>

            {tab === 'analytics' ? (
              <AnalyticsPanel wishlistId={id} />
            ) : wishlist.items.length === 0 ? (
              <EmptyState
                title="This wishlist is empty"
                message="Tap the heart icon on any product to save it here, or move an item over from another wishlist."
                actionLabel="Browse the Shop"
                actionTo="/shop"
              >
                <span className="grid place-items-center w-14 h-14 rounded-full bg-secondary mx-auto -mt-2 mb-2"><Heart className="w-6 h-6 text-primary" /></span>
              </EmptyState>
            ) : (
              <div className="grid grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                {wishlist.items.map((item) => (
                  <WishlistItemTile
                    key={item.id}
                    item={item}
                    wishlists={allWishlists}
                    currentId={id}
                    onRemove={removeItem}
                    onMove={moveItem}
                    busy={busyItem === item.id}
                  />
                ))}
              </div>
            )}
          </>
        )}
      </AccountLayout>
    </>
  );
};

export default WishlistDetailPage;
