import React, { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Lock, Eye, EyeOff } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import Seo from '../components/Seo';
import { resetPasswordRequest } from '../services/authService';
import { useToast } from '../hooks/use-toast';

/**
 * Shared "reset password" page for every account type (buyer, seller,
 * admin) — one backend endpoint, one page. The token comes from the URL
 * path, matching the link the backend actually emails:
 * `${frontendUrl}/reset-password/:token` (see auth.service.js#forgotPassword).
 */
const ResetPasswordPage = () => {
  const { token } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!password.trim() || password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    setError('');
    setSubmitting(true);
    try {
      await resetPasswordRequest(token, password);
      setDone(true);
      toast({ title: 'Password reset', description: 'You can now log in with your new password.' });
    } catch (err) {
      setError(err?.message || 'This reset link is invalid or has expired. Please request a new one.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Seo title="Reset Your Password" description="Choose a new password for your PicaMarts account." noIndex />
      <Header />
      <div className="flex-1 grid place-items-center px-5 py-16">
        <div className="w-full max-w-md">
          <div className="bg-white rounded-3xl border border-border soft-shadow p-8">
            <h1 className="text-2xl font-black tracking-tight text-center">Choose a new password</h1>
            <p className="text-sm text-muted-foreground text-center mt-2">
              Enter a new password to finish resetting your account.
            </p>

            {done ? (
              <div className="mt-8 space-y-5">
                <div className="text-sm text-center bg-secondary/60 rounded-2xl p-5">
                  Your password has been reset. Please log in again.
                </div>
                <button
                  onClick={() => navigate('/login')}
                  className="w-full px-6 py-3.5 rounded-full brand-gradient text-white font-semibold soft-shadow hover:soft-shadow-lg transition-shadow"
                >
                  Go to sign in
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="mt-8 space-y-4" noValidate>
                <div>
                  <label htmlFor="password" className="text-sm font-medium block mb-1.5">New password</label>
                  <div className="flex items-center gap-2 bg-secondary/60 rounded-2xl px-4 py-3 border border-transparent focus-within:border-primary transition-colors">
                    <Lock className="w-4 h-4 text-muted-foreground shrink-0" />
                    <input id="password" type={showPw ? 'text' : 'password'} autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="At least 6 characters" className="bg-transparent outline-none text-sm w-full" />
                    <button type="button" aria-label={showPw ? 'Hide password' : 'Show password'} onClick={() => setShowPw((s) => !s)} className="text-muted-foreground shrink-0">
                      {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
                <div>
                  <label htmlFor="confirmPassword" className="text-sm font-medium block mb-1.5">Confirm password</label>
                  <div className="flex items-center gap-2 bg-secondary/60 rounded-2xl px-4 py-3 border border-transparent focus-within:border-primary transition-colors">
                    <Lock className="w-4 h-4 text-muted-foreground shrink-0" />
                    <input id="confirmPassword" type={showPw ? 'text' : 'password'} autoComplete="new-password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="Re-enter password" className="bg-transparent outline-none text-sm w-full" />
                  </div>
                </div>

                {error && <p className="text-sm text-destructive" role="alert">{error}</p>}

                <button type="submit" disabled={submitting} className="w-full px-6 py-3.5 rounded-full brand-gradient text-white font-semibold soft-shadow hover:soft-shadow-lg transition-shadow disabled:opacity-60 disabled:cursor-not-allowed">
                  {submitting ? 'Resetting…' : 'Reset password'}
                </button>
              </form>
            )}

            <p className="text-sm text-center text-muted-foreground mt-6">
              <Link to="/forgot-password" className="font-semibold text-primary hover:underline">Request a new link</Link>
            </p>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default ResetPasswordPage;
