import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingBag, Minus, Plus, X, ArrowRight, ShieldCheck, Tag, Truck, Zap } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import Seo from '../components/Seo';
import Breadcrumbs from '../components/Breadcrumbs';
import { useStore } from '../context/StoreContext';
import { useToast } from '../hooks/use-toast';
import { isPhysicalItem, getItemShippingInfo, getCartShippingTotal } from '../lib/shipping';

const CartPage = () => {
  const { cart, updateQty, removeFromCart, cartSubtotal } = useStore();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [promo, setPromo] = useState('');

  const shippingTotal = getCartShippingTotal(cart);
  const cartTotal = cartSubtotal + shippingTotal;

  const applyPromo = (e) => {
    e.preventDefault();
    toast({ title: promo.trim() ? 'Promo code not recognized' : 'Enter a promo code first', variant: 'destructive' });
  };

  const handleCheckout = () => navigate('/checkout');

  return (
    <div className="min-h-screen">
      <Seo title="Your Cart" description="Review your cart and check out instantly on PicaMarts." noIndex />
    <Header />
      <div className="mx-auto max-w-[90rem] px-5 lg:px-8 pt-10 pb-24">
        <Breadcrumbs items={[{ name: 'Cart' }]} />
        <h1 className="text-4xl md:text-5xl font-black tracking-tight">Your <span className="brand-text">Cart</span></h1>
        <p className="text-muted-foreground mt-3">{cart.length} item{cart.length === 1 ? '' : 's'} in your cart.</p>

        {cart.length === 0 ? (
          <div className="mt-10 bg-white rounded-3xl border border-border p-16 text-center max-w-lg mx-auto">
            <span className="grid place-items-center w-16 h-16 rounded-full bg-secondary mx-auto mb-5">
              <ShoppingBag className="w-7 h-7 text-primary" />
            </span>
            <h2 className="text-lg font-bold">Your cart is empty</h2>
            <p className="text-sm text-muted-foreground mt-1.5">Add a product to get started — every download is instant at checkout.</p>
            <Link to="/shop" className="inline-flex items-center gap-1.5 justify-center mt-6 px-6 py-3 rounded-full brand-gradient text-white font-semibold">
              Browse the Shop <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        ) : (
          <div className="mt-10 flex flex-col lg:flex-row gap-8">
            {/* Items */}
            <div className="flex-1 space-y-4">
              {cart.map((item) => {
                const physical = isPhysicalItem(item);
                const shipInfo = getItemShippingInfo(item);
                return (
                <div key={item.id} className="bg-white rounded-3xl border border-border p-4">
                  <div className="flex flex-wrap sm:flex-nowrap items-center gap-3 sm:gap-4">
                    <Link to={`/product/${item.productId}`} className="order-1 sm:order-1 w-20 h-20 rounded-2xl overflow-hidden bg-secondary shrink-0">
                      <img src={item.img} alt={item.title} className="w-full h-full object-cover" />
                    </Link>
                    <div className="order-2 sm:order-2 flex-1 min-w-[90px] sm:min-w-0">
                      <Link to={`/product/${item.productId}`} className="font-semibold text-sm hover:text-primary transition-colors line-clamp-1">{item.title}</Link>
                      <p className="text-sm font-bold mt-1.5">${item.price.toFixed(2)}</p>
                    </div>
                    <button aria-label="Remove item" onClick={() => removeFromCart(item.id).catch(() => toast({ title: 'Could not remove item', variant: 'destructive' }))} className="order-3 sm:order-4 w-9 h-9 grid place-items-center rounded-full hover:bg-secondary transition-colors shrink-0 text-muted-foreground hover:text-destructive">
                      <X className="w-4 h-4" />
                    </button>
                    <div className="order-4 sm:order-3 flex items-center gap-2 border border-border rounded-full px-1 py-1 shrink-0">
                      <button aria-label="Decrease quantity" onClick={() => updateQty(item.id, item.qty - 1).catch(() => toast({ title: 'Could not update quantity', variant: 'destructive' }))} className="w-7 h-7 grid place-items-center rounded-full hover:bg-secondary transition-colors">
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="text-sm font-medium w-5 text-center">{item.qty}</span>
                      <button aria-label="Increase quantity" onClick={() => updateQty(item.id, item.qty + 1).catch(() => toast({ title: 'Could not update quantity', variant: 'destructive' }))} className="w-7 h-7 grid place-items-center rounded-full hover:bg-secondary transition-colors">
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Shipping — read straight from the product's saved shipping data */}
                  {physical ? (
                    <div className="mt-3 pt-3 border-t border-border grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-1.5 text-xs">
                      <span className="col-span-2 sm:col-span-3 flex items-center gap-1.5 text-muted-foreground font-semibold mb-0.5">
                        <Truck className="w-3.5 h-3.5" /> Shipping
                      </span>
                      <div><dt className="text-muted-foreground inline">Cost: </dt><dd className="font-medium inline">{shipInfo.isFree ? 'Free' : `$${shipInfo.cost.toFixed(2)}`}</dd></div>
                      <div><dt className="text-muted-foreground inline">Method: </dt><dd className="font-medium inline">{shipInfo.method}</dd></div>
                      {shipInfo.estimatedDelivery && <div><dt className="text-muted-foreground inline">Delivery: </dt><dd className="font-medium inline">{shipInfo.estimatedDelivery}</dd></div>}
                      {shipInfo.processingTime && <div><dt className="text-muted-foreground inline">Processing: </dt><dd className="font-medium inline">{shipInfo.processingTime}</dd></div>}
                      {shipInfo.shipsFrom && <div><dt className="text-muted-foreground inline">Ships From: </dt><dd className="font-medium inline">{shipInfo.shipsFrom}</dd></div>}
                    </div>
                  ) : (
                    <div className="mt-3 pt-3 border-t border-border">
                      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-primary">
                        <Zap className="w-3.5 h-3.5" /> Instant Digital Download
                      </span>
                    </div>
                  )}
                </div>
                );
              })}
            </div>

            {/* Summary */}
            <aside className="lg:w-96 shrink-0">
              <div className="bg-white rounded-3xl border border-border soft-shadow p-6 lg:sticky lg:top-24">
                <h2 className="font-bold text-lg mb-5">Order Summary</h2>
                <form onSubmit={applyPromo} className="flex items-center gap-2 mb-5">
                  <div className="flex items-center gap-2 flex-1 bg-secondary/60 rounded-full px-4 py-2.5">
                    <Tag className="w-4 h-4 text-muted-foreground" />
                    <input value={promo} onChange={(e) => setPromo(e.target.value)} placeholder="Promo code" aria-label="Promo code" className="bg-transparent outline-none text-sm w-full" />
                  </div>
                  <button type="submit" className="px-4 py-2.5 rounded-full border border-border text-sm font-semibold hover:bg-secondary transition-colors shrink-0">Apply</button>
                </form>
                <div className="space-y-2.5 text-sm">
                  <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span className="font-medium">${cartSubtotal.toFixed(2)}</span></div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Shipping</span>
                    <span className="font-medium">{shippingTotal > 0 ? `$${shippingTotal.toFixed(2)}` : (cart.some(isPhysicalItem) ? 'Free' : 'Instant Download')}</span>
                  </div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Taxes</span><span className="font-medium">Calculated at checkout</span></div>
                </div>
                <div className="flex justify-between items-baseline mt-4 pt-4 border-t border-border">
                  <span className="font-semibold">Total</span>
                  <span className="text-2xl font-black">${cartTotal.toFixed(2)}</span>
                </div>
                <button onClick={handleCheckout} className="w-full mt-6 px-6 py-3.5 rounded-full brand-gradient text-white font-semibold soft-shadow hover:soft-shadow-lg transition-shadow">
                  Checkout
                </button>
                <p className="flex items-center gap-1.5 justify-center text-xs text-muted-foreground mt-4">
                  <ShieldCheck className="w-3.5 h-3.5" /> Secure checkout{cart.every((i) => !isPhysicalItem(i)) ? ' · Instant download' : ''}
                </p>
              </div>
            </aside>
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
};

export default CartPage;
