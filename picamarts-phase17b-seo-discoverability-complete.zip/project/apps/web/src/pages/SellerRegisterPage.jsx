import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Store, User, Mail, Lock, Eye, EyeOff } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import Seo from '../components/Seo';
import { useSellerAuth } from '../context/SellerAuthContext';
import { useToast } from '../hooks/use-toast';

const SellerRegisterPage = () => {
  const { register } = useSellerAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [storeName, setStoreName] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [agree, setAgree] = useState(false);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!storeName.trim() || !name.trim() || !email.trim() || !password.trim()) {
      setError('Please fill in all fields.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    if (!agree) {
      setError('Please agree to the Seller Terms to continue.');
      return;
    }
    setError('');
    setSubmitting(true);
    try {
      await register({ storeName: storeName.trim(), name: name.trim(), email: email.trim(), password });
      // The backend requires a verified email before the first login (same
      // rule as buyer registration), so send them to sign in rather than
      // the dashboard. Their store application is submitted automatically
      // the first time they log in (see SellerAuthContext).
      toast({ title: 'Account created!', description: 'Check your email to verify your account, then sign in to finish setting up your store.' });
      navigate('/seller/login');
    } catch (err) {
      setError(err?.message || 'Unable to create your account. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Seo title="Open Your Store" description="Create your PicaMarts seller account and start selling digital art." noIndex />
      <Header />
      <div className="flex-1 grid place-items-center px-5 py-16">
        <div className="w-full max-w-md">
          <div className="bg-white rounded-3xl border border-border soft-shadow p-8">
            <h1 className="text-2xl font-black tracking-tight text-center">Create your seller account</h1>
            <p className="text-sm text-muted-foreground text-center mt-2">Set up your store and start listing products.</p>

            <form onSubmit={handleSubmit} className="mt-8 space-y-4" noValidate>
              <div>
                <label htmlFor="storeName" className="text-sm font-medium block mb-1.5">Store name</label>
                <div className="flex items-center gap-2 bg-secondary/60 rounded-2xl px-4 py-3 border border-transparent focus-within:border-primary transition-colors">
                  <Store className="w-4 h-4 text-muted-foreground shrink-0" />
                  <input id="storeName" value={storeName} onChange={(e) => setStoreName(e.target.value)} placeholder="Studio Lume" className="bg-transparent outline-none text-sm w-full" />
                </div>
              </div>
              <div>
                <label htmlFor="name" className="text-sm font-medium block mb-1.5">Your name</label>
                <div className="flex items-center gap-2 bg-secondary/60 rounded-2xl px-4 py-3 border border-transparent focus-within:border-primary transition-colors">
                  <User className="w-4 h-4 text-muted-foreground shrink-0" />
                  <input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Jane Doe" className="bg-transparent outline-none text-sm w-full" />
                </div>
              </div>
              <div>
                <label htmlFor="email" className="text-sm font-medium block mb-1.5">Email</label>
                <div className="flex items-center gap-2 bg-secondary/60 rounded-2xl px-4 py-3 border border-transparent focus-within:border-primary transition-colors">
                  <Mail className="w-4 h-4 text-muted-foreground shrink-0" />
                  <input id="email" type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" className="bg-transparent outline-none text-sm w-full" />
                </div>
              </div>
              <div>
                <label htmlFor="password" className="text-sm font-medium block mb-1.5">Password</label>
                <div className="flex items-center gap-2 bg-secondary/60 rounded-2xl px-4 py-3 border border-transparent focus-within:border-primary transition-colors">
                  <Lock className="w-4 h-4 text-muted-foreground shrink-0" />
                  <input id="password" type={showPw ? 'text' : 'password'} autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="At least 6 characters" className="bg-transparent outline-none text-sm w-full" />
                  <button type="button" aria-label={showPw ? 'Hide password' : 'Show password'} onClick={() => setShowPw((s) => !s)} className="text-muted-foreground shrink-0">
                    {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <label className="flex items-start gap-2.5 text-sm text-muted-foreground cursor-pointer">
                <input type="checkbox" checked={agree} onChange={(e) => setAgree(e.target.checked)} className="mt-0.5 accent-primary" />
                I agree to the Seller Terms &amp; Conditions and licensing policies.
              </label>

              {error && <p className="text-sm text-destructive font-medium" role="alert">{error}</p>}

              <button type="submit" disabled={submitting} className="w-full brand-gradient text-white font-semibold py-3.5 rounded-2xl hover:opacity-95 active:scale-[0.99] transition-all disabled:opacity-60 disabled:cursor-not-allowed">
                {submitting ? 'Creating account…' : 'Create store'}
              </button>
            </form>

            <p className="text-sm text-muted-foreground text-center mt-6">
              Already selling? <Link to="/seller/login" className="text-primary font-semibold hover:underline">Sign in</Link>
            </p>
          </div>
          <p className="text-center mt-6">
            <Link to="/become-a-seller" className="text-sm font-medium text-muted-foreground hover:text-foreground">← Back to seller info</Link>
          </p>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default SellerRegisterPage;
