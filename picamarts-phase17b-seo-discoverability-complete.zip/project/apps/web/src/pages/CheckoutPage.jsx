import React, { useEffect, useMemo, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';
import {
  ShieldCheck, Lock, ArrowLeft, CreditCard, CheckCircle2, Wallet, Building2,
  FileText, Download, Truck, Zap, AlertTriangle,
} from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import Seo from '../components/Seo';
import Breadcrumbs from '../components/Breadcrumbs';
import EmptyState from '../components/EmptyState';
import { useStore } from '../context/StoreContext';
import { useToast } from '../hooks/use-toast';
import { isPhysicalItem, getItemShippingInfo, getCartShippingTotal, cartHasPhysicalItems, cartIsAllDigital } from '../lib/shipping';
import { getCheckoutSummary, estimateShipping } from '../services/checkoutService';
import ShippingEstimateCard from '../components/shipping/ShippingEstimateCard';
import { createOrder, getOrderById } from '../services/orderService';
import { createPaymentIntent, confirmPayment, getPayment } from '../services/paymentService';
import { stripePromise, isStripeConfigured } from '../lib/stripe';
import { getErrorMessage } from '../lib/errorMessage';

// Only "card" is backed by the real payment flow (Stripe). The others are
// kept visible — buyers researching PicaMarts should see the roadmap — but
// are disabled rather than faked, since there's no backend support for them.
const PAYMENT_METHODS = [
  { id: 'card', label: 'Credit Card', icon: CreditCard, live: true },
  { id: 'paypal', label: 'PayPal', icon: Wallet, live: false },
  { id: 'bank', label: 'Bank Transfer', icon: Building2, live: false },
  { id: 'wallet', label: 'Picamarts Wallet', icon: Wallet, live: false },
];

const emptyAddress = { fullName: '', line1: '', city: '', state: '', postalCode: '', country: '', phone: '' };

const AddressFields = ({ value, onChange, idPrefix }) => {
  const set = (k) => (e) => onChange({ ...value, [k]: e.target.value });
  return (
    <div className="grid sm:grid-cols-2 gap-4">
      <div className="sm:col-span-2">
        <label htmlFor={`${idPrefix}-name`} className="text-sm font-medium block mb-1.5">Full name</label>
        <input id={`${idPrefix}-name`} value={value.fullName} onChange={set('fullName')} required className="w-full bg-secondary/60 rounded-xl px-4 py-2.5 text-sm outline-none border border-transparent focus:border-primary" />
      </div>
      <div className="sm:col-span-2">
        <label htmlFor={`${idPrefix}-line1`} className="text-sm font-medium block mb-1.5">Address</label>
        <input id={`${idPrefix}-line1`} value={value.line1} onChange={set('line1')} required className="w-full bg-secondary/60 rounded-xl px-4 py-2.5 text-sm outline-none border border-transparent focus:border-primary" />
      </div>
      <div>
        <label className="text-sm font-medium block mb-1.5">City</label>
        <input value={value.city} onChange={set('city')} required className="w-full bg-secondary/60 rounded-xl px-4 py-2.5 text-sm outline-none border border-transparent focus:border-primary" />
      </div>
      <div>
        <label className="text-sm font-medium block mb-1.5">State/Province</label>
        <input value={value.state} onChange={set('state')} className="w-full bg-secondary/60 rounded-xl px-4 py-2.5 text-sm outline-none border border-transparent focus:border-primary" />
      </div>
      <div>
        <label className="text-sm font-medium block mb-1.5">Postal code</label>
        <input value={value.postalCode} onChange={set('postalCode')} required className="w-full bg-secondary/60 rounded-xl px-4 py-2.5 text-sm outline-none border border-transparent focus:border-primary" />
      </div>
      <div>
        <label className="text-sm font-medium block mb-1.5">Country</label>
        <input value={value.country} onChange={set('country')} required className="w-full bg-secondary/60 rounded-xl px-4 py-2.5 text-sm outline-none border border-transparent focus:border-primary" />
      </div>
      <div className="sm:col-span-2">
        <label className="text-sm font-medium block mb-1.5">Phone</label>
        <input value={value.phone} onChange={set('phone')} className="w-full bg-secondary/60 rounded-xl px-4 py-2.5 text-sm outline-none border border-transparent focus:border-primary" />
      </div>
    </div>
  );
};

const cardElementOptions = {
  style: {
    base: {
      fontSize: '14px',
      color: '#0f172a',
      '::placeholder': { color: '#94a3b8' },
    },
    invalid: { color: '#dc2626' },
  },
};

/** Renders the confirmed backend order using the same visual layout the old mock success screen used. Backend order items carry titleSnapshot/thumbnailSnapshot/quantity/lockedPrice, not the cart's title/img/qty — mapped inline below. */
const OrderConfirmed = ({ order }) => {
  const { toast } = useToast();
  const items = (order.items || []).map((item) => ({
    id: item.product,
    title: item.titleSnapshot,
    img: item.thumbnailSnapshot?.url || '',
    qty: item.quantity,
  }));
  const download = (item) => {
    toast({ title: 'Download started', description: `${item.title} — file delivery isn't wired up on the backend yet, so nothing is actually sent.` });
  };
  return (
    <div className="min-h-screen flex flex-col">
      <Seo title="Order Confirmed" description="Your PicaMarts order is confirmed." noIndex />
      <Header />
      <div className="flex-1 mx-auto max-w-2xl w-full px-5 py-16 text-center">
        <span className="grid place-items-center w-20 h-20 rounded-full bg-emerald-100 text-emerald-600 mx-auto mb-6">
          <CheckCircle2 className="w-9 h-9" />
        </span>
        <h1 className="text-2xl md:text-3xl font-black tracking-tight">Thank you for your order!</h1>
        <p className="text-muted-foreground mt-2 leading-relaxed">Your files are ready to download instantly.</p>

        <div className="mt-8 bg-white rounded-3xl border border-border soft-shadow p-6 text-left">
          <div className="flex flex-wrap items-center justify-between gap-3 pb-4 mb-4 border-b border-border">
            <div>
              <p className="text-xs text-muted-foreground">Order Number</p>
              <p className="font-bold">{order.orderNumber}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Invoice</p>
              <button onClick={() => toast({ title: 'Invoice download started', description: `INV-${order.orderNumber}` })} className="inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:underline">
                <FileText className="w-3.5 h-3.5" /> INV-{order.orderNumber}
              </button>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Estimated Delivery</p>
              <p className="font-semibold flex items-center gap-1.5">
                <Truck className="w-3.5 h-3.5" />
                {cartIsAllDigital(order.items) ? 'Instant' : 'See shipping details'}
              </p>
            </div>
          </div>
          <ul className="space-y-3">
            {items.map((item, i) => {
              const physical = isPhysicalItem(order.items[i]);
              const info = getItemShippingInfo(order.items[i]);
              return (
                <li key={`${item.id}-${i}`} className="flex items-center gap-3">
                  <img src={item.img} alt={item.title} className="w-10 h-10 rounded-lg object-cover shrink-0 bg-secondary" />
                  <span className="flex-1 min-w-0 text-sm truncate">{item.title}</span>
                  {physical ? (
                    <span className="text-xs font-semibold text-muted-foreground text-right shrink-0">
                      {info?.method}{info?.estimatedDelivery ? ` · ${info.estimatedDelivery}` : ''}
                    </span>
                  ) : (
                    <button onClick={() => download(item)} className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full brand-gradient text-white">
                      <Download className="w-3 h-3" /> Download
                    </button>
                  )}
                </li>
              );
            })}
          </ul>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-3 mt-8">
          <Link to="/downloads" className="inline-flex items-center gap-1.5 px-6 py-3 rounded-full brand-gradient text-white font-semibold soft-shadow hover:soft-shadow-lg transition-shadow">
            Go to Downloads
          </Link>
          <Link to="/orders" className="inline-flex items-center gap-1.5 px-6 py-3 rounded-full border border-border font-semibold hover:bg-secondary transition-colors">
            View Order
          </Link>
          <Link to="/shop" className="inline-flex items-center gap-1.5 px-6 py-3 rounded-full border border-border font-semibold hover:bg-secondary transition-colors">
            Continue Shopping
          </Link>
        </div>
      </div>
      <Footer />
    </div>
  );
};

const CheckoutForm = () => {
  const { cart, cartSubtotal, user, updateQty, removeFromCart, refreshOrders } = useStore();
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const stripe = useStripe();
  const elements = useElements();

  const retryOrderId = location.state?.retryOrderId || null;

  const [phase, setPhase] = useState(retryOrderId ? 'loadingRetry' : 'address');
  const [order, setOrder] = useState(null); // real backend order, once created
  const [paymentInfo, setPaymentInfo] = useState(null); // { payment, clientSecret }

  const [email, setEmail] = useState(user?.email || '');
  const [billing, setBilling] = useState({ ...emptyAddress, fullName: user?.name || '' });
  const [shipping, setShipping] = useState({ ...emptyAddress, fullName: user?.name || '' });
  const [sameAsBilling, setSameAsBilling] = useState(true);
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [notes, setNotes] = useState('');
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [cardError, setCardError] = useState(null);

  const [checkoutSummary, setCheckoutSummary] = useState(null);
  const [summaryLoading, setSummaryLoading] = useState(false);

  // Phase 14.2, Part 5/6 — real backend shipping estimate for the buyer's
  // current destination. Informational only (see ShippingEstimateCard's own
  // header comment) — never feeds order creation, which still uses the
  // cart's saved per-product shipping data via lib/shipping.js.
  const [shippingEstimate, setShippingEstimate] = useState(null);
  const [shippingEstimateLoading, setShippingEstimateLoading] = useState(false);
  const [shippingEstimateError, setShippingEstimateError] = useState(false);
  const [selectedMethodKey, setSelectedMethodKey] = useState(null);

  const [submitting, setSubmitting] = useState(false);
  const [paying, setPaying] = useState(false);

  const hasPhysical = cartHasPhysicalItems(cart);
  const allDigital = cartIsAllDigital(cart);
  const shippingCost = getCartShippingTotal(cart);
  const tax = 0; // Digital goods aren't taxed on this backend yet.
  const estimatedTotal = Math.max(0, Math.round((cartSubtotal + tax + shippingCost) * 100) / 100);

  // Non-destructive checkout preview — tells the buyer up front if the cart
  // has a blocking issue (out of stock, price changed, etc.) before they
  // fill in address details.
  useEffect(() => {
    if (phase !== 'address' || cart.length === 0) return;
    let cancelled = false;
    setSummaryLoading(true);
    getCheckoutSummary()
      .then((res) => { if (!cancelled) setCheckoutSummary(res); })
      .catch(() => { if (!cancelled) setCheckoutSummary(null); })
      .finally(() => { if (!cancelled) setSummaryLoading(false); });
    return () => { cancelled = true; };
  }, [phase, cart.length]);

  // Real shipping estimate — debounced against the destination address the
  // buyer is currently entering, only while there are physical items.
  const destination = sameAsBilling ? billing : shipping;
  useEffect(() => {
    if (phase !== 'address' || !hasPhysical || !destination.country.trim()) {
      setShippingEstimate(null);
      return;
    }
    let cancelled = false;
    setShippingEstimateLoading(true);
    setShippingEstimateError(false);
    const timer = setTimeout(() => {
      estimateShipping({ country: destination.country, state: destination.state })
        .then((res) => { if (!cancelled) setShippingEstimate(res); })
        .catch(() => { if (!cancelled) setShippingEstimateError(true); })
        .finally(() => { if (!cancelled) setShippingEstimateLoading(false); });
    }, 500);
    return () => { cancelled = true; clearTimeout(timer); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, hasPhysical, destination.country, destination.state]);

  // Retry mode: a previous payment attempt failed. Load the existing order
  // (already has addresses saved server-side) and create a fresh payment
  // intent for it, skipping straight to the payment step — the cart was
  // already cleared when the order was originally created, so there's
  // nothing left to re-collect.
  useEffect(() => {
    if (!retryOrderId) return;
    let cancelled = false;
    (async () => {
      try {
        const existingOrder = await getOrderById(retryOrderId);
        const intent = await createPaymentIntent(retryOrderId);
        if (cancelled) return;
        setOrder(existingOrder);
        setPaymentInfo(intent);
        setPhase('payment');
      } catch (err) {
        if (cancelled) return;
        toast({ title: 'Could not resume checkout', description: getErrorMessage(err), variant: 'destructive' });
        navigate('/orders');
      }
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [retryOrderId]);

  const submitAddress = async (e) => {
    e.preventDefault();
    if (!email.trim() || !billing.fullName.trim() || !billing.line1.trim() || !billing.city.trim() || !billing.postalCode.trim() || !billing.country.trim()) {
      toast({ title: 'Missing details', description: 'Please complete your contact and billing details.', variant: 'destructive' });
      return;
    }
    if (hasPhysical && !sameAsBilling && (!shipping.fullName.trim() || !shipping.line1.trim() || !shipping.city.trim() || !shipping.postalCode.trim() || !shipping.country.trim())) {
      toast({ title: 'Missing shipping address', description: 'Please complete your shipping address.', variant: 'destructive' });
      return;
    }
    if (paymentMethod !== 'card') {
      toast({ title: 'Payment method unavailable', description: 'Only Credit Card checkout is live right now — please select it to continue.', variant: 'destructive' });
      return;
    }
    if (!agreedToTerms) {
      toast({ title: 'Please agree to the Terms', description: 'You must accept the Terms of Service to place your order.', variant: 'destructive' });
      return;
    }
    if (checkoutSummary && checkoutSummary.canCheckout === false) {
      toast({ title: 'Cart is not ready for checkout', description: (checkoutSummary.blockingIssues || []).join(' ') || 'Please review your cart.', variant: 'destructive' });
      return;
    }

    setSubmitting(true);
    try {
      const shippingAddress = sameAsBilling ? billing : shipping;
      const createdOrder = await createOrder({ shippingAddress, billingAddress: billing, notes });
      const intent = await createPaymentIntent(createdOrder.id);
      setOrder(createdOrder);
      setPaymentInfo(intent);
      setPhase('payment');
    } catch (err) {
      toast({ title: 'Could not start checkout', description: getErrorMessage(err), variant: 'destructive' });
    } finally {
      setSubmitting(false);
    }
  };

  const submitPayment = async (e) => {
    e.preventDefault();
    if (!stripe || !elements || !paymentInfo) return;
    setPaying(true);
    setCardError(null);
    try {
      const cardElement = elements.getElement(CardElement);
      const { error: pmError, paymentMethod: stripePaymentMethod } = await stripe.createPaymentMethod({
        type: 'card',
        card: cardElement,
        billing_details: { name: billing.fullName || user?.name || undefined, email: email || user?.email || undefined },
      });

      if (pmError) {
        setCardError(pmError.message);
        setPaying(false);
        return;
      }

      let payment = await confirmPayment(paymentInfo.payment.id, stripePaymentMethod.id);

      if (payment.status === 'requires_action' && paymentInfo.clientSecret) {
        const { error: actionError } = await stripe.confirmCardPayment(paymentInfo.clientSecret);
        if (actionError) {
          navigate('/order-failed', { state: { reason: actionError.message, orderId: order.id, paymentId: paymentInfo.payment.id } });
          return;
        }
        payment = await getPayment(paymentInfo.payment.id);
      }

      if (payment.status === 'succeeded') {
        await refreshOrders();
        setPhase('success');
      } else {
        navigate('/order-failed', { state: { reason: 'Your payment was declined. Please try a different card.', orderId: order.id, paymentId: paymentInfo.payment.id } });
      }
    } catch (err) {
      navigate('/order-failed', { state: { reason: getErrorMessage(err), orderId: order?.id, paymentId: paymentInfo?.payment?.id } });
    } finally {
      setPaying(false);
    }
  };

  if (phase === 'loadingRetry') {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="flex-1 grid place-items-center py-24 text-sm text-muted-foreground">Resuming checkout…</div>
        <Footer />
      </div>
    );
  }

  if (phase === 'success' && order) {
    return <OrderConfirmed order={order} />;
  }

  if (phase === 'payment' && order && paymentInfo) {
    return (
      <div className="min-h-screen">
        <Seo title="Checkout — Payment" description="Complete your PicaMarts purchase securely." noIndex />
        <Header />
        <div className="mx-auto max-w-2xl px-5 lg:px-8 pt-10 pb-24">
          <Breadcrumbs items={[{ name: 'Cart', to: '/cart' }, { name: 'Checkout' }]} />
          <h1 className="text-4xl md:text-5xl font-black tracking-tight">Payment</h1>
          <p className="text-muted-foreground mt-2">Order <span className="font-semibold text-foreground">{order.orderNumber}</span> · <span className="font-bold text-foreground">${(order.grandTotal ?? paymentInfo.payment.amount).toFixed(2)}</span></p>

          <form onSubmit={submitPayment} className="mt-8 bg-white rounded-3xl border border-border soft-shadow p-6 space-y-4">
            <h2 className="font-bold flex items-center gap-2"><CreditCard className="w-4 h-4 text-primary" /> Card details</h2>
            <div className="w-full bg-secondary/60 rounded-xl px-4 py-3.5 border border-transparent focus-within:border-primary">
              <CardElement options={cardElementOptions} onChange={(e) => setCardError(e.error?.message || null)} />
            </div>
            {cardError && <p className="text-xs text-destructive">{cardError}</p>}
            <p className="flex items-center gap-1.5 text-xs text-muted-foreground"><Lock className="w-3.5 h-3.5" /> Stripe test mode — use 4242 4242 4242 4242 to succeed, or 4000 0000 0000 0002 to preview a declined payment.</p>

            <button
              type="submit"
              disabled={!stripe || paying}
              className="w-full px-6 py-3.5 rounded-full brand-gradient text-white font-semibold soft-shadow hover:soft-shadow-lg transition-shadow disabled:opacity-70"
            >
              {paying ? 'Confirming payment…' : `Pay $${(order.grandTotal ?? paymentInfo.payment.amount).toFixed(2)}`}
            </button>
            <p className="flex items-center gap-1.5 justify-center text-xs text-muted-foreground"><ShieldCheck className="w-3.5 h-3.5" /> Secure checkout via Stripe</p>
          </form>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Seo title="Checkout" description="Complete your PicaMarts purchase securely." noIndex />
      <Header />
      <div className="mx-auto max-w-[90rem] px-5 lg:px-8 pt-10 pb-24">
        <Breadcrumbs items={[{ name: 'Cart', to: '/cart' }, { name: 'Checkout' }]} />
        <h1 className="text-4xl md:text-5xl font-black tracking-tight">Checkout</h1>

        {cart.length === 0 ? (
          <div className="mt-10 max-w-lg mx-auto">
            <EmptyState title="Your cart is empty" message="Add a product before heading to checkout." actionLabel="Browse the Shop" actionTo="/shop" />
          </div>
        ) : (
          <div className="mt-10 flex flex-col lg:flex-row gap-8">
            <form onSubmit={submitAddress} className="flex-1 space-y-5 min-w-0">
              {checkoutSummary && checkoutSummary.canCheckout === false && (
                <div className="flex items-start gap-2.5 bg-amber-50 border border-amber-200 text-amber-800 rounded-2xl p-4 text-sm">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold">Your cart isn't ready for checkout</p>
                    <ul className="list-disc list-inside mt-1">
                      {(checkoutSummary.blockingIssues || []).map((issue) => <li key={issue}>{issue}</li>)}
                    </ul>
                  </div>
                </div>
              )}

              <div className="bg-white rounded-3xl border border-border soft-shadow p-6">
                <h2 className="font-bold mb-4">Order Review</h2>
                <ul className="divide-y divide-border">
                  {cart.map((item) => (
                    <li key={item.id} className="flex flex-wrap sm:flex-nowrap items-center gap-3 py-3 first:pt-0 last:pb-0">
                      <img src={item.img} alt={item.title} className="w-14 h-14 rounded-xl object-cover shrink-0 bg-secondary" />
                      <div className="flex-1 min-w-[100px] sm:min-w-0">
                        <p className="text-sm font-semibold truncate">{item.title}</p>
                        {!item.isAvailable && <p className="text-xs text-destructive font-medium">No longer available</p>}
                      </div>
                      <div className="w-full sm:w-auto flex items-center justify-between sm:justify-normal gap-3 shrink-0">
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button type="button" onClick={() => updateQty(item.id, item.qty - 1)} className="w-7 h-7 grid place-items-center rounded-full border border-border hover:bg-secondary">−</button>
                          <span className="w-6 text-center text-sm font-semibold">{item.qty}</span>
                          <button type="button" onClick={() => updateQty(item.id, item.qty + 1)} className="w-7 h-7 grid place-items-center rounded-full border border-border hover:bg-secondary">+</button>
                        </div>
                        <span className="text-sm font-bold w-16 text-right shrink-0">${(item.price * item.qty).toFixed(2)}</span>
                        <button type="button" onClick={() => removeFromCart(item.id)} className="text-xs text-muted-foreground hover:text-destructive shrink-0">Remove</button>
                      </div>
                    </li>
                  ))}
                </ul>
                <p className="flex items-center gap-1.5 text-xs text-muted-foreground mt-4 pt-4 border-t border-border">
                  <Download className="w-3.5 h-3.5" />
                  {allDigital
                    ? 'All files unlock for instant download in your account immediately after payment.'
                    : 'Digital files unlock instantly after payment; physical items ship per the details below.'}
                </p>
              </div>

              <div className="bg-white rounded-3xl border border-border soft-shadow p-6">
                <h2 className="font-bold mb-4">Contact Details</h2>
                <label htmlFor="co-email" className="text-sm font-medium block mb-1.5">Email</label>
                <input id="co-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="w-full bg-secondary/60 rounded-xl px-4 py-2.5 text-sm outline-none border border-transparent focus:border-primary" />
              </div>

              <div className="bg-white rounded-3xl border border-border soft-shadow p-6">
                <h2 className="font-bold mb-4">Billing Address</h2>
                <AddressFields value={billing} onChange={setBilling} idPrefix="bill" />
              </div>

              {hasPhysical && (
                <div className="bg-white rounded-3xl border border-border soft-shadow p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="font-bold">Shipping Address</h2>
                    <label className="flex items-center gap-2 text-xs font-medium cursor-pointer">
                      <input type="checkbox" checked={sameAsBilling} onChange={(e) => setSameAsBilling(e.target.checked)} className="rounded" />
                      Same as billing
                    </label>
                  </div>
                  {sameAsBilling ? (
                    <p className="text-sm text-muted-foreground">Using your billing address above for delivery.</p>
                  ) : (
                    <AddressFields value={shipping} onChange={setShipping} idPrefix="ship" />
                  )}
                </div>
              )}

              {hasPhysical && (
                <div className="bg-white rounded-3xl border border-border soft-shadow p-6">
                  <h2 className="font-bold mb-4 flex items-center gap-2"><Truck className="w-4 h-4 text-primary" /> Shipping Details</h2>
                  <div className="space-y-4">
                    {cart.filter(isPhysicalItem).map((item) => {
                      const info = getItemShippingInfo(item);
                      return (
                        <div key={`ship-${item.id}`} className="flex items-start justify-between gap-4 pb-4 border-b border-border last:border-0 last:pb-0">
                          <div className="min-w-0">
                            <p className="text-sm font-semibold truncate">{item.title}</p>
                            <dl className="mt-1.5 grid grid-cols-2 gap-x-4 gap-y-1 text-xs">
                              <div><dt className="text-muted-foreground inline">Method: </dt><dd className="font-medium inline">{info.method}</dd></div>
                              {info.estimatedDelivery && <div><dt className="text-muted-foreground inline">Delivery: </dt><dd className="font-medium inline">{info.estimatedDelivery}</dd></div>}
                              {info.processingTime && <div><dt className="text-muted-foreground inline">Processing: </dt><dd className="font-medium inline">{info.processingTime}</dd></div>}
                              {info.shipsFrom && <div><dt className="text-muted-foreground inline">Ships From: </dt><dd className="font-medium inline">{info.shipsFrom}</dd></div>}
                            </dl>
                          </div>
                          <span className="text-sm font-bold shrink-0">{info.isFree ? 'Free' : `$${info.cost.toFixed(2)}`}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {hasPhysical && (
                <ShippingEstimateCard
                  loading={shippingEstimateLoading}
                  estimate={shippingEstimate}
                  error={shippingEstimateError}
                  selectedMethodKey={selectedMethodKey}
                  onSelect={setSelectedMethodKey}
                />
              )}

              <div className="bg-white rounded-3xl border border-border soft-shadow p-6">
                <h2 className="font-bold mb-4">Payment Method</h2>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mb-1">
                  {PAYMENT_METHODS.map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      disabled={!m.live}
                      onClick={() => m.live && setPaymentMethod(m.id)}
                      className={`flex flex-col items-center gap-1.5 px-3 py-3 rounded-xl border text-xs font-semibold transition-colors ${paymentMethod === m.id ? 'border-primary bg-primary/10 text-primary' : 'border-border hover:bg-secondary'} ${!m.live ? 'opacity-40 cursor-not-allowed hover:bg-transparent' : ''}`}
                    >
                      <m.icon className="w-4 h-4" /> {m.label}
                      {!m.live && <span className="text-[10px] font-medium normal-case">Coming soon</span>}
                    </button>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground mt-3">You'll enter your card details securely via Stripe on the next step.</p>
                <div className="flex flex-wrap items-center gap-2 mt-4 pt-4 border-t border-border">
                  <span className="text-xs text-muted-foreground">We accept:</span>
                  {['Visa', 'Mastercard', 'Amex'].map((label) => (
                    <span key={label} className="text-[11px] font-semibold px-2.5 py-1 rounded-md border border-border bg-secondary/40">{label}</span>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-3xl border border-border soft-shadow p-6">
                <h2 className="font-bold mb-4">Order Notes</h2>
                <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} placeholder="Add any notes about your order (optional)" className="w-full bg-secondary/60 rounded-xl px-4 py-2.5 text-sm outline-none border border-transparent focus:border-primary resize-none" />
              </div>

              <label className="flex items-start gap-2.5 text-sm cursor-pointer px-1">
                <input type="checkbox" checked={agreedToTerms} onChange={(e) => setAgreedToTerms(e.target.checked)} className="mt-0.5 rounded" />
                <span>I agree to the <Link to="/terms" className="text-primary hover:underline">Terms of Service</Link> and <Link to="/privacy-policy" className="text-primary hover:underline">Privacy Policy</Link>.</span>
              </label>

              <Link to="/cart" className="inline-flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-foreground transition-colors">
                <ArrowLeft className="w-4 h-4" /> Back to cart
              </Link>
            </form>

            <aside className="lg:w-96 shrink-0">
              <div className="bg-white rounded-3xl border border-border soft-shadow p-6 lg:sticky lg:top-24 space-y-5">
                <h2 className="font-bold text-lg">Order Summary</h2>

                <div className="space-y-2 text-sm pt-4 border-t border-border">
                  <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span className="font-semibold">${cartSubtotal.toFixed(2)}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Tax</span><span className="font-semibold">${tax.toFixed(2)}</span></div>
                  {!allDigital && (
                    <div className="flex justify-between"><span className="text-muted-foreground">Shipping</span><span className="font-semibold">{shippingCost === 0 ? 'Free' : `$${shippingCost.toFixed(2)}`}</span></div>
                  )}
                </div>

                <div className="flex justify-between items-baseline pt-4 border-t border-border">
                  <span className="font-semibold">Estimated Total</span>
                  <span className="text-2xl font-black">${estimatedTotal.toFixed(2)}</span>
                </div>
                <p className="text-[11px] text-muted-foreground -mt-3">Final total is confirmed by the server once your order is created.</p>

                {allDigital ? (
                  <p className="flex items-center gap-1.5 text-xs font-semibold text-primary"><Zap className="w-3.5 h-3.5" /> Instant Download</p>
                ) : (
                  <p className="flex items-center gap-1.5 text-xs text-muted-foreground"><Truck className="w-3.5 h-3.5" /> Physical items ship per the details above{cart.some((i) => !isPhysicalItem(i)) ? '; digital items unlock instantly' : ''}</p>
                )}

                <button
                  onClick={submitAddress}
                  disabled={submitting || summaryLoading}
                  className="w-full px-6 py-3.5 rounded-full brand-gradient text-white font-semibold soft-shadow hover:soft-shadow-lg transition-shadow disabled:opacity-70"
                >
                  {submitting ? 'Creating order…' : 'Continue to Payment'}
                </button>
                <p className="flex items-center gap-1.5 justify-center text-xs text-muted-foreground">
                  <ShieldCheck className="w-3.5 h-3.5" /> Secure checkout{allDigital ? ' · Instant download' : ''}
                </p>
              </div>
            </aside>
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
};

const CheckoutPage = () => {
  if (!isStripeConfigured) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="flex-1 mx-auto max-w-lg w-full px-5 py-24 text-center">
          <h1 className="text-xl font-bold">Payments aren't configured yet</h1>
          <p className="text-sm text-muted-foreground mt-2">Set <code className="px-1.5 py-0.5 rounded bg-secondary">VITE_STRIPE_PUBLISHABLE_KEY</code> in the web app's environment to enable checkout.</p>
        </div>
        <Footer />
      </div>
    );
  }
  return (
    <Elements stripe={stripePromise}>
      <CheckoutForm />
    </Elements>
  );
};

export default CheckoutPage;
