import { useSyncExternalStore } from 'react';
import { subscribeCatalog, getCatalogVersion } from '../services/catalogStore';

/**
 * Returns a number that changes once the shared catalog cache (categories/
 * brands/collections/tags — see services/catalogStore.js) first loads.
 * Components that read categoryRepository synchronously add this to a
 * useMemo dependency array so they re-render with real data as soon as it
 * arrives, instead of being stuck with the empty initial snapshot forever.
 */
export const useCatalogVersion = () =>
  useSyncExternalStore(subscribeCatalog, getCatalogVersion, getCatalogVersion);
