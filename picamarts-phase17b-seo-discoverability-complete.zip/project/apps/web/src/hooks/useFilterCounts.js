import { useEffect, useState } from 'react';
import { productsApi } from '../services/api';

/**
 * Phase 17A.2 — Dynamic Filter Counts. For one multi-select filter
 * dimension (e.g. `categories`, `brands`), computes how many published
 * products would match if that single option were applied on top of
 * every OTHER currently active filter — the dimension itself is
 * excluded from the base so a category's count reflects "if I also
 * checked this" rather than shrinking to only the already-checked ones.
 *
 * There's no dedicated backend facet-count endpoint (see
 * services/api.js#productsApi.count's own doc comment), so this fans
 * out one lightweight `limit=1` request per option in parallel.
 *
 * Returns a `Map<string, number|null>` — a missing/`null` entry means
 * that option's count is still loading or failed; callers should
 * render nothing (not "0") for those until they resolve.
 */
export function useFilterCounts({ filters, query = '', dimensionKey, optionValues, enabled = true }) {
  const [counts, setCounts] = useState(new Map());

  useEffect(() => {
    if (!enabled || !optionValues?.length) {
      setCounts(new Map());
      return undefined;
    }
    let cancelled = false;
    const baseFilters = { ...filters, [dimensionKey]: [] };

    Promise.all(
      optionValues.map((value) =>
        productsApi
          .count({ filters: { ...baseFilters, [dimensionKey]: [value] }, query })
          .then((total) => [value, total])
          .catch(() => [value, null])
      )
    ).then((pairs) => {
      if (!cancelled) setCounts(new Map(pairs));
    });

    return () => { cancelled = true; };
    // Deliberately keyed on serialized values — `filters`/`optionValues` are
    // fresh object/array references every render, and comparing their
    // contents (not identity) is what should actually re-trigger the fetch.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled, dimensionKey, JSON.stringify(optionValues), JSON.stringify(filters), query]);

  return counts;
}

export default useFilterCounts;
