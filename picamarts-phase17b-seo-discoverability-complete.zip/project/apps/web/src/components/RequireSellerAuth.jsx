import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useSellerAuth } from '../context/SellerAuthContext';
import { Spinner } from './ui/spinner';

// Wraps the /seller/* routes — normal storefront users (or buyers/admins)
// are bounced to /seller/login and sent back to where they were headed
// once they sign in with a seller account. While the real session is
// still being restored (page reload / cookie-refresh check), this shows
// a brief loading state instead of prematurely redirecting a
// still-logged-in seller to the login page.
const RequireSellerAuth = ({ children }) => {
  const { isAuthenticated, authLoading } = useSellerAuth();
  const location = useLocation();

  if (authLoading) {
    return (
      <div className="min-h-screen grid place-items-center">
        <Spinner />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/seller/login" replace state={{ from: location }} />;
  }
  return children;
};

export default RequireSellerAuth;
