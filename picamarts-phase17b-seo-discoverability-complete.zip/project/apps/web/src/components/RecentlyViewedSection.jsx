import React, { useEffect, useState } from 'react';
import ProductCard from './ProductCard';
import { getRecentlyViewedForUser } from '../services/recentlyViewed';
import { useStore } from '../context/StoreContext';

/**
 * Renders nothing if there's no browsing history yet — safe to drop
 * into any page unconditionally. `excludeId` keeps a product detail
 * page from showing itself in its own "recently viewed" row.
 *
 * Phase 17A, Part 5 — prefers the buyer's real server-recorded history
 * when signed in (getRecentlyViewedForUser), falling back to the
 * anonymous localStorage list otherwise.
 */
const RecentlyViewedSection = ({ excludeId = null, title = 'Recently Viewed', limit = 6, className = 'mt-20' }) => {
  const { user } = useStore();
  const [items, setItems] = useState([]);

  useEffect(() => {
    let cancelled = false;
    getRecentlyViewedForUser(user, excludeId, limit).then((result) => { if (!cancelled) setItems(result); });
    return () => { cancelled = true; };
  }, [user, excludeId, limit]);

  if (items.length === 0) return null;

  return (
    <div className={className}>
      <h2 className="text-2xl font-bold mb-6">{title}</h2>
      <div className="grid grid-cols-2 lg:grid-cols-4 xl:grid-cols-6 gap-5">
        {items.map((p) => <ProductCard key={p.id} p={p} />)}
      </div>
    </div>
  );
};

export default RecentlyViewedSection;
