import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Heart, Eye, Star, Download, ShoppingBag, Scale } from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { useToast } from '../hooks/use-toast';
import { slugify } from '../data';
import QuickViewDialog from './QuickViewDialog';

const badgeStyle = {
  Sale: 'bg-accent text-white',
  'Best Seller': 'brand-gradient text-white',
  New: 'bg-foreground text-white',
  Premium: 'bg-amber-400 text-foreground',
};

// ShopPage pads the catalog with duplicate-id cards (id + 100) to fill a
// fuller demo grid; baseId (when present) is the real product id used for
// routing/wishlist/cart so duplicated cards still link to a real product.
const ProductCard = ({ p }) => {
  const { toggleWishlist, inWishlist, addToCart, toggleCompare, inCompare, compareList, MAX_COMPARE } = useStore();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [quickView, setQuickView] = useState(false);
  const realId = p.baseId ?? p.id;
  const wishlisted = inWishlist(realId);
  const compared = inCompare(realId);

  const handleAddToCart = async (e) => {
    e.preventDefault();
    try {
      await addToCart({ ...p, id: realId });
      toast({ title: 'Added to cart', description: p.title });
    } catch (err) {
      if (err?.requiresAuth) {
        toast({ title: 'Please log in', description: 'Log in to add items to your cart.' });
        navigate('/login');
      } else {
        toast({ title: 'Could not add to cart', description: err?.message || 'Please try again.', variant: 'destructive' });
      }
    }
  };

  const handleToggleWishlist = async (e) => {
    e.preventDefault();
    try {
      await toggleWishlist({ ...p, id: realId });
    } catch (err) {
      if (err?.requiresAuth) {
        toast({ title: 'Please log in', description: 'Log in to save items to your wishlist.' });
        navigate('/login');
      } else {
        toast({ title: 'Could not update wishlist', description: err?.message || 'Please try again.', variant: 'destructive' });
      }
    }
  };

  const handleToggleCompare = (e) => {
    e.preventDefault();
    if (!compared && compareList.length >= MAX_COMPARE) {
      toast({ title: 'Compare list is full', description: `You can compare up to ${MAX_COMPARE} products at a time.` });
      return;
    }
    toggleCompare({ ...p, id: realId });
    toast({ title: compared ? 'Removed from compare' : 'Added to compare', description: p.title });
  };

  return (
    <article className="group relative bg-white rounded-3xl p-3 border border-border soft-shadow hover:soft-shadow-lg hover:-translate-y-1 focus-within:soft-shadow-lg transition-all duration-300">
      <Link
        to={`/product/${realId}`}
        className="block relative overflow-hidden rounded-2xl bg-secondary aspect-square focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        aria-label={p.title}
      >
        <img src={p.img} alt={p.title} loading="lazy" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
        {p.badge && (
          <span className={`absolute top-3 left-3 text-[11px] font-semibold px-2.5 py-1 rounded-full ${badgeStyle[p.badge] || 'bg-white'}`}>{p.badge}</span>
        )}

        {/* Hover actions — Quick View + Add to Cart (also shown on keyboard focus) */}
        <div className="absolute inset-x-3 bottom-3 flex gap-2 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 group-focus-within:translate-y-0 group-focus-within:opacity-100 transition-all duration-300">
          <button
            type="button"
            onClick={(e) => { e.preventDefault(); setQuickView(true); }}
            className="flex-1 flex items-center justify-center gap-1.5 text-sm font-medium bg-white/95 backdrop-blur rounded-xl py-2 hover:bg-white transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            aria-label={`Quick view ${p.title}`}
          >
            <Eye className="w-4 h-4" aria-hidden="true" /> Quick View
          </button>
          <button
            type="button"
            onClick={handleAddToCart}
            className="grid place-items-center w-10 rounded-xl brand-gradient text-white hover:opacity-95 active:scale-95 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1"
            aria-label={`Add ${p.title} to cart`}
          >
            <ShoppingBag className="w-4 h-4" aria-hidden="true" />
          </button>
        </div>
      </Link>

      <button
        type="button"
        aria-label={wishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
        aria-pressed={wishlisted}
        onClick={handleToggleWishlist}
        className="absolute top-6 right-6 grid place-items-center w-9 h-9 rounded-full glass text-foreground hover:text-accent transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        <Heart className={`w-4 h-4 transition-colors ${wishlisted ? 'fill-accent text-accent' : ''}`} />
      </button>

      <button
        type="button"
        aria-label={compared ? 'Remove from compare' : 'Add to compare'}
        aria-pressed={compared}
        onClick={handleToggleCompare}
        className={`absolute top-[3.75rem] right-6 grid place-items-center w-9 h-9 rounded-full glass transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${compared ? 'text-primary' : 'text-foreground hover:text-primary'}`}
      >
        <Scale className={`w-4 h-4 transition-colors ${compared ? 'fill-primary/10' : ''}`} />
      </button>

      <div className="px-1.5 pt-3 pb-1.5">
        <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
          <span>{p.cat}</span>
          <span className="flex items-center gap-1" aria-label={`Rated ${p.rating} out of 5 from ${p.reviewCount ?? 0} reviews`}>
            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" aria-hidden="true" /> {p.rating}
            {p.reviewCount != null && <span className="text-muted-foreground/80">({p.reviewCount})</span>}
          </span>
        </div>
        <Link to={`/product/${realId}`} className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-md">
          <h3 className="text-[15px] font-semibold leading-snug line-clamp-1 hover:text-primary transition-colors">{p.title}</h3>
        </Link>
        <p className="text-xs text-muted-foreground mt-0.5">
          by{' '}
          <Link
            to={`/seller/${slugify(p.artist)}`}
            className="hover:text-primary transition-colors focus-visible:outline-none focus-visible:underline"
          >
            {p.artist}
          </Link>
        </p>
        <div className="flex items-center justify-between mt-3">
          <div className="flex items-baseline gap-1.5">
            <span className="text-lg font-bold">${p.price}</span>
            {p.old && <span className="text-sm text-muted-foreground line-through" aria-label={`Original price $${p.old}`}>${p.old}</span>}
          </div>
          <span className="flex items-center gap-1 text-xs text-muted-foreground" aria-label={`${(p.downloads ?? 0).toLocaleString()} downloads`}>
            <Download className="w-3.5 h-3.5" aria-hidden="true" /> {((p.downloads ?? 0) / 1000).toFixed(1)}k
          </span>
        </div>
      </div>

      <QuickViewDialog product={p} open={quickView} onOpenChange={setQuickView} />
    </article>
  );
};

export default ProductCard;
