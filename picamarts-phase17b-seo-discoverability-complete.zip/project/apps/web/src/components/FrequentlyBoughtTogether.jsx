import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Plus, ShoppingBag } from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { useToast } from '../hooks/use-toast';

/**
 * Shows the current product bundled with 1-2 related items and a combined
 * "Add all to cart" action. Bundle membership is picked from the related
 * list passed in — purely a merchandising UI, no special bundle pricing
 * or backend logic.
 */
const FrequentlyBoughtTogether = ({ product, related = [] }) => {
  const { addToCart } = useStore();
  const { toast } = useToast();
  const navigate = useNavigate();
  const bundleExtras = related.slice(0, 2);
  const bundle = [product, ...bundleExtras];
  const [checked, setChecked] = useState(() => new Set(bundle.map((p) => p.id)));

  if (bundleExtras.length === 0) return null;

  const toggle = (id) => {
    if (id === product.id) return; // current product always included
    setChecked((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const selected = bundle.filter((p) => checked.has(p.id));
  const total = selected.reduce((s, p) => s + (p.price || 0), 0);

  const addBundle = async () => {
    try {
      // Sequential, not parallel — each call re-fetches/replaces the shared
      // cart state, so concurrent requests could race and clobber each other.
      for (const p of selected) {
        // eslint-disable-next-line no-await-in-loop
        await addToCart(p);
      }
      toast({ title: 'Added to cart', description: `${selected.length} item${selected.length === 1 ? '' : 's'} added.` });
    } catch (err) {
      if (err?.requiresAuth) {
        toast({ title: 'Please log in', description: 'Log in to add items to your cart.' });
        navigate('/login');
      } else {
        toast({ title: 'Could not add bundle to cart', description: err?.message || 'Please try again.', variant: 'destructive' });
      }
    }
  };

  return (
    <div className="mt-16 bg-white rounded-3xl border border-border soft-shadow p-6">
      <h2 className="text-xl font-bold mb-5">Frequently Bought Together</h2>
      <div className="flex flex-wrap items-center gap-3">
        {bundle.map((p, i) => (
          <React.Fragment key={p.id}>
            {i > 0 && <Plus className="w-4 h-4 text-muted-foreground shrink-0" aria-hidden="true" />}
            <label className={`flex flex-col items-center gap-2 shrink-0 ${p.id === product.id ? '' : 'cursor-pointer'}`}>
              <span className="relative">
                <Link to={`/product/${p.id}`} className="block w-20 h-20 rounded-2xl overflow-hidden bg-secondary">
                  <img src={p.img} alt={p.title} loading="lazy" className="w-full h-full object-cover" />
                </Link>
                <input
                  type="checkbox"
                  checked={checked.has(p.id)}
                  onChange={() => toggle(p.id)}
                  disabled={p.id === product.id}
                  aria-label={`Include ${p.title} in bundle`}
                  className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded accent-current"
                />
              </span>
              <span className="text-xs text-center max-w-[6rem] line-clamp-2">{p.title}</span>
              <span className="text-xs font-semibold">${p.price}</span>
            </label>
          </React.Fragment>
        ))}
        <div className="ml-auto flex flex-col items-end gap-2">
          <p className="text-sm text-muted-foreground">Total for {selected.length} item{selected.length === 1 ? '' : 's'}: <span className="font-black text-foreground text-lg">${total.toFixed(2)}</span></p>
          <button
            type="button"
            onClick={addBundle}
            className="inline-flex items-center gap-1.5 px-6 py-3 rounded-full brand-gradient text-white font-semibold soft-shadow hover:opacity-95 transition-opacity"
          >
            <ShoppingBag className="w-4 h-4" /> Add Selected to Cart
          </button>
        </div>
      </div>
    </div>
  );
};

export default FrequentlyBoughtTogether;
