import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Twitter, Github, Youtube, ArrowRight, Check } from 'lucide-react';
import { LOGO } from '../data';
import { newsletterApi } from '../services/api';

const cols = [
  { title: 'Marketplace', links: [
    { name: 'Shop All', to: '/shop' },
    { name: 'Categories', to: '/categories' },
    { name: 'Collections', to: '/collections' },
    { name: 'Best Sellers', to: '/shop?sort=top-rated' },
    { name: 'Become a Seller', to: '/become-a-seller' },
  ] },
  { title: 'Company', links: [
    { name: 'About', to: '/about' },
    { name: 'Blog', to: '/blog' },
    { name: 'Contact', to: '/contact' },
    { name: 'Careers', to: '/contact' },
    { name: 'Affiliates', to: '/contact' },
  ] },
  { title: 'Support', links: [
    { name: 'FAQ', to: '/faq' },
    { name: 'Licensing', to: '/terms' },
    { name: 'Wishlist', to: '/wishlist' },
    { name: 'Cart', to: '/cart' },
    { name: 'Help Center', to: '/contact' },
  ] },
  { title: 'Legal', links: [
    { name: 'Privacy Policy', to: '/privacy' },
    { name: 'Terms & Conditions', to: '/terms' },
    { name: 'Refund Policy', to: '/refund-policy' },
    { name: 'Cookies', to: '/privacy' },
    { name: 'DMCA', to: '/terms' },
  ] },
];

/** Inline newsletter signup — wired to the mock newsletterApi service. */
const NewsletterForm = () => {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState('idle'); // idle | loading | done

  const submit = async (e) => {
    e.preventDefault();
    if (!email.trim() || status === 'loading') return;
    setStatus('loading');
    await newsletterApi.subscribe(email.trim());
    setStatus('done');
    setEmail('');
  };

  if (status === 'done') {
    return (
      <p className="flex items-center gap-2 text-sm font-medium text-primary mt-5">
        <Check className="w-4 h-4" /> You're subscribed — thanks!
      </p>
    );
  }

  return (
    <form onSubmit={submit} className="mt-5 flex items-center gap-1.5 max-w-xs bg-secondary/70 rounded-full pl-4 pr-1.5 py-1.5 border border-border focus-within:border-primary/40 transition-colors">
      <input
        type="email"
        required
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="Your email"
        aria-label="Email address for newsletter"
        className="bg-transparent outline-none text-sm w-full placeholder:text-muted-foreground py-1.5"
      />
      <button
        type="submit"
        disabled={status === 'loading'}
        aria-label="Subscribe to newsletter"
        className="shrink-0 grid place-items-center w-9 h-9 rounded-full brand-gradient text-white hover:opacity-95 active:scale-95 transition-all disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
      >
        <ArrowRight className="w-4 h-4" />
      </button>
    </form>
  );
};

const Footer = () => (
  <footer className="mt-24 border-t border-border bg-white">
    <div className="mx-auto max-w-[90rem] px-5 lg:px-8 py-16">
      <div className="grid gap-12 lg:grid-cols-[1.4fr_repeat(4,1fr)]">
        <div>
          <Link to="/" className="inline-block mb-4" aria-label="PicaMarts home">
            <img src={LOGO} alt="PicaMarts" className="h-14 w-auto" />
          </Link>
          <p className="text-sm text-muted-foreground max-w-xs leading-relaxed">
            A premium marketplace for digital art. Instant downloads, clear licensing, and hand-picked quality from talented creators worldwide.
          </p>
          <div className="flex gap-2 mt-5">
            {[Instagram, Twitter, Github, Youtube].map((Ic, i) => (
              <a key={i} href="#" aria-label="Social" className="grid place-items-center w-9 h-9 rounded-full bg-secondary text-primary hover:brand-gradient hover:text-white transition-colors">
                <Ic className="w-4 h-4" />
              </a>
            ))}
          </div>
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mt-8 mb-1">Newsletter</p>
          <p className="text-xs text-muted-foreground max-w-xs">New drops, deals, and creator spotlights — no spam.</p>
          <NewsletterForm />
        </div>
        {cols.map((c) => (
          <div key={c.title}>
            <h4 className="text-sm font-semibold mb-4">{c.title}</h4>
            <ul className="space-y-2.5">
              {c.links.map((l) => (
                <li key={l.name}><Link to={l.to} className="text-sm text-muted-foreground hover:text-primary transition-colors">{l.name}</Link></li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="mt-14 pt-8 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-4">
        <p className="text-xs text-muted-foreground">© {new Date().getFullYear()} PicaMarts. All rights reserved.</p>
        <p className="text-xs text-muted-foreground">Secure payments · Instant delivery · 30-day guarantee</p>
      </div>
    </div>
  </footer>
);

export default Footer;
