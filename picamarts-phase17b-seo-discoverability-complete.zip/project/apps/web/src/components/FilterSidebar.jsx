import React from 'react';
import { SlidersHorizontal, Star, RotateCcw } from 'lucide-react';
import {
  PRICE_RANGES, RATING_FILTERS, SELLER_RATING_FILTERS, FILE_TYPE_FILTERS, LICENSE_FILTERS, DEFAULT_FILTERS,
} from '../constants';
import { useFilterCounts } from '../hooks/useFilterCounts';

const Group = ({ title, children }) => (
  <fieldset className="pt-4 mt-4 border-t border-border first:pt-0 first:mt-0 first:border-0">
    <legend className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2.5">{title}</legend>
    {children}
  </fieldset>
);

const Radio = ({ name, checked, onChange, children }) => (
  <label className="flex items-center gap-2.5 py-1.5 px-1 rounded-lg cursor-pointer text-sm hover:text-primary transition-colors">
    <input
      type="radio"
      name={name}
      checked={checked}
      onChange={onChange}
      className="w-4 h-4 accent-[#6C3BFF] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
    />
    <span className={checked ? 'font-semibold text-foreground' : 'text-foreground/80'}>{children}</span>
  </label>
);

const Check = ({ checked, onChange, children, count }) => (
  <label className="flex items-center justify-between gap-2.5 py-1.5 px-1 rounded-lg cursor-pointer text-sm hover:text-primary transition-colors">
    <span className="flex items-center gap-2.5 min-w-0">
      <input
        type="checkbox"
        checked={checked}
        onChange={onChange}
        className="w-4 h-4 rounded accent-[#6C3BFF] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring shrink-0"
      />
      <span className={`truncate ${checked ? 'font-semibold text-foreground' : 'text-foreground/80'}`}>{children}</span>
    </span>
    {typeof count === 'number' && <span className="text-xs text-muted-foreground shrink-0">{count}</span>}
  </label>
);

/**
 * Shared filters for the Shop and Category pages.
 * Controlled: pass `filters` + `onChange(nextFilters)`.
 * `categorySlot` lets each page render its own category list at the top
 * (Shop uses buttons, Category pages use navigation links).
 *
 * Phase 17A.2 — Storefront Filters adds three groups, all optional via
 * props so this stays a drop-in for any existing caller that doesn't
 * pass them:
 *   - `categoryOptions` [{id, name}] → a "Categories" multi-select
 *     checkbox group (`filters.categories`), additive on top of the
 *     single-select category pills in `categorySlot`.
 *   - `brandOptions` [{id, name}] → a "Brand" multi-select checkbox
 *     group (`filters.brands`).
 *   - Seller Rating (`filters.sellerRating`) is always shown — it has
 *     no external option list, just the fixed SELLER_RATING_FILTERS tiers.
 * Live "(N results)" counts next to each category/brand checkbox come
 * from useFilterCounts and only fire when `categoryOptions`/`brandOptions`
 * are actually passed in.
 */
const FilterSidebar = ({
  filters, onChange, categorySlot, resultCount, categoryOptions = [], brandOptions = [], query = '',
}) => {
  const set = (patch) => onChange({ ...filters, ...patch });
  const toggleIn = (key, value) =>
    set({ [key]: filters[key].includes(value) ? filters[key].filter((v) => v !== value) : [...filters[key], value] });

  const categoryCounts = useFilterCounts({
    filters, query, dimensionKey: 'categories', optionValues: categoryOptions.map((c) => c.id), enabled: categoryOptions.length > 0,
  });
  const brandCounts = useFilterCounts({
    filters, query, dimensionKey: 'brands', optionValues: brandOptions.map((b) => b.id), enabled: brandOptions.length > 0,
  });

  const isDefault =
    filters.price === DEFAULT_FILTERS.price &&
    filters.rating === DEFAULT_FILTERS.rating &&
    filters.fileTypes.length === 0 &&
    filters.licenses.length === 0 &&
    (filters.categories?.length ?? 0) === 0 &&
    (filters.brands?.length ?? 0) === 0 &&
    (filters.sellerRating ?? 0) === 0;

  return (
    <div className="bg-white rounded-3xl p-5 border border-border soft-shadow lg:sticky lg:top-[9.5rem]">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2 text-sm font-semibold">
          <SlidersHorizontal className="w-4 h-4" aria-hidden="true" /> Filters
          {typeof resultCount === 'number' && (
            <span className="text-xs font-normal text-muted-foreground">· {resultCount} result{resultCount === 1 ? '' : 's'}</span>
          )}
        </div>
        {!isDefault && (
          <button
            type="button"
            onClick={() => set({ price: 'any', rating: 0, fileTypes: [], licenses: [], categories: [], brands: [], sellerRating: 0 })}
            className="flex items-center gap-1 text-xs font-semibold text-primary hover:opacity-80 transition-opacity focus-visible:outline-none focus-visible:underline"
          >
            <RotateCcw className="w-3 h-3" aria-hidden="true" /> Reset
          </button>
        )}
      </div>

      {categorySlot}

      {categoryOptions.length > 0 && (
        <Group title="Categories">
          <div className="max-h-56 overflow-y-auto pr-1">
            {categoryOptions.map((c) => (
              <Check key={c.id} checked={filters.categories?.includes(c.id)} onChange={() => toggleIn('categories', c.id)} count={categoryCounts.get(c.id) ?? undefined}>
                {c.name}
              </Check>
            ))}
          </div>
        </Group>
      )}

      {brandOptions.length > 0 && (
        <Group title="Brand">
          <div className="max-h-56 overflow-y-auto pr-1">
            {brandOptions.map((b) => (
              <Check key={b.id} checked={filters.brands?.includes(b.id)} onChange={() => toggleIn('brands', b.id)} count={brandCounts.get(b.id) ?? undefined}>
                {b.name}
              </Check>
            ))}
          </div>
        </Group>
      )}

      <Group title="Price range">
        {PRICE_RANGES.map((r) => (
          <Radio key={r.id} name="price" checked={filters.price === r.id} onChange={() => set({ price: r.id })}>
            {r.label}
          </Radio>
        ))}
      </Group>

      <Group title="Rating">
        {RATING_FILTERS.map((r) => (
          <Radio key={r.id} name="rating" checked={filters.rating === r.id} onChange={() => set({ rating: r.id })}>
            <span className="inline-flex items-center gap-1">
              {r.id > 0 && <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" aria-hidden="true" />}
              {r.label}
            </span>
          </Radio>
        ))}
      </Group>

      <Group title="Seller Rating">
        {SELLER_RATING_FILTERS.map((r) => (
          <Radio key={r.id} name="sellerRating" checked={(filters.sellerRating ?? 0) === r.id} onChange={() => set({ sellerRating: r.id })}>
            <span className="inline-flex items-center gap-1">
              {r.id > 0 && <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" aria-hidden="true" />}
              {r.label}
            </span>
          </Radio>
        ))}
      </Group>

      <Group title="File type">
        <div className="grid grid-cols-2 gap-x-1">
          {FILE_TYPE_FILTERS.map((t) => (
            <Check key={t} checked={filters.fileTypes.includes(t)} onChange={() => toggleIn('fileTypes', t)}>
              {t}
            </Check>
          ))}
        </div>
      </Group>

      <Group title="License">
        {LICENSE_FILTERS.map((l) => (
          <Check key={l.id} checked={filters.licenses.includes(l.id)} onChange={() => toggleIn('licenses', l.id)}>
            {l.label}
          </Check>
        ))}
      </Group>
    </div>
  );
};

export default FilterSidebar;
