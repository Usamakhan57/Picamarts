import React, { useRef, useState, useCallback, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, Search, Star, Sparkles, TrendingUp, Users, Download,
  Layers, Code2, PenTool, Frame, Image as ImageIcon, BadgeCheck, ShieldCheck, Zap,
} from 'lucide-react';
import { getHomepageCategories } from '../services/categoryRepository';
import { useCatalogVersion } from '../hooks/useCatalogVersion';

/* ------------------------------------------------------------------ */
/*  Motion presets                                                     */
/* ------------------------------------------------------------------ */
const fadeUp = {
  hidden: { opacity: 0, y: 22 },
  show: (i = 0) => ({ opacity: 1, y: 0, transition: { duration: 0.55, delay: i * 0.07, ease: 'easeOut' } }),
};

/* ------------------------------------------------------------------ */
/*  Content                                                             */
/* ------------------------------------------------------------------ */
// Illustrative marketplace-wide numbers surfaced inside the hero.
const STATS = [
  { icon: Layers, value: '24K+', label: 'Digital Products' },
  { icon: Users, value: '12K+', label: 'Verified Creators' },
  { icon: Download, value: '180K+', label: 'Downloads' },
  { icon: Star, value: '4.9/5', label: 'Average Rating' },
];

// Cross-section of what buyers find on the marketplace — powers the
// floating preview cards on desktop and the scroll showcase on mobile.
const FLOATING_CARDS = [
  {
    id: 'ui-kit', title: 'Nova UI Kit', category: 'UI Kit', price: 49, rating: 4.9, creator: 'Aria Studio',
    bestseller: true, icon: Layers, gradient: 'linear-gradient(135deg,#6C3BFF,#8F63FF)',
    wrap: 'top-0 left-2 lg:left-0', rotate: -7, z: 20, delay: 0.1, duration: 6.4, depth: 0.6,
  },
  {
    id: 'react-template', title: 'Orbit Dashboard', category: 'React Template', price: 39, rating: 4.8, creator: 'CodeCraft',
    bestseller: false, icon: Code2, gradient: 'linear-gradient(135deg,#20182F,#463A66)',
    wrap: 'top-10 right-0 lg:right-2', rotate: 6, z: 10, delay: 0.3, duration: 7.2, depth: 0.9,
  },
  {
    id: 'logo-pack', title: 'Minimal Logo Pack', category: 'Logo Pack', price: 19, rating: 5.0, creator: 'Nova Design',
    bestseller: true, icon: PenTool, gradient: 'linear-gradient(135deg,#FF4FD8,#FF9FE4)',
    wrap: 'top-[42%] left-0 lg:-left-6', rotate: -4, z: 30, delay: 0.5, duration: 6.8, depth: 1.1,
  },
  {
    id: 'canva-bundle', title: 'Bloom Canva Bundle', category: 'Canva Bundle', price: 15, rating: 4.7, creator: 'PixelBloom',
    bestseller: false, icon: ImageIcon, gradient: 'linear-gradient(135deg,#12B8E0,#6C3BFF)',
    wrap: 'top-[48%] right-0 lg:-right-8', rotate: 5, z: 20, delay: 0.2, duration: 7.6, depth: 0.75,
  },
  {
    id: 'mockup', title: 'Studio Mockup Set', category: 'Mockup', price: 12, rating: 4.9, creator: 'MockLab',
    bestseller: false, icon: Frame, gradient: 'linear-gradient(135deg,#FFB020,#FF7A59)',
    wrap: 'bottom-4 left-[12%] lg:left-[8%]', rotate: -5, z: 10, delay: 0.6, duration: 6.2, depth: 1,
  },
  {
    id: 'clipart', title: 'Wildflower Clipart', category: 'Clipart', price: 8, rating: 4.6, creator: 'ArtVilla',
    bestseller: true, icon: Sparkles, gradient: 'linear-gradient(135deg,#8F63FF,#FF4FD8)',
    wrap: 'bottom-0 right-[8%] lg:right-0', rotate: 7, z: 25, delay: 0.4, duration: 6.9, depth: 0.85,
  },
];

/* ------------------------------------------------------------------ */
/*  Small shared pieces                                                */
/* ------------------------------------------------------------------ */
const TrustBadge = ({ compact = false }) => (
  <motion.div
    initial="hidden"
    animate="show"
    variants={fadeUp}
    className={`inline-flex items-center gap-2.5 glass rounded-full pl-1.5 pr-4 py-1.5 soft-shadow ${compact ? 'text-[11px]' : 'text-xs sm:text-[13px]'}`}
  >
    <span className="flex -space-x-2" aria-hidden="true">
      {['#6C3BFF', '#8F63FF', '#FF4FD8', '#FFB020'].map((c) => (
        <span key={c} className="w-[1.375rem] h-[1.375rem] rounded-full border-2 border-white" style={{ background: c }} />
      ))}
    </span>
    <span className="font-semibold text-foreground/80">
      Trusted by <span className="text-foreground">50,000+</span> creators worldwide
    </span>
  </motion.div>
);

const HeroSearchBar = ({ className = '', size = 'lg' }) => {
  const [q, setQ] = useState('');
  const navigate = useNavigate();

  const submit = (e) => {
    e.preventDefault();
    navigate(q.trim() ? `/search?q=${encodeURIComponent(q.trim())}` : '/search');
  };

  return (
    <form
      onSubmit={submit}
      role="search"
      aria-label="Search the marketplace"
      className={`flex items-center gap-1.5 sm:gap-2 bg-white rounded-full border border-border soft-shadow-lg ${size === 'lg' ? 'p-2 pl-5' : 'p-1.5 pl-4'} ${className}`}
    >
      <Search className="w-[1.125rem] h-[1.125rem] text-muted-foreground shrink-0" aria-hidden="true" />
      <label htmlFor="hero-search" className="sr-only">Search digital products</label>
      <input
        id="hero-search"
        type="search"
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Search UI kits, templates, logos, mockups…"
        className="flex-1 min-w-0 bg-transparent outline-none text-sm sm:text-[15px] placeholder:text-muted-foreground/60"
      />
      <button
        type="submit"
        className="shrink-0 brand-gradient text-white text-xs sm:text-sm font-semibold px-4 sm:px-6 py-2.5 rounded-full hover:opacity-95 active:scale-[0.97] transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
      >
        Search
      </button>
    </form>
  );
};

const CategoryPills = ({ className = '', scrollable = false }) => {
  const catalogVersion = useCatalogVersion();
  const pills = useMemo(() => getHomepageCategories().slice(0, 7), [catalogVersion]);
  return (
    <div className={`flex items-center gap-2 ${scrollable ? 'overflow-x-auto no-scrollbar -mx-4 px-4 sm:mx-0 sm:px-0' : 'flex-wrap'} ${className}`}>
      <span className="text-xs font-semibold text-muted-foreground/80 shrink-0">Popular:</span>
      {pills.map((c) => (
        <Link
          key={c.id}
          to={`/category/${c.slug}`}
          className="inline-flex items-center gap-1.5 shrink-0 text-xs sm:text-[13px] font-semibold bg-white border border-border rounded-full px-3.5 py-1.5 hover:-translate-y-0.5 hover:soft-shadow transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <c.icon className="w-3.5 h-3.5" style={{ color: c.color }} aria-hidden="true" />
          {c.name}
        </Link>
      ))}
    </div>
  );
};

const CTAButtons = ({ className = '', stacked = false }) => (
  <div className={`flex ${stacked ? 'flex-col' : 'flex-wrap'} gap-3 ${className}`}>
    <Link
      to="/shop"
      className={`group inline-flex items-center justify-center gap-2 brand-gradient text-white font-semibold px-7 py-3.5 rounded-full soft-shadow-lg hover:opacity-95 hover:-translate-y-0.5 active:scale-[0.98] transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 ${stacked ? 'w-full' : ''}`}
    >
      Explore Marketplace <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
    </Link>
    <Link
      to="/become-a-seller"
      className={`inline-flex items-center justify-center gap-2 bg-white text-foreground font-semibold px-7 py-3.5 rounded-full border border-border hover:bg-secondary hover:-translate-y-0.5 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${stacked ? 'w-full' : ''}`}
    >
      Become a Seller
    </Link>
  </div>
);

const TrustStrip = ({ className = '' }) => (
  <div className={`flex flex-wrap items-center gap-x-6 gap-y-2 ${className}`}>
    {[[ShieldCheck, 'Verified Creators'], [BadgeCheck, 'Buyer Protection'], [Zap, 'Instant Download']].map(([Icon, label]) => (
      <div key={label} className="flex items-center gap-1.5 text-xs font-medium text-foreground/70">
        <Icon className="w-3.5 h-3.5 text-primary" aria-hidden="true" />
        {label}
      </div>
    ))}
  </div>
);

const StatsRow = ({ stats, cols = 4, className = '' }) => (
  <motion.div
    initial="hidden"
    whileInView="show"
    viewport={{ once: true }}
    variants={fadeUp}
    className={`glass rounded-3xl soft-shadow px-3 sm:px-6 py-4 sm:py-6 ${className}`}
  >
    <dl className={`grid ${cols === 3 ? 'grid-cols-3' : 'grid-cols-2 lg:grid-cols-4'} divide-x divide-border/70 text-center`}>
      {stats.map((s) => (
        <div key={s.label} className="flex flex-col items-center justify-center gap-1 sm:gap-1.5 px-1 sm:px-2">
          <span className="hidden sm:grid place-items-center w-9 h-9 rounded-xl bg-primary/10 text-primary mb-0.5">
            <s.icon className="w-4 h-4" aria-hidden="true" />
          </span>
          <dt className="sr-only">{s.label}</dt>
          <dd>
            <span className="block text-base sm:text-xl font-extrabold brand-text">{s.value}</span>
            <span className="block text-[10px] sm:text-xs text-muted-foreground mt-0.5 leading-tight">{s.label}</span>
          </dd>
        </div>
      ))}
    </dl>
  </motion.div>
);

/* ------------------------------------------------------------------ */
/*  Floating product card (desktop, absolutely positioned + parallax)  */
/* ------------------------------------------------------------------ */
const FloatingCard = ({ card, parallax }) => {
  const Icon = card.icon;
  return (
    <div
      className={`absolute ${card.wrap}`}
      style={{
        zIndex: card.z,
        transform: `translate3d(${parallax.x * card.depth}px, ${parallax.y * card.depth}px, 0)`,
        transition: 'transform 0.35s ease-out',
      }}
    >
      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.9, rotate: card.rotate }}
        animate={{ opacity: 1, y: [0, -12, 0], scale: 1, rotate: card.rotate }}
        transition={{
          opacity: { duration: 0.6, delay: card.delay },
          scale: { duration: 0.6, delay: card.delay },
          y: { duration: card.duration, repeat: Infinity, ease: 'easeInOut', delay: card.delay },
        }}
        whileHover={{ scale: 1.07, rotate: 0, zIndex: 50 }}
        className="glass rounded-2xl p-3 soft-shadow-lg w-[10rem] xl:w-[10.5rem] cursor-pointer"
      >
        <div className="relative rounded-xl overflow-hidden h-20 xl:h-24 grid place-items-center" style={{ background: card.gradient }}>
          <Icon className="w-8 h-8 text-white/95" strokeWidth={1.6} aria-hidden="true" />
          {card.bestseller && (
            <span className="absolute top-1.5 left-1.5 inline-flex items-center gap-1 text-[9px] font-bold bg-white/95 text-foreground px-1.5 py-0.5 rounded-full">
              <TrendingUp className="w-2.5 h-2.5" aria-hidden="true" /> Bestseller
            </span>
          )}
        </div>
        <div className="mt-2.5 px-0.5">
          <p className="text-[10.5px] font-medium text-muted-foreground truncate">{card.category}</p>
          <p className="text-[13px] font-bold leading-snug truncate">{card.title}</p>
          <div className="flex items-center justify-between mt-1.5">
            <span className="text-sm font-extrabold brand-text">${card.price}</span>
            <span className="flex items-center gap-0.5 text-[11px] font-semibold text-foreground/70">
              <Star className="w-3 h-3 fill-amber-400 text-amber-400" aria-hidden="true" /> {card.rating}
            </span>
          </div>
          <p className="text-[10px] text-muted-foreground mt-1 truncate">by {card.creator}</p>
        </div>
      </motion.div>
    </div>
  );
};

/** Desktop-only floating cluster with subtle mouse-parallax + perpetual float. */
const DesktopMarketplaceVisual = () => {
  const ref = useRef(null);
  const [parallax, setParallax] = useState({ x: 0, y: 0 });

  const handleMove = useCallback((e) => {
    const rect = ref.current?.getBoundingClientRect();
    if (!rect) return;
    const x = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
    const y = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
    setParallax({ x: x * 11, y: y * 11 });
  }, []);
  const handleLeave = useCallback(() => setParallax({ x: 0, y: 0 }), []);

  return (
    <div
      ref={ref}
      onMouseMove={handleMove}
      onMouseLeave={handleLeave}
      className="relative w-full h-[32rem] xl:h-[36rem]"
      aria-hidden="true"
    >
      {/* mesh glow */}
      <div className="absolute inset-0 -z-10 flex items-center justify-center">
        <div className="w-[85%] h-[85%] rounded-full bg-gradient-to-br from-primary/25 via-accent/15 to-transparent blur-3xl" />
      </div>
      {/* dotted texture */}
      <div
        className="absolute inset-0 -z-10 opacity-30"
        style={{ backgroundImage: 'radial-gradient(rgba(108,59,255,0.35) 1px, transparent 1.5px)', backgroundSize: '20px 20px' }}
      />
      {FLOATING_CARDS.map((card) => (
        <FloatingCard key={card.id} card={card} parallax={parallax} />
      ))}
    </div>
  );
};

/** Mobile-only horizontal showcase — same catalog, entirely different composition. */
const MobileMarketplaceShowcase = ({ className = '' }) => (
  <div className={`-mx-4 px-4 sm:-mx-6 sm:px-6 ${className}`}>
    <div className="flex gap-3 overflow-x-auto no-scrollbar pb-1 snap-x snap-mandatory">
      {FLOATING_CARDS.map((card, i) => {
        const Icon = card.icon;
        return (
          <motion.div
            key={card.id}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: [0, -8, 0] }}
            transition={{
              opacity: { duration: 0.5, delay: i * 0.06 },
              y: { duration: 5 + (i % 3), repeat: Infinity, ease: 'easeInOut', delay: i * 0.15 },
            }}
            className="glass rounded-2xl p-2.5 soft-shadow-lg w-[8.5rem] shrink-0 snap-start"
          >
            <div className="relative rounded-xl overflow-hidden h-[4.5rem] grid place-items-center" style={{ background: card.gradient }}>
              <Icon className="w-6 h-6 text-white/95" strokeWidth={1.6} aria-hidden="true" />
              {card.bestseller && (
                <span className="absolute top-1 left-1 text-[8px] font-bold bg-white/95 text-foreground px-1.5 py-0.5 rounded-full">Bestseller</span>
              )}
            </div>
            <div className="mt-2 px-0.5">
              <p className="text-[11px] font-bold leading-snug truncate">{card.title}</p>
              <div className="flex items-center justify-between mt-1">
                <span className="text-[12.5px] font-extrabold brand-text">${card.price}</span>
                <span className="flex items-center gap-0.5 text-[10px] font-semibold text-foreground/70">
                  <Star className="w-2.5 h-2.5 fill-amber-400 text-amber-400" aria-hidden="true" /> {card.rating}
                </span>
              </div>
              <p className="text-[9px] text-muted-foreground mt-0.5 truncate">by {card.creator}</p>
            </div>
          </motion.div>
        );
      })}
    </div>
  </div>
);

/* ------------------------------------------------------------------ */
/*  Hero                                                                */
/* ------------------------------------------------------------------ */
/**
 * Homepage hero — rebuilt from scratch as a premium digital-marketplace
 * landing moment (Creative Market / Envato / UI8 territory): big bold
 * two-line headline, in-hero marketplace search with category pills,
 * a powerful CTA pair, live marketplace stats, and a cluster of floating
 * product-preview cards with glassmorphism, mesh gradients and mouse
 * parallax. Mobile ships a fully dedicated composition, not a shrunk
 * desktop layout.
 */
const HeroSection = () => (
  <section className="mx-auto max-w-[90rem] px-3 sm:px-5 lg:px-8 pt-4 lg:pt-6" aria-label="Welcome to PicaMarts — the marketplace for premium digital products">
    <div className="relative overflow-hidden rounded-[2rem] lg:rounded-[2.5rem] bg-gradient-to-br from-[#F3EEFF] via-[#FBF7FF] to-[#FFEFFA] border border-white/70 soft-shadow">
      {/* ambient mesh blobs */}
      <div className="absolute -top-40 -right-32 w-[42rem] h-[42rem] rounded-full brand-gradient opacity-20 blur-3xl animate-hero-blob" aria-hidden="true" />
      <div className="absolute top-52 -left-40 w-[30rem] h-[30rem] rounded-full bg-accent opacity-10 blur-3xl animate-hero-blob" style={{ animationDelay: '2s' }} aria-hidden="true" />
      <div className="absolute bottom-0 right-1/4 w-[24rem] h-[24rem] rounded-full bg-[#12B8E0] opacity-10 blur-3xl animate-hero-blob" style={{ animationDelay: '4s' }} aria-hidden="true" />

      {/* ============================= DESKTOP ============================= */}
      <div className="hidden lg:block relative px-10 xl:px-14 pt-14 pb-10">
        <div className="grid grid-cols-2 gap-14 items-center">
          {/* Left — copy, search, pills, CTA */}
          <div>
            <TrustBadge />

            <motion.h1
              initial="hidden"
              animate="show"
              custom={1}
              variants={fadeUp}
              className="mt-6 text-5xl xl:text-[3.75rem] font-black tracking-tight leading-[1.05]"
            >
              The Marketplace for
              <br />
              <span className="brand-text">Premium Digital Products</span>
            </motion.h1>

            <motion.p
              initial="hidden"
              animate="show"
              custom={2}
              variants={fadeUp}
              className="mt-5 text-lg text-muted-foreground max-w-lg leading-relaxed"
            >
              UI kits, templates, logos and mockups from 12,000+ verified creators.
              Instant downloads, clean licensing, zero hassle.
            </motion.p>

            <motion.div initial="hidden" animate="show" custom={3} variants={fadeUp} className="mt-8">
              <HeroSearchBar />
            </motion.div>

            <motion.div initial="hidden" animate="show" custom={4} variants={fadeUp} className="mt-4">
              <CategoryPills />
            </motion.div>

            <motion.div initial="hidden" animate="show" custom={5} variants={fadeUp} className="mt-8">
              <CTAButtons />
            </motion.div>

            <motion.div initial="hidden" animate="show" custom={6} variants={fadeUp}>
              <TrustStrip className="mt-7" />
            </motion.div>
          </div>

          {/* Right — floating product cluster */}
          <DesktopMarketplaceVisual />
        </div>

        <StatsRow stats={STATS} cols={4} className="mt-12" />
      </div>

      {/* ============================= MOBILE ============================= */}
      <div className="lg:hidden relative px-4 sm:px-6 pt-8 pb-8">
        <TrustBadge compact />

        <motion.h1
          initial="hidden"
          animate="show"
          custom={1}
          variants={fadeUp}
          className="mt-4 text-3xl sm:text-4xl font-black tracking-tight leading-[1.08]"
        >
          The Marketplace for <span className="brand-text">Premium Digital Products</span>
        </motion.h1>

        <motion.p
          initial="hidden"
          animate="show"
          custom={2}
          variants={fadeUp}
          className="mt-3 text-sm sm:text-[15px] text-muted-foreground leading-relaxed max-w-md"
        >
          UI kits, templates, logos and mockups from verified creators — instant downloads, clean licensing.
        </motion.p>

        <motion.div initial="hidden" animate="show" custom={3} variants={fadeUp} className="mt-5">
          <HeroSearchBar size="sm" />
        </motion.div>

        <motion.div initial="hidden" animate="show" custom={4} variants={fadeUp} className="mt-3.5">
          <CategoryPills scrollable />
        </motion.div>

        <motion.div initial="hidden" animate="show" custom={5} variants={fadeUp} className="mt-6">
          <CTAButtons stacked className="sm:flex-row sm:[&>*]:w-auto" />
        </motion.div>

        <motion.div initial="hidden" animate="show" custom={6} variants={fadeUp} className="mt-8">
          <p className="text-xs font-semibold text-muted-foreground mb-3">Trending on PicaMarts</p>
          <MobileMarketplaceShowcase />
        </motion.div>

        <StatsRow stats={STATS.slice(0, 3)} cols={3} className="mt-7" />
      </div>
    </div>
  </section>
);

export default HeroSection;
