import React from 'react';
import { Check } from 'lucide-react';
import ShipmentStatusBadge from './ShipmentStatusBadge';

const fmt = (iso) =>
  new Date(iso).toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });

/**
 * Phase 14.2, Part 8 — "View Timeline". Renders a Shipment's own
 * `timeline` array (see models/Shipment.js#shipmentTimelineEntrySchema)
 * as a vertical, newest-first activity log — one entry per status
 * transition, each carrying its own note and timestamp.
 */
const ShipmentTimeline = ({ timeline = [], className = '' }) => {
  if (!timeline.length) {
    return <p className={`text-sm text-muted-foreground ${className}`}>No activity recorded yet.</p>;
  }

  const entries = [...timeline].sort((a, b) => new Date(b.at) - new Date(a.at));

  return (
    <ol className={`space-y-0 ${className}`}>
      {entries.map((entry, i) => (
        <li key={`${entry.status}-${entry.at}-${i}`} className="relative pl-6 pb-5 last:pb-0">
          {i !== entries.length - 1 && <span className="absolute left-[7px] top-4 bottom-0 w-px bg-border" aria-hidden="true" />}
          <span className="absolute left-0 top-0.5 grid place-items-center w-4 h-4 rounded-full bg-primary text-white">
            <Check className="w-2.5 h-2.5" />
          </span>
          <div className="flex flex-wrap items-center gap-2">
            <ShipmentStatusBadge status={entry.status} />
            <span className="text-xs text-muted-foreground">{fmt(entry.at)}</span>
          </div>
          {entry.note && <p className="text-sm mt-1 text-muted-foreground">{entry.note}</p>}
        </li>
      ))}
    </ol>
  );
};

export default ShipmentTimeline;
