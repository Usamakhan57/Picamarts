import React from 'react';
import { Truck, AlertTriangle } from 'lucide-react';

/**
 * Phase 14.2, Part 5/6 — shows the real backend's shipping estimate
 * (POST /checkout/shipping, see services/checkoutService.js#estimateShipping)
 * for the buyer's current destination address, and lets them pick a
 * preferred method for reference. This is informational only — the
 * order's own persisted `shipping` total still comes from the cart's
 * saved per-product shipping data (see lib/shipping.js), same as
 * checkout.service.js's own estimateShipping already documents; this
 * card never feeds a value back into order creation.
 */
const ShippingEstimateCard = ({ loading, estimate, error, selectedMethodKey, onSelect, className = '' }) => {
  if (loading) {
    return (
      <div className={`bg-white rounded-3xl border border-border soft-shadow p-6 ${className}`}>
        <div className="h-4 w-40 rounded bg-secondary/60 animate-pulse mb-4" />
        <div className="space-y-2">
          <div className="h-12 rounded-xl bg-secondary/60 animate-pulse" />
          <div className="h-12 rounded-xl bg-secondary/60 animate-pulse" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={`bg-white rounded-3xl border border-border soft-shadow p-6 ${className}`}>
        <p className="flex items-center gap-2 text-sm text-muted-foreground">
          <AlertTriangle className="w-4 h-4" /> Couldn't load a shipping estimate for this address yet.
        </p>
      </div>
    );
  }

  if (!estimate || !estimate.shippingRequired) return null;

  const methods = estimate.methods || [];
  const unconfigured = estimate.unconfiguredItems || [];

  return (
    <div className={`bg-white rounded-3xl border border-border soft-shadow p-6 ${className}`}>
      <h2 className="font-bold flex items-center gap-2 mb-1">
        <Truck className="w-4 h-4 text-primary" /> Shipping Estimate
      </h2>
      <p className="text-xs text-muted-foreground mb-4">Estimated cost and delivery window for this address.</p>

      {methods.length === 0 ? (
        <p className="text-sm text-muted-foreground">No shipping methods are available for this destination yet.</p>
      ) : (
        <div className="space-y-2">
          {methods.map((method) => {
            const key = `${method.profileId}-${method.zoneId || 'free'}-${method.rateId || 'free'}`;
            const selected = selectedMethodKey === key;
            return (
              <button
                key={key}
                type="button"
                onClick={() => onSelect?.(key, method)}
                className={`w-full flex items-center justify-between gap-3 px-4 py-3 rounded-xl border text-left transition-colors ${
                  selected ? 'border-primary bg-primary/5' : 'border-border hover:bg-secondary/40'
                }`}
              >
                <div>
                  <p className="text-sm font-semibold">{method.methodName}</p>
                  {method.estimatedDeliveryDays && (
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {method.estimatedDeliveryDays.min}–{method.estimatedDeliveryDays.max} business days
                    </p>
                  )}
                </div>
                <span className="text-sm font-bold shrink-0">{method.cost === 0 ? 'Free' : `$${method.cost.toFixed(2)}`}</span>
              </button>
            );
          })}
        </div>
      )}

      {unconfigured.length > 0 && (
        <p className="mt-3 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-xl p-2.5">
          {unconfigured.length} item{unconfigured.length > 1 ? 's' : ''} in your cart don't have shipping configured by the seller yet —
          contact the seller before ordering, or shipping will be estimated separately.
        </p>
      )}
    </div>
  );
};

export default ShippingEstimateCard;
