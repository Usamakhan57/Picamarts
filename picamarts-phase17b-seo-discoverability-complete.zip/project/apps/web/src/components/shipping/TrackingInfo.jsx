import React from 'react';
import { Truck, Copy, ExternalLink } from 'lucide-react';
import { useToast } from '../../hooks/use-toast';

/**
 * Phase 14.2, Part 8 — carrier + tracking number for one shipment, with
 * click-to-copy and an optional link out to the carrier's own tracking
 * page (`trackingUrl`, seller/admin-entered — see Shipment.trackingUrl).
 * Renders nothing when there's no tracking number yet (still pending).
 */
const TrackingInfo = ({ carrier, trackingNumber, trackingUrl, className = '' }) => {
  const { toast } = useToast();

  if (!trackingNumber) return null;

  const copy = () => {
    navigator.clipboard?.writeText(trackingNumber).catch(() => {});
    toast({ title: 'Tracking number copied', description: trackingNumber });
  };

  return (
    <div className={`flex flex-wrap items-center gap-2 ${className}`}>
      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground">
        <Truck className="w-3.5 h-3.5" /> {carrier || 'Carrier'}
      </span>
      <button
        onClick={copy}
        title="Click to copy"
        className="inline-flex items-center gap-1.5 text-[11px] font-mono font-semibold px-2.5 py-1 rounded-md border border-border bg-secondary/40 hover:bg-secondary transition-colors"
      >
        <Copy className="w-3 h-3" /> {trackingNumber}
      </button>
      {trackingUrl && (
        <a
          href={trackingUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline"
        >
          Track <ExternalLink className="w-3 h-3" />
        </a>
      )}
    </div>
  );
};

export default TrackingInfo;
