import React from 'react';
import { Clock, PackageCheck, Truck, Home, Undo2 } from 'lucide-react';

/**
 * Phase 14.2, Part 8 — one shared visual for a Shipment's `status`
 * field everywhere it's shown (customer tracking, seller/admin
 * dashboards). Matches apps/api/src/constants/shippingEnums.js#SHIPMENT_STATUSES
 * exactly — five values, nothing invented on the frontend.
 */
const STATUS_META = {
  pending: { label: 'Pending', icon: Clock, className: 'bg-amber-100 text-amber-700' },
  shipped: { label: 'Shipped', icon: PackageCheck, className: 'bg-indigo-100 text-indigo-700' },
  in_transit: { label: 'In Transit', icon: Truck, className: 'bg-blue-100 text-blue-700' },
  delivered: { label: 'Delivered', icon: Home, className: 'bg-emerald-100 text-emerald-700' },
  returned: { label: 'Returned', icon: Undo2, className: 'bg-red-100 text-red-700' },
};

const ShipmentStatusBadge = ({ status, className = '' }) => {
  const meta = STATUS_META[status] || { label: status || 'Unknown', icon: Clock, className: 'bg-gray-100 text-gray-600' };
  const Icon = meta.icon;
  return (
    <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap ${meta.className} ${className}`}>
      <Icon className="w-3.5 h-3.5" /> {meta.label}
    </span>
  );
};

export default ShipmentStatusBadge;
