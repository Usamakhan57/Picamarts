import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Star, Download, Heart, ShoppingBag, ArrowRight } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from './ui/dialog';
import { useStore } from '../context/StoreContext';
import { useToast } from '../hooks/use-toast';

/**
 * Lightweight product preview opened from a card's Quick View action.
 * Shows the essentials with paths to the full page or straight to cart.
 */
const QuickViewDialog = ({ product, open, onOpenChange }) => {
  const { addToCart, toggleWishlist, inWishlist } = useStore();
  const { toast } = useToast();
  const navigate = useNavigate();

  if (!product) return null;

  const realId = product.baseId ?? product.id;
  const wishlisted = inWishlist(realId);

  const handleAdd = async () => {
    try {
      await addToCart({ ...product, id: realId });
      toast({ title: 'Added to cart', description: product.title });
      onOpenChange(false);
    } catch (err) {
      if (err?.requiresAuth) {
        toast({ title: 'Please log in', description: 'Log in to add items to your cart.' });
        onOpenChange(false);
        navigate('/login');
      } else {
        toast({ title: 'Could not add to cart', description: err?.message || 'Please try again.', variant: 'destructive' });
      }
    }
  };

  const handleToggleWishlist = async () => {
    try {
      await toggleWishlist({ ...product, id: realId });
    } catch (err) {
      if (err?.requiresAuth) {
        toast({ title: 'Please log in', description: 'Log in to save items to your wishlist.' });
        onOpenChange(false);
        navigate('/login');
      } else {
        toast({ title: 'Could not update wishlist', description: err?.message || 'Please try again.', variant: 'destructive' });
      }
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl rounded-3xl p-0 overflow-hidden">
        <div className="grid sm:grid-cols-2">
          <div className="relative bg-secondary aspect-square sm:aspect-auto">
            <img src={product.img} alt={product.title} className="w-full h-full object-cover" />
            {product.badge && (
              <span className="absolute top-4 left-4 text-[11px] font-semibold px-2.5 py-1 rounded-full bg-white/90 backdrop-blur">
                {product.badge}
              </span>
            )}
          </div>
          <div className="p-6 sm:p-8 flex flex-col">
            <p className="text-xs font-semibold text-primary">{product.cat}</p>
            <DialogTitle className="mt-1.5 text-xl font-bold leading-snug">{product.title}</DialogTitle>
            <DialogDescription className="sr-only">Quick view of {product.title}</DialogDescription>
            <p className="text-sm text-muted-foreground mt-1">by {product.artist}</p>

            <div className="flex items-center gap-4 mt-3 text-sm">
              <span className="flex items-center gap-1 font-medium">
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" aria-hidden="true" /> {product.rating}
                <span className="text-muted-foreground font-normal">({product.reviewCount})</span>
              </span>
              <span className="flex items-center gap-1 text-muted-foreground">
                <Download className="w-4 h-4" aria-hidden="true" /> {((product.downloads ?? 0) / 1000).toFixed(1)}k downloads
              </span>
            </div>

            <p className="mt-4 text-sm text-muted-foreground leading-relaxed line-clamp-3">{product.description}</p>

            <div className="flex flex-wrap gap-1.5 mt-4">
              {product.fileTypes?.map((t) => (
                <span key={t} className="text-[11px] font-medium px-2.5 py-1 rounded-full bg-secondary text-secondary-foreground">{t}</span>
              ))}
            </div>

            <div className="mt-auto pt-6">
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-extrabold">${product.price}</span>
                {product.old && <span className="text-sm text-muted-foreground line-through">${product.old}</span>}
              </div>
              <div className="flex items-center gap-2 mt-4">
                <button
                  type="button"
                  onClick={handleAdd}
                  className="flex-1 inline-flex items-center justify-center gap-2 px-5 py-3 rounded-full brand-gradient text-white text-sm font-semibold soft-shadow hover:opacity-95 active:scale-[0.98] transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                >
                  <ShoppingBag className="w-4 h-4" /> Add to Cart
                </button>
                <button
                  type="button"
                  aria-label={wishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
                  aria-pressed={wishlisted}
                  onClick={handleToggleWishlist}
                  className="grid place-items-center w-11 h-11 rounded-full border border-border hover:bg-secondary transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <Heart className={`w-4 h-4 ${wishlisted ? 'fill-accent text-accent' : ''}`} />
                </button>
              </div>
              <Link
                to={`/product/${realId}`}
                onClick={() => onOpenChange(false)}
                className="mt-3 inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:gap-2.5 transition-all"
              >
                View full details <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default QuickViewDialog;
