/**
 * adminProductService.js — Phase 15C, Part 5. Real backend-backed
 * adapter for the Admin Products list, Product Form, and Inventory
 * pages. Replaces the old mock `admin/api/products.js` entirely.
 *
 * Every function maps 1:1 to a real /products endpoint (Phase 5 CRUD +
 * listing/filtering, Phase 6 media). No bulk-action endpoint exists on
 * the backend, so "bulk" operations here are sequential loops over the
 * real single-item endpoints — an accepted, disclosed choice rather
 * than inventing a backend feature that isn't there.
 */
import api from './apiClient';

/** Backend Product → the flat shape this admin's list/form/inventory pages read. Keeps the raw `category`/`brand`/`collection` refs (populated docs or bare ids) alongside a few convenience aliases. */
export const mapProduct = (p) => ({
  ...p,
  price: p.basePrice,
  categoryId: typeof p.category === 'string' ? p.category : p.category?.id || '',
  categoryName: typeof p.category === 'object' ? p.category?.name : '',
  brandId: typeof p.brand === 'string' ? p.brand : p.brand?.id || '',
  collectionId: typeof p.collection === 'string' ? p.collection : p.collection?.id || '',
  tagNames: (p.tags || []).map((t) => (typeof t === 'string' ? t : t.name)),
  thumbnailUrl: p.thumbnail?.url || '',
  galleryUrls: (p.gallery || []).map((g) => ({ id: g.id, url: g.url })),
});

/**
 * Admin-wide product listing (every seller, every status incl. the
 * soft-delete "deleted" trash, via ?status=deleted). Supports the same
 * page/limit/sort/q/category/brand/collection/status/featured/
 * stockStatus params as GET /products/admin.
 */
export const listAdminProducts = (params = {}) =>
  api.get('/products/admin', { params }).then((res) => ({
    products: res.data.map(mapProduct),
    pagination: res.pagination,
  }));

export const getAdminProduct = (id) => api.get(`/products/${id}`).then((res) => mapProduct(res.data.product));

export const createAdminProduct = (payload) => api.post('/products', payload).then((res) => mapProduct(res.data.product));

export const updateAdminProduct = (id, payload) => api.patch(`/products/${id}`, payload).then((res) => mapProduct(res.data.product));

export const changeAdminProductStatus = (id, status) =>
  api.patch(`/products/${id}/status`, { status }).then((res) => mapProduct(res.data.product));

/** Soft-delete only — the backend never physically removes a product. */
export const deleteAdminProduct = (id) => api.delete(`/products/${id}`);

/** Sequential loop over the real soft-delete endpoint — no bulk-delete endpoint exists on the backend. */
export const bulkDeleteAdminProducts = async (ids) => {
  for (const id of ids) {
    // eslint-disable-next-line no-await-in-loop -- deliberately sequential, see file header
    await deleteAdminProduct(id);
  }
};

/** Sequential loop over the real status endpoint. */
export const bulkChangeAdminProductStatus = async (ids, status) => {
  for (const id of ids) {
    // eslint-disable-next-line no-await-in-loop -- deliberately sequential, see file header
    await changeAdminProductStatus(id, status);
  }
};

/** Total product count matching an arbitrary filter, read off the pagination envelope of a 1-item request — used for category/brand/collection "N products" counts without a dedicated count endpoint. */
export const countAdminProducts = (params = {}) =>
  api.get('/products/admin', { params: { ...params, limit: 1 } }).then((res) => res.pagination?.totalItems || 0);

// ---------------------------------------------------------------------
// Media (Phase 6) — real Cloudinary uploads. Only available once a
// product exists (these are /products/:id/... endpoints), so the
// Product Form only offers them in Edit mode; Create mode keeps the
// shared ImageUploadInput's local preview but does not send it to the
// backend (same disclosed gap as services/sellerProductService.js).
// ---------------------------------------------------------------------
export const uploadProductThumbnail = (id, file) => {
  const formData = new FormData();
  formData.append('image', file);
  return api.post(`/products/${id}/thumbnail`, formData, { headers: { 'Content-Type': 'multipart/form-data' } }).then((res) => mapProduct(res.data.product));
};

export const uploadProductGalleryImages = (id, files) => {
  const formData = new FormData();
  Array.from(files).forEach((file) => formData.append('images', file));
  return api.post(`/products/${id}/images`, formData, { headers: { 'Content-Type': 'multipart/form-data' } }).then((res) => mapProduct(res.data.product));
};

export const removeProductGalleryImage = (id, imageId) => api.delete(`/products/${id}/images/${imageId}`).then((res) => mapProduct(res.data.product));
