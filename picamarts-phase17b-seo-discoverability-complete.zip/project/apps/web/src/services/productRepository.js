/**
 * productRepository.js — maps backend Product docs to the storefront
 * product shape every page/component already expects, and provides the
 * few synchronous lookups (category product counts) that read from the
 * bounded product cache in catalogStore.js.
 *
 * The async fetch functions themselves (list/get/curated feeds/search)
 * live in services/api.js, which is the layer every page already calls
 * through `productsApi` — this file only maps and resolves references.
 *
 * Schema mapping (backend Product → storefront shape):
 *   title/basePrice/salePrice     → title/price/old (unchanged names, salePrice wins when set)
 *   thumbnail.url / gallery[].url → img / images[]
 *   category (id)                 → categoryId + cat (name, via categoryRepository) + catSlug
 *   brand (id)                    → artist (brand display name, via resolveBrandName below)
 *   licenses (id[])                → licenses[] (full License docs: id/name/price/description/commercialRights/enabled)
 *   ratingAverage/ratingCount      → rating/reviewCount
 *   downloads/views/salesCount     → downloads (unchanged)
 *   No frontend `fileTypes` concept exists on the backend schema — falls
 *   back to a generic ['Digital File'] tag rather than inventing data.
 */
import { resolveCategoryName, resolveCategorySlug } from './categoryRepository';
import { getBrandsRaw, getLicensesRaw, getProductsCacheRaw } from './catalogStore';

/** Resolve a brand id to its display name — same pattern as categoryRepository's resolveCategoryName. */
function resolveBrandName(brandId) {
  if (!brandId) return null;
  const found = getBrandsRaw().find((b) => String(b.id) === String(brandId));
  return found ? found.name : null;
}

/** Resolve a product's license id refs to full license objects, in the shape ProductDetailPage's license selector expects. */
function resolveLicenses(licenseIds, basePrice) {
  if (!Array.isArray(licenseIds) || licenseIds.length === 0) return [];
  const catalog = getLicensesRaw();
  return licenseIds
    .map((licenseId) => catalog.find((l) => String(l.id) === String(licenseId)))
    .filter(Boolean)
    .map((l) => ({
      id: l.id,
      name: l.name,
      price: Math.round((basePrice || 0) * (l.priceMultiplier ?? 1) * 100) / 100,
      description: l.description || '',
      commercialRights: !!l.commercialUse,
      enabled: l.active !== false,
    }));
}

/** Map one backend Product doc to the storefront product shape. */
export function mapBackendProduct(p) {
  if (!p) return null;

  const displayPrice = p.salePrice != null ? p.salePrice : p.basePrice;
  const oldPrice = p.salePrice != null ? p.basePrice : null;

  let badge = null;
  if (p.salePrice != null) badge = 'Sale';
  else if (p.featured) badge = 'Featured';

  const rawImages = Array.isArray(p.gallery) && p.gallery.length > 0
    ? p.gallery.map((img) => img.url).filter(Boolean)
    : [];
  const thumbnailUrl = p.thumbnail?.url || null;
  const images = thumbnailUrl ? [thumbnailUrl, ...rawImages.filter((u) => u !== thumbnailUrl)] : rawImages;

  const licenses = resolveLicenses(p.licenses, p.basePrice);

  return {
    // Core identity
    id: p.id,
    title: p.title,
    slug: p.slug || String(p.id),

    // Category
    categoryId: p.category || null,
    cat: (p.category && resolveCategoryName(p.category)) || 'Others',
    catSlug: p.category ? resolveCategorySlug(p.category) : null,

    // Pricing
    price: displayPrice,
    old: oldPrice,

    // Media
    img: thumbnailUrl || images[0] || null,
    images: images.length > 0 ? images : [''],

    // Discovery
    badge,
    rating: p.ratingAverage ?? 0,
    reviewCount: p.ratingCount ?? 0,
    downloads: p.downloads ?? 0,

    // Attribution
    artist: resolveBrandName(p.brand) || 'PicaMarts',

    // Product details for ProductDetailPage
    fileTypes: p.compatibleWith?.length ? p.compatibleWith : ['Digital File'],
    dimensions: p.dimensions || null,
    version: p.version || null,
    description: p.description || '',
    whatsIncluded: '',
    licenseIds: (p.licenses || []).map(String),
    licenses,
    faqs: [],

    // Shipping
    productType: p.type === 'physical' ? 'physical' : 'digital',
    shipping: p.type === 'physical'
      ? { productType: 'physical', shippingClass: p.shippingClass || '', weight: p.weight, dimensions: p.dimensions }
      : { productType: 'digital' },

    // Inventory
    sku: p.sku || null,
    unlimitedStock: p.allowBackorder ?? null,
    stock: p.stock ?? null,
    lowStockThreshold: p.lowStockThreshold ?? null,
    barcode: null,

    // Extended digital-product fields
    fileSize: p.fileSize || null,
    resolution: null,
    orientation: null,
    colorSpace: null,
    requirements: null,
    supportedSoftware: Array.isArray(p.compatibleWith) ? p.compatibleWith : [],
    compatibleVersions: [],
    liveDemoUrl: null,
    shortDescription: p.shortDescription || '',

    featured: !!p.featured,
    status: p.status,
    tags: (p.tags || []).map(String),
    createdAt: p.createdAt || new Date().toISOString(),

    // Phase 17B — SEO & Discoverability. Previously dropped entirely on
    // the floor here, so admin-set SEO overrides never reached the
    // storefront even though the fields existed on the backend model.
    seoTitle: p.seoTitle || '',
    seoDescription: p.seoDescription || '',
    canonicalUrl: p.canonicalUrl || '',
    ogImage: p.ogImage || '',
    noIndex: !!p.noIndex,
  };
}

/**
 * Synchronous, real-data-backed product list — reads the same bounded
 * cache as getProductCountByCategoryId (see catalogStore.js's header
 * comment on the cap). Kept for the Seller Dashboard's mock "New Product"
 * seed data (pages/seller/api/sellerProducts.js), which predates the
 * Seller Dashboard backend-integration sub-phase (13.7) and just needs
 * *some* real catalog data to seed its demo list from — not the primary
 * product-browsing path (that's productsApi.list in api.js, which queries
 * the backend live).
 */
export function loadStorefrontProducts() {
  return getProductsCacheRaw().map(mapBackendProduct);
}

/**
 * Count of visible products per categoryId, from the bounded product cache
 * (catalogStore — see that file's header comment on why it's capped).
 * Powers the "Products Count" column on category listings; on a catalog
 * larger than the cache's cap this will undercount — a flagged, accepted
 * tradeoff until a dedicated backend aggregate endpoint exists.
 */
export function getProductCountByCategoryId() {
  const counts = {};
  for (const p of getProductsCacheRaw()) {
    if (!p.category) continue;
    const key = String(p.category);
    counts[key] = (counts[key] || 0) + 1;
  }
  return counts;
}
