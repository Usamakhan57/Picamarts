/**
 * wishlistService.js — thin wrappers around the real backend's /wishlist
 * endpoints. Keyed by productId (not a line id) — see
 * apps/api/src/routes/v1/wishlist.routes.js.
 */
import api from './apiClient';

export const getWishlist = () => api.get('/wishlist').then((res) => res.data.wishlist);

export const addWishlistItem = (productId) =>
  api.post('/wishlist', { productId }).then((res) => res.data.wishlist);

export const removeWishlistItem = (productId) =>
  api.delete(`/wishlist/${productId}`).then((res) => res.data.wishlist);

export const clearWishlistRequest = () => api.delete('/wishlist').then((res) => res.data.wishlist);

/** Atomically moves one wishlist item into the cart — returns both updated collections. */
export const moveWishlistItemToCart = (productId) =>
  api.post(`/wishlist/${productId}/move-to-cart`).then((res) => ({ wishlist: res.data.wishlist, cart: res.data.cart }));
