/**
 * sellerProductService.js — thin wrappers around the real backend's
 * seller-scoped /products endpoints (Phase 5 CRUD + Phase 6 media +
 * Phase 14.1 digital-file upload). Every function maps 1:1 to one route;
 * no client-side re-shaping of business rules.
 */
import api from './apiClient';

/** The authenticated seller's own products (any status except deleted). Supports the same page/limit/sort/q/status/category params as the public catalog. */
export const listMyProducts = (params = {}) =>
  api.get('/products/mine', { params }).then((res) => ({ products: res.data, meta: res.meta }));

export const getProduct = (id) => api.get(`/products/${id}`).then((res) => res.data.product);

export const createProduct = (payload) => api.post('/products', payload).then((res) => res.data.product);

export const updateProduct = (id, payload) => api.patch(`/products/${id}`, payload).then((res) => res.data.product);

export const changeProductStatus = (id, status) =>
  api.patch(`/products/${id}/status`, { status }).then((res) => res.data.product);

export const deleteProduct = (id) => api.delete(`/products/${id}`);

// ---------------------------------------------------------------------
// Media (Phase 6) — real Cloudinary uploads. NOT yet wired into the
// product form UI (that form's ImageUploadInput is a shared,
// data-URL-only component used across the whole admin panel — rewiring
// it is its own media-upload sub-phase); these wrappers exist so that
// sub-phase can plug straight in without touching this service again.
// ---------------------------------------------------------------------
export const uploadThumbnail = (id, file) => {
  const formData = new FormData();
  formData.append('image', file);
  return api.post(`/products/${id}/thumbnail`, formData, { headers: { 'Content-Type': 'multipart/form-data' } }).then((res) => res.data.product);
};

export const uploadGalleryImages = (id, files) => {
  const formData = new FormData();
  Array.from(files).forEach((file) => formData.append('images', file));
  return api.post(`/products/${id}/images`, formData, { headers: { 'Content-Type': 'multipart/form-data' } }).then((res) => res.data.product);
};

export const removeGalleryImage = (id, imageId) => api.delete(`/products/${id}/images/${imageId}`).then((res) => res.data.product);

export const uploadDownloadFiles = (id, files) => {
  const formData = new FormData();
  Array.from(files).forEach((file) => formData.append('files', file));
  return api.post(`/products/${id}/downloads`, formData, { headers: { 'Content-Type': 'multipart/form-data' } }).then((res) => res.data.product);
};

export const removeDownloadFile = (id, fileId) => api.delete(`/products/${id}/downloads/${fileId}`).then((res) => res.data.product);
