/**
 * adminTagService.js — Phase 15C, Part 5. Thin wrapper around the real
 * backend's /tags endpoints (Phase 4), plus one helper the Admin Product
 * Form needs: resolving the free-text chip list the shared `TagsInput`
 * component produces into the real ObjectId array `Product.tags`
 * actually stores.
 *
 * Tag creation is open to sellers/admins (see tag.routes.js) and the Tag
 * model enforces a unique `name` index, so "resolve" here means
 * find-by-name-first, create-if-missing, with a defensive re-find if a
 * concurrent create raced us to the same name (409).
 */
import api from './apiClient';

export const listTags = (params = {}) =>
  api.get('/tags', { params }).then((res) => ({ tags: res.data.tags, meta: res.meta }));

const findTagByName = async (name) => {
  const { tags } = await listTags({ q: name, limit: 5 });
  return tags.find((t) => t.name.toLowerCase() === name.toLowerCase()) || null;
};

const findOrCreateTag = async (name) => {
  const existing = await findTagByName(name);
  if (existing) return existing;
  try {
    const res = await api.post('/tags', { name });
    return res.data.tag;
  } catch (err) {
    // Unique-name race: someone else created it between our find and create.
    if (err?.status === 409) {
      const retry = await findTagByName(name);
      if (retry) return retry;
    }
    throw err;
  }
};

/**
 * Maps a list of tag chips — each either a plain name string (freshly
 * typed in TagsInput) or an existing `{ id, name }` tag object (loaded
 * from a product being edited) — to a de-duplicated array of real Tag
 * ids, creating any brand-new names along the way.
 */
export const resolveTagsToIds = async (chips) => {
  const names = (chips || []).filter(Boolean);
  const ids = [];
  for (const chip of names) {
    if (typeof chip === 'object' && chip.id) {
      ids.push(chip.id);
      continue;
    }
    const name = String(chip).trim();
    if (!name) continue;
    // eslint-disable-next-line no-await-in-loop -- tag creation must stay sequential to avoid duplicate-name races against each other
    const tag = await findOrCreateTag(name);
    ids.push(tag.id);
  }
  return [...new Set(ids)];
};
