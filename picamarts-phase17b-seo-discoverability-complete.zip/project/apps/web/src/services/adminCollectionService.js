/**
 * adminCollectionService.js — Phase 15C, Part 5. Real backend-backed
 * adapter for the Admin Collections page. Replaces the old mock
 * `admin/api/collections.js` entirely.
 *
 * Schema mapping (backend Collection → admin list/form shape):
 *   active     → status: 'active' | 'draft'
 *   thumbnail.url → image (flat string)
 *
 * Known, disclosed gap: the old mock stored `productIds` directly on
 * each collection record (a collection "owns" a list of products). The
 * real relationship is the other way round — `Product.collection` is a
 * single ref pointing at one Collection — so there is no
 * `Collection.productIds` to read or write here. The membership count
 * shown in the list is derived via countAdminProducts (one request per
 * collection); assigning a product to a collection is done from the
 * Product Form's own Collection field, not from this page — there is no
 * backend endpoint to bulk-assign products to a collection from this
 * side.
 */
import api from './apiClient';

const mapFromBackend = (c) => ({
  ...c,
  status: c.active ? 'active' : 'draft',
  image: c.thumbnail?.url || c.banner?.url || '',
  metaKeywords: c.metaKeywords || [],
});

const mapToBackend = (form) => {
  const payload = {
    name: form.name,
    slug: form.slug || undefined,
    description: form.description || undefined,
    thumbnail: form.image ? { url: form.image } : undefined,
    featured: !!form.featured,
    active: form.status === 'active',
    seoTitle: form.seoTitle || undefined,
    seoDescription: form.seoDescription || undefined,
    // Phase 17B — SEO & Discoverability. Additive.
    canonicalUrl: form.canonicalUrl || undefined,
    metaKeywords: form.metaKeywords?.length ? form.metaKeywords : undefined,
    ogImage: form.ogImage || undefined,
    noIndex: !!form.noIndex,
  };
  Object.keys(payload).forEach((key) => payload[key] === undefined && delete payload[key]);
  return payload;
};

/** Every collection, one page at a time up to a generous cap (mirrors listAllCategories). */
export const listAllCollections = async () => {
  const all = [];
  let page = 1;
  // eslint-disable-next-line no-constant-condition -- bounded by the page/pageCap check below
  while (true) {
    // eslint-disable-next-line no-await-in-loop -- sequential pagination, bounded to 5 pages (500 collections)
    const res = await api.get('/collections', { params: { page, limit: 100, sort: 'name' } });
    all.push(...res.data.collections.map(mapFromBackend));
    const meta = res.meta;
    if (!meta || page >= meta.totalPages || page >= 5) break;
    page += 1;
  }
  return all;
};

export const getCollection = (id) => api.get(`/collections/${id}`).then((res) => mapFromBackend(res.data.collection));

export const createCollection = (form) => api.post('/collections', mapToBackend(form)).then((res) => mapFromBackend(res.data.collection));

export const updateCollection = (id, form) => api.patch(`/collections/${id}`, mapToBackend(form)).then((res) => mapFromBackend(res.data.collection));

export const deleteCollection = (id) => api.delete(`/collections/${id}`);

export const toggleCollectionActive = (id) => api.patch(`/collections/${id}/toggle-active`).then((res) => mapFromBackend(res.data.collection));

/** Real per-collection product counts (see file header). */
export const getProductCountByCollectionId = async (collections) => {
  const { countAdminProducts } = await import('./adminProductService');
  const counts = {};
  for (const collection of collections) {
    // eslint-disable-next-line no-await-in-loop -- bounded to the collection list's size
    counts[collection.id] = await countAdminProducts({ collection: collection.id });
  }
  return counts;
};
