/**
 * adminUserService.js — thin wrappers around the real backend's /users
 * admin endpoints (Phase 15C, Part 3). Read/moderate-only, matching the
 * backend: list/search/filter/paginate, view, suspend, activate, delete.
 * Requires an authenticated admin session — apiClient already attaches
 * the bearer token.
 */
import api from './apiClient';

/** Paginated/searchable/filterable user list. `params`: page, limit, q, sort, role, status. */
export const listUsers = (params = {}) =>
  api.get('/users', { params }).then((res) => ({ users: res.data.users, meta: res.meta }));

export const getUserById = (id) => api.get(`/users/${id}`).then((res) => res.data.user);

export const suspendUser = (id) => api.patch(`/users/${id}/suspend`).then((res) => res.data.user);

export const activateUser = (id) => api.patch(`/users/${id}/activate`).then((res) => res.data.user);

export const deleteUser = (id) => api.delete(`/users/${id}`).then((res) => res.data);
