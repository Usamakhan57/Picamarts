/**
 * Centralized API client.
 *
 * One Axios instance for the whole app (storefront + admin + seller/buyer
 * dashboards). Handles:
 *  - base URL + timeout
 *  - access-token injection on every request
 *  - httpOnly refresh-token cookie flow on 401 (single in-flight refresh,
 *    queued retries, hard logout if refresh itself fails)
 *  - unwraps the backend's { success, data, message } envelope so callers
 *    just get `data` back
 *
 * This is the ONLY place that talks to axios directly. Every other service
 * module imports `api` from here.
 */
import axios from 'axios';
import { API_BASE_URL } from '../constants';

const ACCESS_TOKEN_KEY = 'pm_access_token';

let accessToken = null;
try {
  accessToken = localStorage.getItem(ACCESS_TOKEN_KEY) || null;
} catch {
  accessToken = null;
}

/** In-memory subscribers waiting on session state changes (login/logout/refresh-failure). */
const sessionListeners = new Set();

export const onSessionChange = (listener) => {
  sessionListeners.add(listener);
  return () => sessionListeners.delete(listener);
};

const emitSessionChange = (event) => {
  sessionListeners.forEach((listener) => {
    try {
      listener(event);
    } catch {
      /* listener errors shouldn't break the auth flow */
    }
  });
};

export const getAccessToken = () => accessToken;

export const setAccessToken = (token) => {
  accessToken = token || null;
  try {
    if (token) localStorage.setItem(ACCESS_TOKEN_KEY, token);
    else localStorage.removeItem(ACCESS_TOKEN_KEY);
  } catch {
    /* localStorage may be unavailable (private browsing, SSR) — token still works in-memory */
  }
};

export const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 15000,
  withCredentials: true, // sends the httpOnly refresh-token cookie
  headers: { 'Content-Type': 'application/json' },
});

api.interceptors.request.use((config) => {
  if (accessToken) {
    config.headers = config.headers || {};
    config.headers.Authorization = `Bearer ${accessToken}`;
  }
  return config;
});

// Routes that must never trigger the refresh flow (avoids infinite loops /
// refreshing on the refresh call itself or on the login/register screens).
const NO_REFRESH_PATHS = ['/auth/login', '/auth/register', '/auth/refresh', '/auth/logout'];

let isRefreshing = false;
let pendingQueue = [];

const flushQueue = (error, token) => {
  pendingQueue.forEach(({ resolve, reject }) => {
    if (error) reject(error);
    else resolve(token);
  });
  pendingQueue = [];
};

const isNoRefreshPath = (url = '') => NO_REFRESH_PATHS.some((p) => url.includes(p));

api.interceptors.response.use(
  (response) => response.data,
  async (error) => {
    const { config, response } = error;

    if (!response) {
      // network error / timeout — surface a consistent shape
      return Promise.reject({ isNetworkError: true, message: 'Network error. Please check your connection.', original: error });
    }

    const status = response.status;
    const originalRequest = config || {};

    if (status === 401 && !originalRequest._retry && !isNoRefreshPath(originalRequest.url)) {
      if (isRefreshing) {
        // queue this request until the in-flight refresh resolves
        return new Promise((resolve, reject) => {
          pendingQueue.push({
            resolve: (token) => {
              originalRequest._retry = true;
              originalRequest.headers = originalRequest.headers || {};
              originalRequest.headers.Authorization = `Bearer ${token}`;
              resolve(api(originalRequest));
            },
            reject,
          });
        });
      }

      originalRequest._retry = true;
      isRefreshing = true;

      try {
        const refreshResponse = await api.post('/auth/refresh');
        const newToken = refreshResponse?.data?.accessToken;
        setAccessToken(newToken);
        isRefreshing = false;
        flushQueue(null, newToken);
        emitSessionChange({ type: 'refreshed', user: refreshResponse?.data?.user });

        originalRequest.headers = originalRequest.headers || {};
        originalRequest.headers.Authorization = `Bearer ${newToken}`;
        return api(originalRequest);
      } catch (refreshError) {
        isRefreshing = false;
        flushQueue(refreshError, null);
        setAccessToken(null);
        emitSessionChange({ type: 'expired' });
        return Promise.reject(normalizeError(refreshError));
      }
    }

    return Promise.reject(normalizeError(error));
  }
);

/** Normalizes any thrown error into a consistent { status, message, errors, code } shape. */
function normalizeError(error) {
  const response = error?.response;
  if (!response) {
    return { status: 0, message: error?.message || 'Network error.', errors: null, isNetworkError: true };
  }
  const body = response.data || {};
  // The backend uses `details` for both 400 blocking-issue lists (e.g.
  // checkout/order creation: string[]) and 422 validation errors (array of
  // {path,message}) — `errors` is kept for backward compatibility with any
  // other shape, but `details` is the one actually sent by this API.
  return {
    status: response.status,
    message: body.message || 'Something went wrong. Please try again.',
    errors: body.errors || null,
    details: body.details || null,
    code: body.code || null,
  };
}

export default api;
