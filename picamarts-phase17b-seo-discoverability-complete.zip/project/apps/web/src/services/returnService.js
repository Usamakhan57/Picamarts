/**
 * returnService.js — thin wrappers around the real backend's /returns
 * endpoints (Phase 16D, Part 2). Buyer self-service (create/list/cancel/
 * ship) and seller review (list/approve/reject/receive/complete) share
 * this one file, same "one service per resource" convention
 * payoutService.js/walletService.js already established.
 */
import api from './apiClient';

// --------------------------------------------------------------------
// Buyer self-service
// --------------------------------------------------------------------

export const createReturnRequest = (orderId, payload) =>
  api.post(`/returns/orders/${orderId}`, payload).then((res) => res.data.request);

export const uploadReturnAttachments = (files) => {
  const form = new FormData();
  files.forEach((f) => form.append('files', f));
  return api.post('/returns/attachments', form, { headers: { 'Content-Type': 'multipart/form-data' } }).then((res) => res.data.attachments);
};

export const getMyReturnRequests = (params = {}) =>
  api.get('/returns/me', { params }).then((res) => ({ requests: res.data.requests, meta: res.meta }));

export const getMyReturnRequest = (requestId) => api.get(`/returns/me/${requestId}`).then((res) => res.data.request);

export const cancelReturnRequest = (requestId) => api.post(`/returns/me/${requestId}/cancel`).then((res) => res.data.request);

export const shipReturnRequest = (requestId, payload) =>
  api.post(`/returns/me/${requestId}/ship`, payload).then((res) => res.data.request);

// --------------------------------------------------------------------
// Seller review (own store's returns only)
// --------------------------------------------------------------------

export const getSellerReturnRequests = (params = {}) =>
  api.get('/returns/seller', { params }).then((res) => ({ requests: res.data.requests, meta: res.meta }));

export const approveReturnRequest = (requestId, note) =>
  api.post(`/returns/seller/${requestId}/approve`, { note }).then((res) => res.data.request);

export const rejectReturnRequest = (requestId, note) =>
  api.post(`/returns/seller/${requestId}/reject`, { note }).then((res) => res.data.request);

export const markReturnReceived = (requestId) => api.post(`/returns/seller/${requestId}/received`).then((res) => res.data.request);

export const completeReturnRequest = (requestId) => api.post(`/returns/seller/${requestId}/complete`).then((res) => res.data.request);
