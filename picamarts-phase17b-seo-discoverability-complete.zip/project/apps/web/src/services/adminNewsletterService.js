/**
 * adminNewsletterService.js — Phase 15C, Part 11 (CMS). Real backend-
 * backed adapter for the Admin Newsletter page. The real backend only
 * models a subscriber list (subscribe/unsubscribe + admin list/export)
 * — there is no "newsletter design/campaign settings" model, which is
 * what the old mock's NewsletterCms page actually managed. That page
 * is rebuilt as a subscriber-management view instead of kept as a
 * non-functional relic.
 */
import api from './apiClient';

export const listSubscribers = (params = {}) =>
  api.get('/newsletter/subscribers', { params: { limit: 20, ...params } }).then((res) => ({ subscribers: res.data.subscribers, meta: res.meta }));

/** Downloads the real CSV export. Same blob-download caveat as analyticsService.js#exportReport — apiClient's response interceptor unconditionally resolves to `response.data`, so with `responseType: 'blob'` this resolves directly to the Blob, and the filename is built client-side. */
export const exportSubscribers = (params = {}) =>
  api.get('/newsletter/export', { params, responseType: 'blob' }).then((blob) => {
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `newsletter-subscribers-${Date.now()}.csv`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(url);
  });
