/**
 * cartService.js — thin wrappers around the real backend's /cart endpoints.
 *
 * The backend cart has no per-license concept (Cart.items is just
 * {product, quantity} — see apps/api/src/models/Cart.js) and is keyed by
 * cart-item id, not product id. Every function here returns the full
 * `{ id, items, summary }` cart envelope so StoreContext can just replace
 * its cart state with the response after each mutation.
 */
import api from './apiClient';

export const getCart = () => api.get('/cart').then((res) => res.data.cart);

export const addCartItem = (productId, quantity = 1) =>
  api.post('/cart/items', { productId, quantity }).then((res) => res.data.cart);

export const updateCartItemQuantity = (itemId, quantity) =>
  api.patch(`/cart/items/${itemId}`, { quantity }).then((res) => res.data.cart);

export const removeCartItem = (itemId) =>
  api.delete(`/cart/items/${itemId}`).then((res) => res.data.cart);

export const clearCartRequest = () => api.delete('/cart').then((res) => res.data.cart);
