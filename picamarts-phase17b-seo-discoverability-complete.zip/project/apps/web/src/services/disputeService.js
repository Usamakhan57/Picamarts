/**
 * disputeService.js — thin wrappers around the real backend's
 * /disputes endpoints (Phase 16D, Part 7). Buyer opens disputes;
 * buyer + seller share the evidence/list/get endpoints — role is
 * derived server-side (see dispute.service.js#addEvidence).
 */
import api from './apiClient';

export const openDispute = (orderId, payload) => api.post(`/disputes/orders/${orderId}`, payload).then((res) => res.data.dispute);

export const uploadDisputeAttachments = (files) => {
  const form = new FormData();
  files.forEach((f) => form.append('files', f));
  return api.post('/disputes/attachments', form, { headers: { 'Content-Type': 'multipart/form-data' } }).then((res) => res.data.attachments);
};

export const getMyDisputes = (params = {}) =>
  api.get('/disputes/me', { params }).then((res) => ({ disputes: res.data.disputes, meta: res.meta }));

export const getDispute = (disputeId) => api.get(`/disputes/${disputeId}`).then((res) => res.data.dispute);

export const addDisputeEvidence = (disputeId, payload) =>
  api.post(`/disputes/${disputeId}/evidence`, payload).then((res) => res.data.dispute);
