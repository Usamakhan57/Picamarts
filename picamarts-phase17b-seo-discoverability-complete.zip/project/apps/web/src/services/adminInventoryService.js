/**
 * adminInventoryService.js — Phase 15C, Part 5. Real backend-backed
 * adapter for the Admin Inventory page. Replaces the old mock
 * `admin/api/inventory.js` entirely.
 *
 * Inventory is still deliberately NOT a separate resource — same
 * design decision as the old mock — it reads/writes the same
 * `/products` records (stock, lowStockThreshold) via the real backend's
 * product update endpoint, so Products and Inventory can never drift
 * out of sync.
 *
 * Known, disclosed gap: the old mock kept a `stock_log` audit trail
 * (every adjustment recorded with a reason). The real backend has no
 * stock-history collection or endpoint — PATCH /products/:id only ever
 * stores the resulting `stock` number, nothing about how it got there —
 * so no log is written or shown here. The "reason" field is kept in
 * the adjust-stock dialog for the admin's own reference while typing,
 * but is not persisted anywhere; this is flagged, not silently dropped.
 */
import { getAdminProduct, updateAdminProduct, listAdminProducts } from './adminProductService';

const toInventoryRow = (p) => ({
  id: p.id,
  title: p.title,
  sku: p.sku || '—',
  image: p.thumbnailUrl,
  stock: p.stock,
  lowStockThreshold: p.lowStockThreshold,
  status: p.stock === 0 ? 'out_of_stock' : p.stock <= p.lowStockThreshold ? 'low_stock' : 'in_stock',
});

/** Paginated, filterable (stockStatus/q) inventory listing — mirrors the real /products/admin params, always excludes the deleted trash. */
export const listInventory = (params = {}) =>
  listAdminProducts(params).then(({ products, pagination }) => ({
    items: products.filter((p) => p.status !== 'deleted').map(toInventoryRow),
    pagination,
  }));

/** Sets the product's stock to current + delta (delta may be negative for removals) via the real PATCH /products/:id endpoint. `reason` is UI-only — see file header. */
export const adjustStock = async (productId, delta) => {
  const product = await getAdminProduct(productId);
  const nextStock = Math.max(0, (product?.stock || 0) + delta);
  const updated = await updateAdminProduct(productId, { stock: nextStock });
  return updated.stock;
};
