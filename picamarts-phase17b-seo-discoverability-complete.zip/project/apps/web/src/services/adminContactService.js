/**
 * adminContactService.js — Phase 15C, Part 11 (CMS). Real backend-backed
 * adapter for a brand-new Admin Contact Messages inbox — the real
 * `/contact` endpoints (apps/api/src/models/ContactMessage.js) have
 * existed since Phase 10.3 with no admin UI at all until now (the old
 * mock CMS instead had a "Contact Settings" page for editable business
 * info, which has no backend model — that content lives on
 * HomepageConfig.footerContent.contactInfo instead, see
 * adminHomepageService.js / HomepageCms.jsx).
 */
import api from './apiClient';

export const listMessages = (params = {}) =>
  api.get('/contact', { params: { limit: 20, ...params } }).then((res) => ({ messages: res.data.messages, meta: res.meta }));

export const getMessage = (id) => api.get(`/contact/${id}`).then((res) => res.data.message);

export const updateMessageStatus = (id, payload) => api.patch(`/contact/${id}/status`, payload).then((res) => res.data.message);

export const deleteMessage = (id) => api.delete(`/contact/${id}`);
