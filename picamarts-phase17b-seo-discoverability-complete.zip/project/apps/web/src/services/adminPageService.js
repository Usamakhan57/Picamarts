/**
 * adminPageService.js — Phase 15C, Part 11 (CMS). Real backend-backed
 * adapter for the Admin Static Pages editor. Wraps the real
 * `/pages` endpoints (apps/api/src/{controllers,services}/page.*) —
 * one Page document per fixed `pageType` (About Us, Contact Us,
 * Privacy Policy, Terms & Conditions, FAQ, Refund/Shipping/Cookie
 * Policy — Homepage's own pageType is managed separately via the
 * Homepage CMS editor, see adminHomepageService.js). Replaces the old
 * mock `admin/api/staticPages.js` entirely for admin use.
 */
import api from './apiClient';

/** Every manageable static page type, in the order the backend defines them (excludes 'homepage', which has its own dedicated editor). */
export const STATIC_PAGE_TYPES = [
  'about-us',
  'contact-us',
  'privacy-policy',
  'terms-conditions',
  'faq',
  'refund-policy',
  'shipping-policy',
  'cookie-policy',
];

export const listPages = (params = {}) =>
  api.get('/pages', { params: { limit: 50, ...params } }).then((res) => res.data.pages);

export const getPage = (id) => api.get(`/pages/${id}`).then((res) => res.data.page);

/** Returns null (not an error) when no Page has been created yet for this type — the form treats that as "create" instead of "edit". */
export const getPageByType = (pageType) =>
  api
    .get(`/pages/type/${pageType}`)
    .then((res) => res.data.page)
    .catch((err) => {
      if (err.status === 404) return null;
      throw err;
    });

export const createPage = (payload) => api.post('/pages', payload).then((res) => res.data.page);

export const updatePage = (id, payload) => api.patch(`/pages/${id}`, payload).then((res) => res.data.page);

export const deletePage = (id) => api.delete(`/pages/${id}`);
