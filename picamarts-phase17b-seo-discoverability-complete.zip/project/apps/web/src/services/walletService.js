/**
 * walletService.js — thin wrappers around the real backend's /wallet
 * endpoints (Phase 16B). Seller self-service only — the acting seller
 * is always resolved server-side from the auth token, never passed in.
 */
import api from './apiClient';

export const getMyWalletSummary = () => api.get('/wallet/me').then((res) => res.data.wallet);

export const getMyTransactions = (params = {}) =>
  api.get('/wallet/me/transactions', { params }).then((res) => ({ transactions: res.data.transactions, meta: res.meta }));
