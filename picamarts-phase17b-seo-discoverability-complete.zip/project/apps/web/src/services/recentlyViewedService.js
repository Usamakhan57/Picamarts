/**
 * recentlyViewedService.js — Phase 17A, Part 5. The backend now
 * auto-records a view server-side (fire-and-forget on GET /products/:id
 * and GET /products/slug/:slug — see product.controller.js) whenever
 * the caller is an authenticated buyer, so this module never needs to
 * report a view itself; it only reads/manages the resulting list.
 *
 * The backend's own product summary (title/slug/thumbnail/basePrice/
 * salePrice/currency/status only — see recentlyViewed.repository.js)
 * is lighter than the storefront's full product-card shape (category
 * name, brand/artist, rating, etc.), so `list()` resolves each id
 * through the existing, already-mapped `productsApi.get`, keeping
 * exact shape parity with every other product-card row on the site
 * rather than inventing a second partial mapping.
 */
import api from './apiClient';
import { productsApi } from './api';

export const recentlyViewedService = {
  /** Full storefront-shaped products, newest-viewed first, buyer's real history. */
  list: async (limit = 12) => {
    const res = await api.get('/recently-viewed');
    const ids = (res.data?.recentlyViewed?.items || [])
      .filter((item) => item.product)
      .map((item) => item.product.id)
      .slice(0, limit);

    const products = await Promise.all(ids.map((id) => productsApi.get(id).catch(() => null)));
    return products.filter(Boolean);
  },

  remove: async (productId) => {
    const res = await api.delete(`/recently-viewed/${productId}`);
    return res.data.recentlyViewed;
  },

  clear: async () => {
    const res = await api.delete('/recently-viewed');
    return res.data.recentlyViewed;
  },
};

export default recentlyViewedService;
