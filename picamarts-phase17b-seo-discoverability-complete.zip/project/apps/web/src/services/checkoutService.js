/**
 * checkoutService.js — thin wrappers around the real backend's /checkout
 * endpoints. Both operate on the authenticated buyer's own cart; there's
 * no request body — see apps/api/src/controllers/checkout.controller.js.
 */
import api from './apiClient';

/** Non-destructive preview: always succeeds, even for an empty/blocked cart — canCheckout/blockingIssues tell the UI why. */
export const getCheckoutSummary = () => api.get('/checkout/summary').then((res) => res.data.checkout);

/** Validates + locks current prices; throws (400) with `errors`/`message` if the cart isn't checkout-ready. */
export const lockCheckout = () => api.post('/checkout').then((res) => res.data.checkout);

/**
 * Phase 14.2, Part 5 — estimates available shipping methods/cost for the
 * buyer's current cart against a destination address. Purely informational:
 * shippingRequired:false for all-digital carts, and physical items without
 * an assigned ShippingProfile come back listed under unconfiguredItems.
 * Doesn't touch order creation — see checkout.controller.js#estimateShipping.
 */
export const estimateShipping = (destination) =>
  api.post('/checkout/shipping', destination).then((res) => res.data);
