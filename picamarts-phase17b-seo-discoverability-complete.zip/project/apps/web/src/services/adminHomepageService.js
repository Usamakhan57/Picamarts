/**
 * adminHomepageService.js — Phase 15C, Part 11 (CMS). Real backend-backed
 * adapter for the Admin Homepage CMS editor. Wraps the real
 * `GET/PATCH /homepage` singleton (apps/api/src/models/HomepageConfig.js) —
 * one document covering every homepage section the backend actually
 * models: hero banner, featured categories/products, testimonials,
 * promotional sections, FAQ section, footer content (incl. social
 * links + contact info), and homepage SEO.
 *
 * This single service now backs what used to be six separate admin
 * pages/mocks (Homepage, Hero Slider, Testimonials, FAQ, Footer,
 * Social Settings) — HomepageConfig is one document, so a page per
 * section would just be six forms PATCHing the same resource. The old
 * mock's "Hero Slider" (a list of multiple rotating slides) is folded
 * down to the real model's single `heroBanner` object — there is no
 * slide list to manage. "Promotional Banners" (admin/pages/banners)
 * is a separate nav item but maps onto this same document's
 * `promotionalSections` array — see BannersList.jsx.
 *
 * Dropped entirely, no backend equivalent: Header CMS, Navigation
 * Menus, Popup Manager, Global Site Settings, a standalone SEO
 * Manager (SEO lives embedded per-entity — Page.seo / BlogPost.seo /
 * this document's own `seo` field — never as its own collection), and
 * Email Templates.
 */
import api from './apiClient';

export const getHomepage = () => api.get('/homepage').then((res) => res.data.homepage);

/** Partial update — only the sections included in `payload` are replaced; everything else is left untouched by the backend itself. */
export const updateHomepage = (payload) => api.patch('/homepage', payload).then((res) => res.data.homepage);
