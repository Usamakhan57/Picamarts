/**
 * reviewService.js — thin wrappers around the real backend's /reviews
 * endpoints, admin-moderation side only (Phase 15C, Part 9). Buyer-side
 * review submission/editing (storefront product pages, "My Reviews")
 * is a separate, still-mock area of the app and out of scope here — see
 * services/buyerDashboard.js.
 */
import api from './apiClient';

/** Paginated/filterable review list across every product. `params`: page, limit, status, rating, sort. */
export const listAllReviews = (params = {}) =>
  api.get('/reviews', { params }).then((res) => ({ reviews: res.data.reviews, meta: res.meta }));

/** Admin moderation — set status (published/hidden) and/or an internal moderationNote. */
export const moderateReview = (reviewId, payload) =>
  api.patch(`/reviews/${reviewId}`, payload).then((res) => res.data.review);

export const deleteReview = (reviewId) => api.delete(`/reviews/${reviewId}`);
