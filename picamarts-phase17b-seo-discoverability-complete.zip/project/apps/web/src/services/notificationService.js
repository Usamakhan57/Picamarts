/**
 * notificationService.js — thin wrappers around the real backend's
 * /notifications endpoints (Phase 10.2 — Notification System). One
 * module for every account type: buyer, seller, and admin all read/
 * write their own notifications through the exact same endpoints, no
 * role branching needed here.
 */
import api from './apiClient';

export const listNotifications = (params = {}) =>
  api.get('/notifications', { params }).then((res) => ({ notifications: res.data.notifications, meta: res.meta }));

export const getNotification = (id) => api.get(`/notifications/${id}`).then((res) => res.data.notification);

export const getUnreadCount = () => api.get('/notifications/unread-count').then((res) => res.data.unreadCount ?? 0);

export const markAsRead = (id) => api.patch(`/notifications/${id}/read`).then((res) => res.data.notification);

export const markAllAsRead = () => api.patch('/notifications/read-all').then((res) => res.data);

export const deleteNotification = (id) => api.delete(`/notifications/${id}`);

export const deleteAllNotifications = () => api.delete('/notifications').then((res) => res.data);

export const getNotificationPreferences = () => api.get('/notifications/preferences').then((res) => res.data);

export const updateNotificationPreferences = (payload) =>
  api.patch('/notifications/preferences', payload).then((res) => res.data);
