/**
 * Auth API — thin wrappers around every /auth/* backend endpoint.
 * Callers (AuthContext, Login/Register pages, account Security page) never
 * touch apiClient or axios directly.
 */
import api, { setAccessToken } from './apiClient';

/** @returns {Promise<{user: object}>} */
export const registerRequest = ({ name, email, password, role }) =>
  api.post('/auth/register', { name, email, password, role }).then((res) => res.data);

export const verifyEmailRequest = (token) =>
  api.post('/auth/verify-email', { token }).then((res) => res.data);

/** Logs in, stores the access token in memory/localStorage, returns the user. */
export const loginRequest = async ({ email, password }) => {
  const res = await api.post('/auth/login', { email, password });
  setAccessToken(res.data.accessToken);
  return res.data.user;
};

export const logoutRequest = async () => {
  try {
    await api.post('/auth/logout');
  } finally {
    setAccessToken(null);
  }
};

/** Exchanges the httpOnly refresh cookie for a fresh access token + user. */
export const refreshSessionRequest = async () => {
  const res = await api.post('/auth/refresh');
  setAccessToken(res.data.accessToken);
  return res.data.user;
};

export const forgotPasswordRequest = (email) =>
  api.post('/auth/forgot-password', { email }).then((res) => res.data);

export const resetPasswordRequest = (token, newPassword) =>
  api.post('/auth/reset-password', { token, newPassword }).then((res) => res.data);

export const changePasswordRequest = (currentPassword, newPassword) =>
  api.post('/auth/change-password', { currentPassword, newPassword }).then((res) => {
    setAccessToken(null); // backend revokes the session on password change
    return res.data;
  });

export const getCurrentUserRequest = () => api.get('/auth/me').then((res) => res.data.user);

export const updateProfileRequest = (payload) =>
  api.patch('/auth/profile', payload).then((res) => res.data.user);
