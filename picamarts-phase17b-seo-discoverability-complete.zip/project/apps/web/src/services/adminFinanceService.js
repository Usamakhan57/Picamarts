/**
 * adminFinanceService.js — thin wrappers around the real backend's
 * /wallet/admin/* and /commission/* endpoints (Phase 16B, Parts 5 & 7).
 * Admin-only.
 */
import api from './apiClient';

// --------------------------------------------------------------------
// Wallet — admin finance overview (Part 7)
// --------------------------------------------------------------------

export const getFinanceOverview = () => api.get('/wallet/admin/overview').then((res) => res.data);

export const getSellerWallet = (sellerId) => api.get(`/wallet/admin/${sellerId}`).then((res) => res.data);

export const adjustSellerWallet = (sellerId, payload) =>
  api.post(`/wallet/admin/${sellerId}/adjust`, payload).then((res) => res.data);

export const closeSellerBalance = (sellerId) => api.post(`/wallet/admin/${sellerId}/close`).then((res) => res.data);

// --------------------------------------------------------------------
// Commission settings (Part 5)
// --------------------------------------------------------------------

export const getGlobalCommission = () => api.get('/commission/settings').then((res) => res.data.settings);

export const updateGlobalCommission = (defaultCommissionRate) =>
  api.patch('/commission/settings', { defaultCommissionRate }).then((res) => res.data.settings);

export const updateCategoryCommission = (categoryId, commissionRate) =>
  api.patch(`/commission/categories/${categoryId}`, { commissionRate }).then((res) => res.data);

export const updateSellerCommission = (sellerId, commissionRate) =>
  api.patch(`/commission/sellers/${sellerId}`, { commissionRate }).then((res) => res.data);

// --------------------------------------------------------------------
// Payouts — admin queue (Phase 16C, Parts 4/5/7)
// --------------------------------------------------------------------

export const getPayoutOverview = () => api.get('/payouts/admin/overview').then((res) => res.data);

export const getPayoutQueue = (params = {}) =>
  api.get('/payouts/admin', { params }).then((res) => ({ requests: res.data.requests, meta: res.meta }));

export const approvePayout = (requestId) => api.post(`/payouts/admin/${requestId}/approve`).then((res) => res.data.request);

export const rejectPayout = (requestId, reason) =>
  api.post(`/payouts/admin/${requestId}/reject`, { reason }).then((res) => res.data.request);

export const retryPayout = (requestId) => api.post(`/payouts/admin/${requestId}/retry`).then((res) => res.data.request);

// --------------------------------------------------------------------
// Refunds — admin queue (Phase 16D, Part 3)
// --------------------------------------------------------------------

export const getRefundOverview = () => api.get('/refunds/admin/overview').then((res) => res.data);

export const getRefundQueue = (params = {}) =>
  api.get('/refunds/admin', { params }).then((res) => ({ requests: res.data.requests, meta: res.meta }));

export const approveRefund = (requestId, note) => api.post(`/refunds/admin/${requestId}/approve`, { note }).then((res) => res.data.request);

export const rejectRefund = (requestId, note) => api.post(`/refunds/admin/${requestId}/reject`, { note }).then((res) => res.data.request);

export const retryRefund = (requestId) => api.post(`/refunds/admin/${requestId}/retry`).then((res) => res.data.request);

export const bulkRefundAction = (ids, action, reason) =>
  api.post('/refunds/admin/bulk', { ids, action, reason }).then((res) => res.data);

// --------------------------------------------------------------------
// Returns — admin queue (Phase 16D, Part 2)
// --------------------------------------------------------------------

export const getReturnOverview = () => api.get('/returns/admin/overview').then((res) => res.data);

export const getReturnQueue = (params = {}) =>
  api.get('/returns/admin', { params }).then((res) => ({ requests: res.data.requests, meta: res.meta }));

// --------------------------------------------------------------------
// Disputes & Chargebacks — admin queue (Phase 16D, Part 7)
// --------------------------------------------------------------------

export const getDisputeOverview = () => api.get('/disputes/admin/overview').then((res) => res.data);

export const getDisputeQueue = (params = {}) =>
  api.get('/disputes/admin/queue', { params }).then((res) => ({ disputes: res.data.disputes, meta: res.meta }));

export const markDisputeUnderReview = (disputeId, note) =>
  api.post(`/disputes/admin/${disputeId}/under-review`, { note }).then((res) => res.data.dispute);

export const resolveDispute = (disputeId, outcome, note) =>
  api.post(`/disputes/admin/${disputeId}/resolve`, { outcome, note }).then((res) => res.data.dispute);

export const closeDispute = (disputeId, note) =>
  api.post(`/disputes/admin/${disputeId}/close`, { note }).then((res) => res.data.dispute);
