/**
 * adminBrandService.js — Phase 15C, Part 5. Real backend-backed adapter
 * for the Admin Brands page. Replaces the old mock `admin/api/brands.js`
 * entirely.
 *
 * Schema mapping (backend Brand → admin list/form shape):
 *   active   → status: 'active' | 'inactive'
 *   logo.url → logo (flat string, what the shared ImageUploadInput reads/writes)
 *
 * Known, disclosed gap: the old mock stored a `productCount` field
 * directly on each brand record. The real Brand model has no such
 * field — products merely hold a `brand` ref pointing the other way —
 * so the count is derived on demand via countAdminProducts (one
 * lightweight request per brand, bounded by how many brands a
 * marketplace realistically has).
 */
import api from './apiClient';

const mapFromBackend = (b) => ({
  ...b,
  status: b.active ? 'active' : 'inactive',
  logo: b.logo?.url || '',
  metaKeywords: b.metaKeywords || [],
});

const mapToBackend = (form) => {
  const payload = {
    name: form.name,
    slug: form.slug || undefined,
    logo: form.logo ? { url: form.logo } : undefined,
    website: form.website || undefined,
    description: form.description || undefined,
    featured: !!form.featured,
    active: form.status === 'active',
    // Phase 17B — SEO & Discoverability. Brand had no SEO fields before this.
    seoTitle: form.seoTitle || undefined,
    seoDescription: form.seoDescription || undefined,
    canonicalUrl: form.canonicalUrl || undefined,
    metaKeywords: form.metaKeywords?.length ? form.metaKeywords : undefined,
    ogImage: form.ogImage || undefined,
    noIndex: !!form.noIndex,
  };
  Object.keys(payload).forEach((key) => payload[key] === undefined && delete payload[key]);
  return payload;
};

/** Every brand, one page at a time up to a generous cap (mirrors listAllCategories). */
export const listAllBrands = async () => {
  const all = [];
  let page = 1;
  // eslint-disable-next-line no-constant-condition -- bounded by the page/pageCap check below
  while (true) {
    // eslint-disable-next-line no-await-in-loop -- sequential pagination, bounded to 5 pages (500 brands)
    const res = await api.get('/brands', { params: { page, limit: 100, sort: 'name' } });
    all.push(...res.data.brands.map(mapFromBackend));
    const meta = res.meta;
    if (!meta || page >= meta.totalPages || page >= 5) break;
    page += 1;
  }
  return all;
};

export const getBrand = (id) => api.get(`/brands/${id}`).then((res) => mapFromBackend(res.data.brand));

export const createBrand = (form) => api.post('/brands', mapToBackend(form)).then((res) => mapFromBackend(res.data.brand));

export const updateBrand = (id, form) => api.patch(`/brands/${id}`, mapToBackend(form)).then((res) => mapFromBackend(res.data.brand));

export const deleteBrand = (id) => api.delete(`/brands/${id}`);

export const toggleBrandActive = (id) => api.patch(`/brands/${id}/toggle-active`).then((res) => mapFromBackend(res.data.brand));

/** Real per-brand product counts (see file header). */
export const getProductCountByBrandId = async (brands) => {
  const { countAdminProducts } = await import('./adminProductService');
  const counts = {};
  for (const brand of brands) {
    // eslint-disable-next-line no-await-in-loop -- bounded to the brand list's size
    counts[brand.id] = await countAdminProducts({ brand: brand.id });
  }
  return counts;
};
