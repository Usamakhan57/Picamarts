/**
 * adminCategoryService.js — Phase 15C, Part 5. Real backend-backed
 * adapter for the Admin Categories page. Replaces the old mock
 * `admin/api/categories.js` entirely.
 *
 * Schema mapping (backend Category → admin list/tree shape, same
 * convention as services/categoryRepository.js on the storefront side):
 *   parentCategory → parentId (categoryTree.js's expected field name)
 *   sortOrder       → displayOrder
 *   isActive        → status: 'active' | 'inactive'
 *   isFeatured      → featured
 *   showInMenu      → showOnHomepage (closest real equivalent)
 *
 * Known, disclosed gap: the old mock had a soft-delete "Trash" (move to
 * trash / restore / permanently delete). The real Category model has no
 * `deletedAt` field — DELETE /categories/:id is the only delete
 * operation, is permanent, and the backend itself refuses it (409)
 * while the category still has live subcategories. That Trash/Restore
 * UI is dropped rather than kept as a non-functional relic; the delete
 * confirmation now explains the real, permanent behavior instead.
 */
import api from './apiClient';

const mapFromBackend = (c) => ({
  ...c,
  parentId: c.parentCategory || null,
  displayOrder: c.sortOrder ?? 0,
  status: c.isActive ? 'active' : 'inactive',
  featured: !!c.isFeatured,
  showOnHomepage: !!c.isFeatured,
  showInHeader: !!c.showInHeader,
  image: c.image?.url || '',
  metaKeywords: c.metaKeywords || [],
});

const mapToBackend = (form) => {
  const payload = {
    name: form.name,
    slug: form.slug || undefined,
    description: form.description || undefined,
    image: form.image ? { url: form.image } : undefined,
    icon: form.icon || undefined,
    parentCategory: form.parentId || null,
    sortOrder: form.displayOrder,
    showInMenu: true,
    showInHeader: !!form.showInHeader,
    isFeatured: !!form.featured,
    isActive: form.status === 'active',
    seoTitle: form.seoTitle || undefined,
    seoDescription: form.seoDescription || undefined,
    // Phase 17B — SEO & Discoverability. Additive.
    canonicalUrl: form.canonicalUrl || undefined,
    metaKeywords: form.metaKeywords?.length ? form.metaKeywords : undefined,
    ogImage: form.ogImage || undefined,
    noIndex: !!form.noIndex,
  };
  Object.keys(payload).forEach((key) => payload[key] === undefined && delete payload[key]);
  return payload;
};

/** Every category (active + inactive), one page at a time up to a generous cap — the tree view needs the whole set, not one page of it. */
export const listAllCategories = async () => {
  const all = [];
  let page = 1;
  // eslint-disable-next-line no-constant-condition -- bounded below by the page/pageCap check
  while (true) {
    // eslint-disable-next-line no-await-in-loop -- sequential pagination, bounded to 5 pages (500 categories)
    const res = await api.get('/categories', { params: { page, limit: 100, sort: 'sortOrder,name' } });
    all.push(...res.data.categories.map(mapFromBackend));
    const meta = res.meta;
    if (!meta || page >= meta.totalPages || page >= 5) break;
    page += 1;
  }
  return all;
};

export const getCategory = (id) => api.get(`/categories/${id}`).then((res) => mapFromBackend(res.data.category));

export const createCategory = (form) => api.post('/categories', mapToBackend(form)).then((res) => mapFromBackend(res.data.category));

export const updateCategory = (id, form) => api.patch(`/categories/${id}`, mapToBackend(form)).then((res) => mapFromBackend(res.data.category));

/** Permanent — the backend itself returns 409 if the category still has live subcategories. */
export const deleteCategory = (id) => api.delete(`/categories/${id}`);

export const toggleCategoryActive = (id) => api.patch(`/categories/${id}/toggle-active`).then((res) => mapFromBackend(res.data.category));

/**
 * Real per-category product counts, one request per category
 * (bounded — marketplace category trees are small, typically well
 * under 100 nodes). Falls back to the storefront mock catalog's counts
 * for categories with zero live products so the UI never shows a blank.
 */
export const getProductCountByCategoryId = async (categories) => {
  const { countAdminProducts } = await import('./adminProductService');
  const counts = {};
  for (const cat of categories) {
    // eslint-disable-next-line no-await-in-loop -- bounded to the category tree's size
    counts[cat.id] = await countAdminProducts({ category: cat.id });
  }
  return counts;
};
