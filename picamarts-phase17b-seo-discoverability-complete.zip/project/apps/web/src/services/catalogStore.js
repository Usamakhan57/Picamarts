/**
 * catalogStore.js — one shared, in-memory cache of the marketplace's
 * taxonomy (categories/brands/collections/tags), fetched once from the
 * real backend and read synchronously everywhere else.
 *
 * WHY THIS EXISTS: categoryRepository.js (and a handful of components) were
 * built as *synchronous* reads — Header/HeroSection/etc. call them directly
 * inside `useMemo(() => fn(), [])` with no loading state, because they used
 * to read localStorage. Real backend calls are async, so this store bridges
 * the gap: `preloadCatalog()` is kicked off once, non-blockingly, from
 * StoreContext on app mount; everything else keeps reading synchronously
 * from the cache below (empty until the first load resolves, then correct
 * for the rest of the session). Components that need to re-render once the
 * cache fills in subscribe via `useCatalogVersion()` (hooks/useCatalogVersion.js).
 */
import api from './apiClient';

const state = {
  categories: [],
  brands: [],
  collections: [],
  tags: [],
  licenses: [],
  /** Bounded snapshot of published products — used for category product
   * counts and "related products" style local lookups only. The main
   * catalog browsing experience (ShopPage) queries the backend live with
   * real filters/pagination instead of reading this (see productRepository.js
   * fetchProducts) — real catalogs can be far larger than this cache. */
  products: [],
};

let version = 0;
const listeners = new Set();
const notify = () => {
  version += 1;
  listeners.forEach((listener) => listener());
};

export const subscribeCatalog = (listener) => {
  listeners.add(listener);
  return () => listeners.delete(listener);
};

export const getCatalogVersion = () => version;

/** Fetches every page of a paginated list endpoint (categories/brands/tags are small marketplace-wide lists, never large enough to need true infinite pagination). */
async function fetchAllPages(path, dataKey) {
  const items = [];
  let page = 1;
  // eslint-disable-next-line no-constant-condition
  while (true) {
    const res = await api.get(path, { params: { page, limit: 100 } });
    const pageItems = res.data?.[dataKey] || [];
    items.push(...pageItems);
    const meta = res.meta;
    if (!meta || page >= meta.totalPages || pageItems.length === 0) break;
    page += 1;
  }
  return items;
}

/** Capped product fetch for the local caches described above (category counts, related products). 5 pages @ 100 = 500 products max — a flagged, deliberate scale limit; the real product-browsing experience never reads this. */
const PRODUCT_CACHE_MAX_PAGES = 5;
async function fetchProductsCapped() {
  const items = [];
  for (let page = 1; page <= PRODUCT_CACHE_MAX_PAGES; page += 1) {
    // eslint-disable-next-line no-await-in-loop
    const res = await api.get('/products', { params: { page, limit: 100, sort: 'newest' } });
    const pageItems = res.data || [];
    items.push(...pageItems);
    if (!res.pagination || page >= res.pagination.totalPages || pageItems.length === 0) break;
  }
  return items;
}

let inFlight = null;

/** Kicks off (or returns the in-flight) initial catalog fetch. Safe to call from multiple places — only fetches once per session. */
export function preloadCatalog() {
  if (inFlight) return inFlight;

  inFlight = Promise.all([
    fetchAllPages('/categories', 'categories').then((v) => { state.categories = v; }),
    fetchAllPages('/brands', 'brands').then((v) => { state.brands = v; }),
    fetchAllPages('/collections', 'collections').then((v) => { state.collections = v; }),
    fetchAllPages('/tags', 'tags').then((v) => { state.tags = v; }),
    fetchAllPages('/licenses', 'licenses').then((v) => { state.licenses = v; }),
    fetchProductsCapped().then((v) => { state.products = v; }),
  ])
    .catch((err) => {
      // Non-fatal: the storefront just renders with empty taxonomy until a
      // retry succeeds (e.g. next navigation re-triggers preloadCatalog
      // naturally via StoreProvider's mount effect on a future reload).
      console.error('Catalog preload failed:', err?.message || err);
    })
    .finally(() => notify());

  return inFlight;
}

export const getCategoriesRaw = () => state.categories;
export const getBrandsRaw = () => state.brands;
export const getCollectionsRaw = () => state.collections;
export const getTagsRaw = () => state.tags;
export const getLicensesRaw = () => state.licenses;
export const getProductsCacheRaw = () => state.products;
