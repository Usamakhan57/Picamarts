/**
 * adminBlogService.js — Phase 15C, Part 11 (CMS). Real backend-backed
 * adapter for the Admin Blog pages (Posts, Categories, Tags). Replaces
 * the old mock `admin/api/blogPosts.js` / `blogCategories.js` /
 * `blogTags.js` for admin use ONLY — the storefront's own
 * `services/blog/blogService.js` (consumed by the public BlogPage/
 * BlogPostPage) still reads those same mock files and is left
 * untouched this phase, exactly like the Reviews module's disclosed
 * buyer-side gap in an earlier sub-phase.
 *
 * Backend reality this maps to (see apps/api/src/models/BlogPost.js,
 * BlogCategory.js, controllers/blogPost.controller.js):
 *   - `tags` is a plain string array on BlogPost, not its own
 *     collection — there is no tag rename/merge/delete. `listTags()`
 *     below just surfaces the real `GET /blog/tags` distinct-tag list
 *     (with post counts) for browsing/reuse, not a management page.
 *   - `author` is a User ref, always the acting admin — there is no
 *     separate Author entity to manage (the old mock's "Blog Authors"
 *     page is dropped for this reason, see delivery notes).
 *   - No soft-delete: BlogPost/BlogCategory deletes are permanent (the
 *     old mock's "Trash" page is dropped for the same reason Category
 *     Trash was dropped in Part 5).
 */
import api from './apiClient';

// --------------------------------------------------------------------
// Posts
// --------------------------------------------------------------------

export const listPosts = (params = {}) =>
  api.get('/blog', { params }).then((res) => ({ posts: res.data.posts, meta: res.meta }));

export const getPost = (id) => api.get(`/blog/${id}`).then((res) => res.data.post);

export const createPost = (payload) => api.post('/blog', payload).then((res) => res.data.post);

export const updatePost = (id, payload) => api.patch(`/blog/${id}`, payload).then((res) => res.data.post);

export const deletePost = (id) => api.delete(`/blog/${id}`);

export const listTags = () => api.get('/blog/tags').then((res) => res.data.tags);

// --------------------------------------------------------------------
// Categories
// --------------------------------------------------------------------

export const listCategories = (params = {}) =>
  api.get('/blog/categories', { params }).then((res) => ({ categories: res.data.categories, meta: res.meta }));

export const getCategory = (id) => api.get(`/blog/categories/${id}`).then((res) => res.data.category);

export const createCategory = (payload) => api.post('/blog/categories', payload).then((res) => res.data.category);

export const updateCategory = (id, payload) => api.patch(`/blog/categories/${id}`, payload).then((res) => res.data.category);

export const deleteCategory = (id) => api.delete(`/blog/categories/${id}`);
