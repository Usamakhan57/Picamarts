/**
 * Seller API — thin wrappers around the backend's /sellers/* endpoints:
 * self-service (application + own profile + own dashboard summary) plus,
 * as of Phase 15C Part 4, the admin management endpoints
 * (list/get/approve/reject/suspend/reinstate/update/delete).
 *
 * Every function here requires an authenticated session with the right
 * role (seller for self-service, admin for management) — apiClient
 * already attaches the bearer token, callers don't need to pass one.
 */
import api from './apiClient';

/** Submits a new seller application. 409s if one already exists for this account. */
export const applyAsSeller = (payload) => api.post('/sellers/apply', payload).then((res) => res.data.seller);

/**
 * Fetches the authenticated user's own seller profile.
 * Throws a normalized 404 error (`err.status === 404`) if no application
 * has been submitted yet — callers should treat that as "not applied",
 * not as a hard failure.
 */
export const getMySellerProfile = () => api.get('/sellers/me').then((res) => res.data.seller);

export const updateMySellerProfile = (payload) => api.patch('/sellers/me', payload).then((res) => res.data.seller);

export const submitVerificationDocument = (verificationDocument) =>
  api.post('/sellers/me/verification-document', { verificationDocument }).then((res) => res.data.seller);

/** Dashboard summary (profile + product counts) — real backend data, used for Overview identity bits. */
export const getMySellerDashboard = () => api.get('/sellers/me/dashboard').then((res) => res.data);

// ---------------------------------------------------------------------
// Admin management (Phase 15C, Part 4) — requires an admin session.
// ---------------------------------------------------------------------

/** Paginated/searchable/filterable seller list. `params`: page, limit, q, sort, status. */
export const listSellers = (params = {}) =>
  api.get('/sellers', { params }).then((res) => ({ sellers: res.data.sellers, meta: res.meta }));

/** A single seller with the owning user's name/email populated. */
export const getSellerById = (id) => api.get(`/sellers/${id}`).then((res) => res.data.seller);

export const approveSeller = (id) => api.patch(`/sellers/${id}/approve`).then((res) => res.data.seller);
export const rejectSeller = (id, reason = '') => api.patch(`/sellers/${id}/reject`, { reason }).then((res) => res.data.seller);
export const suspendSeller = (id, reason = '') => api.patch(`/sellers/${id}/suspend`, { reason }).then((res) => res.data.seller);
export const reinstateSeller = (id) => api.patch(`/sellers/${id}/reinstate`).then((res) => res.data.seller);

/** Admin-editable fields only: commissionRate, storeName, storeDescription. */
export const updateSellerByAdmin = (id, payload) => api.patch(`/sellers/${id}`, payload).then((res) => res.data.seller);

export const deleteSellerByAdmin = (id) => api.delete(`/sellers/${id}`).then((res) => res.data);
