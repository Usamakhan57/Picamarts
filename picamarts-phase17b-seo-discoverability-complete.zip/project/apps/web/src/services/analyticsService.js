/**
 * analyticsService.js — thin wrappers around the real backend's
 * /analytics endpoints (Phase 11). A seller calling these is
 * automatically scoped to their own store server-side; an admin gets
 * platform-wide data on the exact same endpoints — no client-side
 * branching needed for that part.
 */
import api from './apiClient';

export const getDashboard = (params = {}) => api.get('/analytics/dashboard', { params }).then((res) => res.data);

export const getSales = (params = {}) => api.get('/analytics/sales', { params }).then((res) => res.data);

export const getOrderAnalytics = (params = {}) => api.get('/analytics/orders', { params }).then((res) => res.data);

export const getRevenue = (params = {}) => api.get('/analytics/revenue', { params }).then((res) => res.data);

export const getProductAnalytics = (params = {}) => api.get('/analytics/products', { params }).then((res) => res.data);

export const getReviewAnalytics = (params = {}) => api.get('/analytics/reviews', { params }).then((res) => res.data);

// Admin-only (platform-wide) — used by the Admin Dashboard sub-phase.
export const getSellerAnalytics = (params = {}) => api.get('/analytics/sellers', { params }).then((res) => res.data);
export const getCustomerAnalytics = (params = {}) => api.get('/analytics/customers', { params }).then((res) => res.data);
export const getPaymentAnalytics = (params = {}) => api.get('/analytics/payments', { params }).then((res) => res.data);

// Phase 17A.2 — Marketplace Growth Analytics. Admin-or-seller (each
// auto-scoped to their own store server-side, same as getProductAnalytics
// above) except getSearchAnalytics, which is platform-wide and admin-only.
export const getCategoryAnalytics = (params = {}) => api.get('/analytics/categories', { params }).then((res) => res.data);
export const getBrandAnalytics = (params = {}) => api.get('/analytics/brands', { params }).then((res) => res.data);
export const getSearchAnalytics = (params = {}) => api.get('/analytics/search', { params }).then((res) => res.data);

/**
 * Downloads a report from /analytics/export. The backend streams a raw
 * file body (csv/xlsx/pdf), not the usual { success, data, message }
 * envelope — apiClient's response interceptor unconditionally resolves to
 * `response.data`, so with `responseType: 'blob'` this call resolves
 * directly to the Blob itself (no access to response headers from here),
 * and the download filename is built client-side instead of read back off
 * Content-Disposition.
 */
export const exportReport = ({ report, format = 'csv', ...filters }) =>
  api.get('/analytics/export', { params: { report, format, ...filters }, responseType: 'blob' }).then((blob) => {
    const filename = `${report}-report-${Date.now()}.${format}`;
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(url);
  });
