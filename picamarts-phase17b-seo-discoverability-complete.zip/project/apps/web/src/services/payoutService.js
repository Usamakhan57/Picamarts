/**
 * payoutService.js — thin wrappers around the real backend's
 * /payouts/me endpoints (Phase 16C). Seller self-service only — the
 * acting seller is always resolved server-side from the auth token.
 */
import api from './apiClient';

export const requestWithdrawal = (payload) => api.post('/payouts/me', payload).then((res) => res.data.request);

export const getMyWithdrawals = (params = {}) =>
  api.get('/payouts/me', { params }).then((res) => ({ requests: res.data.requests, meta: res.meta }));

export const cancelWithdrawal = (requestId) => api.post(`/payouts/me/${requestId}/cancel`).then((res) => res.data.request);
