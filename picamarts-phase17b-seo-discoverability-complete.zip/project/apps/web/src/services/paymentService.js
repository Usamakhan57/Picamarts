/**
 * paymentService.js — thin wrappers around the real backend's /payments
 * endpoints (Stripe-backed — see apps/api/src/services/payment.service.js).
 *
 * Flow used by CheckoutPage: createPaymentIntent(orderId) → collect card
 * details client-side with Stripe.js (CardElement) → stripe.createPaymentMethod
 * → confirmPayment(paymentId, paymentMethodId). The backend calls
 * stripe.paymentIntents.confirm() itself server-side, so the frontend never
 * needs Stripe Elements' own client-side confirmation step — just a
 * PaymentMethod id.
 */
import api from './apiClient';

/** Returns { payment, clientSecret } — clientSecret isn't actually needed for
 * this backend's confirm-server-side flow, but is kept for parity with a
 * future client-side-confirmation upgrade. */
export const createPaymentIntent = (orderId) => api.post('/payments', { orderId }).then((res) => res.data);

export const confirmPayment = (paymentId, paymentMethodId) =>
  api.post(`/payments/${paymentId}/confirm`, paymentMethodId ? { paymentMethodId } : {}).then((res) => res.data.payment);

export const getPayment = (paymentId) => api.get(`/payments/${paymentId}`).then((res) => res.data.payment);

export const cancelPaymentIntent = (paymentId) => api.post(`/payments/${paymentId}/cancel`).then((res) => res.data.payment);

export const listPayments = (params = {}) =>
  api.get('/payments', { params }).then((res) => ({ payments: res.data.payments, meta: res.meta }));

/** Admin only. Omit `amount` for a full refund of whatever remains unrefunded. */
export const refundPayment = (paymentId, amount) =>
  api.post(`/payments/${paymentId}/refund`, amount ? { amount } : {}).then((res) => res.data.payment);

/**
 * Admin only — best-effort lookup of the Payment record for one order,
 * for the Order Detail page (Phase 15C, Part 6). There's no `orderId`
 * filter on GET /payments (the Payments module is off-limits to modify
 * this phase), so this scans a bounded, most-recent-first page and
 * matches client-side on the `order` id already present on every
 * payment response. Flagged limitation: an order whose payment is
 * older than the scanned window won't be found — acceptable for this
 * project's data volume, not a fix for production scale.
 */
export const findPaymentForOrder = (orderId) =>
  listPayments({ limit: 100, sort: '-createdAt' }).then(
    ({ payments }) => payments.find((p) => p.order === orderId) || null
  );
