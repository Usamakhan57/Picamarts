/**
 * shippingService.js — thin wrappers around the real backend's
 * /shipping-profiles and /shipments endpoints (Phase 14.2 — Physical
 * Shipping & Fulfilment). See apps/api/src/controllers/shippingProfile.controller.js
 * and apps/api/src/controllers/shipment.controller.js — every function
 * here maps 1:1 to one route, no client-side re-shaping of business
 * rules (that all lives on the backend already).
 */
import api from './apiClient';

// ---------------------------------------------------------------------
// Shipping Profiles (seller/admin only)
// ---------------------------------------------------------------------

/** The acting seller's own shipping profiles. */
export const listMyShippingProfiles = (params = {}) =>
  api.get('/shipping-profiles/mine', { params }).then((res) => res.data);

/** Admin — every profile across every seller, optionally filtered by seller id. */
export const listAllShippingProfiles = (params = {}) =>
  api.get('/shipping-profiles/admin', { params }).then((res) => res.data);

export const getShippingProfile = (id) =>
  api.get(`/shipping-profiles/${id}`).then((res) => res.data.profile);

export const createShippingProfile = (payload) =>
  api.post('/shipping-profiles', payload).then((res) => res.data.profile);

export const updateShippingProfile = (id, payload) =>
  api.patch(`/shipping-profiles/${id}`, payload).then((res) => res.data.profile);

export const deleteShippingProfile = (id) => api.delete(`/shipping-profiles/${id}`);

// ---------------------------------------------------------------------
// Shipments — buyer (customer tracking)
// ---------------------------------------------------------------------

/** The authenticated buyer's own shipments across every order ("Track My Orders"). */
export const listMyShipments = () => api.get('/shipments/mine').then((res) => res.data.shipments);

/** Every shipment for one order — buyer sees their own, seller/admin see it if they're party to the order. */
export const listShipmentsForOrder = (orderId) =>
  api.get(`/shipments/orders/${orderId}`).then((res) => res.data.shipments);

export const getShipment = (shipmentId) =>
  api.get(`/shipments/${shipmentId}`).then((res) => res.data.shipment);

// ---------------------------------------------------------------------
// Shipments — seller
// ---------------------------------------------------------------------

/** Orders (or partial line items) still awaiting a shipment for the acting seller. */
export const listOrdersToShip = () => api.get('/shipments/to-ship').then((res) => res.data.orders);

/**
 * Creates a shipment for some (or all) of an order's line items that
 * belong to the acting seller — pass `orderItemIds` for partial
 * fulfillment. Admin must additionally pass `seller`.
 */
export const createShipment = (orderId, payload = {}) =>
  api.post(`/shipments/orders/${orderId}`, payload).then((res) => res.data.shipment);

export const updateShipmentStatus = (shipmentId, status, meta = {}) =>
  api.patch(`/shipments/${shipmentId}/status`, { status, ...meta }).then((res) => res.data.shipment);

export const addShipmentTracking = (shipmentId, { carrier, trackingNumber, trackingUrl = '' }) =>
  api.patch(`/shipments/${shipmentId}/tracking`, { carrier, trackingNumber, trackingUrl }).then((res) => res.data.shipment);

// ---------------------------------------------------------------------
// Shipments — seller/admin dashboards
// ---------------------------------------------------------------------

/** Paginated shipment list — admin sees every shipment, seller sees only their own. Accepts { page, limit, status }. */
export const listShipments = (params = {}) =>
  api.get('/shipments', { params }).then((res) => ({ shipments: res.data.shipments, meta: res.meta }));

/** Admin only — quick status counts + delayed-shipment count for the dashboard landing view. */
export const getShippingOverview = () => api.get('/shipments/overview').then((res) => res.data);
