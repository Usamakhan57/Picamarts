/**
 * recommendationService.js — thin wrapper around the real backend's
 * /recommendations endpoints (Phase 17A.2, Part 1 — Recommendation
 * Engine). Every response is `{ products: [...] }` in the same shape
 * GET /products already returns (see apps/api/src/services/recommendation.service.js,
 * which itself reuses product.service.js#listPublicProducts), so this
 * file maps every result through the same mapBackendProduct() every
 * other product-fetching path already uses — no new product shape,
 * no duplicate mapping logic.
 */
import api from './apiClient';
import { mapBackendProduct } from './productRepository';

const toProducts = (res) => (res.data?.products || []).map(mapBackendProduct);

export const recommendationService = {
  /** Same category or overlapping tags as `productId`, ranked by rating then sales. */
  getRelated: async (productId, limit = 8) => {
    if (!productId) return [];
    const res = await api.get(`/recommendations/related/${productId}`, { params: { limit } });
    return toProducts(res);
  },

  /** Products most often bought in the same paid order as `productId`. */
  getFrequentlyBoughtTogether: async (productId, limit = 6) => {
    if (!productId) return [];
    const res = await api.get(`/recommendations/frequently-bought-together/${productId}`, { params: { limit } });
    return toProducts(res);
  },

  /** "Customers who viewed this also viewed" — co-occurrence across buyers' recently-viewed lists. */
  getAlsoViewed: async (productId, limit = 6) => {
    if (!productId) return [];
    const res = await api.get(`/recommendations/also-viewed/${productId}`, { params: { limit } });
    return toProducts(res);
  },

  /** Thin pass-through to the platform-wide trending feed — used as the logged-out/no-signal fallback for personalized recommendations. */
  getTrending: async (limit = 12) => {
    const res = await api.get('/recommendations/trending', { params: { limit } });
    return toProducts(res);
  },

  /** Buyer-only — combines purchase history, wishlist contents, and recently-viewed categories. Throws on 401; callers decide how to degrade (see PersonalizedRecommendations.jsx, which falls back to getTrending for a signed-out visitor). */
  getPersonalized: async (limit = 12) => {
    const res = await api.get('/recommendations/personalized', { params: { limit } });
    return toProducts(res);
  },
};

export default recommendationService;
