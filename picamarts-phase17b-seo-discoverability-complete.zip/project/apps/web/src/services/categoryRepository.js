/**
 * categoryRepository.js — Single source of truth for storefront categories.
 *
 * Reads from the shared catalog cache (services/catalogStore.js — populated
 * once from the real backend's GET /categories) and maps the backend
 * Category schema to whatever shape each storefront surface needs (flat
 * list, tree, breadcrumb chain, single lookup by slug). Every frontend
 * surface — Header mega menu, mobile menu, Home page, Shop filters, search
 * suggestions, category pages, breadcrumbs, product pages — reads
 * categories through this file and nothing else.
 *
 * Schema mapping (backend Category → storefront shape):
 *   parentCategory   → parentId   (categoryTree.js's expected field name)
 *   sortOrder        → displayOrder
 *   isActive         → status === 'active' filtering (backend has no
 *                       separate soft-delete/deletedAt field, so "active"
 *                       here just means isActive: true)
 *   isFeatured       → showOnHomepage (backend has no dedicated homepage
 *                       flag — isFeatured is the closest equivalent and is
 *                       what the Admin Category CMS's "Featured" toggle
 *                       already writes)
 *   icon (free text) → resolved lucide-react component via ICON_MAP,
 *                       same as before — falls back to a generic tag icon
 *                       for any name the map doesn't recognize
 *
 * Still synchronous by design so components that read categories at first
 * paint (Header, Hero) don't need their own loading state — the cache is
 * populated once by catalogStore.preloadCatalog() (triggered from
 * StoreContext), and consumers that need to react to it filling in after
 * their first render subscribe via hooks/useCatalogVersion.js.
 */
import {
  Frame, Image as ImageIcon, Boxes, Palette, CalendarDays, NotebookPen,
  Printer, Mail, PencilRuler, Shirt, Trophy, Leaf, Grid3x3, Layers, Dumbbell,
  Sparkles, Tag as TagIcon,
} from 'lucide-react';
import { slugify } from '../data';
import { getCategoriesRaw } from './catalogStore';
import {
  getCategoryTree, getRootCategories, getChildren, flattenCategories, getAncestors,
} from './categoryTree';

/** lucide-react icon name (stored on the category) → actual component. Unknown names fall back to a generic tag icon rather than crashing. */
const ICON_MAP = {
  Frame, Image: ImageIcon, Boxes, Palette, CalendarDays, NotebookPen,
  Printer, Mail, PencilRuler, Shirt, Trophy, Leaf, Grid3x3, Layers, Dumbbell, Sparkles,
};

/** Fixed accent palette, cycled by position — keeps the existing visual style without a `color` field always being set on every category. */
const ACCENT_COLORS = ['#6C3BFF', '#8F63FF', '#FF4FD8'];

/** Guaranteed non-empty, URL-safe slug for a category — uses the stored slug, or derives one from the name. */
function resolveSlug(cat) {
  const stored = typeof cat.slug === 'string' ? cat.slug.trim() : '';
  if (stored) return stored;
  return cat.name ? slugify(cat.name) : String(cat.id);
}

/** Map one backend Category doc to the storefront shape: resolved icon component, guaranteed slug, deterministic accent color, renamed tree-walking fields. */
function mapToStorefront(cat, index) {
  return {
    ...cat,
    parentId: cat.parentCategory || null,
    displayOrder: cat.sortOrder ?? 0,
    showOnHomepage: !!cat.isFeatured,
    slug: resolveSlug(cat),
    icon: ICON_MAP[cat.icon] || TagIcon,
    color: cat.color || ACCENT_COLORS[index % ACCENT_COLORS.length],
  };
}

/** All active categories, mapped for storefront use — the base list every other function here filters or shapes further. */
export function getStorefrontCategories() {
  return getCategoriesRaw()
    .filter((c) => c.isActive)
    .map(mapToStorefront);
}

/** Categories flagged for the header mega menu / mobile menu, as a nested tree (unlimited depth). */
export function getHeaderCategoryTree() {
  const categories = getStorefrontCategories().filter((c) => c.showInHeader);
  return getCategoryTree(categories);
}

/** Categories flagged for the homepage grid/pills, flattened in tree (parent-then-children) order. */
export function getHomepageCategories() {
  const categories = getStorefrontCategories();
  const tree = getCategoryTree(categories);
  return flattenCategories(tree)
    .filter((c) => c.showOnHomepage)
    .map(({ depth: _depth, ...c }) => c);
}

/** Full nested category tree (all active categories), e.g. for a Categories directory page. */
export function getCategoryTreeForStorefront() {
  return getCategoryTree(getStorefrontCategories());
}

/** Root (top-level) categories only. */
export function getRootStorefrontCategories() {
  return getRootCategories(getStorefrontCategories());
}

/** Direct children of a category id. */
export function getChildCategories(categoryId) {
  return getChildren(getStorefrontCategories(), categoryId);
}

/** A single category by slug, or null. */
export function getCategoryBySlug(slug) {
  return getStorefrontCategories().find((c) => c.slug === slug) || null;
}

/** A single category by id, or null (includes inactive categories — used internally for resolution, not for public listing). */
export function getCategoryById(categoryId) {
  const found = getCategoriesRaw().find((c) => String(c.id) === String(categoryId));
  return found ? mapToStorefront(found, 0) : null;
}

/** Ancestor chain (root → … → parent), for breadcrumbs. Does not include the category itself. */
export function getCategoryAncestors(categoryId) {
  return getAncestors(getStorefrontCategories(), categoryId);
}

/** Full breadcrumb trail including the category itself, root first. */
export function getCategoryBreadcrumbTrail(categoryId) {
  const category = getCategoryById(categoryId);
  if (!category) return [];
  return [...getCategoryAncestors(categoryId), category];
}

/** Case-insensitive name search across active categories — powers search suggestions and search results. */
export function searchCategories(query, limit = 10) {
  const needle = (query || '').trim().toLowerCase();
  if (!needle) return [];
  return getStorefrontCategories().filter((c) => c.name.toLowerCase().includes(needle)).slice(0, limit);
}

/** Resolve a categoryId to its display name — used by productRepository so products never store category names directly. */
export function resolveCategoryName(categoryId) {
  if (!categoryId) return null;
  const found = getCategoriesRaw().find((c) => String(c.id) === String(categoryId));
  return found ? found.name : null;
}

/** Resolve a categoryId to its slug — used by productRepository/product pages for category links. */
export function resolveCategorySlug(categoryId) {
  if (!categoryId) return null;
  const found = getCategoriesRaw().find((c) => String(c.id) === String(categoryId));
  return found ? resolveSlug(found) : null;
}
