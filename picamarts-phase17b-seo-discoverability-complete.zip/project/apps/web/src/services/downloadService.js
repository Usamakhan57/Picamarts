/**
 * downloadService.js — thin wrappers around the real backend's
 * /downloads endpoints (Phase 14.1 — Digital Product Delivery). See
 * apps/api/src/controllers/digitalDelivery.controller.js.
 */
import api from './apiClient';

/** The authenticated buyer's own digital deliveries ("My Downloads"). */
export const listMyDownloads = () => api.get('/downloads').then((res) => res.data.downloads);

/**
 * Redeems a signed, short-lived download URL for one file within a
 * purchased Download. Throws (403/400/404) if the buyer doesn't own
 * it, it's revoked, expired, or the download limit has been reached —
 * callers should catch and show `getErrorMessage(err)`.
 */
export const redeemDownload = (downloadId, fileId) =>
  api.get(`/downloads/${downloadId}/files/${fileId}`).then((res) => res.data);
