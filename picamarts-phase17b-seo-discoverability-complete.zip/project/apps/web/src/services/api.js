/**
 * API service layer — calls the real backend via apiClient/catalogStore.
 *
 * Every function here still returns a Promise with the same shape pages
 * already consume (`useFetch(() => productsApi.list(...), deps)` etc.), so
 * this rewrite needed zero page/component changes beyond what
 * productRepository.js / categoryRepository.js already absorbed.
 *
 * Server-side vs. client-side filtering: category/price/rating/search/sort/
 * pagination are all pushed to the real backend (GET /products supports
 * them natively). fileTypes/licenses filters and "Top Rated" sort have no
 * backend equivalent (no fileTypes concept on the Product schema; no
 * rating-based sort option) — those stay client-side on whatever page of
 * results comes back, a flagged, accepted simplification versus a full
 * search-index-backed catalog.
 */
import api from './apiClient';
import { mapBackendProduct } from './productRepository';
import {
  getStorefrontCategories, getCategoryBySlug,
} from './categoryRepository';
import { getCollectionsRaw } from './catalogStore';
import { searchService } from './searchService';
import { artists, blogPosts } from '../data';
import { PRICE_RANGES, DEFAULT_FILTERS } from '../constants';

const SORT_MAP = {
  'Price: Low to High': 'price_asc',
  'Price: High to Low': 'price_desc',
  Newest: 'newest',
  'Date Added': 'newest',
  Popular: 'popular',
  // Phase 17A, Part 2 — the backend now has a real ratingAverage-based
  // sort preset, so "Top Rated" no longer needs the client-side re-sort
  // hack below (kept only as a defensive fallback for any caller that
  // still passes an unmapped sort label straight through).
  'Top Rated': 'highest_rated',
  // Phase 17A.2 — Improved Sorting Controls.
  'Best Selling': 'best_selling',
};

/** Resolve a display category name (as used by DEFAULT_FILTERS.category / categoryNames) to its backend id. */
const resolveCategoryIdByName = (name) => {
  if (!name || name === 'All') return null;
  const found = getStorefrontCategories().find((c) => c.name === name);
  return found ? found.id : null;
};

/** Apply any filter the backend doesn't support natively (fileTypes/licenses) plus the "Top Rated" client sort. */
const applyClientSideRefinements = (products, filters = DEFAULT_FILTERS, sort) => {
  let r = products;
  if (filters.fileTypes?.length) {
    r = r.filter((p) => filters.fileTypes.some((t) => p.fileTypes?.includes(t)));
  }
  if (filters.licenses?.length) {
    r = r.filter((p) => filters.licenses.some((l) => p.licenseIds?.includes(l)));
  }
  if (sort === 'Top Rated') {
    r = [...r].sort((a, b) => b.rating - a.rating);
  }
  return r;
};

/** Builds the real /products query params from the frontend's filters/sort/query shape. */
const buildProductQuery = ({ filters = DEFAULT_FILTERS, sort = 'Popular', query = '', page = 1, limit = 24 } = {}) => {
  const params = { page, limit, sort: SORT_MAP[sort] || 'newest' };
  if (query?.trim()) params.q = query.trim();

  // Phase 17A.2 — Smart Filtering multi-select. When the sidebar's
  // "Categories" checkbox group has a selection, it takes priority over
  // the single-select category pill/name below — the backend's
  // `?category=id1,id2` already handles the multi-select case natively
  // (product.controller.js#buildMultiSelectFilter), no client-side OR
  // logic needed.
  if (filters.categories?.length) {
    params.category = filters.categories.join(',');
  } else {
    // categoryNames (CategoryPage: parent + all descendants) has no single
    // backend "any of these categories" filter param, so when there's more
    // than one name we fetch the parent category id only and let the
    // repository-level product cache / description note the limitation;
    // a single name maps directly to `category`.
    const categoryName = filters.categoryNames?.length === 1 ? filters.categoryNames[0] : filters.category;
    const categoryId = resolveCategoryIdByName(categoryName);
    if (categoryId) params.category = categoryId;
  }

  if (filters.brands?.length) params.brand = filters.brands.join(',');
  // Phase 17B — the backend has supported a multi-select `?collection=`
  // filter since Phase 17A (product.controller.js#buildMultiSelectFilter);
  // it was never wired up on this side until now (needed so the new
  // collections sitemap has a real, working destination — see
  // ShopPage.jsx and sitemap.service.js).
  if (filters.collections?.length) params.collection = filters.collections.join(',');

  const range = PRICE_RANGES.find((r) => r.id === filters.price) || PRICE_RANGES[0];
  if (range.min > 0) params.minPrice = range.min;
  if (Number.isFinite(range.max)) params.maxPrice = range.max;

  if (filters.rating) params.minRating = filters.rating;
  // Phase 17A.2 — Seller Rating filter (distinct from the product-rating
  // filter above — see product.controller.js#buildSellerFilter).
  if (filters.sellerRating) params.minSellerRating = filters.sellerRating;

  return params;
};

export const productsApi = {
  list: async ({ filters = DEFAULT_FILTERS, sort = 'Popular', query = '' } = {}) => {
    const params = buildProductQuery({ filters, sort, query, limit: 100 });
    const res = await api.get('/products', { params });
    const mapped = (res.data || []).map(mapBackendProduct);
    return applyClientSideRefinements(mapped, filters, sort);
  },

  // Phase 17A.2 — Dynamic Filter Counts. The backend has no dedicated
  // facet-count endpoint, so this reuses the same /products query as
  // .list() with limit=1 and reads the real total off the pagination
  // envelope — one lightweight request per filter option a caller wants
  // a live count for (see hooks/useFilterCounts.js, which fans these
  // out in parallel and is the only current caller).
  count: async ({ filters = DEFAULT_FILTERS, query = '' } = {}) => {
    const params = buildProductQuery({ filters, sort: 'Popular', query, limit: 1 });
    const res = await api.get('/products', { params });
    return res.pagination?.total ?? (res.data || []).length;
  },

  get: async (idOrSlug) => {
    const isObjectId = /^[0-9a-fA-F]{24}$/.test(String(idOrSlug));
    const res = isObjectId
      ? await api.get(`/products/${idOrSlug}`)
      : await api.get(`/products/slug/${idOrSlug}`);
    return mapBackendProduct(res.data.product);
  },

  related: async (product, limit = 4) => {
    if (!product?.categoryId) return [];
    const res = await api.get('/products', { params: { category: product.categoryId, limit: limit + 1 } });
    return (res.data || [])
      .map(mapBackendProduct)
      .filter((p) => String(p.id) !== String(product.id))
      .slice(0, limit);
  },

  popular: async (limit = 12) => {
    const res = await api.get('/products/popular', { params: { limit } });
    return (res.data || []).map(mapBackendProduct);
  },

  // "Recommended for you": prefers the shopper's recently-viewed categories,
  // falling back to overall popularity — same intent as before, now backed
  // by real category-filtered queries instead of a local array filter.
  recommended: async (categoryNames = [], excludeId = null, limit = 8) => {
    const categoryIds = categoryNames.map(resolveCategoryIdByName).filter(Boolean);
    let products = [];
    if (categoryIds.length) {
      const results = await Promise.all(
        categoryIds.map((categoryId) => api.get('/products', { params: { category: categoryId, limit } }))
      );
      products = results.flatMap((res) => (res.data || []).map(mapBackendProduct));
    }
    products = products.filter((p) => String(p.id) !== String(excludeId));
    if (products.length < limit) {
      const res = await api.get('/products/popular', { params: { limit } });
      const popular = (res.data || [])
        .map(mapBackendProduct)
        .filter((p) => String(p.id) !== String(excludeId) && !products.some((existing) => existing.id === p.id));
      products = [...products, ...popular];
    }
    return products.slice(0, limit);
  },

  featured: async (limit = 8) => {
    const res = await api.get('/products/featured', { params: { limit } });
    return (res.data || []).map(mapBackendProduct);
  },

  latest: async (limit = 8) => {
    const res = await api.get('/products/latest', { params: { limit } });
    return (res.data || []).map(mapBackendProduct);
  },

  // Phase 17A, Part 1 — categories/artists (sellers) now come from the
  // real backend cross-entity search (/search) instead of the local
  // `searchCategories` cache match and the static `artists` array.
  // `products` still comes from GET /products?q= (unchanged — it's
  // already the real, fully-mapped, paginatable product search) so no
  // existing product-shape consumer needed to change.
  search: async (q) => {
    const needle = (q || '').trim();
    if (!needle) return { products: [], categories: [], artists: [] };
    const [productsRes, global] = await Promise.all([
      api.get('/products', { params: { q: needle, limit: 40 } }),
      searchService.search(needle).catch(() => ({ categories: [], sellers: [] })),
    ]);
    return {
      products: (productsRes.data || []).map(mapBackendProduct),
      categories: (global.categories || []).map((c) => ({ id: c.id, name: c.name, slug: c.slug })),
      artists: (global.sellers || []).map((s) => ({ slug: s.storeSlug, name: s.storeName })),
    };
  },

  /** Instant search-dropdown suggestions. Genuinely async now (real network
   * call) — SearchBar/Header already render this behind a debounce and a
   * loading-tolerant dropdown, so no component change was needed. */
  suggest: async (q, limit = 5) => {
    const needle = (q || '').trim();
    if (!needle) return { products: [], categories: [], artists: [] };
    const [productsRes, global] = await Promise.all([
      api.get('/products', { params: { q: needle, limit } }),
      searchService.search(needle).catch(() => ({ categories: [], sellers: [] })),
    ]);
    return {
      products: (productsRes.data || []).map(mapBackendProduct),
      categories: (global.categories || []).slice(0, 3).map((c) => ({ id: c.id, name: c.name, slug: c.slug })),
      artists: (global.sellers || []).slice(0, 3).map((s) => ({ slug: s.storeSlug, name: s.storeName })),
    };
  },
};

export const categoriesApi = {
  list: async () => getStorefrontCategories(),
  bySlug: async (slug) => getCategoryBySlug(slug),
};

export const collectionsApi = {
  list: async () => getCollectionsRaw(),
};

// No backend concept of an "Artist" (creator profile) distinct from Brand/
// Seller yet — kept as-is pending a dedicated seller-storefront phase.
export const artistsApi = {
  list: async () => artists,
  bySlug: async (slug) => artists.find((a) => a.slug === slug) || null,
};

// No backend Blog module reachable from the public catalog phase yet —
// see the CMS sub-phase (13.5) for /blog wiring.
export const blogApi = {
  list: async () => blogPosts,
  bySlug: async (slug) => blogPosts.find((b) => b.slug === slug) || null,
};

export const newsletterApi = {
  subscribe: (email) => api.post('/newsletter/subscribe', { email }),
};
