/**
 * searchService.js — thin wrapper around Phase 17A's backend search
 * surface (/search, /search/suggestions, /search/history). Kept
 * separate from services/api.js's existing productsApi.search/suggest
 * (which stay product-centric) so callers that want the raw
 * cross-entity groups — or buyer search history — have a direct path
 * to it without going through the storefront product-shape mapping.
 */
import api from './apiClient';

export const searchService = {
  /** Cross-entity search: { products, categories, brands, collections, tags, sellers }. */
  search: async (q) => {
    const needle = (q || '').trim();
    if (!needle) return { products: [], categories: [], brands: [], collections: [], tags: [], sellers: [] };
    const res = await api.get('/search', { params: { q: needle } });
    return res.data;
  },

  /** Lightweight autocomplete list: [{ type, label, slug, id }]. */
  suggestions: async (q, limit) => {
    const needle = (q || '').trim();
    if (!needle) return [];
    const res = await api.get('/search/suggestions', { params: { q: needle, limit } });
    return res.data.suggestions || [];
  },

  /** Authenticated buyer only — throws (caller decides how to degrade) if not logged in. */
  getHistory: async () => {
    const res = await api.get('/search/history');
    return res.data.history;
  },

  removeHistoryEntry: async (id) => {
    const res = await api.delete(`/search/history/${id}`);
    return res.data.history;
  },

  clearHistory: async () => {
    const res = await api.delete('/search/history');
    return res.data.history;
  },
};

export default searchService;
