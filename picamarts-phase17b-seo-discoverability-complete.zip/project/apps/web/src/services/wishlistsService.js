/**
 * wishlistsService.js — thin wrappers around the real backend's plural
 * /wishlists endpoints (Phase 17A.2, Part 2 — Wishlist Enhancements:
 * multiple named wishlists, public/private + shareable link, moving an
 * item between wishlists, per-wishlist analytics).
 *
 * Deliberately separate from services/wishlistService.js (singular),
 * which continues to wrap the pre-existing `/wishlist` endpoint (the
 * buyer's one default wishlist) and is completely unchanged — see
 * apps/api/src/controllers/wishlists.controller.js's own doc comment
 * for the same singular/plural split on the backend.
 */
import api from './apiClient';

export const wishlistsService = {
  list: () => api.get('/wishlists').then((res) => res.data.wishlists),

  create: ({ name, description } = {}) =>
    api.post('/wishlists', { name, description }).then((res) => res.data.wishlist),

  getById: (id) => api.get(`/wishlists/${id}`).then((res) => res.data.wishlist),

  rename: (id, { name, description }) =>
    api.patch(`/wishlists/${id}`, { name, description }).then((res) => res.data.wishlist),

  setVisibility: (id, isPublic) =>
    api.patch(`/wishlists/${id}/visibility`, { isPublic }).then((res) => res.data.wishlist),

  remove: (id) => api.delete(`/wishlists/${id}`),

  /** Public — no auth required. Used by the storefront's shared-wishlist page. */
  getShared: (token) => api.get(`/wishlists/shared/${token}`).then((res) => res.data.wishlist),

  addItem: (id, productId) =>
    api.post(`/wishlists/${id}/items`, { productId }).then((res) => res.data.wishlist),

  removeItem: (id, productId) =>
    api.delete(`/wishlists/${id}/items/${productId}`).then((res) => res.data.wishlist),

  /** Moves one item from wishlist `id` into `toWishlistId` — returns both updated wishlists. */
  moveItem: (id, productId, toWishlistId) =>
    api.post(`/wishlists/${id}/move`, { productId, toWishlistId }).then((res) => res.data),

  getAnalytics: (id) => api.get(`/wishlists/${id}/analytics`).then((res) => res.data),
};

export default wishlistsService;
