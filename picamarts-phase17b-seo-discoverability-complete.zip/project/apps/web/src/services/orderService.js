/**
 * orderService.js — thin wrappers around the real backend's /orders
 * endpoints. See apps/api/src/validators/order.validator.js for the exact
 * address shape createOrder expects.
 */
import api from './apiClient';

/** shippingAddress: {fullName,line1,line2?,city,state?,postalCode,country,phone?}; billingAddress falls back to shippingAddress server-side when omitted. */
export const createOrder = ({ shippingAddress, billingAddress, notes }) =>
  api.post('/orders', { shippingAddress, billingAddress, notes }).then((res) => res.data.order);

export const listOrders = (params = {}) =>
  api.get('/orders', { params }).then((res) => ({ orders: res.data.orders, meta: res.meta }));

export const getOrderById = (orderId) => api.get(`/orders/${orderId}`).then((res) => res.data.order);

export const cancelOrder = (orderId) => api.patch(`/orders/${orderId}/cancel`).then((res) => res.data.order);

/** Seller/admin fulfillment status update — seller is further restricted server-side to their own orders + fulfillment-only statuses. */
export const updateOrderStatus = (orderId, status) =>
  api.patch(`/orders/${orderId}/status`, { status }).then((res) => res.data.order);

/**
 * Backend order → a flat summary shape for seller/admin order-list UIs.
 * Intentionally separate from (and not shared with) StoreContext.jsx's
 * own private mapOrder/mapOrderItem — this phase's brief explicitly
 * excludes StoreContext from changes, so this is a small, deliberate
 * duplication rather than exporting from there.
 */
export const mapOrderSummary = (order) => ({
  id: order.orderNumber,
  orderId: order.id,
  date: order.createdAt,
  total: order.grandTotal,
  rawStatus: order.status,
  paymentStatus: order.paymentStatus,
  // Phase 15C — admin Recent Orders widget needs a customer label but
  // Order.buyer is never populated with a name (and the Order module is
  // off-limits to modify). shippingAddress.fullName is a snapshot
  // already stored on every order at creation time, so this needs no
  // backend change at all.
  customerName: order.shippingAddress?.fullName || '',
  items: (order.items || []).map((item) => ({
    id: item.product,
    title: item.titleSnapshot,
    img: item.thumbnailSnapshot?.url || '',
    qty: item.quantity,
  })),
});
