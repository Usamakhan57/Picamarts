/**
 * sellerDownloadService.js — thin wrappers around the real backend's
 * seller/admin digital-delivery dashboard endpoints (Phase 14.1, Parts
 * 10-12). Buyer-facing "My Downloads" already has its own
 * services/downloadService.js — this is the seller/admin side.
 */
import api from './apiClient';

/** Per-product purchase/download/revocation counts for the acting seller (or platform-wide for an admin). */
export const getDeliveryStats = () => api.get('/downloads/stats').then((res) => res.data.stats);

/** Individual delivery records (license keys, download counts, status) for the acting seller's own products. */
export const listDeliveries = (params = {}) =>
  api.get('/downloads/deliveries', { params }).then((res) => ({ deliveries: res.data.deliveries, meta: res.meta }));

export const listDownloadLogs = (params = {}) =>
  api.get('/downloads/logs', { params }).then((res) => ({ logs: res.data.logs, meta: res.meta }));

export const revokeDownload = (downloadId, reason) =>
  api.patch(`/downloads/${downloadId}/revoke`, { reason }).then((res) => res.data.download);

/**
 * Admin/seller — best-effort lookup of digital deliveries for one
 * order (Phase 15C, Part 6's Order Detail page). GET /downloads/deliveries
 * has no `orderId` filter, so this scans a bounded, most-recent-first
 * page and matches client-side on the `order` id already present on
 * every delivery response — same accepted-tradeoff pattern as
 * paymentService.js#findPaymentForOrder.
 */
export const findDeliveriesForOrder = (orderId) =>
  listDeliveries({ limit: 100 }).then(({ deliveries }) => deliveries.filter((d) => d.order === orderId));
