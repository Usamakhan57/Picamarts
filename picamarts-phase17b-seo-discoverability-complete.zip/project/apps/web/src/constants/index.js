/**
 * Central constants — shared by filters, search, SEO, and the API service
 * layer. When the Node/Express backend goes live, only API_BASE_URL and
 * ENDPOINTS need to change.
 */

export const SITE = {
  name: 'PicaMarts',
  tagline: 'Premium Digital Art Marketplace',
  url: 'https://picamarts.com',
  description:
    'Discover premium SVGs, cliparts, wall art, planners, fonts and templates from verified creators. Clean licensing and instant downloads on PicaMarts.',
  twitter: '@picamarts',
};

/**
 * Backend base URL. Matches apps/api's mount path (config.apiPrefix + '/v1',
 * i.e. '/api/v1' by default — see apps/api/src/routes/index.js). In dev, the
 * relative '/api' path is proxied to the local API by vite.config.js; in
 * production set VITE_API_URL to the deployed API origin (e.g.
 * https://api.yourdomain.com/api/v1).
 */
export const API_BASE_URL = import.meta.env.VITE_API_URL || '/api/v1';

export const ENDPOINTS = {
  products: '/products',
  product: (id) => `/products/${id}`,
  categories: '/categories',
  categoryProducts: (slug) => `/categories/${slug}/products`,
  collections: '/collections',
  artists: '/artists',
  artist: (slug) => `/artists/${slug}`,
  blog: '/blog',
  blogPost: (slug) => `/blog/${slug}`,
  search: '/search',
  auth: { login: '/auth/login', register: '/auth/register' },
  cart: '/cart',
  orders: '/orders',
  newsletter: '/newsletter/subscribe',
};

export const SORT_OPTIONS = [
  'Popular',
  'Newest',
  'Date Added',
  'Price: Low to High',
  'Price: High to Low',
  'Top Rated',
  'Best Selling',
];

export const PRICE_RANGES = [
  { id: 'any', label: 'Any price', min: 0, max: Infinity },
  { id: 'under-10', label: 'Under $10', min: 0, max: 9.99 },
  { id: '10-15', label: '$10 – $15', min: 10, max: 15 },
  { id: 'over-15', label: 'Over $15', min: 15.01, max: Infinity },
];

export const RATING_FILTERS = [
  { id: 0, label: 'Any rating' },
  { id: 4.5, label: '4.5 & up' },
  { id: 4.8, label: '4.8 & up' },
];

// Phase 17A.2 — Storefront Filters. Seller-level rating (backend's
// `minSellerRating`, a review-weighted average across a seller's own
// published products — see product.controller.js#buildSellerFilter),
// distinct from RATING_FILTERS above which filters by PRODUCT rating.
export const SELLER_RATING_FILTERS = [
  { id: 0, label: 'Any seller rating' },
  { id: 4, label: '4.0 & up' },
  { id: 4.5, label: '4.5 & up' },
  { id: 4.8, label: '4.8 & up' },
];

export const FILE_TYPE_FILTERS = ['PNG', 'SVG', 'PDF', 'EPS', 'DXF', 'Canva Template', 'GoodNotes'];

export const LICENSE_FILTERS = [
  { id: 'personal', label: 'Personal' },
  { id: 'commercial', label: 'Commercial' },
  { id: 'extended', label: 'Extended' },
];

export const DEFAULT_FILTERS = {
  category: 'All',
  price: 'any',
  rating: 0,
  fileTypes: [],
  licenses: [],
  // Phase 17A.2 — Storefront Filters. `categories`/`brands` are
  // additive multi-select refinements (checkbox groups in the sidebar,
  // backend `?category=id1,id2` / `?brand=id1,id2`) layered on top of
  // the existing single-select `category` pill above — either or both
  // can be active at once. `sellerRating` maps to `?minSellerRating=`.
  categories: [],
  brands: [],
  // Phase 17B — SEO & Discoverability. Not exposed as a sidebar checkbox
  // group (no collection-picker UI exists yet), but readable via the
  // `?collection=<id>` URL param so the collections sitemap has a real
  // working destination — see ShopPage.jsx.
  collections: [],
  sellerRating: 0,
};

export const POPULAR_SEARCHES = ['Wall art', 'Clipart', 'Planner', 'PNG bundle', 'T-shirt design', 'Coloring pages'];

export const POPULAR_TAGS = ['printable', 'boho', 'watercolor', 'digital-planner', 'svg', 'commercial-use', 'wedding', 'minimalist'];

export const RECENT_SEARCHES_KEY = 'pm_recent_searches';
export const MAX_RECENT_SEARCHES = 6;

export const PAGE_SIZE = 8;
