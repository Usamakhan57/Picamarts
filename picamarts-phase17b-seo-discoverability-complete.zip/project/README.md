# PicaMarts

PicaMarts — a multi-vendor digital art marketplace (Etsy / Creative
Market / Envato style). This repository is the single, merged
monorepo containing both the production-ready frontend and backend.

```
picamarts/
├── apps/
│   ├── web/     # React (Vite) frontend — production-ready
│   └── api/     # Express + MongoDB backend — Phases 1–4 complete
├── docs/        # Project-level documentation (incl. merge notes)
├── package.json # Root workspace config
├── README.md
└── .gitignore
```

## Backend status (`apps/api`)

- ✅ Phase 1 — Foundation
- ✅ Phase 2 — Authentication
- ✅ Phase 3 — Marketplace Models
- ✅ Phase 4 — Admin Marketplace CRUD

See [`apps/api/README.md`](apps/api/README.md) for full backend
documentation (architecture, endpoints, environment variables).

## Frontend (`apps/web`)

Production-ready React app built with Vite, Tailwind, and Radix UI.
No changes were made to its UI or logic as part of this merge.

## Getting started

This repo uses npm workspaces, so a single `npm install` at the root
installs dependencies for both apps.

```bash
# 1. Install everything (root + apps/web + apps/api)
npm install

# 2. Configure the backend environment
cp apps/api/.env.example apps/api/.env
# then fill in real values (MongoDB URI, JWT secrets, SMTP, Cloudinary, ...)

# 3. Run both apps together
npm run dev
```

`npm run dev` starts the backend (`apps/api`, nodemon on port 5000 by
default) and the frontend (`apps/web`, Vite on port 3000) concurrently.

### Run apps individually

```bash
npm run dev:api      # backend only — http://localhost:5000
npm run dev:web       # frontend only — http://localhost:3000
```

### Other root scripts

```bash
npm run build         # builds apps/web for production
npm run start         # runs both apps in production mode
npm run lint          # lints both apps
npm run test          # runs the backend test suite (apps/api)
```

## API documentation

With the backend running, Swagger UI is available at:

```
http://localhost:5000/api/docs
```

(Disable via `SWAGGER_ENABLED=false` in `apps/api/.env`.)

## Environment

- The frontend's `VITE_API_URL` should point at the backend origin
  (e.g. `http://localhost:5000/api`) when the two are deployed
  separately.
- The backend's `CORS_ORIGINS` and `FRONTEND_URL` should point at the
  frontend origin (defaults already match local dev: port 3000).

## Notes on this merge

This repository was assembled by merging a complete, standalone
frontend project and a complete, standalone backend project into one
workspace. No business logic, UI, database models, authentication, or
tests were changed in the process — only workspace/tooling wiring and
documentation paths. See [`docs/MERGE_NOTES.md`](docs/MERGE_NOTES.md)
for the full record of what moved and what (minimally) changed.

Phase 5 and any further feature development are out of scope for this
merge.
