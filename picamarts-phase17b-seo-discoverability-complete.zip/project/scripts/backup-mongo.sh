#!/usr/bin/env bash
set -euo pipefail

# =====================================================================
# PicaMarts — MongoDB backup script (Phase 12, Part 11).
#
# Usage:
#   ./scripts/backup-mongo.sh
#   MONGODB_URI="mongodb://mongodb:27017/picamarts" ./scripts/backup-mongo.sh
#   BACKUP_DIR=/mnt/backups RETENTION_DAYS=14 ./scripts/backup-mongo.sh
#
# Requires the MongoDB Database Tools (`mongodump`) on PATH — already
# present in the official `mongo` Docker image, so this also runs as:
#   docker compose exec mongodb bash -c "$(cat scripts/backup-mongo.sh)"
#
# Produces a timestamped, gzip-compressed archive under BACKUP_DIR and
# deletes archives older than RETENTION_DAYS (default 7). Exits
# non-zero on any failure — wire this into cron/a scheduler and alert
# on a non-zero exit code.
# =====================================================================

MONGODB_URI="${MONGODB_URI:-mongodb://localhost:27017/picamarts}"
BACKUP_DIR="${BACKUP_DIR:-./backups}"
RETENTION_DAYS="${RETENTION_DAYS:-7}"
TIMESTAMP="$(date -u +%Y%m%dT%H%M%SZ)"
ARCHIVE_PATH="${BACKUP_DIR}/picamarts-${TIMESTAMP}.gz"

mkdir -p "${BACKUP_DIR}"

echo "→ Backing up ${MONGODB_URI} to ${ARCHIVE_PATH}"

if ! command -v mongodump >/dev/null 2>&1; then
  echo "✖ mongodump not found on PATH. Install the MongoDB Database Tools, or run this inside the mongodb container." >&2
  exit 1
fi

mongodump --uri="${MONGODB_URI}" --archive="${ARCHIVE_PATH}" --gzip

if [ ! -s "${ARCHIVE_PATH}" ]; then
  echo "✖ Backup archive is missing or empty — treating as a failed backup." >&2
  exit 1
fi

echo "✔ Backup complete: ${ARCHIVE_PATH} ($(du -h "${ARCHIVE_PATH}" | cut -f1))"

echo "→ Pruning backups older than ${RETENTION_DAYS} days in ${BACKUP_DIR}"
find "${BACKUP_DIR}" -name 'picamarts-*.gz' -type f -mtime "+${RETENTION_DAYS}" -print -delete

echo "✔ Done."
