#!/usr/bin/env bash
set -euo pipefail

# =====================================================================
# PicaMarts — MongoDB restore script (Phase 12, Part 11).
#
# Usage:
#   ./scripts/restore-mongo.sh ./backups/picamarts-20260101T030000Z.gz
#   MONGODB_URI="mongodb://mongodb:27017/picamarts" ./scripts/restore-mongo.sh <archive>
#
# ⚠ DESTRUCTIVE by default: --drop removes every existing collection in
# the target database before restoring, so the result exactly matches
# the backup. Requires typing the database name back to confirm,
# unless CONFIRM=yes is set (e.g. for a scripted/CI restore rehearsal
# against a throwaway database — never set CONFIRM=yes against
# production without a human having already confirmed out-of-band).
# =====================================================================

MONGODB_URI="${MONGODB_URI:-mongodb://localhost:27017/picamarts}"
ARCHIVE_PATH="${1:-}"

if [ -z "${ARCHIVE_PATH}" ]; then
  echo "Usage: $0 <path-to-backup-archive.gz>" >&2
  exit 1
fi

if [ ! -f "${ARCHIVE_PATH}" ]; then
  echo "✖ Archive not found: ${ARCHIVE_PATH}" >&2
  exit 1
fi

if ! command -v mongorestore >/dev/null 2>&1; then
  echo "✖ mongorestore not found on PATH. Install the MongoDB Database Tools, or run this inside the mongodb container." >&2
  exit 1
fi

DB_NAME="$(node -e "console.log(new URL(process.env.MONGODB_URI.replace('mongodb://','http://')).pathname.replace('/',''))" 2>/dev/null || echo "picamarts")"

echo "⚠  This will DROP every existing collection in database '${DB_NAME}' at ${MONGODB_URI} and restore from:"
echo "   ${ARCHIVE_PATH}"

if [ "${CONFIRM:-}" != "yes" ]; then
  read -r -p "Type the database name (${DB_NAME}) to confirm: " CONFIRMATION
  if [ "${CONFIRMATION}" != "${DB_NAME}" ]; then
    echo "✖ Confirmation did not match. Aborting — nothing was restored." >&2
    exit 1
  fi
fi

echo "→ Restoring ${ARCHIVE_PATH} into ${MONGODB_URI} (--drop)"
mongorestore --uri="${MONGODB_URI}" --archive="${ARCHIVE_PATH}" --gzip --drop

echo "✔ Restore complete."
